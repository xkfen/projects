#!/usr/bin/env bash


root=`pwd`

echo "========== 开始初始化 approval db ============ env : " $1
cd approval && ./init_db.sh $1

echo " "

echo "========== 开始初始化 rule_data_manager db ============ env : " $1
cd ${root}/rule_data_manager && ./init_db.sh $1
