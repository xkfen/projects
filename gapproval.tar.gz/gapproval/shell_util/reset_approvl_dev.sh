#!/usr/bin/env bash


cd /home/devk8s/workspace/qiyuan_deploy

git pull

cd new_dev

./reset_approval.sh
