#!/usr/bin/env bash

########################################
#                                      #
#      这是构建docker镜像的base脚本       #
#                                      #
########################################

env=$1
if [ ! ${env} ];then
    echo 'env不能为空  dev、preprod、prod'
    exit 2
fi

project_base_path=`pwd`
if [ `expr index "$project_base_path" /go/src/gapproval` == 0 ];then
    exit 2
fi

projectName=$2
case ${projectName} in
    [Aa]pi* )
        echo 'only更新 api gw docker.....'
        cd ${project_base_path}
        cd apigw/docker
        ./mk_image.sh ${env} 1
        ;;
    [Aa]pp* )
        echo 'only更新 approval docker.....'
        cd ${project_base_path}
        cd approval/docker
        ./mk_image.sh ${env} 1
        ;;
    [Tt]* )
        echo 'only更新 timer docker.....'
        cd ${project_base_path}
        cd timer/docker
        ./mk_image.sh ${env} 1
        ;;
    [Ii]* )
        echo 'only更新 interview docker.....'
        cd ${project_base_path}
        cd interview/docker
        ./mk_image.sh ${env} 1
        ;;
    [Rr]ule* )
        echo 'only更新 rule_data_manager docker.....'
        cd ${project_base_path}
        cd rule_data_manager/docker
        ./mk_image.sh ${env} 1
        ;;
    * )
        echo '更新所有服务 docker.....'
        cd ${project_base_path}
        cd apigw/docker
        ./mk_image.sh ${env} 1

        cd ${project_base_path}
        cd approval/docker
        ./mk_image.sh ${env} 1

        cd ${project_base_path}
        cd timer/docker
        ./mk_image.sh ${env} 1

        cd ${project_base_path}
        cd interview/docker
        ./mk_image.sh ${env} 1

        cd ${project_base_path}
        cd rule_data_manager/docker
        ./mk_image.sh ${env} 1
        ;;
esac;
