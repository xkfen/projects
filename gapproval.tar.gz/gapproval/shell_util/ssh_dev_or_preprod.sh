#!/usr/bin/env bash


ssh $1@$2 -C /bin/bash < $3