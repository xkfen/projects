package main

import (
	"gapproval/common/gw"
	"gapproval/approval/grpc/server"
	"gcoresys/common/util"
	"gopkg.in/gin-gonic/gin.v1"
	"gcoresys/common/logger"
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"errors"
	"time"
	"flag"
)

func main() {
	var (
		env = flag.String("env", "dev", "运行环境配置")
	)
	logger.InitLogger(logger.LvlDebug, nil)
	// 初始化数据库
	logger.Info("初始化数据库" + *env)
	//config.GetApprovalDbConfig(*env)
	r := gin.Default()
	if *env == "prod" {
		gin.SetMode(gin.ReleaseMode) //ReleaseMode
	} else {
		gin.SetMode(gin.ReleaseMode) //全局设置环境，此为开发环境，线上环境为gin.ReleaseMode
	}
	v1 := r.Group("/api/v1")
	{
		v1.POST("/approval", NewApprovalOrderHandler)
	}
	r.Run(":9009")
}


//创建审批单
func NewApprovalOrderHandler(c *gin.Context) {
	var newApprovalOrderReq server.NewApprovalOrderReq
	if c.BindJSON(&newApprovalOrderReq) == nil && newApprovalOrderReq.ApprovalOrder != nil {
		newApprovalOrderReq.ApprovalOrder.AllInfo = util.StringifyJson(newApprovalOrderReq.AllInfo)
		newApprovalOrderReq.ApprovalOrder.OrderInfo = util.StringifyJson(newApprovalOrderReq.OrderInfo)

		err := NewApprovalOrder(newApprovalOrderReq.ApprovalOrder)
		if err != nil {
			gw.RenderError(c, err.Error())
		} else {
			gw.RenderSuccess(c, `{"success": true, "info":"创建成功"}`)
		}
	} else {
		gw.RenderError(c, "参数错误,请检查参数是否正确")
	}
}

// 创建审批单
func NewApprovalOrder(order *model.ApprovalOrder) (err error) {
	if err = IsVaildApprovalOrder(order); err != nil {
		return
	}
	// 开启事物
	//tx := config.GetDb().Begin()
	//tx := config.GetTargetDb().Begin()
	tx := config.GetProdDb().Begin()
	defer util.ClearTransaction(tx)
	// 审批记录
	if err1 := tx.Model(&model.ApprovalLog{}).Create(&model.ApprovalLog{ApprovalJinjianId: order.JinjianId,
		ApprovalName: order.JinjianUserName, ApprovalStatus: "用户完成进件", ApprovalType: "cs"}).Error; err1 != nil {
		logger.Info("ApprovalLog记录出错 ", err1.Error())
	}
	// 设置提交时间  中介和进件系统需要的字段
	nowTime := time.Now()
	order.CommitTime = &nowTime
	if err = tx.Model(order).Create(order).Error; err != nil {
		logger.Error("============创建审批单出错", "err", err.Error())
		tx.Rollback()
		return
	}
	tx.Commit()
	return
}


func  IsVaildApprovalOrder(a *model.ApprovalOrder) (err error) {
	switch {
	case a.JinjianId == "":
		err = errors.New("进件id不能为空")
	//case !a.CheckJinjianIDExist() :
	//	err = errors.New("进件id已存在")
	case a.LoanAmount <= 0:
		err = errors.New("贷款金额必须大于0")
	case a.AgencyEmployee == "":
		err = errors.New("业务员不能为空")
	case a.AgencyName == "":
		err = errors.New("中介机构不能为空")
	case a.LoanTerm <= 0:
		err = errors.New("贷款期数必须大于0")
	case a.ShowId == "":
		err = errors.New("前端显示进件id不能为空")
	case a.AllInfo == "":
		err = errors.New("进件allInfo信息不能为空")
	case a.OrderInfo == "":
		err = errors.New("进件order信息不能为空")
	case a.UserIdNum == "":
		err = errors.New("用户身份证号不能为空")
	case a.ChannelManager == "":
		//err = errors.New("进件渠道经理不能为空")
	case a.ProductId == "":
		//err = errors.New("产品id不能为空")
	case a.ProductName == "":
		//err = errors.New("产品名不能为空")
	}
	return
}