package main

import (
	"gcoresys/common/logger"
	"gapproval/approval/model"
	accModel "gcoresys/accounting/model"
	"gapproval/approval/db/config"
	"flag"
	//"gcoresys/common/util"
	"fmt"
	"time"
	"gcoresys/common/util"
)

func main() {
	var (
		env = flag.String("env", "dev", "运行环境配置")
	)
	logger.InitLogger(logger.LvlDebug, nil)
	// 初始化数据库
	logger.Info("初始化数据库" + *env)
	//config.GetApprovalDbConfig(*env)
	//selectRstDB("18688735562", "吴继成")
	migrate()
	migrateCoreSys()
}

func migrate() {
	// 开始数据割接
	var aoList []model.ApprovalOrder
	if err := config.GetProdDb().Model(aoList).Find(&aoList).Error; err != nil {
		panic(err.Error())
	}
	if len(aoList) == 0 {
		panic("数组长度为0, 请检查 ")
	}
	for _, ao := range aoList {
		status, comment, commitAt, finishAt := selectRstDB(ao.JinjianUserId, ao.JinjianUserName)
		if status == "y" || status == "n" {
			aoProd90 := selectProd90DB(ao.JinjianUserId, ao.JinjianUserName)
			ao.FirstTrailId = aoProd90.FirstTrailId
			ao.FirstTrailName = aoProd90.FirstTrailName
			ao.ReTrailId = "lilinhai"
			ao.ReTrailName = "李林海"
			ao.CustomServiceId = "dbmigrate"
			ao.CustomServiceName = "融数通割接数据割接"
			ao.CustomServiceStatus = "融数通割接数据"
			// 创建初审抢单记录
			if err1 := config.GetProdDb().Model(&model.ApprovalLog{}).Create(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId,
				ApprovalName: ao.FirstTrailName, ApprovalStatus: "初审抢单", ApprovalType: "cs"}).Error; err1 != nil {
				logger.Info("ApprovalLog记录出错 ", err1.Error())
			}
			// 创建初审结论记录
			var csResult model.ApprovalCsResult
			config.GetTargetDb().Model(csResult).Where("approval_id = ? ", aoProd90.ID).First(&csResult)
			csResult.ID = 0
			csResult.ApprovalId = ao.ID
			if csResult.CsName == "蔡宏轩" {
				csResult.CsName = "汪扬帆"
			}
			if err := config.GetProdDb().Model(csResult).Create(&csResult).Error; err != nil {
				panic(err.Error())
			}
			// 终审抢单
			if err1 := config.GetProdDb().Model(&model.ApprovalLog{}).Create(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId,
				ApprovalName: ao.ReTrailName, ApprovalStatus: "终审抢单", ApprovalType: "zs"}).Error; err1 != nil {
				logger.Info("ApprovalLog记录出错 ", err1.Error())
			}

			layout := time.RFC3339
			tmpTime, err := time.Parse(layout, commitAt)
			if err != nil {
				panic(err.Error())
			}
			ao.CommitTime = &tmpTime
			ao.ApprovalStartTime = &tmpTime
			switch status {
			case "y":
				if ao.JinjianUserName == "杨科" {
					ao.FirstTrailStatus = model.ApprovalStatusFirstTrailRefuse
					ao.ReTrailStatus = model.ApprovalStatusReTrailRefuse
					ao.ReTrailStatusDes = comment
					ao.AgencyStatus = model.AgencyStatusRefuse
					tmpTime, err := time.Parse(layout, finishAt)
					if err != nil {
						panic(err.Error())
					}
					ao.ApprovalRefuseTime = &tmpTime
				} else {
					ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
					ao.ReTrailStatus = model.ApprovalStatusReTrailPass
					ao.ReTrailStatusDes = comment
					ao.AgencyStatus = model.AgencyStatusPass
					tmpTime, err := time.Parse(layout, finishAt)
					if err != nil {
						panic(err.Error())
					}
					ao.ApprovalPassTime = &tmpTime
				}
			case "n":
				if ao.JinjianUserName == "梁兴" {
					ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
					ao.ReTrailStatus = model.ApprovalStatusReTrailPass
					ao.ReTrailStatusDes = comment
					ao.AgencyStatus = model.AgencyStatusPass
					tmpTime, err := time.Parse(layout, finishAt)
					if err != nil {
						panic(err.Error())
					}
					ao.ApprovalPassTime = &tmpTime
				} else {
					ao.FirstTrailStatus = model.ApprovalStatusFirstTrailRefuse
					ao.ReTrailStatus = model.ApprovalStatusReTrailRefuse
					ao.ReTrailStatusDes = comment
					ao.AgencyStatus = model.AgencyStatusRefuse
					tmpTime, err := time.Parse(layout, finishAt)
					if err != nil {
						panic(err.Error())
					}
					ao.ApprovalRefuseTime = &tmpTime
				}
			}
			if aoProd90.FirstTrailStatusDes != "" {
				ao.FirstTrailStatusDes = aoProd90.FirstTrailStatusDes
			} else {
				ao.FirstTrailStatusDes = comment
			}
			// 创建初审操作记录
			if err1 := config.GetProdDb().Model(&model.ApprovalLog{}).Create(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId,
				ApprovalName: ao.FirstTrailName, ApprovalStatus: ao.FirstTrailStatus, ApprovalType: "cs", ApprovalDesc: ao.FirstTrailStatusDes}).Error; err1 != nil {
				logger.Info("ApprovalLog记录出错 ", err1.Error())
			}
			// 创建终审操作记录
			if err1 := config.GetProdDb().Model(&model.ApprovalLog{}).Create(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId,
				ApprovalName: ao.ReTrailName, ApprovalStatus: ao.ReTrailStatus, ApprovalType: "zs", ApprovalDesc: ao.ReTrailStatusDes}).Error; err1 != nil {
				logger.Info("ApprovalLog记录出错 ", err1.Error())
			}
			// 量化评分和等级
			ao.QuantizationPoint = aoProd90.QuantizationPoint
			if ao.QuantizationPoint != 0 {
				switch {
				case ao.QuantizationPoint < 439:
					ao.QuantizationLevel = 1
				case ao.QuantizationPoint <= 449 && ao.QuantizationPoint >= 440:
					ao.QuantizationLevel = 2
				case ao.QuantizationPoint <= 479 && ao.QuantizationPoint >= 450:
					ao.QuantizationLevel = 3
				case ao.QuantizationPoint <= 519 && ao.QuantizationPoint >= 480:
					ao.QuantizationLevel = 4
				case ao.QuantizationPoint >= 520:
					ao.QuantizationLevel = 5
				}
			}
			// 更新数据
			if err := config.GetProdDb().Model(ao).Updates(ao).Error; err != nil {
				panic(err.Error())
			}
		}
	}
}

// 查询prod90上的数据
func selectProd90DB(jinjian_user_id, jinjian_user_name string) (model.ApprovalOrder) {
	var order model.ApprovalOrder
	if err := config.GetTargetDb().Model(order).Where("jinjian_user_id = ? AND jinjian_user_name = ? ",
		jinjian_user_id, jinjian_user_name).First(&order).Error; err != nil {
		panic(err.Error())
	}

	if order.FirstTrailName == "蔡宏轩" || order.FirstTrailId == "caihongxuan" {
		order.FirstTrailId = "wangyangfan"
		order.FirstTrailName = "汪扬帆"
	}

	return order
}

// 查询融数通上的数据
func selectRstDB(jinjian_user_id, jinjian_user_name string) (status, comment string, commitAt string, finishAt string) {
	row := config.GetRstDb().Table("apply").Where("create_by_id in (SELECT id FROM user WHERE name = ? AND phone_no = ?)", jinjian_user_name, jinjian_user_id).Select("status, comment, last_commit_at, finish_time").Row()
	row.Scan(&status, &comment, &commitAt, &finishAt)
	fmt.Println(status)
	fmt.Println(comment)
	fmt.Println(commitAt)
	fmt.Println(finishAt)
	return
}

const jsonStr = `[{"id_num":"230107197709160410","account_id":1,"id":1,"created_at":"2017-08-25T17:50:01.601561882+08:00","updated_at":"2017-08-25T17:50:01.601561882+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"230107197709160410","user_name":"韩东","cellphone":"18603001616","loan_bind_cellphone":"","loan_bank_card_num":"6214867864001616","loan_bank_name":"招商银行","repay_bank_card_num":"6214867864001616","repay_bank_name":"招商银行","repay_bind_cellphone":"18603001616","product_name":"qy_001","product_id":"qy_001","loan_amount":5000000,"loan_year_rate":10,"platform_year_rate":14,"total_year_rate":24,"platform_service_rate":3,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-05-31T00:00:00+08:00","first_repay_at":"2017-06-09T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170527004","user_id":1,"check_status":"uncheck","status":"loaned"},{"id_num":"441425196503294653","account_id":3,"id":3,"created_at":"2017-08-25T17:50:01.809699077+08:00","updated_at":"2017-08-25T17:50:01.809699077+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"441425196503294653","user_name":"高缄","cellphone":"13410501488","loan_bind_cellphone":"","loan_bank_card_num":"6214857807145422","loan_bank_name":"招商银行","repay_bank_card_num":"6214857807145422","repay_bank_name":"招商银行","repay_bind_cellphone":"13410501488","product_name":"qy_001","product_id":"qy_001","loan_amount":12000000,"loan_year_rate":10,"platform_year_rate":18,"total_year_rate":28,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-07-14T00:00:00+08:00","first_repay_at":"2017-08-11T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H-qy20170712002","user_id":3,"check_status":"uncheck","status":"loaned"},{"id_num":"445221199101116572","account_id":5,"id":5,"created_at":"2017-08-25T17:50:02.025196004+08:00","updated_at":"2017-08-25T17:50:02.025196004+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"445221199101116572","user_name":"史晓帆","cellphone":"15989520822","loan_bind_cellphone":"","loan_bank_card_num":"6214857812459792 ","loan_bank_name":"招商银行","repay_bank_card_num":"6214857812459792","repay_bank_name":"招商银行","repay_bind_cellphone":"15989520822","product_name":"qy_001","product_id":"qy_001","loan_amount":3000000,"loan_year_rate":10,"platform_year_rate":18,"total_year_rate":28,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-07-03T00:00:00+08:00","first_repay_at":"2017-07-15T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170629007","user_id":5,"check_status":"uncheck","status":"loaned"},{"id_num":"440306197408101242","account_id":7,"id":7,"created_at":"2017-08-25T17:50:02.259222795+08:00","updated_at":"2017-08-25T17:50:02.259222795+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"440306197408101242","user_name":"唐小慧","cellphone":"13480859668","loan_bind_cellphone":"","loan_bank_card_num":"6214856554791511","loan_bank_name":"招商银行","repay_bank_card_num":"6214856554791511","repay_bank_name":"招商银行","repay_bind_cellphone":"13480859668","product_name":"qy_001","product_id":"qy_001","loan_amount":10000000,"loan_year_rate":10,"platform_year_rate":18,"total_year_rate":28,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-07-26T00:00:00+08:00","first_repay_at":"2017-08-12T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H-qy20170719001","user_id":7,"check_status":"uncheck","status":"loaned"},{"id_num":"350521197004305057","account_id":9,"id":9,"created_at":"2017-08-25T17:50:02.461372412+08:00","updated_at":"2017-08-25T17:50:02.461372412+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"350521197004305057","user_name":"张志明","cellphone":"13713027827","loan_bind_cellphone":"","loan_bank_card_num":"6230580000037703472 ","loan_bank_name":"平安银行","repay_bank_card_num":"6230580000037703472","repay_bank_name":"平安银行","repay_bind_cellphone":"13713027827","product_name":"qy_001","product_id":"qy_001","loan_amount":8000000,"loan_year_rate":10,"platform_year_rate":18,"total_year_rate":28,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-06-30T00:00:00+08:00","first_repay_at":"2017-07-23T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170629003","user_id":9,"check_status":"uncheck","status":"loaned"},{"id_num":"441621197502063044","account_id":11,"id":11,"created_at":"2017-08-25T17:50:02.639667022+08:00","updated_at":"2017-08-25T17:50:02.639667022+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"441621197502063044","user_name":"张志芳","cellphone":"13632663886","loan_bind_cellphone":"","loan_bank_card_num":"6230580000132526133 ","loan_bank_name":"平安银行","repay_bank_card_num":"6230580000132526133","repay_bank_name":"平安银行","repay_bind_cellphone":"13632663886","product_name":"qy_001","product_id":"qy_001","loan_amount":15000000,"loan_year_rate":10,"platform_year_rate":18,"total_year_rate":28,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-06-29T00:00:00+08:00","first_repay_at":"2017-07-15T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170627002","user_id":11,"check_status":"uncheck","status":"loaned"},{"id_num":"370602197911082627","account_id":13,"id":13,"created_at":"2017-08-25T17:50:02.818062134+08:00","updated_at":"2017-08-25T17:50:02.818062134+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"370602197911082627","user_name":"张艳艳","cellphone":"13534250231","loan_bind_cellphone":"","loan_bank_card_num":"6222024000039621327","loan_bank_name":"工商银行","repay_bank_card_num":"6222024000039621327","repay_bank_name":"工商银行","repay_bind_cellphone":"13534250231","product_name":"qy_001","product_id":"qy_001","loan_amount":10000000,"loan_year_rate":10,"platform_year_rate":18,"total_year_rate":28,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-07-12T00:00:00+08:00","first_repay_at":"2017-08-01T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170710001","user_id":13,"check_status":"uncheck","status":"loaned"},{"id_num":"430403196808240516","account_id":15,"id":15,"created_at":"2017-08-25T17:50:03.04546019+08:00","updated_at":"2017-08-25T17:50:03.04546019+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"430403196808240516","user_name":"朱章春","cellphone":"13802264866","loan_bind_cellphone":"","loan_bank_card_num":"6230580000130580637 ","loan_bank_name":"平安银行","repay_bank_card_num":"6230580000130580637","repay_bank_name":"平安银行","repay_bind_cellphone":"13802264866","product_name":"qy_001","product_id":"qy_001","loan_amount":20000000,"loan_year_rate":10,"platform_year_rate":16,"total_year_rate":26,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-07-05T00:00:00+08:00","first_repay_at":"2017-07-05T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170630002","user_id":15,"check_status":"uncheck","status":"loaned"},{"id_num":"411328198712010685","account_id":17,"id":17,"created_at":"2017-08-25T17:50:03.215898107+08:00","updated_at":"2017-08-25T17:50:03.215898107+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"411328198712010685","user_name":"李帅","cellphone":"13728782672","loan_bind_cellphone":"","loan_bank_card_num":"6226097550789136 ","loan_bank_name":"招商银行","repay_bank_card_num":"6226097550789136","repay_bank_name":"招商银行","repay_bind_cellphone":"13728782672","product_name":"qy_001","product_id":"qy_001","loan_amount":10000000,"loan_year_rate":10,"platform_year_rate":16,"total_year_rate":26,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-07-03T00:00:00+08:00","first_repay_at":"2017-07-16T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170630003","user_id":17,"check_status":"uncheck","status":"loaned"},{"id_num":"132521196909100028","account_id":19,"id":19,"created_at":"2017-08-25T17:50:03.404208072+08:00","updated_at":"2017-08-25T17:50:03.404208072+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"132521196909100028","user_name":"杜万梅","cellphone":"13824368469","loan_bind_cellphone":"","loan_bank_card_num":"6222980001331588 ","loan_bank_name":"平安银行","repay_bank_card_num":"6222980001331588","repay_bank_name":"平安银行","repay_bind_cellphone":"13824368469","product_name":"qy_001","product_id":"qy_001","loan_amount":6000000,"loan_year_rate":10,"platform_year_rate":14,"total_year_rate":24,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-06-20T00:00:00+08:00","first_repay_at":"2017-07-11T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170616001","user_id":19,"check_status":"uncheck","status":"loaned"},{"id_num":"360123198401212214","account_id":21,"id":21,"created_at":"2017-08-25T17:50:03.630613233+08:00","updated_at":"2017-08-25T17:50:03.630613233+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"360123198401212214","user_name":"杨璆","cellphone":"15019403515","loan_bind_cellphone":"","loan_bank_card_num":"6217007200027936742","loan_bank_name":"建设银行","repay_bank_card_num":"6217007200027936742","repay_bank_name":"建设银行","repay_bind_cellphone":"15019403515","product_name":"qy_001","product_id":"qy_001","loan_amount":15000000,"loan_year_rate":10,"platform_year_rate":14,"total_year_rate":24,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-06-12T00:00:00+08:00","first_repay_at":"2017-06-13T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170609001","user_id":21,"check_status":"uncheck","status":"loaned"},{"id_num":"450121197210106616","account_id":23,"id":23,"created_at":"2017-08-25T17:50:03.850304015+08:00","updated_at":"2017-08-25T17:50:03.850304015+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"450121197210106616","user_name":"梁兴","cellphone":"15989895929","loan_bind_cellphone":"","loan_bank_card_num":"6230580000068389860 ","loan_bank_name":"平安银行","repay_bank_card_num":"6230580000068389860","repay_bank_name":"平安银行","repay_bind_cellphone":"15989895929","product_name":"qy_001","product_id":"qy_001","loan_amount":6000000,"loan_year_rate":10,"platform_year_rate":18,"total_year_rate":28,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-06-22T00:00:00+08:00","first_repay_at":"2017-07-17T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170619003","user_id":23,"check_status":"uncheck","status":"loaned"},{"id_num":"420603197409131527","account_id":25,"id":25,"created_at":"2017-08-25T17:50:04.079146981+08:00","updated_at":"2017-08-25T17:50:04.079146981+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"420603197409131527","user_name":"王静","cellphone":"13510466908","loan_bind_cellphone":"","loan_bank_card_num":"6216262000005367767 ","loan_bank_name":"平安银行","repay_bank_card_num":"6216262000005367767","repay_bank_name":"平安银行","repay_bind_cellphone":"13510466908","product_name":"qy_001","product_id":"qy_001","loan_amount":6000000,"loan_year_rate":10,"platform_year_rate":18,"total_year_rate":28,"platform_service_rate":0,"loan_term":12,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-07-06T00:00:00+08:00","first_repay_at":"2017-07-14T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170704003","user_id":25,"check_status":"uncheck","status":"loaned"},{"id_num":"42050219771212132X ","account_id":27,"id":27,"created_at":"2017-08-25T17:50:04.213410226+08:00","updated_at":"2017-08-25T17:50:04.213410226+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"42050219771212132X ","user_name":"罗亚静","cellphone":"18603077300","loan_bind_cellphone":"","loan_bank_card_num":"4340617200141564","loan_bank_name":"建设银行","repay_bank_card_num":"4340617200141564 ","repay_bank_name":"建设银行","repay_bind_cellphone":"18603077300","product_name":"qy_001","product_id":"qy_001","loan_amount":10000000,"loan_year_rate":10,"platform_year_rate":14,"total_year_rate":24,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-06-22T00:00:00+08:00","first_repay_at":"2017-07-20T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170620003","user_id":27,"check_status":"uncheck","status":"loaned"},{"id_num":"420400196904151037","account_id":29,"id":29,"created_at":"2017-08-25T17:50:04.418568676+08:00","updated_at":"2017-08-25T17:50:04.418568676+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"420400196904151037","user_name":"袁先斌","cellphone":"13682670707","loan_bind_cellphone":"","loan_bank_card_num":"622909336798604519 ","loan_bank_name":"兴业银行 ","repay_bank_card_num":"622909336798604519","repay_bank_name":"兴业银行 ","repay_bind_cellphone":"13682670707","product_name":"qy_001","product_id":"qy_001","loan_amount":10000000,"loan_year_rate":10,"platform_year_rate":14,"total_year_rate":24,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-06-14T00:00:00+08:00","first_repay_at":"2017-07-12T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170612002","user_id":29,"check_status":"uncheck","status":"loaned"},{"id_num":"420106196510310877","account_id":31,"id":31,"created_at":"2017-08-25T17:50:04.632151078+08:00","updated_at":"2017-08-25T17:50:04.632151078+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"420106196510310877","user_name":"许振","cellphone":"13902933159","loan_bind_cellphone":"","loan_bank_card_num":"6230580000090187399","loan_bank_name":"平安银行","repay_bank_card_num":"6230580000090187399","repay_bank_name":"平安银行","repay_bind_cellphone":"13902933159","product_name":"qy_001","product_id":"qy_001","loan_amount":15000000,"loan_year_rate":10,"platform_year_rate":16,"total_year_rate":26,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-07-07T00:00:00+08:00","first_repay_at":"2017-07-10T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170704009","user_id":31,"check_status":"uncheck","status":"loaned"},{"id_num":"441522198306203615","account_id":33,"id":33,"created_at":"2017-08-25T17:50:04.80747512+08:00","updated_at":"2017-08-25T17:50:04.80747512+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"441522198306203615","user_name":"谢招好","cellphone":"13652306300","loan_bind_cellphone":"","loan_bank_card_num":"6230584000003157501","loan_bank_name":"平安银行","repay_bank_card_num":"6230584000003157501","repay_bank_name":"平安银行","repay_bind_cellphone":"13652306300","product_name":"qy_001","product_id":"qy_001","loan_amount":3000000,"loan_year_rate":10,"platform_year_rate":14,"total_year_rate":24,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-06-23T00:00:00+08:00","first_repay_at":"2017-07-12T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170620004","user_id":33,"check_status":"uncheck","status":"loaned"},{"id_num":"430124197810248699","account_id":35,"id":35,"created_at":"2017-08-25T17:50:05.028450139+08:00","updated_at":"2017-08-25T17:50:05.028450139+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"430124197810248699","user_name":"谭军良","cellphone":"13927407756","loan_bind_cellphone":"","loan_bank_card_num":"6230580000032535416 ","loan_bank_name":"平安银行","repay_bank_card_num":"6230580000032535416","repay_bank_name":"平安银行","repay_bind_cellphone":"13927407756","product_name":"qy_001","product_id":"qy_001","loan_amount":6000000,"loan_year_rate":10,"platform_year_rate":18,"total_year_rate":28,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-06-29T00:00:00+08:00","first_repay_at":"2017-07-10T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170628002","user_id":35,"check_status":"uncheck","status":"loaned"},{"id_num":"441621197405252732","account_id":37,"id":37,"created_at":"2017-08-25T17:50:05.205638078+08:00","updated_at":"2017-08-25T17:50:05.205638078+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"441621197405252732","user_name":"郑茂权","cellphone":"13632930863","loan_bind_cellphone":"","loan_bank_card_num":"6013822000630823329","loan_bank_name":"中国银行","repay_bank_card_num":"6013822000630823329","repay_bank_name":"中国银行","repay_bind_cellphone":"13632930863","product_name":"qy_001","product_id":"qy_001","loan_amount":10000000,"loan_year_rate":10,"platform_year_rate":14,"total_year_rate":24,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-06-21T00:00:00+08:00","first_repay_at":"2017-06-21T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170616002","user_id":37,"check_status":"uncheck","status":"loaned"},{"id_num":"441621199008176464","account_id":39,"id":39,"created_at":"2017-08-25T17:50:05.438059225+08:00","updated_at":"2017-08-25T17:50:05.438059225+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"441621199008176464","user_name":"钟小莲","cellphone":"18718567934","loan_bind_cellphone":"","loan_bank_card_num":"6222024000038644940","loan_bank_name":"工商银行","repay_bank_card_num":"6222024000038644940","repay_bank_name":"工商银行","repay_bind_cellphone":"18718567934","product_name":"qy_001","product_id":"qy_001","loan_amount":10000000,"loan_year_rate":10,"platform_year_rate":14,"total_year_rate":24,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-06-22T00:00:00+08:00","first_repay_at":"2017-07-05T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170620006","user_id":39,"check_status":"uncheck","status":"loaned"},{"id_num":"440306198501313543","account_id":41,"id":41,"created_at":"2017-08-25T17:50:05.658614925+08:00","updated_at":"2017-08-25T17:50:05.658614925+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"440306198501313543","user_name":"钟雪霞","cellphone":"15989860320","loan_bind_cellphone":"","loan_bank_card_num":"6228450120002427716","loan_bank_name":"农业银行","repay_bank_card_num":"6228450120002427716","repay_bank_name":"农业银行","repay_bind_cellphone":"15989860320","product_name":"qy_001","product_id":"qy_001","loan_amount":20000000,"loan_year_rate":10,"platform_year_rate":16,"total_year_rate":26,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-06-29T00:00:00+08:00","first_repay_at":"2017-07-23T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170628004","user_id":41,"check_status":"uncheck","status":"loaned"},{"id_num":"441481198311230882","account_id":43,"id":43,"created_at":"2017-08-25T17:50:05.845643688+08:00","updated_at":"2017-08-25T17:50:05.845643688+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"441481198311230882","user_name":"陈秋月","cellphone":"13798578995","loan_bind_cellphone":"","loan_bank_card_num":"6230582000029951210","loan_bank_name":"平安银行","repay_bank_card_num":"6230582000029951210","repay_bank_name":"平安银行","repay_bind_cellphone":"13798578995","product_name":"qy_001","product_id":"qy_001","loan_amount":6000000,"loan_year_rate":10,"platform_year_rate":14,"total_year_rate":24,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-06-12T00:00:00+08:00","first_repay_at":"2017-07-06T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170608002","user_id":43,"check_status":"uncheck","status":"loaned"},{"id_num":"360521196112170011","account_id":45,"id":45,"created_at":"2017-08-25T17:50:06.067724357+08:00","updated_at":"2017-08-25T17:50:06.067724357+08:00","deleted_at":null,"chan_serial_number":"","loan_chan":"lianlian","repay_chan":"","repay_rule":"blf","user_id_num":"360521196112170011","user_name":"韦成斌","cellphone":"13923842981","loan_bind_cellphone":"","loan_bank_card_num":"4340617200890533 ","loan_bank_name":"建设银行","repay_bank_card_num":"4340617200890533","repay_bank_name":"建设银行","repay_bind_cellphone":"13923842981","product_name":"qy_001","product_id":"qy_001","loan_amount":6000000,"loan_year_rate":10,"platform_year_rate":14,"total_year_rate":24,"platform_service_rate":0,"loan_term":24,"overdue_ratio":1.5,"overdue_platform_pay_base":5000,"overdue_m1":1,"overdue_m2":2,"overdue_m3":3,"settle_split":7,"rate_before_settle_split":3,"rate_after_settle_split":0,"loan_at":"2017-06-15T00:00:00+08:00","first_repay_at":"2017-06-18T00:00:00+08:00","days_in_month":30,"days_in_year":360,"first_do_not_pay_in":2,"settle_at":null,"contract_id":"H_qy20170613001","user_id":45,"check_status":"uncheck","status":"loaned"}]`


type SuccessInfo struct {
	IdNum string    			`json:"id_num"`
	AccountId uint				`json:"account_id"`
	*accModel.Account
}

func migrateCoreSys() {
	var successInfoList []SuccessInfo
	if err := util.ParseJson(jsonStr, &successInfoList); err != nil {
		panic(err.Error())
	}
	if len(successInfoList) == 0 {
		panic("数组长度为0")
	}
	for _, info := range successInfoList {
		var ao model.ApprovalOrder
		if err := config.GetProdDb().Model(ao).Where("user_id_num = ?", info.IdNum).First(&ao).Error; err != nil {
			panic(err.Error())
		}
		ao.ApprovedRate = info.TotalYearRate
		ao.ApprovedAmount = info.LoanAmount
		ao.Cellphone = info.Cellphone
		ao.ContractId = info.ContractId
		ao.LoanTerm = info.LoanTerm
		ao.LoanAt = &info.LoanAt
		ao.SalaryAt = &info.FirstRepayAt
		ao.LoanCard = info.LoanBankCardNum
		ao.LoanBankName = info.LoanBankName
		ao.Card1 = info.RepayBankCardNum
		ao.BankName = info.RepayBankName
		ao.CardOnePhone = info.RepayBindCellphone
		ao.AccountID = info.AccountId
		// 更新数据
		if err := config.GetProdDb().Model(ao).Updates(ao).Error; err != nil {
			panic(err.Error())
		}
	}
}