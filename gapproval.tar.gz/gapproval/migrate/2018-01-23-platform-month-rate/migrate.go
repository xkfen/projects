package main

import (
	"gcoresys/common/logger"
	"gcoresys/common/util"
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"time"
)

/**
 @FileDescription: 
 @author: WangXi
 @create: 09:17 2018/1/23
*/

const data string = `[
  {
    "user_name": "苏浩",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "林艇",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "唐建军",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "高志平",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "田佩君",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "史红岩",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "许志红",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "方耀良",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "张鸿顺",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "郑小勇",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "陈海珍",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "丘春能",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "杨芳",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "谢锐彬",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "付丽丽",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "江敏",
    "loan_rate": 0.15,
    "monthly_rate": 0.00601532793444444
  },
  {
    "user_name": "梁旭思",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "黄福生",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "彭素绸",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "张权",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "卢进荣",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "刘旭",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "刘德璋",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "朱成仁",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "孙萍",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "赵志强",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "余素芹",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "詹燕",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "卢刚",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "竟义博",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "陈友荣",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "陈伟",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "郭阳智",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "王三强",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "李婵娟",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "张湘云",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "汪德霞",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "陈俊锛",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "李力",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "田诗瑶",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "胡嘉歆",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "詹平生",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "肖蔚锋",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "杨学会",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "陈金燕",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "张旺涛",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "郑奕涛",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "高伟华",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "吴岗基",
    "loan_rate": 0.15,
    "monthly_rate": 0.00607625774089553
  },
  {
    "user_name": "彭素凌",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "林燕",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "游春荣",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "陈振宇",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "聂斌",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "吴晓寒",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "郭红玉",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "张萍",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "陈懿",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "郑松涛",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "戴斌",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "毛助发",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "黄德发",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "余海兰",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "刘卫东",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "向坤升",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "蔡志鹏",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "贺红龙",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "江海燕",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "徐桂芳",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "林新月",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "张金华",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "许镌淇",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "周晓军",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "吴风龙",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "张春茂",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "何玉珍",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "卢玉芳",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "王容",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "敖艳",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "潘昌强",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "刘刚",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "李国辉",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "何芳",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "谭远霞",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "解明哲",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "刁灵燕",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "刘东",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "林向民",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "蒋小文",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "潘佐羽",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "王万霞",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "贾鑫",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "刘彩娥",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "童少华",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "付宝贤",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "林紫玉",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "宾志成",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "杨群",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "张建蔚",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "李璇",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "邓影玲",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "胡林",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "曾东霞",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "张秋斌",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "孙卫东",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "郑玉玲",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "黄略",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "徐明",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "糜道先",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "兰标德",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "李媛媛",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "郑夏滨",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "陈海龙",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "骆恒凯",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "李会玲",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "罗家俊",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "钟建辉",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "刘星高",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "曾勇",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "冯源",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "陈鹰",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "王威",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "张士凤",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "胡义",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  },
  {
    "user_name": "马惠贤",
    "loan_rate": 0.15,
    "monthly_rate": 0.006
  }
]`

func main() {
	logger.InitLogger(logger.LvlDebug, nil)
	migrate()
}

func migrate() {
	var dataMap []map[string]interface{}

	if err := util.ParseJson(data, &dataMap); err != nil {
		panic(err.Error())
	}

	for _, d := range dataMap {

		var ao model.ApprovalOrder
		if err := config.GetProdDb().Model(&model.ApprovalOrder{}).
			Where("jinjian_user_name = ?", d["user_name"]).First(&ao).Error; err != nil {
			if err.Error() == "record not found" {
				logger.Info("=========未找到ao", "user_name", d["user_name"])
			} else {
				panic(err.Error())
			}
		} else {
			// 判断 平台月利率是否为0

			if ao.PlatformMonthRate == 0 {

				if err := config.GetProdDb().Model(&model.ApprovalOrder{}).
					Where("id = ?", ao.ID).
					Update("platform_month_rate", d["monthly_rate"].(float64)*100).Error; err != nil {
					panic(err.Error())
				}

				time.Sleep(500 * time.Millisecond)

			} else {
				logger.Info("用户已存在平台月利率", "jinjian_id: ", ao.JinjianId, "jinjian_user_name: ", ao.JinjianUserName, "月利率: ", ao.PlatformMonthRate)
			}
		}
		//fmt.Println(reflect.TypeOf(d["monthly_rate"]))
	}

}
