package main

import (
	"flag"
	"gcoresys/common/logger"
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"gcoresys/common/util"
	"fmt"
)

func main() {
	var (
		env = flag.String("env", "dev", "运行环境配置")
	)
	logger.InitLogger(logger.LvlDebug, nil)
	// 初始化数据库
	logger.Info("初始化数据库" + *env)
	config.GetApprovalDbConfig(*env)
	migrate(*env)

}

func migrate(env string) {
	// 开始数据割接
	var aoList []model.ApprovalOrder
	if err := config.GetDataMigrateDb(env).Model(aoList).
		Where("created_at BETWEEN ? AND ?", "2017-08-25", "2017-08-26").Find(&aoList).Error; err != nil {
		panic(err.Error())
	}
	if len(aoList) == 0 {
		panic("审批查询后数组长度为0, 请检查 ")
	}

	var count int

	for _, ao := range aoList {
		var allInfo map[string]interface{}

		var shouldUpdate  = false

		if err := util.ParseJson(ao.AllInfo, &allInfo); err != nil {
			panic(ao.JinjianId + "  allInfo转换出错: " + err.Error())
		}

		// salary_bank
		if sbList, ok := allInfo["salary_bank"].([]interface{}); ok {
			if len(sbList) > 0 {
				if sb, ok := sbList[0].(map[string]interface{}); ok {
					sb["isJump"] = false
					shouldUpdate = true
				}
			} else {
				fmt.Println(ao.JinjianId + " 没有salary_bank 数组 ")
			}
		} else {
			fmt.Println(ao.JinjianId + " map 没有 salary_bank ")
		}

		// other_bank
		if sbList, ok := allInfo["other_bank"].([]interface{}); ok {
			if len(sbList) > 0 {
				if sb, ok := sbList[0].(map[string]interface{}); ok {
					sb["isJump"] = false
					shouldUpdate = true
				}
			} else {
				fmt.Println(ao.JinjianId + " other_bank 数组 ")
			}
		} else {
			fmt.Println(ao.JinjianId + " map 没有 other_bank ")
		}

		if shouldUpdate {
			if err := config.GetDataMigrateDb(env).Model(ao).Where("id = ?", ao.ID).
				Update("all_info", util.StringifyJson(allInfo)).Error; err != nil {
				panic(ao.JinjianId + "  allInfo save出错: " + err.Error())
			}
			count ++
		}

	}

	logger.Info("更新完成 ", "总计数量", count)

}
