/**
 @FileDescription: 
 @author: WangXi
 @create: 14:19 2018/1/8
*/

package main

import (
	"gapproval/approval/model"
	"strconv"
	"time"
	"math/rand"
	"fmt"
	"gcoresys/common/logger"
	"gapproval/approval/db/config"
)

func main() {
	migrate()
}

func migrate() {

	fmt.Println("开始构建seed数据 .....")

	rnd := rand.New(rand.NewSource(time.Now().UnixNano()))
	for i := 1; i < 6; i ++ {
		paoF := model.GetDefaultPreApprovalOrder()
		paoF.PreApprovalID = "X" + "403" + strconv.Itoa(i) + fmt.Sprintf("%04v", rnd.Int31n(1000000))
		paoF.UserName = "测试" + strconv.Itoa(i)
		paoF.UserIdNum = fmt.Sprintf("%018v", rnd.Int31n(1000000))

		if err := transactCreatePreApproval(paoF); err != nil {
			panic(err.Error())
		}

		time.Sleep(1 * time.Second)

	}

	for i := 1; i < 5; i ++ {
		paoF := model.GetDefaultPreApprovalOrder()
		paoF.PreApprovalID = "X" + "403" + strconv.Itoa(i) + fmt.Sprintf("%04v", rnd.Int31n(1000000))
		paoF.UserName = "测试" + strconv.Itoa(i)
		paoF.UserIdNum = fmt.Sprintf("%018v", rnd.Int31n(1000000))
		paoF.AgencyName = "点点金融"
		paoF.AgencyEmployeeId = "tty00" + strconv.Itoa(i)
		paoF.AgencyEmployee = "渠道0" + strconv.Itoa(i)

		if err := transactCreatePreApproval(paoF); err != nil {
			panic(err.Error())
		}

		time.Sleep(1 * time.Second)
	}

	for i := 1; i < 6; i ++ {
		paoF := model.GetDefaultPreApprovalOrder()
		paoF.PreApprovalID = "X" + "403" + strconv.Itoa(i) + fmt.Sprintf("%04v", rnd.Int31n(1000000))
		paoF.UserName = "测试" + strconv.Itoa(i)
		paoF.UserIdNum = fmt.Sprintf("%018v", rnd.Int31n(1000000))
		paoF.AgencyName = "神马金融"
		paoF.AgencyEmployeeId = "tty00" + strconv.Itoa(i)
		paoF.AgencyEmployee = "渠道0" + strconv.Itoa(i)

		if err := transactCreatePreApproval(paoF); err != nil {
			panic(err.Error())
		}

		time.Sleep(1 * time.Second)
	}

	fmt.Println("构建完成")
}


func transactCreatePreApproval(pao *model.PreApprovalOrder) (err error) {

	var count int

	if err := config.GetTargetDb().Model(&model.PreApprovalOrder{}).Where("user_id_num = ?", pao.UserIdNum).
		Count(&count).Error; err != nil {
		logger.Error("获取预审申请次数出错", "err", err.Error())
	}

	// 开启事物
	txSqlBase := config.GetTargetDb().Begin()

	// 设置提交时间

	if pao.CommitTime == nil {
		nowTime := time.Now()
		pao.CommitTime = &nowTime
	}

	// 获取申请次数
	pao.PreApprovalCount = count + 1
	// 预审状态  待预审
	pao.PreApprovalStatus = model.WAITPREAPPROVAL

	// 创建 预审批单
	if err = txSqlBase.Model(&model.PreApprovalOrder{}).Create(pao).Error; err != nil {
		logger.Error("============创建预审批单出错err: " + err.Error())
		txSqlBase.Rollback()
		return
	}

	// 创建 预审操作日志
	if err = txSqlBase.Model(&model.PreApprovalLog{}).Create(&model.PreApprovalLog{
		PreApprovalId:     pao.PreApprovalID,
		PreApprovalName:   pao.AgencyName + " " + pao.AgencyEmployee,
		PreApprovalStatus: "渠道完成申请",
		PreApprovalDesc:   "",
	}).Error; err != nil {
		logger.Error("============创建预审批log出错err: " + err.Error())
		txSqlBase.Rollback()
		return
	}

	txSqlBase.Commit()
	return
}