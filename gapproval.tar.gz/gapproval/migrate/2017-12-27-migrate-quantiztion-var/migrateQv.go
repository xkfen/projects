package main

import (
	"flag"
	"gcoresys/common/logger"
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"gcoresys/common/util"
	"fmt"
)

func main() {
	var (
		env = flag.String("env", "dev", "运行环境配置")
	)
	logger.InitLogger(logger.LvlDebug, nil)
	// 初始化数据库
	logger.Info("初始化数据库" + *env)
	config.GetApprovalDbConfig(*env)
	migrate(*env)

}

func migrate(env string) {
	// 开始数据割接
	var aoList []model.ApprovalOrder
	if err := config.GetDataMigrateDb(env).Model(aoList).Find(&aoList).Error; err != nil {
		panic(err.Error())
	}
	if len(aoList) == 0 {
		panic("审批查询后数组长度为0, 请检查 ")
	}

	var emptyMapCount = 0

	for _, ao := range aoList {
		var qv model.ApprovalQuantizationVar
		if config.GetDataMigrateDb(env).LogMode(false).Model(qv).
			Where("jinjian_id = ?", ao.JinjianId).First(&qv).RecordNotFound() {

			var aqv model.ApprovalQuantizationVar
			if ao.QuantizationMap != "" {
				if err := util.ParseJson(ao.QuantizationMap, &aqv); err != nil {
					fmt.Println(ao.JinjianId + "  QuantizationMap转换出错: " + err.Error())
				} else {
					aqv.JinjianId = ao.JinjianId
					if err := config.GetDataMigrateDb(env).LogMode(false).Model(aqv).Create(&aqv).Error; err != nil {
						fmt.Println(ao.JinjianId + "  QuantizationMap create: " + err.Error())
					}
				}
			} else {
				emptyMapCount ++
				//fmt.Println(ao.JinjianId + "  QuantizationMap 为空 ")
			}
		}

	}

	logger.Info("========","qv map 为空", emptyMapCount)

}
