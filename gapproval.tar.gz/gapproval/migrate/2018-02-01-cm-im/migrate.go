package main

import (
	"gcoresys/common/logger"
	"gapproval/approval/model"
	"gapproval/approval/db/config"
)

/**
 @FileDescription: 
 @author: WangXi
 @create: 10:09 2018/2/1
*/
func main() {
	logger.InitLogger(logger.LvlDebug, nil)
	migrate()
}

func migrate() {
	var aoList []model.ApprovalOrder
	if err := config.GetDataMigrateDb("prod").Model(aoList).
		Where("channel_manager <> ?", "").Find(&aoList).Error; err != nil {
		panic(err.Error())
	}
	if len(aoList) == 0 {
		panic("审批查询后数组长度为0, 请检查 ")
	}

	logger.Info("==============开始割接")

	for _, ao := range aoList {
		ao.InterViewManager = ao.ChannelManager

		logger.Info("============" +ao. JinjianId)

		if err := config.GetDataMigrateDb("prod").Model(ao).Where("id = ?", ao.ID).
			Update("inter_view_manager", ao.InterViewManager).Error; err != nil {
			panic(ao.JinjianId + "  inter_view_manager save出错: " + err.Error())
		}
	}

	logger.Info("==============割接结束")

}