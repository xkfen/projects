package main

//import (
//	"gapproval/common/httpReq"
//	"gcoresys/common/logger"
//)
//
//func main() {
//	logger.InitLogger(logger.LvlDebug, nil)
//	param := map[string]string{
//		"CorpID":   "CDJS002922",
//		"Pwd":      "zm0513@",
//		"Mobile":   "18676740087",
//		"Content":  "尊敬的用户，您的借款申请因故未能通过审核。感谢您的理解与支持！",
//		"SendTime": "",
//	}
//	reqUrl := "https://sdk2.028lk.com/utf8/BatchSend2.aspx"
//	respCode, respResult, respErr := httpReq.PostFormDataProxyNoCheck(param, reqUrl)
//	if respErr != nil {
//		logger.Info(respErr.Error())
//		return
//	}
//	if respCode != 200 {
//		logger.Info("短信网关返回错误码: ", "code", respCode)
//		return
//	}
//	logger.Info("短信发送成功", "resp", respResult)
//}
//


