package test1

import (
	"testing"
	"fmt"
	"gcoresys/common/util"
	"time"
)

func TestGetStrFromJson(t *testing.T) {
	data := map[string]interface{}{
		"x": "1",
	}
	str := util.GetStrFromJson(data, "xx")
	fmt.Println(data["xx"])
	fmt.Println(str)

	fmt.Println(time.Now().Add(time.Minute * 30).Format("2006-01-02 15:04:05"))

}