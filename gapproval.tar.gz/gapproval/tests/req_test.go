package main

import (
	"testing"
	"fmt"
	"gcoresys/common/util"
	"gapproval/approval/service"
)

func TestReq(t *testing.T){
	fmt.Println(util.StringifyJson(service.QueryPreOrderListReq{}))
}