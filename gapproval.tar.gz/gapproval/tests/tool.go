package main

import (
	"gapproval/approval/db/config"
	"gapproval/approval/model"
	"fmt"
	"gcoresys/common/util"
)

func main() {
	config.GetApprovalDbConfig("dev")
	var o model.ApprovalOrder
	if err := config.GetDb().Model(&model.ApprovalOrder{}).Where("jinjian_id='order_1504613397237'").First(&o).Error;err != nil {
		panic(err.Error())
	}
	fmt.Println(util.StringifyJson(o))
	//if err := config.GetDb().Create(model.GetDefaultApprovalOrder()).Error; err != nil {
	//	fmt.Println(err.Error())
	//}
}
