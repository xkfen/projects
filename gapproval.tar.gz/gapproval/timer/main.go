package main

import(
	"gcoresys/common/logger"
	"gcoresys/common/util/schedule"
	"gapproval/approval/db/config"
	"gcoresys/common"
	"gapproval/approval/serviceV1"
)

func main() {
	env := common.DefineRunTimeCommonFlag()
	// 初始化日志
	if common.GetUseDocker() != 0 {
		logger.InitLogger(logger.LvlDebug, "qy_approval_timer.log")
	} else {
		logger.InitLogger(logger.LvlDebug, nil)
	}

	// 初始化数据库连接
	config.GetApprovalDbConfig(env)

	// 启动定时去查询放款情况
	startTimer()
}

// 启动定时任务
func startTimer() {
	var tasks []*schedule.QyTask
	// 每天检查逾期和待扣
	tasks = append(tasks, GetDailyT())
	schedule.StartSchedule(tasks, false)
}

var dailyT *schedule.QyTask
func GetDailyT() *schedule.QyTask {
	spec := "0 0/15 * * * ? "
	// 生产环境下每天执行一次即可
	if common.GetUseDocker() == 2 {
		spec = "0 0/15 * * * ? "
	}
	if dailyT == nil {
		dailyT = &schedule.QyTask{
			// 任务名称
			Name: "是否放款",
			// 需要执行的任务
			Run: serviceV1.CheckIsLoan,
			Spec: spec,
		}
	}
	return dailyT
}
