#!/usr/bin/env bash


image_name="dev.dr:5000/qy_approval_timer:1.0"

if [ $1 == "test" ];then
image_name="test.dr:5000/qy_approval_timer:1.0"
fi

if [ $1 == "prod" ];then
image_name="prod.dr:5000/qy_approval_timer:2.0"
fi

if [ $1 == "preprod" ];then
image_name="preprod.dr:5000/qy_approval_timer:2.0"
fi

# 生成docker image
docker rmi -f $image_name
echo '正在生成docker镜像'
docker build -f ./Dockerfile -t $image_name ./

if [ $2 ];then
    docker push $image_name
fi