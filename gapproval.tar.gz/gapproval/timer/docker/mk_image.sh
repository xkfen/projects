#!/usr/bin/env bash


root=`pwd`

if [ $1 ];then
    # 编译项目
    echo '正在编译项目'
    rm -rf tmp
    mkdir -p tmp

    cd ../
    GOOS=linux go build -o $root/tmp/approval_timer
fi

cd $root

if [ $2 ];then
    ./push_image.sh $1 $2
fi