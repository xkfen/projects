#!/usr/bin/env bash

approval_timer --env=$QY_ENV --docker_env=$QY_DOCKER_ENV
