package main

import (
	"gapproval/approval/db/config"
	"gapproval/approval/grpc"
	"gcoresys/common/logger"
	"gcoresys/common"
	"gcoresys/common/util"
	"time"
)

func main() {
	env := common.DefineRunTimeCommonFlag()
	// 初始化日志
	if common.GetUseDocker() != 0 {
		logger.InitLogger(logger.LvlInfo, "qy_gapproval.log")
	} else {
		logger.InitLogger(logger.LvlDebug, nil)
	}
	// 初始化数据库
	logger.Info("初始化数据库" + env)
	config.GetApprovalDbConfig(env)
	logger.Info("====v3.2.2============系统更新时间： " + time.Now().String())
	util.WishNoBug()
	//启动PRC服务
	grpc.StartApprovalRpcServer()
}
