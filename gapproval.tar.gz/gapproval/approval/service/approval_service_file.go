package service

import (
	ivModel "gapproval/interview/model"
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"gcoresys/common/util"
	"strings"
	"github.com/tidwall/gjson"
	"errors"
	"reflect"
	"gapproval/common/tool"
	"github.com/jinzhu/gorm"
)

type AllFiles struct {
	JinjianId string `json:"jinjian_id"`
	// 用户进件身份证照片
	IdCardFiles []file `json:"id_card_files"`
	//IdCardFacePhoto string `json:"id_card_face_photo"`
	//IdCardBackPhoto string `json:"id_card_back_photo"`
	//IdCardA string `json:"id_card_a"`
	//IdCardB string `json:"id_card_b"`
	//IdCardC string `json:"id_card_c"`
	// 放款卡
	LoanBankFiles []file `json:"loan_bank_files"`
	// 扣款卡
	PayBankFiles []file `json:"pay_bank_files"`
	// 征信报告
	CreditReportFiles []file `json:"credit_report_files"`
	// 面谈声明
	InterviewStatementFiles []file `json:"interview_statement_files"`
	// 进件方案文件
	//JinjianPlanFiles []file `json:"jinjian_plan_files"` 已拆分成房产和保单
	// 房产
	HouseLoanFiles   []file `json:"house_loan_files"`
	// 保单
	BanDanFiles  []file `json:"ban_dan_files"`
	// 社保,公积金,税务等
	SocialSecurityAndProvidentFundAndTaxFiles []file `json:"social_security_and_provident_fund_and_tax_files"`
	// 远程面签上传视频
	VideoPath []file `json:"video_path"`
	// 用途资料
	UsageFiles []file `json:"usage_files"`
	// 合同,协议等
	ContractFiles []file `json:"contract_files"`
	// 征信授权书
	AuthorizationLetterFiles []file `json:"authorization_letter_files"`
	// 退补件资料
	TuiBuJianFiles []file `json:"tui_bu_jian_files"`
	// 其他资料
	OtherFiles []file `json:"other_files"`
}

type file struct {
	Id uint `json:"id"`
	// 文件类型
	FileType string `json:"file_type"`
	// 文件路径
	FilePath string `json:"path"`
	// 备注
	Remark string `json:"remark"`
	// 文件来源阶段 (进件jj,面签mq,审批sp)  , (预审批ysp, 审批sp)
	Stage  string  `json:"stage"`
}

// 查询面签和审批的所有文件, added by zebreay 郑柏屹
func GetAllFiles(jinjianId string) (allFiles AllFiles, err error) {
	allFiles.JinjianId = jinjianId
	// 面签文件备注
	var IdCardRemark = map[string]string{ivModel.IdCardA:"手持身份证正面照",ivModel.IdCardB:"手持身份证反面照", ivModel.IdCardC:"手持身份证与合同签署页",
		ivModel.JinjianPlan: "进件方案文件",ivModel.PLAN: "进件文件",ivModel.SoundPlan:"进件方案上传录音",ivModel.CreditReport:"征信报告",
		ivModel.LoanBankCard:"放款银行卡",ivModel.OtherType:"其他文件"}

	var ao model.ApprovalOrder
	db := config.GetDb()
	err = db.Model(&model.ApprovalOrder{}).Where("jinjian_id=?", jinjianId).Select("all_info, inter_view").First(&ao).Error
	if err != nil {
		return
	}
	// 身份证文件*************************************
	if face:= gjson.Get(ao.AllInfo, "idcard_info.facePhoto").Str; face != "" {
		allFiles.IdCardFiles = append(allFiles.IdCardFiles, file{FileType: "id_card_face_photo", FilePath: face, Stage: "jj"})
	}
	if back:= gjson.Get(ao.AllInfo, "idcard_info.backPhoto").Str; back != "" {
		allFiles.IdCardFiles = append(allFiles.IdCardFiles, file{FileType: "id_card_back_photo", FilePath: back, Stage: "jj"})
	}
	if len(allFiles.IdCardFiles) < 2 {
		err = errors.New("身份证文件读取出错, 请联系技术人员")
		return
	}
	var interView ivModel.Interview
	if err = util.ParseJson(ao.InterView, &interView); err != nil {
		err = errors.New("GetAllFiles 出错" + err.Error())
		return
	}
	for _, x := range interView.IdCardFile {
		allFiles.IdCardFiles = append(allFiles.IdCardFiles, file{FileType: x.FileType, FilePath: x.FilePath, Remark:"[面签文件] "+IdCardRemark[x.FileType], Stage: "mq"})
	}
	// 放款卡文件*************************************
	if len(interView.LoanBank) > 0 && len(interView.LoanBank[0].FilesUrl) > 0 {
		allFiles.LoanBankFiles = append(allFiles.LoanBankFiles, file{FileType: interView.LoanBank[0].FilesUrl[0].FileType,
			FilePath: interView.LoanBank[0].FilesUrl[0].FilePath,Remark:"[面签文件] "+IdCardRemark[interView.LoanBank[0].FilesUrl[0].FileType], Stage: "mq"})
	}
	// 征信报告文件***********************************
	for _, x := range interView.CreditReportFile {
		allFiles.CreditReportFiles = append(allFiles.CreditReportFiles, file{FileType: x.FileType, FilePath: x.FilePath, Remark:"[面签文件] "+IdCardRemark[x.FileType], Stage: "mq"})
	}
	// 进件方案文件***********************************现在分为 房产 和 保单
	plan := interView.JinjianPlan
	if len(plan) > 0 && plan[:1] == "[" {
		for _, x := range interView.JinjianPlanFiles {
			allFiles.HouseLoanFiles = append(allFiles.HouseLoanFiles, file{FileType: x.FileType, FilePath: x.FilePath, Remark:"[面签文件] "+IdCardRemark[x.FileType], Stage: "mq"})
		}
	}
	if len(plan) > 0 && plan[:1] == "{" {
		for _, x := range interView.JinjianPlanFiles {
			allFiles.BanDanFiles = append(allFiles.BanDanFiles, file{FileType: x.FileType, FilePath: x.FilePath, Remark:"[面签文件] "+IdCardRemark[x.FileType], Stage: "mq"})
		}
	}
	// 社保,公积金,税务等********************['houseFace(房产正面)', 'houseBack(房产反面)', 'marriage(结婚证)', 'social(社保) fund(公积金)']
	if credit := gjson.Get(ao.AllInfo, "credit_files").Array();len(credit) > 0 {
		for _, x := range credit {
			allFiles.SocialSecurityAndProvidentFundAndTaxFiles = append(allFiles.SocialSecurityAndProvidentFundAndTaxFiles,
				file{FileType: gjson.Get(x.Raw, "fileType").Str, FilePath: gjson.Get(x.Raw, "file").Str, Stage: "jj"})
		}
	}

	// 视频面签文件*************************************
	if interView.VideoPath != "" {
		allFiles.VideoPath = append(allFiles.VideoPath, file{FileType: "interview_video", FilePath: interView.VideoPath})
	}
	// 其他文件 以及 合同,协议等 文件**********************
	for _, x := range interView.OtherFile {
		allFiles.OtherFiles = append(allFiles.OtherFiles, file{0,x.FileType, x.FilePath, "[面签文件] "+IdCardRemark[x.FileType], "mq"})
	}
	for _, x := range interView.ContractFile {
		allFiles.ContractFiles = append(allFiles.ContractFiles, file{FileType: x.FileType, FilePath: x.FilePath, Remark:"[面签文件] "+IdCardRemark[x.FileType], Stage: "mq"})
	}
	// 取出审批端所有文件
	getFilesFromApprovalStage(&allFiles, jinjianId)
	return
}

func getFilesFromApprovalStage(allFiles *AllFiles, jinjianId string) {
	list := model.GetApprovalFileList(jinjianId)
	for _, x := range list {
		if x.FileType == "id_card_face_photo" {
			allFiles.IdCardFiles[0] = file{Id:x.ID, FileType: x.FileType, FilePath: x.FileUrl, Remark: x.Desc, Stage: "sp"}
		}
		if x.FileType == "id_card_back_photo" {
			allFiles.IdCardFiles[1] = file{Id:x.ID, FileType: x.FileType, FilePath: x.FileUrl, Remark: x.Desc, Stage: "sp"}
		}
		if strings.Contains(x.FileType, "contract") { // 适配旧数据
			allFiles.ContractFiles = append(allFiles.ContractFiles, file{Id:x.ID, FileType: x.FileType, FilePath: x.FileUrl, Remark: x.Desc, Stage: "sp"})
			continue
		} // 反射完成剩余文件
		rt := reflect.TypeOf(*allFiles)
		rv := reflect.ValueOf(allFiles).Elem()
		for i := 1; i < rt.NumField(); i++ {
			if strings.Contains(rt.Field(i).Tag.Get("json"), x.FileType) {
				var value []file
				if v, ok := rv.Field(i).Interface().([]file); ok {
					value = append(v, file{Id:x.ID, FileType: x.FileType, FilePath: x.FileUrl, Remark: x.Desc, Stage: "sp"})
				}
				rv.Field(i).Set(reflect.ValueOf(value))
				break
			}
		}
	}
}

// 将面签的路径转换为 Deployment 项目中的配置.
func ivAsset(url string) string {
	return strings.Replace(url, "assets","interview_assets", 1)
}

// 获取审批打包压缩的文件
func PackCompressedApprovalFile(jinjianId string) (fileUrls string, err error) {
	var approvalFiles []model.ApprovalFile

	allFiles, err := GetAllFiles(jinjianId)
	if err != nil {
		return
	}

	rt := reflect.TypeOf(allFiles)
	rv := reflect.ValueOf(allFiles)
	for i := 1; i < rt.NumField(); i++ {
		for _, x := range tool.ToSlice(rv.Field(i).Interface()) {
			if url, ok := x.(file); ok {
				// 排除进件和审批的文件, 转换面签的文件路径
				if url.Id == 0 && i != 8 && i != 9 && url.FileType != "id_card_face_photo" && url.FileType != "id_card_back_photo" {
					url.FilePath = ivAsset(url.FilePath)
				}
				approvalFiles = append(approvalFiles, model.ApprovalFile{JinjianId:jinjianId, FileUrl:url.FilePath})
			}
		}
	}

	if len(approvalFiles) <= 0 {
		return fileUrls, errors.New("未查询到相关文件，无法压缩")
	}

	return util.StringifyJson(approvalFiles), nil
}

// *********************************************************************************
// ---------------------------------File Operations---------------------------------

func UploadApprovalFile(file model.ApprovalFile) (err error) {
	if err = file.IsValidApprovalFile(); err != nil {
		return
	}

	if file.FileType == "id_card_face_photo" || file.FileType == "id_card_back_photo" {
		return errors.New("身份证正反面没有上传操作, 只能更新")
	}

	return file.Create()
}

func UpdateApprovalFile(file model.ApprovalFile) (err error) {
	if err = file.IsValidApprovalFile(); err != nil {
		return
	}

	if file.FileType == "id_card_face_photo" || file.FileType == "id_card_back_photo" {
		return createOrUpdateIdCard(file)
	}

	return file.UpdateNew()
}

func createOrUpdateIdCard(file model.ApprovalFile) error {
	var aoFile model.ApprovalFile
	if err := config.GetDb().Model(&aoFile).Where("jinjian_id=? AND file_type=?", file.JinjianId, file.FileType).First(&aoFile).Error; err != nil && err != gorm.ErrRecordNotFound {
		return err
	} else {
		if err == gorm.ErrRecordNotFound {
			return file.Create()
		}
		file.ID = aoFile.ID
		return file.UpdateNew()
	}
}
//
//// 将身份证正反面文件更新进AllInfo里
//func updateIdCardToAllInfo(file model.ApprovalFile) error {
//	ao, err := model.GetApprovalOrderByJinjianId(file.JinjianId)
//	if err != nil {
//		return err
//	}
//	var face, back string
//
//	switch file.FileType {
//	case "id_card_face_photo":
//		if face, err = tool.UpdateIntoJson(ao.AllInfo, "idcard_info.facePhoto", file.FileUrl); err != nil {
//			return err
//		}
//		if err = ao.Update(&model.ApprovalOrder{AllInfo:face}); err != nil {
//			return err
//		}
//	case "id_card_back_photo":
//		if back, err = tool.UpdateIntoJson(ao.AllInfo, "idcard_info.backPhoto", file.FileUrl); err != nil {
//			return err
//		}
//		if err = ao.Update(&model.ApprovalOrder{AllInfo:back}); err != nil {
//			return err
//		}
//	default:
//		return errors.New("不可能运行到这里")
//	}
//	return nil
//}

func DeleteApprovalFile(file model.ApprovalFile) error {
	if file.FileType == "id_card_face_photo" || file.FileType == "id_card_back_photo" {
		return errors.New("身份证正反面没有删除操作, 只能更新")
	}
	return file.Delete()
}

func OperationTranslation(op string) string {
	var dictionary = map[string]string{"upload":"上传", "update":"更新", "delete":"删除"}
	return dictionary[op]
}