package service

import (
	"gapproval/approval/db/config"
	"gapproval/approval/model"
	"gcoresys/common/logger"
	"gcoresys/common/util"
	"errors"
	"time"
)

// 审批报表
func ApprovalReportForm(start, end string) (data string, err error) {

	startTime, err := time.Parse("2006-01-02 15:04:05", start)
	if err != nil {
		startTime, err = time.Parse("2006-01-02", start)
		if err != nil {
			if start == "" {
				startTime = time.Unix(0, 0)
			} else {
				return data, errors.New("开始时间格式错误，请检查")
			}
		}
	}

	endTime, err := time.Parse("2006-01-02 15:04:05", end)
	if err != nil {
		endTime, err = time.Parse("2006-01-02", end)
		if err != nil {
			if end == "" {
				endTime = time.Now()
			} else {
				return data, errors.New("结束时间格式错误，请检查")
			}
		}
	}

	if startTime.After(endTime) {
		return data, errors.New("开始时间错误，请检查")
	}

	var orderList []model.ApprovalOrder
	if err = config.GetDb().Model(&model.ApprovalOrder{}).Where("inter_view_finish_time BETWEEN ? AND ?", startTime, endTime).Find(&orderList).Error; err != nil {
		logger.Error("========== ApprovalReportForm", "err", err.Error())
		return
	}

	return util.StringifyJson(orderList), nil
}
