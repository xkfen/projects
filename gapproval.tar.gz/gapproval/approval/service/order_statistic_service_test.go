package service

import (
	"testing"
	"time"
	"gcoresys/common/util"
	"fmt"
	"github.com/stretchr/testify/assert"
	"strconv"
	"gapproval/approval/model"
	"gapproval/approval/db/config"
)

// 测试将带有十分秒的时间转为不包含十分秒的日期
func TestTimeToDate(t *testing.T) {
	oneStepTest(func() {
		todayTime := time.Now()
		today := util.GetDate(todayTime)
		fmt.Println(today)
	})
}

// 测试预审批订单概括---待分配订单
func TestStatisticOrderCountWaitApproval(t *testing.T) {
	oneStepTest(func() {
		order1 := model.GetDefaultPreApprovalOrder()
		order1.PreApprovalID = "1"
		assert.NoError(t, CreatePreApproval(order1))
		order2 := model.GetDefaultPreApprovalOrder()
		order2.PreApprovalID = "2"
		assert.NoError(t, CreatePreApproval(order2))
		order3 := model.GetDefaultPreApprovalOrder()
		order3.PreApprovalID = "3"
		assert.NoError(t, CreatePreApproval(order3))
		order4 := model.GetDefaultPreApprovalOrder()
		order4.PreApprovalID = "4"
		assert.NoError(t, CreatePreApproval(order4))
		info, err := StatisticOrderCount("Null", "Null", "ys")
		assert.NoError(t, err)
		assert.Equal(t, 4, info.ToBeAssignCount)

		for i:=0; i < 101; i++ {
			pao := model.GetDefaultPreApprovalOrder()
			pao.PreApprovalID = util.GetMsgId()
			assert.NoError(t, CreatePreApproval(pao))
			pao.PreApprovalID= pao.PreApprovalID + strconv.Itoa(i)
		}
	})

}

//// 测试预审批订单概括--待分配订单
//func TestStatisticOrderCountPreWaitApproval(t *testing.T) {
//	oneStepTest(func() {
//		pao := model.GetDefaultPreApprovalOrder()
//		pao.IsFast = ""
//		assert.NoError(t, serviceV1.CreatePreApproval(pao))
//		pao.PreApprovalStatus = model.WAITPREAPPROVAL
//		paoR, err := serviceV1.GetPreApprovalInfo(pao.PreApprovalID)
//		assert.NoError(t, err)
//		assert.Equal(t, pao.PreApprovalID, paoR.PreApprovalID)
//		assert.Equal(t, "test001", paoR.PreTrailId)
//		assert.Equal(t, "测试001", paoR.PreTrailName)
//		assert.Equal(t, model.WAITPREAPPROVAL, paoR.PreApprovalStatus)
//		info, err := StatisticOrderCount("test001", "测试001", "ys")
//		assert.NoError(t, err)
//		// 待分配订单
//		assert.Equal(t, 1, info.ToBeAssignCount)
//		fmt.Println(util.StringifyJson(info))
//	})
//}

//// 测试预审批我的待办订单
//func TestStatisticOrderCountPreMyTodo(t *testing.T) {
//	oneStepTest(func() {
//		pao := model.GetDefaultPreApprovalOrder()
//		pao.IsFast = ""
//		assert.NoError(t, CreatePreApproval(pao))
//		assert.NoError(t, serviceV1.GrabPreApproval("test001", "测试001"))
//		paoR, err := serviceV1.GetPreApprovalInfo(pao.PreApprovalID)
//		assert.NoError(t, err)
//		assert.Equal(t, pao.PreApprovalID, paoR.PreApprovalID)
//		assert.Equal(t, "test001", paoR.PreTrailId)
//		assert.Equal(t, "测试001", paoR.PreTrailName)
//		assert.Equal(t, model.PREAPPROVALING, paoR.PreApprovalStatus)
//		info, err := StatisticOrderCount("test001", "测试001", "ys")
//		assert.NoError(t, err)
//		// 待分配订单
//		assert.Equal(t, 1, info.MyToDoOrderCount)
//		fmt.Println(util.StringifyJson(info))
//	})
//}
//
//// 测试预审批预审打回订单数量
//func TestStatisticOrderCountPreRepulse(t *testing.T) {
//	oneStepTest(func() {
//		pao := model.GetDefaultPreApprovalOrder()
//		pao.IsFast = ""
//		assert.NoError(t, CreatePreApproval(pao))
//		assert.NoError(t, serviceV1.GrabPreApproval("test001", "测试001"))
//		paoR, err := serviceV1.GetPreApprovalInfo(pao.PreApprovalID)
//		assert.NoError(t, err)
//		assert.Equal(t, pao.PreApprovalID, paoR.PreApprovalID)
//		assert.Equal(t, "test001", paoR.PreTrailId)
//		assert.Equal(t, "测试001", paoR.PreTrailName)
//		assert.Equal(t, model.PREAPPROVALING, paoR.PreApprovalStatus)
//		// 打回
//		assert.NoError(t, serviceV1.PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: pao.PreApprovalID,
//			PreApprovalStatus: model.PREAPPROVALREPULSE, OpDesc: "ssss"}))
//
//		info, err := StatisticOrderCount("test001", "测试001", "ys")
//		assert.NoError(t, err)
//		// 待分配订单
//		assert.Equal(t, 1, info.PreRepulseCount)
//		fmt.Println(util.StringifyJson(info))
//	})
//}

// 初审--待分配订单
//func TestStatisticOrderCountCSWaitApproval(t *testing.T) {
//	oneStepTest(func() {
//		order := model.GetDefaultApprovalOrder()
//		order.FirstTrailId = "test001"
//		order.FirstTrailName = "测试001"
//		assert.NoError(t, serviceV1.NewApprovalOrder(order))
//		info, err := StatisticOrderCount("test001", "测试001", "cs")
//		assert.NoError(t, err)
//		// 待分配订单
//		assert.Equal(t, 1, info.ToBeAssignCount)
//		fmt.Println(util.StringifyJson(info))
//	})
//
//}

func TestHistoryStatistic(t *testing.T) {
	oneStepTest(func() {
		log1 := model.ApprovalLog{
			ApprovalJinjianId:"1111",
			ApprovalType:"cs",
			ApprovalName:"初审2000",
			ApprovalStatus:"初审阶段撤销",
			ApprovalDesc:"sss",
		}
		err := log1.Create()
		log2 := model.ApprovalLog{
			ApprovalJinjianId:"1111",
			ApprovalType:"zs",
			ApprovalName:"终审2000",
			ApprovalStatus:"终审拒绝",
			ApprovalDesc:"sss",
		}
		err = log2.Create()
		log3 := model.ApprovalLog{
			ApprovalJinjianId:"5555",
			ApprovalType:"kf",
			ApprovalName:"客服2000",
			ApprovalStatus:"用户拒绝",
			ApprovalDesc:"sss",
		}
		err = log3.Create()
		assert.Equal(t, nil,err)
		// 初审
		c := HistoryStatistic("cs2000", "初审2000", "cs")
		// 终审
		h := HistoryStatistic("zs2000", "终审2000", "zs")
		// 客服
		kfH := HistoryStatistic("kf2000","客服2000","kf")
		fmt.Println(h)
		fmt.Println(kfH)
		fmt.Println(c)

		//assert.Equal(t, 1, kfH.TodayFinishedOrderCount)
		assert.Equal(t, 1, h.TodayFinishedOrderCount)
		assert.Equal(t, 1, c.TodayFinishedOrderCount)
	})
}


func TestHistoryS(t *testing.T){
	oneStepTest(func() {
		if err := config.GetDb().Model(&model.ApprovalOrder{}).Where("first_trail_id = ? and first_trail_name = ? and first_trail_status in (?) and date()", "cs2000", "客服2000", []string{model.ApprovalStatusFirstTrailPass, model.ApprovalStatusFirstTrailRefuse, model.ApprovalStatusCustomCancel}).Error; err != nil {

		}
	})
}
