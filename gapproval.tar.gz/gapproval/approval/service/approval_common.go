package service

import (
	"gapproval/common/httpReq"
	"gapproval/common/global"
	"gcoresys/common/logger"
	"gcoresys/common"
	"gcoresys/common/util"
	"github.com/tidwall/gjson"
	"errors"
	"time"
	"gapproval/approval/model"
	"gcoresys/accounting/grpc/server"
	csModel "gcoresys/accounting/model"
)

// 调用风控接口, 检测 身份证\姓名 是否匹配
func CheckIdCardAndName(orderId string, idCard string, name string) (result string) {

	req := map[string]string{"id": orderId, "card": idCard, "name": name}
	resp, err := httpReq.PostJsonProxy(req, global.GetRiskControlServerUrl()+"/api/v1/id_cards/check")
	if err != nil {
		logger.Error("调用风控系统错误", "err", err.Error())
		return "unmatched"
	}

	logger.Debug("CheckIdCardAndName", "resp", resp)
	r, ok := resp["result"].(string)
	if !ok {
		logger.Warn("身份证号与姓名匹配 返回结果解析错误", "err", resp)
	}
	return r
}

// 根据身份证号码查询身份证户籍地址
func GetPlaceInfoByIdNum(idCard string) (place string) {
	req := map[string]interface{}{"id_card": idCard}
	respResult, err := httpReq.PostJsonProxy(req, global.GetRiskControlServerUrl()+"/api/v1/uniform_interface/GetIDCardPlace")
	if err != nil {
		logger.Error("风控查询身份证户籍地址返回报错", "err", err.Error())
		return
	}

	return util.GetStrFromJson(respResult, "place")
}

// 检查通话记录
func CheckCallRecord(jinjianId, allInfo string) (result bool, err error) {

	if common.GetUseDocker() != 2 {
		return true, nil
	}

	var phoneNum string
	if gjson.Get(allInfo, "call_record.isJump").Bool() {
		phoneNum = gjson.Get(allInfo, "other_call.0.cellphone").Str
	} else {
		phoneNum = gjson.Get(allInfo, "call_record.cellphone").Str
	}

	if phoneNum == "" {
		return false, errors.New("未检查到手机号")
	}

	req := map[string]string{"jin_jian_id": jinjianId, "phone": phoneNum}
	resultResp, err := httpReq.PostJsonProxy(req, global.GetCallCenterUrl()+"/api/v1/records/has_oneself")
	if err != nil {
		logger.Error("========查询通话记录返回结果出错: ", "resp", resultResp, "err", err.Error())
		return false, err
	}

	return resultResp["result"].(bool), nil
}

//==============================================================================

//  创建预审批记录
func AsyncNewPreApprovalLog(log *model.PreApprovalLog) {
	go log.Create()
}

//  transact func 创建审批记录
func AsyncNewApprovalLog(log *model.ApprovalLog) {
	go log.Create()
}

// 异步 审批时间记录
func AsyncApprovalTimeRecord(jinjianId string, trt ...string) {
	go createApprovalTimeRecord(jinjianId, trt...)
}

// 异步创建审批时间记录
func createApprovalTimeRecord(jinjianId string, trt ...string) {
	for _, arg := range trt {
		nowTime := time.Now()
		timeRecord := &model.ApprovalTimeRecord{JinjianId: jinjianId, TimePoint: &nowTime, TimeRecordType: arg}
		timeRecord.Create()
		time.Sleep(100 * time.Millisecond)
	}
}

//  transact func  审批业务留痕
func AsyncApprovalTrace(ao model.ApprovalOrder) {
	go transactApprovalTrace(ao)
}

func transactApprovalTrace(ao model.ApprovalOrder) {
	if common.GetUseDocker() == 0 {
		return
	}
	resultResp, err := httpReq.PostJsonProxy(ao, global.GetRiskControlServerUrl()+"/api/v1/records/approval/order")
	if err != nil {
		logger.Error("========审批业务留痕请求风控出错", "resp", resultResp, "err", err.Error())
		return
	}
}

//==============================================================================

// post core system
func PostCoreSysNewAccount(ao model.ApprovalOrder) (resp *server_grpc.NewAccountResp, err error) {
	var loanAt, firstRepayAt time.Time

	if (ao.FundSide == model.MrOnionFundSide || ao.FundSide == model.YUECAIFundSide || ao.FundSide == model.HAIJINSHEFundSide || ao.FundSide == model.CLFundSide) &&
		ao.LoanAt == nil && ao.SalaryAt == nil {
		loanAt = time.Now()
		firstRepayAt = time.Now()
	} else {
		loanAt = *ao.LoanAt
		firstRepayAt = *ao.SalaryAt
	}

	accountReq := csModel.Account{
		LoanInfo: csModel.LoanInfo{
			UserIdNum:     ao.UserIdNum,
			UserName:      ao.JinjianUserName,
			Cellphone:     ao.Cellphone,
			ContractId:    ao.ContractId,
			LoanAmount:    ao.ApprovedAmount,
			TotalYearRate: ao.ApprovedRate,
			// 平台月利率
			PlatformYearRate:   ao.PlatformMonthRate * 12,
			LoanTerm:           ao.LoanTerm,
			LoanAt:             loanAt,
			FirstRepayAt:       firstRepayAt,
			LoanBankCardNum:    ao.LoanCard,
			LoanBankName:       ao.LoanBankName,
			LoanBindCellphone:  ao.Cellphone,
			RepayBankCardNum:   ao.Card1,
			RepayBankName:      ao.BankName,
			RepayBindCellphone: ao.CardOnePhone,
			ProductId:          ao.ProductId,
			ProductName:        ao.ProductName,
			FundSide:           ao.FundSide, // 2018-01-23 11:59:13  需要添加资金方
		},
	}
	userReq := csModel.User{
		IdNum:     ao.UserIdNum,
		Name:      ao.JinjianUserName,
		Cellphone: ao.Cellphone,
	}
	req := map[string]interface{}{"account": accountReq, "user": userReq}
	respResult, err := httpReq.PostJsonProxyNoCheck(req, global.GetCoreSysUrl()+"/api/v1/account")
	if err != nil {
		return nil, err
	}
	var tmpResp server_grpc.NewAccountResp
	if err = util.ParseJson(respResult, &tmpResp); err != nil {
		logger.Error("核心系统respResult返回", "respResult", respResult)
		logger.Error("解析创建账户出错", "err", err.Error())
		return nil, err
	}
	if !tmpResp.Success {
		return nil, errors.New("核心系统响应success 为false  ," + tmpResp.Info + " ," + tmpResp.ErrorMsg)
	}
	return &tmpResp, err
}

// post fin system
func PostFinSys(req map[string]interface{}) (err error) {
	_, err = httpReq.PostJsonProxy(req, global.GetFinUrl()+"/api/v1/cw/cw_orders/new_order")
	if err != nil {
		logger.Error("========请求财务出错: " + err.Error())
		return err
	}
	return
}
