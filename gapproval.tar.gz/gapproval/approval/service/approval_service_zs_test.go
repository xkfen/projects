package service

import (
	"testing"
	"github.com/stretchr/testify/assert"
	"gapproval/approval/model"
)

func TestReTrailOperationPass(t *testing.T) {
	oneStepTest(func() {
		// 从创建基础订单模型
		ao := model.GetTestCompleteApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
		ao.ReTrailStatus = model.ApprovalStatusWaitReTrail
		ao.ApprovedAmount = 10
		assert.NoError(t, ao.Create())

		threePartyInfo := model.GetDefaultThreePartyInfo()
		threePartyInfo.JinjianId = ao.JinjianId
		assert.NoError(t, threePartyInfo.Create())

		userInfo := model.GetDefaultApprovalUserInfoSup()
		userInfo.JinjianId = ao.JinjianId
		assert.NoError(t, userInfo.Create())

		// 创建基础操作模型
		operation := GetDefaultApprovalOperationZS(ao.JinjianId, model.ApprovalStatusReTrailPass)

		// 执行操作
		assert.NoError(t, operation.Pass())

		// 校验结果
		aR, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, model.ApprovalStatusReTrailPass, aR.ReTrailStatus)
		assert.Equal(t, model.ApprovalStatusWaitCustomConfirm, aR.CustomServiceStatus)
		assert.Equal(t, "客服中", aR.ApprovalStatus)
	})
}

func TestReTrailOperationRefuse(t *testing.T) {
	oneStepTest(func() {
		// 从创建基础订单模型
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
		ao.ReTrailStatus = model.ApprovalStatusWaitReTrail
		assert.NoError(t, ao.Create())

		// 创建基础操作模型
		operation := GetDefaultApprovalOperationZS(ao.JinjianId, model.ApprovalStatusReTrailRefuse)

		// 执行操作
		assert.NoError(t, operation.Refuse())

		// 校验结果
		aR, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, model.ApprovalStatusReTrailRefuse, aR.ReTrailStatus)
		assert.Equal(t, model.AgencyStatusRefuse, aR.AgencyStatus)
		assert.Equal(t, model.ApprovalStatusReTrailRefuse, aR.ApprovalStatus)
	})
}

func TestReTrailOperationBackIv(t *testing.T) {
	oneStepTest(func() {
		// 从创建基础订单模型
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
		ao.ReTrailStatus = model.ApprovalStatusWaitReTrail
		assert.NoError(t, ao.Create())

		// 创建基础操作模型
		operation := GetDefaultApprovalOperationZS(ao.JinjianId, model.ApprovalStatusReTrailBackIv)

		// 执行操作
		assert.NoError(t, operation.BackIv())

		// 校验结果
		aR, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, model.ApprovalStatusReTrailBackIv, aR.ReTrailStatus)
		assert.Equal(t, model.ApprovalStatusReTrailBackIv, aR.InterViewStatus)
		assert.Equal(t, model.ApprovalStatusReTrailBackIv, aR.ApprovalStatus)
	})
}

func TestReTrailOperationCancel(t *testing.T) {
	oneStepTest(func() {
		// 从创建基础订单模型
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
		ao.ReTrailStatus = model.ApprovalStatusWaitReTrail
		assert.NoError(t, ao.Create())

		// 创建基础操作模型
		operation := GetDefaultApprovalOperationZS(ao.JinjianId, model.ApprovalStatusCustomCancel)

		// 执行操作
		assert.NoError(t, operation.Cancel())

		// 校验结果
		aR, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, model.ApprovalStatusCustomCancel, aR.ReTrailStatus)
		assert.Equal(t, "终审阶段撤销", aR.ApprovalStatus)
	})
}

func TestReTrailOperationBack(t *testing.T) {
	oneStepTest(func() {
		// 从创建基础订单模型
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
		ao.ReTrailStatus = model.ApprovalStatusWaitReTrail
		assert.NoError(t, ao.Create())

		// 创建基础操作模型
		operation := GetDefaultApprovalOperationZS(ao.JinjianId, model.ApprovalStatusReTrailBack)

		// 执行操作
		assert.NoError(t, operation.Back())

		// 校验结果
		aR, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, model.ApprovalStatusReTrailBack, aR.ReTrailStatus)
		assert.Equal(t, model.ApprovalStatusReTrailBack, aR.FirstTrailStatus)
		assert.Equal(t, "初审中", aR.ApprovalStatus)
	})
}

func TestReTrailOperationExchange(t *testing.T) {
	oneStepTest(func() {
		// 从创建基础订单模型
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
		ao.ReTrailStatus = model.ApprovalStatusWaitReTrail
		assert.NoError(t, ao.Create())

		// 创建基础操作模型
		operation := GetDefaultApprovalOperationZS(ao.JinjianId, model.ApprovalStatusReTrailExchange)

		// 执行操作
		assert.NoError(t, operation.Exchange())

		// 校验结果
		aR, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, model.ApprovalStatusReTrailExchange, aR.ReTrailStatus)
		assert.Equal(t, operation.ExchangeId, aR.ReTrailId)
		assert.Equal(t, operation.ExchangeName, aR.ReTrailName)
	})
}

func TestReTrailOperationSuspend(t *testing.T) {
	oneStepTest(func() {
		// 从创建基础订单模型
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
		ao.ReTrailStatus = model.ApprovalStatusWaitReTrail
		assert.NoError(t, ao.Create())

		// 创建基础操作模型
		operation := GetDefaultApprovalOperationZS(ao.JinjianId, model.ApprovalSuspend)

		// 执行操作
		assert.NoError(t, operation.Suspend())

		// 校验结果
		aR, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, "on", aR.Suspending)
	})
}
