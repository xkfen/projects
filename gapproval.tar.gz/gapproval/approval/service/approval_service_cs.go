package service

import (
	"gapproval/approval/model"
	"errors"
	"gcoresys/common/logger"
	"time"
)

type ApprovalOperationCS struct {
	JinjianId string `json:"jinjian_id"`
	// 审批操作
	Status string `json:"status"`
	// 操作备注
	StatusDes string `json:"status_des"`
	// 流转账号
	ExchangeId string `json:"exchange_id"`
	// 流转姓名
	ExchangeName string `json:"exchange_name"`
	// 打回数据
	RepulseData string `json:"repulse_data"`
	// 主要原因
	RefuseReason string `json:"refuse_reason"`
	// 外部原因
	ExternalReason string `json:"external_reason"`
}

//  初审操作
func FirstTrailOperation(operation ApprovalOperationCS) (err error) {

	switch operation.Status {
	case model.ApprovalStatusFirstTrailPass:
		return operation.Pass()

	case model.ApprovalStatusFirstTrailBackIv:
		return operation.Back()

	case model.ApprovalStatusFirstTrailRepulse:
		return operation.Repulse()

	case model.ApprovalStatusFirstTrailRefuse:
		return operation.Refuse()

	case model.ApprovalStatusFirstTrailExchange:
		return operation.Exchange()

	case model.ApprovalSuspend:
		return operation.Suspend()

	case model.ApprovalStatusCustomCancel:
		return operation.Cancel()

	default:
		return errors.New("初审不存在该操作:" + operation.Status)
	}
}

func (operation *ApprovalOperationCS) Pass() error {
	if operation.StatusDes == "" {
		return errors.New("备注不能为空")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	if ao.FirstTrailStatus != model.ApprovalStatusWaitFirstTrail && ao.FirstTrailStatus != model.ApprovalStatusFirstTrailExchange && ao.FirstTrailStatus != model.ApprovalStatusReTrailBack {
		logger.Error("==================初审通过状态错误： ", "当前状态: ", ao.InterViewStatus)
		return errors.New("初审当前状态为:" + ao.FirstTrailStatus + ",提交失败")
	}

	if err := ao.FirstTrailPassRule(); err != nil {
		return err
	}

	ao.FirstTrailStatus = operation.Status
	if err := ao.Update(map[string]interface{}{
		"first_trail_status":     operation.Status, // 修改初审状态
		"first_trail_status_des": operation.StatusDes,
		"re_trail_status":        model.ApprovalStatusWaitReTrail, // 开启终审
		"approval_status":        ao.GetAoCurrStatus(),
	}); err != nil {
		return err
	}

	if ao.ReTrailId != "Null" && ao.ReTrailName != "Null" {
		AsyncApprovalTimeRecord(ao.JinjianId, model.TP_CS, model.TP_ZS)
	} else {
		AsyncApprovalTimeRecord(ao.JinjianId, model.TP_CS, model.TP_GRAB_ZS)
	}

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.FirstTrailName,
		ApprovalStatus: operation.Status, ApprovalType: "cs", ApprovalDesc: operation.StatusDes})

	return nil
}

func (operation *ApprovalOperationCS) Refuse() (err error) {
	if operation.StatusDes == "" {
		return errors.New("初审拒绝，备注不能为空")
	}
	if operation.RefuseReason == "" {
		return errors.New("初审拒绝，拒绝原因不能为空")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	if ao.FirstTrailStatus != model.ApprovalStatusWaitFirstTrail && ao.FirstTrailStatus != model.ApprovalStatusFirstTrailExchange && ao.FirstTrailStatus != model.ApprovalStatusReTrailBack {
		logger.Error("==================初审拒绝状态错误： ", "当前状态: ", ao.InterViewStatus)
		return errors.New("初审当前状态为:" + ao.FirstTrailStatus + ",提交失败")
	}
	// 2018-4-12 16:22
	//if err = ao.FirstTrailBaseRule(); err != nil {
	//	return
	//}

	ao.FirstTrailStatus = operation.Status
	if err = ao.Update(map[string]interface{}{
		"first_trail_status":     operation.Status, // 修改初审状态
		"first_trail_status_des": operation.StatusDes,
		"refuse_reason":          operation.RefuseReason,
		"re_trail_status":        model.ApprovalStatusWaitReTrail, // 开启终审
		"approval_status":        ao.GetAoCurrStatus(),
	}); err != nil {
		return
	}

	if ao.ReTrailId != "Null" && ao.ReTrailName != "Null" {
		AsyncApprovalTimeRecord(ao.JinjianId, model.TP_CS, model.TP_ZS)
	} else {
		AsyncApprovalTimeRecord(ao.JinjianId, model.TP_CS, model.TP_GRAB_ZS)
	}

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.FirstTrailName,
		ApprovalStatus: operation.Status, ApprovalType: "cs", ApprovalDesc: operation.StatusDes})

	return nil
}

func (operation *ApprovalOperationCS) Repulse() (err error) {
	if operation.RepulseData == "" {
		return errors.New("打回数据不能为空")
	}
	if operation.StatusDes == "" {
		return errors.New("初审打回状态说明不能为空")
	}
	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	if ao.FirstTrailStatus != model.ApprovalStatusWaitFirstTrail &&
		ao.FirstTrailStatus != model.ApprovalStatusReTrailBack &&
		ao.FirstTrailStatus != model.ApprovalStatusFirstTrailExchange {
		logger.Error("==================初审打回状态错误： ", "当前状态: ", ao.InterViewStatus)
		return errors.New("审批单状态错误，无法打回")
	}
	if ao.FirstTrailStatus == model.ApprovalStatusFirstTrailRepulse {
		err = errors.New("审批单状态已经是初审打回") // 跑不到这里的...
		return
	}

	ao.AgencyStatus = model.AgencyStatusRepulse
	ao.FirstTrailStatus = model.ApprovalStatusFirstTrailRepulse //初审打回
	if err = ao.Update(map[string]interface{}{
		"first_trail_status":         model.ApprovalStatusFirstTrailRepulse, // 修改初审状态
		"first_trail_status_repulse": operation.RepulseData,
		"first_trail_status_des":     operation.StatusDes,
		"repulse_desc":               operation.StatusDes,
		"agency_status":              model.AgencyStatusRepulse,
		"approval_status":            model.ApprovalStatusFirstTrailRepulse,
	}); err != nil {
		return
	}

	// 初审打回时间
	nowTime := time.Now()
	ao.ApprovalRepulseTime = &nowTime

	if err = ao.Update(); err != nil {
		return err
	}

	AsyncApprovalTimeRecord(ao.JinjianId, model.TP_CS, model.TP_USERINPUT)

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.FirstTrailName,
		ApprovalStatus: "初审打回给用户",
		ApprovalType: "cs", ApprovalDesc: ao.FirstTrailStatusDes})

	return nil
}

func (operation *ApprovalOperationCS) Cancel() (err error) {
	if operation.Status != model.ApprovalStatusCustomCancel {
		return errors.New("撤销参数出错，请检查")
	}
	if operation.StatusDes == "" {
		return errors.New("撤销说明不能为空, 请检查")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	if ao.FirstTrailStatus != model.ApprovalStatusWaitFirstTrail && ao.FirstTrailStatus != model.ApprovalStatusFirstTrailExchange && ao.FirstTrailStatus != model.ApprovalStatusReTrailBack {
		logger.Error("==================初审撤销状态错误： ", "当前状态: ", ao.InterViewStatus)
		return errors.New("初审当前状态为:" + ao.FirstTrailStatus + ",提交失败")
	}

	ao.FirstTrailStatus = model.ApprovalStatusCustomCancel
	ao.FirstTrailStatusDes = operation.StatusDes

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.FirstTrailName,
		ApprovalStatus: "初审阶段撤销",
		ApprovalType: "cs", ApprovalDesc: operation.StatusDes})

	ao.AgencyStatus = "已撤销"
	nowTime := time.Now()
	ao.CancelTime = &nowTime
	ao.ApprovalStatus = ao.GetAoCurrStatus()

	if err = ao.Update(); err != nil {
		return err
	}

	// 发短信   撤销
	SendSms(ao, "cancel", true)
	AsyncApprovalTimeRecord(ao.JinjianId, model.TP_CS)

	return nil

}

func (operation *ApprovalOperationCS) Back() (err error) {
	var u = map[string]interface{}{
		"first_trail_status":     model.ApprovalStatusFirstTrailBackIv,
		"inter_view_status":      model.ApprovalStatusFirstTrailBackIv,
		"first_trail_status_des": operation.StatusDes,
		"approval_status":        model.ApprovalStatusFirstTrailBackIv,
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	if ao.FirstTrailStatus != model.ApprovalStatusWaitFirstTrail && ao.FirstTrailStatus != model.ApprovalStatusFirstTrailExchange && ao.FirstTrailStatus != model.ApprovalStatusReTrailBack {
		logger.Error("==================初审退回面签状态错误： ", "当前状态: ", ao.InterViewStatus)
		return errors.New("初审当前状态为:" + ao.FirstTrailStatus + ",提交失败")
	}

	if err = ao.Update(u); err != nil {
		logger.Error("==================初审退回面签操作，UpdateERR：" + err.Error())
		return
	}

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.FirstTrailName,
		ApprovalStatus: "退回面签", ApprovalType: "cs", ApprovalDesc: model.ApprovalStatusFirstTrailBackIv})

	//  时间
	AsyncApprovalTimeRecord(ao.JinjianId, model.TP_CS, model.TP_CS_BACK_IV)

	return nil
}

func (operation *ApprovalOperationCS) Exchange() (err error) {
	if operation.ExchangeName == "" || operation.ExchangeId == "" || operation.ExchangeName == "Null" ||
		operation.ExchangeId == "Null" {
		return errors.New("流转参数出错，请检查")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.FirstTrailName,
		ApprovalStatus: "初审流转给" + operation.ExchangeName, ApprovalType: "cs", ApprovalDesc: operation.StatusDes})

	ao.FirstTrailId = operation.ExchangeId
	ao.FirstTrailName = operation.ExchangeName
	ao.FirstTrailStatus = model.ApprovalStatusFirstTrailExchange
	ao.FirstTrailStatusDes = operation.StatusDes
	ao.ApprovalStatus = ao.GetAoCurrStatus()

	if err = ao.Update(); err != nil {
		return err
	}

	return nil
}

func (operation *ApprovalOperationCS) Suspend() (err error) {
	if operation.StatusDes == "" {
		return errors.New("挂起原因不能为空")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return
	}

	ao.Suspending = "on" // 现在只有开启挂起，解挂在获取订单详情时解挂
	ao.SuspenseDesc = operation.StatusDes

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.FirstTrailName,
		ApprovalStatus: "初审挂起", ApprovalType: "cs", ApprovalDesc: operation.StatusDes})

	ao.ApprovalStatus = ao.GetAoCurrStatus()
	if err = ao.Update(); err != nil {
		logger.Error("==================审批挂起操作，UpdateERR：" + err.Error())
		return
	}

	return nil
}

// 返回初审状态筛选需要的参数
func FirstTrailStatusList(typeKey string, status string) (statusList []string) {
	switch typeKey {
	case "all":
		switch status {
		case model.ApprovalStatusWaitFirstTrail: // 待初审
			statusList = []string{model.ApprovalStatusWaitFirstTrail}
			return statusList
		case model.ApprovalStatusWaitAgencyConfirm: // 待渠道放款
			statusList = []string{model.ApprovalStatusWaitAgencyConfirm}
			return statusList
		case model.ApprovalStatusWaitUserInput: // 待补录数据
			statusList = []string{model.ApprovalStatusWaitUserInput}
			return statusList
		case model.ApprovalStatusWaitInterView: // 待面签
			statusList = []string{model.ApprovalStatusWaitInterView}
			return statusList
		case model.ApprovalStatusInterViewing: // 面签中
			statusList = []string{model.ApprovalStatusInterViewing}
			return statusList
		default:
			statusList = []string{model.ApprovalStatusWaitFirstTrail, model.ApprovalStatusWaitAgencyConfirm,
				model.ApprovalStatusWaitUserInput, model.ApprovalStatusWaitInterView, model.ApprovalStatusInterViewing}
			return statusList
		}
	case "history":
		switch status {
		case model.ApprovalStatusFirstTrailPass: // 初审通过
			statusList = []string{model.ApprovalStatusFirstTrailPass}
			return statusList
		case model.ApprovalStatusFirstTrailRefuse: // 初审拒绝
			statusList = []string{model.ApprovalStatusFirstTrailRefuse}
			return statusList
		case model.ApprovalStatusCustomCancel: // 已撤销
			statusList = []string{model.ApprovalStatusCustomCancel}
			return statusList
		default:
			statusList = []string{model.ApprovalStatusFirstTrailPass, model.ApprovalStatusFirstTrailRefuse, model.ApprovalStatusCustomCancel}
			return statusList
		}
	case "me":
		switch status {
		case model.ApprovalStatusWaitFirstTrail: // 待初审
			statusList = []string{model.ApprovalStatusWaitFirstTrail}
			return statusList
		case model.ApprovalStatusWaitAgencyConfirm: // 待渠道放款
			statusList = []string{model.ApprovalStatusWaitAgencyConfirm}
			return statusList
		case model.ApprovalStatusWaitUserInput: // 待补录数据
			statusList = []string{model.ApprovalStatusWaitUserInput}
			return statusList
		case model.ApprovalStatusFirstTrailExchange: // 初审流转
			statusList = []string{model.ApprovalStatusFirstTrailExchange}
			return statusList
		case model.ApprovalStatusFirstTrailRepulse: // 初审打回
			statusList = []string{model.ApprovalStatusFirstTrailRepulse}
			return statusList
		case model.ApprovalStatusReTrailBack: // 终审退回
			statusList = []string{model.ApprovalStatusReTrailBack}
			return statusList
		default:
			statusList = []string{model.ApprovalStatusWaitFirstTrail, model.ApprovalStatusWaitAgencyConfirm,
				model.ApprovalStatusWaitUserInput, model.ApprovalStatusFirstTrailExchange,
				model.ApprovalStatusFirstTrailRepulse, model.ApprovalStatusReTrailBack}
			return statusList
		}
	case "query":
		switch status {
		case "all":
			statusList = []string{model.ApprovalStatusWaitFirstTrail, model.ApprovalStatusWaitAgencyConfirm,
				model.ApprovalStatusWaitUserInput, model.ApprovalStatusFirstTrailExchange,
				model.ApprovalStatusFirstTrailRepulse, model.ApprovalStatusReTrailBack,
				model.ApprovalStatusFirstTrailPass, model.ApprovalStatusFirstTrailRefuse,
				model.ApprovalStatusCustomCancel, model.ApprovalStatusWaitInterView, model.ApprovalStatusInterViewing}
			return statusList
		case "handling":
			statusList = []string{model.ApprovalStatusWaitFirstTrail, model.ApprovalStatusWaitAgencyConfirm,
				model.ApprovalStatusWaitUserInput, model.ApprovalStatusFirstTrailExchange,
				model.ApprovalStatusFirstTrailRepulse, model.ApprovalStatusReTrailBack}
			return statusList
		case "ending":
			statusList = []string{model.ApprovalStatusCustomCancel}
			return statusList
		}
	}
	return
}