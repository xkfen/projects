package service

import (
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
	"gcoresys/common/util"
	"strings"
	"github.com/jinzhu/gorm"
	"reflect"
	"errors"
	"gapproval/common/tool"
)

type AllPreApprovalFiles struct {
	PreApprovalId string `json:"pre_approval_id"`
	// 征信报告
	CreditFiles []file `json:"credit_files"`
	// 退补件资料
	TuiBuJianFiles []file `json:"tui_bu_jian_files"`
	// 其他文件
	OtherFiles []file `json:"other_files"`
}

// 获取所有文件资料
func GetPreApprovalFiles(preApprovalId string) (files AllPreApprovalFiles, err error) {
	files.PreApprovalId = preApprovalId
	var preFiles []model.ApprovalFile
	if preFiles, err = getFilesFromPreviewStage(preApprovalId); err != nil {
		return
	}
	files = transferFileToFront(preFiles)
	err = getFilesFromCurrentPreApprovalStage(&files, preApprovalId)
	return
}

// 获取所有gpreview阶段的文件
func getFilesFromPreviewStage(preApprovalId string) (preFiles []model.ApprovalFile, err error) {
	var preOrder model.PreApprovalOrder
	if err = config.GetDb().Model(&model.PreApprovalOrder{}).Select("pre_approval_file").Where("pre_approval_id = ?", preApprovalId).First(&preOrder).Error; err != nil {
		logger.Error("err", "根据预审批编号查询预审批订单出错", err.Error())
		return
	}
	if err = util.ParseJson(preOrder.PreApprovalFile, &preFiles); err != nil {
		logger.Error("GetPreApprovalFiles parseJson Failed; error=" + err.Error())
		return
	}
	return
}

// 将文件转换为前端
func transferFileToFront(preFiles []model.ApprovalFile) (allFiles AllPreApprovalFiles) {
	for _, x := range preFiles {
		x.ID = 0 - x.ID
		switch {
		case strings.Contains(x.FileType, "征信"):
			allFiles.CreditFiles = append(allFiles.CreditFiles, file{Id: x.ID, FileType: x.FileType, FilePath: x.FileUrl, Stage: "ysp"})
		default:
			allFiles.OtherFiles = append(allFiles.OtherFiles, file{Id: x.ID, FileType: x.FileType, FilePath: x.FileUrl, Stage: "ysp"})
		}
	}
	return
}

// 获取所有审批阶段文件
func getFilesFromCurrentPreApprovalStage(allFiles *AllPreApprovalFiles, preApprovalId string) (err error) {
	var currentStageFiles []model.ApprovalFile
	if err = config.GetDb().Model(&model.ApprovalFile{}).Where("pre_approval_id = ?", preApprovalId).Find(&currentStageFiles).Error; err != nil && err != gorm.ErrRecordNotFound {
		logger.Error("getFilesFromCurrentPreApprovalStage Find files Failed; error=" + err.Error())
		return
	}
	for _, x := range currentStageFiles {
		rt := reflect.TypeOf(*allFiles)
		rv := reflect.ValueOf(allFiles).Elem()
		for i := 1; i < rt.NumField(); i++ {
			if strings.Contains(rt.Field(i).Tag.Get("json"), x.FileType) {
				var value []file
				if v, ok := rv.Field(i).Interface().([]file); ok {
					value = append(v, file{Id: x.ID, FileType: x.FileType, FilePath: x.FileUrl, Remark: x.Desc, Stage: "sp"})
				}
				rv.Field(i).Set(reflect.ValueOf(value))
			}
		}
	}
	return
}

// 获取所有文件路径, 提供给打包handler
func GetPackCompressedPreApprovalFiles(preApprovalId string) (fileUrls string, err error) {
	var preFiles []model.ApprovalFile

	allFiles, err := GetPreApprovalFiles(preApprovalId)
	if err != nil {
		return
	}

	rt := reflect.TypeOf(allFiles)
	rv := reflect.ValueOf(allFiles)
	for i := 1; i < rt.NumField(); i++ {
		for _, x := range tool.ToSlice(rv.Field(i).Interface()) {
			if url, ok := x.(file); ok {
				if url.Stage == "ysp" {  // 将渠道预审批的路径转换为 Deployment 项目中的配置.
					url.FilePath = strings.Replace(url.FilePath, "/assets", "/preview_assets", 1)
				}
				preFiles = append(preFiles, model.ApprovalFile{PreApprovalId:preApprovalId, FileUrl:url.FilePath})
			}
		}
	}

	if len(preFiles) <= 0 {
		return fileUrls, errors.New("未查询到相关文件，无法压缩")
	}

	return util.StringifyJson(preFiles), nil
}

// 上传预审批文件
func UploadPreApprovalFile(preFile model.ApprovalFile) (err error) {
	if err = preFile.IsValidPreApprovalFile(); err != nil {
		return
	}
	return preFile.Create()
}

// 更新预审批文件
func UpdatePreApprovalFile(stage string, preFile model.ApprovalFile) (err error) {
	if err = preFile.IsValidPreApprovalFile(); err != nil {
		return
	}
	switch stage {
	case "":
		return errors.New("更新预审批文件必须传stage")
	case "ysp":
		var preFiles, files []model.ApprovalFile
		if preFiles, err = getFilesFromPreviewStage(preFile.PreApprovalId); err != nil {
			return
		}
		for _, x := range preFiles {
			if x.ID == preFile.ID {
				files = append(files, preFile)
				continue
			}
			files = append(files, x)
		}
		jsonFile := util.StringifyJson(files)
		if err = config.GetDb().Model(&model.PreApprovalOrder{}).Where("pre_approval_id=?", preFile.PreApprovalId).Update(map[string]interface{}{"pre_approval_file": jsonFile}).Error; err != nil {
			return
		}
	case "sp":
		return preFile.UpdateNew()
	default:
		return errors.New("目前没有此阶段的文件, stage= " + stage)
	}
	return
}

// 删除预审批文件
func DeletePreApprovalFile(stage string, preFile model.ApprovalFile) (err error) {
	switch stage {
	case "":
		return errors.New("删除预审批文件必须传stage")
	case "ysp":
		var preFiles, files []model.ApprovalFile
		if preFiles, err = getFilesFromPreviewStage(preFile.PreApprovalId); err != nil {
			return
		}
		for _, x := range preFiles {
			if x.ID == preFile.ID {
				continue
			}
			files = append(files, x)
		}
		jsonFile := util.StringifyJson(files)
		if err = config.GetDb().Model(&model.PreApprovalOrder{}).Where("pre_approval_id=?", preFile.PreApprovalId).Update(map[string]interface{}{"pre_approval_file": jsonFile}).Error; err != nil {
			return
		}
	case "sp":
		return preFile.Delete()
	default:
		return errors.New("目前没有此阶段的文件, stage= " + stage)
	}
	return
}
