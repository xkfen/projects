package service

import (
	"gapproval/approval/model"
	"errors"
	"gcoresys/common/logger"
	"time"
)

type ApprovalOperationZS struct {
	JinjianId string `json:"jinjian_id"`
	// 审批操作
	Status string `json:"status"`
	// 操作备注
	StatusDes string `json:"status_des"`
	// 流转账号
	ExchangeId string `json:"exchange_id"`
	// 流转姓名
	ExchangeName string `json:"exchange_name"`
	// 主要原因
	RefuseReason string `json:"refuse_reason"`
	// 外部原因
	ExternalReason string `json:"external_reason"`
	// 发送消息开关
	SendUserMsgSwitch bool `json:"send_user_msg_switch"`
	// 海金社用到以下字段
	// 风险等级
	RiskLevel string `json:"risk_level"`
	// 风险结论
	RiskResult string `json:"risk_result"`
}

//  终审操作
func ReTrailOperation(operation ApprovalOperationZS) (err error) {

	switch operation.Status {

	case model.ApprovalStatusReTrailPass:
		return operation.Pass()

	case model.ApprovalStatusReTrailBackIv: // "终审退回面签"
		return operation.BackIv()

	case model.ApprovalStatusReTrailBack: // "终审打回初审"
		return operation.Back()

	case model.ApprovalStatusReTrailRefuse: // "终审拒绝"
		return operation.Refuse()

	case model.ApprovalStatusReTrailExchange:
		return operation.Exchange()

	case model.ApprovalSuspend:
		return operation.Suspend()

	case model.ApprovalStatusCustomCancel:
		return operation.Cancel()

	default:
		return errors.New("终审不存在该操作:" + operation.Status)
	}
}

//  终审通过
func (operation *ApprovalOperationZS) Pass() error {
	if operation.StatusDes == "" {
		return errors.New("备注不能为空")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}
	if ao.FundSide == model.HAIJINSHEFundSide { // 海金社的情况下
		if operation.RiskLevel == "" || operation.RiskResult == "" {
			return errors.New("风险等级 和 风险结论 不能为空")
		}
	}

	if ao.ReTrailStatus != model.ApprovalStatusWaitReTrail && ao.ReTrailStatus != model.ApprovalStatusReTrailExchange && ao.ReTrailStatus != model.ApprovalStatusCustomServiceBack && ao.ReTrailStatus != model.ApprovalStatusFinanceBack {
		logger.Error("==================终审通过状态错误： ", "当前状态: ", ao.ReTrailStatus)
		return errors.New("终审当前状态为:" + ao.ReTrailStatus + ",提交失败")
	}

	ao.ReTrailStatusDes = operation.StatusDes
	if err := ao.RtPassRuleByFundSide(); err != nil {
		return err
	}

	nowTime := time.Now()
	ao.ReTrailStatus = operation.Status // 因为ao.GetAoCurrStatus方法要校验ReTrailStatus, 所以要提前更新掉
	if err := ao.Update(map[string]interface{}{
		"re_trail_status":       operation.Status, // 修改终审状态
		"re_trail_status_des":   operation.StatusDes,
		"custom_service_status": model.ApprovalStatusWaitCustomConfirm, // 开启客服
		"approval_pass_time":    &nowTime,
		"agency_status":         model.AgencyStatusPass,
		"risk_level":            operation.RiskLevel,
		"risk_result":           operation.RiskResult,
		"approval_status":       ao.GetAoCurrStatus(), // 这个方法不太适应新版,最好重写下
	}); err != nil {
		return err
	}

	if ao.CustomServiceId != "Null" && ao.CustomServiceName != "Null" {
		AsyncApprovalTimeRecord(ao.JinjianId, model.TP_ZS, model.TP_KF)
	} else {
		AsyncApprovalTimeRecord(ao.JinjianId, model.TP_ZS, model.TP_GRAB_KF)
	}

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.ReTrailName,
		ApprovalStatus: operation.Status, ApprovalType: "zs", ApprovalDesc: operation.StatusDes})

	// 发短信   通过
	SendSms(ao, "pass", operation.SendUserMsgSwitch)
	return nil
}

// 终审拒绝
func (operation *ApprovalOperationZS) Refuse() error {
	if operation.StatusDes == "" {
		return errors.New("备注不能为空")
	}

	if operation.RefuseReason == "" {
		return errors.New("拒绝原因不能为空")
	}

	if operation.ExternalReason == "" {
		return errors.New("拒绝外部原因不能为空")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	if ao.ReTrailStatus != model.ApprovalStatusWaitReTrail && ao.ReTrailStatus != model.ApprovalStatusReTrailExchange && ao.ReTrailStatus != model.ApprovalStatusCustomServiceBack && ao.ReTrailStatus != model.ApprovalStatusFinanceBack {
		logger.Error("==================终审拒绝状态错误： ", "当前状态: ", ao.ReTrailStatus)
		return errors.New("终审当前状态为:" + ao.ReTrailStatus + ",提交失败")
	}

	nowTime := time.Now()
	ao.ReTrailStatus = operation.Status // 因为ao.GetAoCurrStatus方法要校验ReTrailStatus, 所以要提前更新掉
	if err := ao.Update(map[string]interface{}{
		"re_trail_status":      operation.Status, // 修改终审状态 终审拒绝
		"re_trail_status_des":  operation.StatusDes,
		"refuse_reason":        operation.RefuseReason,
		"external_reason":      operation.ExternalReason,
		"agency_status":        model.AgencyStatusRefuse,
		"approval_refuse_time": &nowTime,
		"approval_status":      ao.GetAoCurrStatus(), // 这个方法不太适应新版,最好重写下
	}); err != nil {
		return err
	}

	AsyncApprovalTimeRecord(ao.JinjianId, model.TP_ZS)

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.ReTrailName,
		ApprovalStatus: operation.Status, ApprovalType: "zs", ApprovalDesc: operation.StatusDes})

	// 发短信   拒绝
	SendSms(ao, "refuse", operation.SendUserMsgSwitch)

	return nil
}

// 终审退回面签
func (operation *ApprovalOperationZS) BackIv() error {
	if operation.StatusDes == "" {
		return errors.New("备注不能为空")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	if ao.ReTrailStatus != model.ApprovalStatusWaitReTrail && ao.ReTrailStatus != model.ApprovalStatusReTrailExchange && ao.ReTrailStatus != model.ApprovalStatusCustomServiceBack && ao.ReTrailStatus != model.ApprovalStatusFinanceBack {
		logger.Error("==================终审拒绝状态错误： ", "当前状态: ", ao.ReTrailStatus)
		return errors.New("终审当前状态为:" + ao.ReTrailStatus + ",提交失败")
	}

	ao.ReTrailStatus = operation.Status // 因为ao.GetAoCurrStatus方法要校验ReTrailStatus, 所以要提前更新掉
	if err := ao.Update(map[string]interface{}{
		"re_trail_status":     operation.Status, // 修改终审状态 终审退回给面签
		"re_trail_status_des": operation.StatusDes,
		"inter_view_status":   operation.Status, // 修改面签状态 终审退回给面签
		"approval_status":     model.ApprovalStatusReTrailBackIv,
	}); err != nil {
		return err
	}

	AsyncApprovalTimeRecord(ao.JinjianId, model.TP_ZS, model.TP_ZS_BACK_IV)

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.ReTrailName,
		ApprovalStatus: operation.Status, ApprovalType: "zs", ApprovalDesc: operation.StatusDes})

	return nil
}

// 已撤销
func (operation *ApprovalOperationZS) Cancel() error {

	if operation.StatusDes == "" {
		return errors.New("备注不能为空")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	// 不是正常进行中的终审单,不能执行撤销操作
	if ao.ReTrailStatus != model.ApprovalStatusWaitReTrail && ao.ReTrailStatus != model.ApprovalStatusReTrailExchange && ao.ReTrailStatus != model.ApprovalStatusCustomServiceBack && ao.ReTrailStatus != model.ApprovalStatusFinanceBack {
		logger.Error("==================终审撤销状态错误： ", "当前状态: ", ao.ReTrailStatus)
		return errors.New("终审当前状态为:" + ao.ReTrailStatus + ",提交失败")
	}

	ao.ReTrailStatus = operation.Status // 因为ao.GetAoCurrStatus方法要校验ReTrailStatus, 所以要提前更新掉
	if err := ao.Update(map[string]interface{}{
		"re_trail_status":     operation.Status, // 修改终审状态
		"re_trail_status_des": operation.StatusDes,
		"approval_status":     "终审阶段撤销",
	}); err != nil {
		return err
	}

	// 原逻辑中撤销操作没有状态记录,所以注释掉
	//model.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.ReTrailName,
	//	ApprovalStatus: operation.Status, ApprovalType: "zs", ApprovalDesc: operation.StatusDes})

	return nil
}

// 终审退回
func (operation *ApprovalOperationZS) Back() error {

	if operation.StatusDes == "" {
		return errors.New("终审退回说明不能为空")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	if ao.ReTrailStatus != model.ApprovalStatusWaitReTrail && ao.ReTrailStatus != model.ApprovalStatusReTrailExchange && ao.ReTrailStatus != model.ApprovalStatusCustomServiceBack && ao.ReTrailStatus != model.ApprovalStatusFinanceBack {
		logger.Error("==================终审退回状态错误： ", "当前状态: ", ao.ReTrailStatus)
		return errors.New("终审当前状态为:" + ao.ReTrailStatus + ",提交失败")
	}

	ao.FirstTrailStatus = operation.Status // 因为ao.GetAoCurrStatus方法要校验ReTrailStatus, 所以要提前更新掉
	ao.ReTrailStatus = operation.Status
	if err := ao.Update(map[string]interface{}{
		"re_trail_status":     operation.Status, // 修改终审状态为终审退回
		"re_trail_status_des": operation.StatusDes,
		"first_trail_status":  operation.Status, // 修改初审状态为终审退回
		"approval_status":     "初审中",
	}); err != nil {
		return err
	}

	AsyncApprovalTimeRecord(ao.JinjianId, model.TP_ZS, model.TP_CS)

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.ReTrailName,
		ApprovalStatus: "终审退回给" + ao.FirstTrailName, ApprovalType: "zs", ApprovalDesc: operation.StatusDes})

	return nil
}

// 终审流转
func (operation *ApprovalOperationZS) Exchange() error {
	if operation.StatusDes == "" {
		return errors.New("备注不能为空")
	}
	if operation.ExchangeId == "" || operation.ExchangeId == "Null" {
		return errors.New("流转账号不能为空")
	}
	if operation.ExchangeName == "" || operation.ExchangeName == "Null" {
		return errors.New("流转姓名不能为空")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	if ao.ReTrailStatus != model.ApprovalStatusWaitReTrail && ao.ReTrailStatus != model.ApprovalStatusReTrailExchange && ao.ReTrailStatus != model.ApprovalStatusCustomServiceBack && ao.ReTrailStatus != model.ApprovalStatusFinanceBack {
		logger.Error("==================终审流转状态错误： ", "当前状态: ", ao.ReTrailStatus)
		return errors.New("终审当前状态为:" + ao.ReTrailStatus + ",提交失败")
	}

	ao.ReTrailStatus = operation.Status // 因为ao.GetAoCurrStatus方法要校验ReTrailStatus, 所以要提前更新掉
	if err := ao.Update(map[string]interface{}{
		"re_trail_status":     operation.Status, // 修改终审状态 终审流转
		"re_trail_status_des": operation.StatusDes,
		"re_trail_id":         operation.ExchangeId,
		"re_trail_name":       operation.ExchangeName,
	}); err != nil {
		return err
	}

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.ReTrailName,
		ApprovalStatus: operation.Status, ApprovalType: "zs", ApprovalDesc: operation.StatusDes})

	return nil
}

// 挂起
func (operation *ApprovalOperationZS) Suspend() error {
	if operation.StatusDes == "" {
		return errors.New("挂起原因不能为空")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	if err := ao.Update(map[string]interface{}{
		"suspending":    "on", // 修改终审状态 挂起
		"suspense_desc": operation.StatusDes,
	}); err != nil {
		return err
	}

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.ReTrailName,
		ApprovalStatus: "终审挂起", ApprovalType: "zs", ApprovalDesc: operation.StatusDes})

	return nil
}


// 返回终审状态筛选需要的参数
func ReTrailStatusList(typeKey string, status string) (statusList []string) {
	switch typeKey {
	case "all":
		switch status {
		case model.ApprovalStatusWaitReTrail: // 待终审
			statusList = []string{model.ApprovalStatusWaitReTrail}
			return statusList
		default:
			statusList = []string{model.ApprovalStatusWaitReTrail}
			return statusList
		}
	case "history":
		switch status {
		case model.ApprovalStatusReTrailPass: // 终审通过
			statusList = []string{model.ApprovalStatusReTrailPass}
			return statusList
		case model.ApprovalStatusReTrailRefuse: // 终审拒绝
			statusList = []string{model.ApprovalStatusReTrailRefuse}
			return statusList
		case model.ApprovalStatusCustomCancel: // 已撤销
			statusList = []string{model.ApprovalStatusCustomCancel}
			return statusList
		default:
			statusList = []string{model.ApprovalStatusReTrailPass, model.ApprovalStatusReTrailRefuse, model.ApprovalStatusCustomCancel}
			return statusList
		}
	case "me":
		switch status {
		case model.ApprovalStatusWaitReTrail: // 待终审
			statusList = []string{model.ApprovalStatusWaitReTrail}
			return statusList
		case model.ApprovalStatusReTrailExchange: // 终审流转
			statusList = []string{model.ApprovalStatusReTrailExchange}
			return statusList
		case model.ApprovalStatusCustomServiceBack: // 客服退回
			statusList = []string{model.ApprovalStatusCustomServiceBack}
			return statusList
		case model.ApprovalStatusFinanceBack: // 财务退回
			statusList = []string{model.ApprovalStatusFinanceBack}
			return statusList
		case model.ApprovalStatusReTrailFinish: // 待上传合同
			statusList = []string{model.ApprovalStatusReTrailFinish}
			return statusList
		default:
			statusList = []string{model.ApprovalStatusWaitReTrail, model.ApprovalStatusReTrailExchange,
				model.ApprovalStatusCustomServiceBack, model.ApprovalStatusFinanceBack, model.ApprovalStatusReTrailFinish}
			return statusList
		}
	case "query":
		switch status {
		case "all":
			statusList = []string{model.ApprovalStatusWaitReTrail, model.ApprovalStatusReTrailExchange,
				model.ApprovalStatusCustomServiceBack, model.ApprovalStatusReTrailPass,
				model.ApprovalStatusReTrailRefuse, model.ApprovalStatusCustomCancel, model.ApprovalStatusFinanceBack}
			return statusList
		case "handling":
			statusList = []string{model.ApprovalStatusWaitReTrail, model.ApprovalStatusReTrailExchange,
				model.ApprovalStatusCustomServiceBack, model.ApprovalStatusFinanceBack, model.ApprovalStatusReTrailFinish}
			return statusList
		case "ending":
			statusList = []string{model.ApprovalStatusReTrailRefuse, model.ApprovalStatusCustomCancel}
			return statusList
		}
	}
	return
}