package service

import (
	"testing"
	"github.com/stretchr/testify/assert"
	"gapproval/approval/model"
)

func TestFirstTrailOperationPass(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetTestCompleteApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
		assert.NoError(t, ao.Create())

		info := model.GetDefaultThreePartyInfo()
		info.JinjianId = ao.JinjianId
		assert.NoError(t, info.Create())

		userinfo := model.GetDefaultApprovalUserInfoSup()
		userinfo.JinjianId = ao.JinjianId
		assert.NoError(t, userinfo.Create())

		operation := GetTestApprovalOperationCS("pass")
		operation.JinjianId = ao.JinjianId
		assert.NoError(t, FirstTrailOperation(operation))

		changedAo, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, model.ApprovalStatusWaitReTrail, changedAo.ReTrailStatus)
		assert.Equal(t, model.ApprovalStatusFirstTrailPass, changedAo.FirstTrailStatus)
		assert.Equal(t, operation.StatusDes, changedAo.FirstTrailStatusDes)
		assert.Equal(t, "终审中", changedAo.ApprovalStatus)
	})
}

func TestFirstTrailOperationRefuse(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetTestCompleteApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
		assert.NoError(t, ao.Create())

		info := model.GetDefaultThreePartyInfo()
		info.JinjianId = ao.JinjianId
		assert.NoError(t, info.Create())

		userinfo := model.GetDefaultApprovalUserInfoSup()
		userinfo.JinjianId = ao.JinjianId
		assert.NoError(t, userinfo.Create())

		operation := GetTestApprovalOperationCS("refuse")
		operation.JinjianId = ao.JinjianId
		assert.NoError(t, FirstTrailOperation(operation))

		changedAo, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, model.ApprovalStatusWaitReTrail, changedAo.ReTrailStatus)
		assert.Equal(t, model.ApprovalStatusFirstTrailRefuse, changedAo.FirstTrailStatus)
		assert.Equal(t, operation.StatusDes, changedAo.FirstTrailStatusDes)
		assert.Equal(t, "终审中", changedAo.ApprovalStatus)
	})
}

func TestFirstTrailOperationRepulse(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetTestCompleteApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
		assert.NoError(t, ao.Create())

		info := model.GetDefaultThreePartyInfo()
		info.JinjianId = ao.JinjianId
		assert.NoError(t, info.Create())

		userinfo := model.GetDefaultApprovalUserInfoSup()
		userinfo.JinjianId = ao.JinjianId
		assert.NoError(t, userinfo.Create())

		operation := GetTestApprovalOperationCS("repulse")
		operation.JinjianId = ao.JinjianId
		assert.NoError(t, FirstTrailOperation(operation))

		changedAo, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, "Null", changedAo.ReTrailStatus)
		assert.Equal(t, model.ApprovalStatusFirstTrailRepulse, changedAo.FirstTrailStatus)
		assert.Equal(t, operation.StatusDes, changedAo.FirstTrailStatusDes)
		assert.Equal(t, "初审打回", changedAo.ApprovalStatus)
	})
}

func TestFirstTrailOperationCancel(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetTestCompleteApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
		assert.NoError(t, ao.Create())

		info := model.GetDefaultThreePartyInfo()
		info.JinjianId = ao.JinjianId
		assert.NoError(t, info.Create())

		userinfo := model.GetDefaultApprovalUserInfoSup()
		userinfo.JinjianId = ao.JinjianId
		assert.NoError(t, userinfo.Create())

		operation := GetTestApprovalOperationCS("cancel")
		operation.JinjianId = ao.JinjianId
		assert.NoError(t, FirstTrailOperation(operation))

		changedAo, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, "Null", changedAo.ReTrailStatus)
		assert.Equal(t, model.ApprovalStatusCustomCancel, changedAo.FirstTrailStatus)
		assert.Equal(t, operation.StatusDes, changedAo.FirstTrailStatusDes)
		assert.Equal(t, "撤销", changedAo.ApprovalStatus)
	})
}

func TestFirstTrailOperationBack(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetTestCompleteApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
		assert.NoError(t, ao.Create())

		info := model.GetDefaultThreePartyInfo()
		info.JinjianId = ao.JinjianId
		assert.NoError(t, info.Create())

		userinfo := model.GetDefaultApprovalUserInfoSup()
		userinfo.JinjianId = ao.JinjianId
		assert.NoError(t, userinfo.Create())

		operation := GetTestApprovalOperationCS("back")
		operation.JinjianId = ao.JinjianId
		assert.NoError(t, FirstTrailOperation(operation))

		changedAo, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, "Null", changedAo.ReTrailStatus)
		assert.Equal(t, model.ApprovalStatusFirstTrailBackIv, changedAo.FirstTrailStatus)
		assert.Equal(t, model.ApprovalStatusFirstTrailBackIv, changedAo.InterViewStatus)
		assert.Equal(t, operation.StatusDes, changedAo.FirstTrailStatusDes)
		assert.Equal(t, "初审退回面签", changedAo.ApprovalStatus)
	})
}

func TestFirstTrailOperationExchange(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetTestCompleteApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
		assert.NoError(t, ao.Create())

		info := model.GetDefaultThreePartyInfo()
		info.JinjianId = ao.JinjianId
		assert.NoError(t, info.Create())

		userinfo := model.GetDefaultApprovalUserInfoSup()
		userinfo.JinjianId = ao.JinjianId
		assert.NoError(t, userinfo.Create())

		operation := GetTestApprovalOperationCS("exchange")
		operation.JinjianId = ao.JinjianId
		assert.NoError(t, FirstTrailOperation(operation))

		changedAo, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, "Null", changedAo.ReTrailStatus)
		assert.Equal(t, model.ApprovalStatusFirstTrailExchange, changedAo.FirstTrailStatus)
		assert.Equal(t, operation.StatusDes, changedAo.FirstTrailStatusDes)
		assert.Equal(t, "初审中", changedAo.ApprovalStatus)
		assert.Equal(t, operation.ExchangeId, changedAo.FirstTrailId)
		assert.Equal(t, operation.ExchangeName, changedAo.FirstTrailName)
		assert.Equal(t, "off", changedAo.Suspending)
	})
}

func TestFirstTrailOperationSuspend(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetTestCompleteApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
		assert.NoError(t, ao.Create())

		info := model.GetDefaultThreePartyInfo()
		info.JinjianId = ao.JinjianId
		assert.NoError(t, info.Create())

		userinfo := model.GetDefaultApprovalUserInfoSup()
		userinfo.JinjianId = ao.JinjianId
		assert.NoError(t, userinfo.Create())

		operation := GetTestApprovalOperationCS("suspend")
		operation.JinjianId = ao.JinjianId
		assert.NoError(t, FirstTrailOperation(operation))

		changedAo, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, "Null", changedAo.ReTrailStatus)
		assert.Equal(t, ao.FirstTrailStatus, changedAo.FirstTrailStatus)
		assert.Equal(t, "on", changedAo.Suspending)
		assert.Equal(t, operation.StatusDes, changedAo.SuspenseDesc)
		assert.Equal(t, "初审中", changedAo.ApprovalStatus)
	})
}
