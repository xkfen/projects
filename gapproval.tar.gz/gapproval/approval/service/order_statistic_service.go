package service

import (
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
	"github.com/jinzhu/gorm"
	"time"
	"gcoresys/common/util"
)

// *******************订单概括*****************
// 用于返回"订单概括"里的统计数据
type OrderGeneralization struct {
	// 待分配订单
	ToBeAssignCount int `json:"to_be_assign_count"`
	// 我的待办订单
	MyToDoOrderCount int `json:"my_to_do_order_count"`
	// 挂起订单
	SuspendCount int `json:"suspend_count"`
	// 回退订单
	ReturnCount int `json:"return_count"`
	// 预审打回订单
	PreRepulseCount int `json:"pre_repulse_count"`
}

// ×××××××××××统计历史订单×××××××××××××××××××
type HistoryOrderCount struct {
	// 今日完成订单
	TodayFinishedOrderCount int `json:"today_finished_order_count"`
	// 所有完成订单
	AllFinishedOrderCount int `json:"all_finished_order_count"`
}

// 订单概括统计
func StatisticOrderCount(userId, name, approvalType string) (info OrderGeneralization, err error) {
	return queryOrderCount(userId, name, approvalType)
}

// 查询订单数量
func queryOrderCount(userId, name, approvalType string) (info OrderGeneralization, err error) {
	logger.Debug("----" + approvalType + "- -----订单概括----------------")
	preBaseSql := config.GetDb().Model(&model.PreApprovalOrder{})
	appBaseSql := config.GetDb().Model(&model.ApprovalOrder{})
	switch approvalType {
	// 预审
	case "ys":
		// 待办订单
		if err = preBaseSql.Where("pre_approval_status in (?) AND pre_trail_id = 'Null' AND pre_trail_name = 'Null'", []string{model.WAITPREAPPROVAL}).Count(&info.ToBeAssignCount).Error; err != nil {
			logger.Error("err", "查询[预审][所有待办订单出错]", err.Error())
		}
		// 我的待办订单
		if err = preBaseSql.Where("pre_approval_status in (?) AND pre_trail_id = ? AND pre_trail_name = ?", []string{model.WAITPREAPPROVAL, model.PREAPPROVALREPULSE, model.PREAPPROVALING}, userId, name).Count(&info.MyToDoOrderCount).Error; err != nil {
			logger.Error("err", "查询[预审][我的待办订单]出错", err.Error())
		}
		// 预审打回订单
		if err = preBaseSql.Where("pre_approval_status in (?) AND pre_trail_id = ? AND pre_trail_name = ?", model.PREAPPROVALREPULSE, userId, name).Count(&info.PreRepulseCount).Error; err != nil {
			logger.Error("err", "查询[预审][预审打回订单]出错", err.Error())
		}
		// 初审
	case "cs":
		// 待办订单
		if err = appBaseSql.Where("first_trail_status in (?) AND first_trail_id = 'Null' AND first_trail_name = 'Null'",
			model.ApprovalStatusWaitFirstTrail).Count(&info.ToBeAssignCount).Error; err != nil {
			logger.Error("err", "查询[初审][所有待办订单出错]", err.Error())
		}
		// 我的待办订单
		if err = appBaseSql.Where("first_trail_status in (?) AND first_trail_id = ? AND first_trail_name = ?",
			FirstTrailStatusList("me", ""), userId, name).Count(&info.MyToDoOrderCount).Error; err != nil {
			logger.Error("err", "查询[初审][我的待办订单出错]", err.Error())
		}
		// 挂起订单
		if err = appBaseSql.Where("first_trail_status in (?) AND suspending in (?) AND first_trail_id = ? AND first_trail_name = ?", FirstTrailStatusList("me", ""),
			model.Suspend, userId, name).Count(&info.SuspendCount).Error; err != nil {
			logger.Error("err", "查询[初审][挂起订单出错]", err.Error())
		}
		// 回退订单
		if err = appBaseSql.Where("first_trail_status in (?) AND first_trail_id = ? AND first_trail_name = ?", model.ApprovalStatusReTrailBack, userId, name).Count(&info.ReturnCount).Error; err != nil {
			logger.Error("err", "查询[初审][回退订单出错]", err.Error())
		}
		// 终审
	case "zs":
		// 待办订单:待终审，初审拒绝
		if err = appBaseSql.Where("re_trail_status in (?) AND re_trail_id = 'Null' AND re_trail_name = 'Null'",
			[]string{model.ApprovalStatusWaitReTrail}).Count(&info.ToBeAssignCount).Error; err != nil && err != gorm.ErrRecordNotFound {
			logger.Error("err", "查询[终审][所有待办订单出错]", err.Error())
		}
		// 我的待办订单
		if err = appBaseSql.Where("re_trail_status in (?) AND re_trail_id = ? AND re_trail_name = ?",
			ReTrailStatusList("me", ""), userId, name).Count(&info.MyToDoOrderCount).Error; err != nil {
			logger.Error("err", "查询[终审][我的待办订单出错]", err.Error())
		}
		// 挂起订单
		if err = appBaseSql.Where("re_trail_status in (?) AND suspending in (?) AND re_trail_id = ? AND re_trail_name = ?", ReTrailStatusList("me", ""), model.Suspend, userId, name).Count(&info.SuspendCount).Error; err != nil {
			logger.Error("err", "查询[终审][挂起订单出错]", err.Error())
		}
		// 回退订单
		if err = appBaseSql.Where("re_trail_status in (?) AND re_trail_id = ? AND re_trail_name = ? ", []string{model.ApprovalStatusCustomServiceBack, model.ApprovalStatusFinanceBack}, userId, name).Count(&info.ReturnCount).Error; err != nil && err != gorm.ErrRecordNotFound {
			logger.Error("err", "查询[终审][回退订单出错]", err.Error())
		}
		// 客服
	case "kf":
		// 待办订单
		if err = appBaseSql.Where("custom_service_status in (?) AND custom_service_id = 'Null' AND custom_service_name = 'Null'", model.ApprovalStatusWaitCustomConfirm).Count(&info.ToBeAssignCount).Error; err != nil {
			logger.Error("err", "查询[客服][所有待办订单出错]", err.Error())
		}
		// 我的待办订单
		if err = appBaseSql.Where("custom_service_status in (?) AND custom_service_id = ? AND custom_service_name = ?", CustomServiceStatusList("me", ""), userId, name).Count(&info.MyToDoOrderCount).Error; err != nil {
			logger.Error("err", "查询[客服][我的待办订单出错]", err.Error())
		}
		// 挂起订单
		if err = appBaseSql.Where("custom_service_status in (?) AND  suspending in (?) AND custom_service_id = ? AND custom_service_name = ?", CustomServiceStatusList("me", ""), model.Suspend, userId, name).Count(&info.SuspendCount).Error; err != nil {
			logger.Error("err", "查询[客服][挂起订单出错]", err.Error())
		}
	default:
		logger.Error("msg", "err", "传入的审批状态有误")
	}
	return
}

// 预审批/审批完成订单状态
func getFinishedApprovalStatus(approvalType string) (status []string) {
	switch approvalType {
	// 预审批:通过，拒绝，撤销
	case "ys":
		status = []string{model.PREAPPROVALPASS, model.PREAPPROVALREFUSE, model.PREAPPROVALCANCEL}
		return
		// 审批---初审:初审通过，初审拒绝，客户已撤销ApprovalStatusFirstTrailPass, ApprovalStatusFirstTrailRefuse,ApprovalStatusCustomCancel
	case "cs":
		//status = []string{model.ApprovalStatusFirstTrailRefuse, model.ApprovalStatusFirstTrailPass, model.ApprovalStatusCustomCancel}
		status = []string{"初审通过", "初审拒绝", "初审阶段撤销"}
		return
		// 	审批--终审:终审通过，终审拒绝，已撤销
	case "zs":
		//	status = []string{model.ApprovalStatusReTrailPass, model.ApprovalStatusReTrailRefuse, model.ApprovalStatusCustomCancel}
		status = []string{"终审拒绝", "终审通过", "终审阶段撤销"}
		return
		//  审批--客服:客户接受, 客户拒绝, 已撤销, 财务退回
	case "kf":
		//	status = []string{model.ApprovalStatusCustomPass, model.ApprovalStatusCustomRefuse, model.ApprovalStatusCustomCancel, model.ApprovalStatusFinanceBack}
		status = []string{"用户接受", "用户拒绝", "客服阶段撤销"}
		return
	}
	return
}

type AllHistory struct {
	AllCount int `json:"all_count"`
}
type TodayHistory struct {
	TodayCount int `json:"today_count"`
}

/**
审批全部完成订单统计是统计的approval_logs表。因为approval_orders表里面没有存放cs/zs/kf完成的时间。
由于approval_logs表里面是每个订单的操作记录都会存在，所以应该按照进件id分组，并且根据当前账户取相同进件id的最大id，再加上筛选的订单状态条件.
cs订单状态在approval_logs分别对应：初审通过，初审拒绝，初审阶段撤销
zs订单状态在approval_logs分别对应：终审通过，终审拒绝，终审阶段撤销
kf订单状态在approval_logs分别对应：用户接受，用户拒绝，客服阶段撤销，kf阶段还应该包括财务退回
 */
// 历史订单统计
func HistoryStatistic(userId, userName, approvalType string) (history HistoryOrderCount) {
	logger.Debug("---" + approvalType + "----历史订单统计----")
	preBaseSql := config.GetDb().Model(&model.PreApprovalOrder{}).Where("pre_approval_status IN (?) AND pre_trail_id = ? AND pre_trail_name = ?", getFinishedApprovalStatus("ys"), userId, userName)
	todayTime := time.Now()
	// 将当前时间转换为不包含十分秒的日期
	today := util.GetDate(todayTime)
	//var all AllHistory
	var t TodayHistory
	switch approvalType {
	case "ys":
		// 所有完成订单
		 if err := preBaseSql.Count(&history.AllFinishedOrderCount).Error; err != nil {
		 	logger.Error("err", "预审批查询全部完成订单出错", err.Error())
		 }
		// 今日完成订单
		 if err := preBaseSql.Where(" DATE(updated_at) = ? ", today).Count(&history.TodayFinishedOrderCount).Error; err != nil {
		 	logger.Error("err", "预审批查询今日完成订单出错", err.Error())
		 }
	case "cs":
		// 今日完成订单
		//if err := config.GetDb().Raw("SELECT  count(1) FROM approval_logs WHERE id IN (SELECT MAX(id) FROM approval_logs WHERE   approval_name = ? GROUP BY approval_jinjian_id HAVING approval_status IN (?) AND DATE(updated_at) = ? ) ", userName, getFinishedApprovalStatus("cs"),  today).Scan(&t).Error; err != nil {
		//	logger.Error("err", "cs 查询今日完成订单出错", err.Error())
		//}
		if err := config.GetDb().Raw("SELECT count(distinct approval_jinjian_id) as today_count FROM approval_logs WHERE approval_name = ?  and  approval_status IN (?)  AND DATE(updated_at) = ? ", userName, getFinishedApprovalStatus("cs"),  today).Scan(&t).Error; err != nil {
			logger.Error("err", "cs 查询今日完成订单出错", err.Error())
		}
		history.TodayFinishedOrderCount = t.TodayCount
		// 所有完成订单
		//if err := config.GetDb().Raw("SELECT count(1)  as all_count FROM approval_logs WHERE id IN (SELECT MAX(id) FROM approval_logs WHERE approval_name = ?  GROUP BY approval_jinjian_id HAVING approval_status IN (?)) ",userName, getFinishedApprovalStatus("cs")).Scan(&all).Error; err != nil {
		//	logger.Error("err", "cs 全部完成订单出错", err.Error())
		//}
		//history.AllFinishedOrderCount = all.AllCount
	case "zs":
		// 今日完成订单
		//if err := config.GetDb().Raw("SELECT count(1) as today_count  FROM approval_logs WHERE id IN (SELECT max(id) FROM approval_logs WHERE approval_name = ?  GROUP BY approval_jinjian_id HAVING approval_status IN (?)  AND DATE(updated_at) = ? );", userName, getFinishedApprovalStatus("zs"), today).Scan(&t).Error; err != nil {
		//	logger.Error("err", "zs查询今日完成订单出错", err.Error())
		//}
		if err := config.GetDb().Raw("SELECT count(distinct approval_jinjian_id) as today_count FROM approval_logs WHERE approval_name = ?  and  approval_status IN (?)  AND DATE(updated_at) = ?", userName, getFinishedApprovalStatus("zs"), today).Scan(&t).Error; err != nil {
			logger.Error("err", "zs查询全部完成订单出错", err.Error())
		}
		history.TodayFinishedOrderCount = t.TodayCount
		// 所有完成订单
		//if err := config.GetDb().Raw("SELECT count(1) as all_count FROM approval_logs WHERE id IN (SELECT max(id) FROM approval_logs WHERE approval_name = ?  GROUP BY approval_jinjian_id HAVING approval_status IN (?) );", userName, getFinishedApprovalStatus("zs")).Scan(&all).Error; err != nil {
		//	logger.Error("err", "zs查询全部完成订单出错", err.Error())
		//}
		//history.AllFinishedOrderCount = all.AllCount
	case "kf":
		// 今日完成订单
		//if err := config.GetDb().Raw("SELECT count(1) as today_count FROM approval_logs WHERE id IN (SELECT MAX(id) FROM approval_logs GROUP BY approval_jinjian_id HAVING (approval_status IN (?) OR approval_status LIKE '%财务退回%')  AND  approval_name = ? AND  DATE(updated_at) = ? );", getFinishedApprovalStatus("kf"), userName, today).Scan(&t).Error; err != nil {
		//	logger.Error("err","kf 今日完成订单出错",err.Error())
		//}
		if err := config.GetDb().Raw("SELECT count(distinct approval_jinjian_id) as  today_count FROM approval_logs WHERE approval_name = ? and  (approval_status IN (?) or approval_status like '%财务退回%') AND DATE(updated_at) = ? ", userName, getFinishedApprovalStatus("kf"), today).Scan(&t).Error; err != nil {
			logger.Error("err","kf 今日完成订单出错",err.Error())
		}
		history.TodayFinishedOrderCount = t.TodayCount
		// 全部完成订单
		//if err := config.GetDb().Raw("SELECT count(1) as all_count FROM approval_logs WHERE id IN (SELECT MAX(id) FROM approval_logs  GROUP BY approval_jinjian_id HAVING (approval_status IN (?) OR approval_status LIKE '%财务退回%') AND approval_name = ?);", getFinishedApprovalStatus("kf"), userName).Scan(&all).Error; err != nil {
		//	logger.Error("err", "kf查询全部完成订单出错", err.Error())
		//}
		//history.AllFinishedOrderCount = all.AllCount
	}
	return
}



