package service

import (
	"testing"
	"github.com/stretchr/testify/assert"
	"gapproval/approval/model"
)

func TestCustomOperationPass(t *testing.T) {
	oneStepTest(func() {
		// 从创建基础订单模型
		ao := model.GetTestCompleteApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
		ao.ReTrailStatus = model.ApprovalStatusReTrailPass
		ao.CustomServiceStatus = model.ApprovalStatusWaitCustomConfirm
		ao.AgencyStatus = model.AgencyStatusPass
		ao.ApprovalStatus = "客服中"
		ao.ApprovedAmount = 10
		assert.NoError(t, ao.Create())

		threePartyInfo := model.GetDefaultThreePartyInfo()
		threePartyInfo.JinjianId = ao.JinjianId
		assert.NoError(t, threePartyInfo.Create())

		userInfo := model.GetDefaultApprovalUserInfoSup()
		userInfo.JinjianId = ao.JinjianId
		assert.NoError(t, userInfo.Create())

		// 创建基础操作模型
		operation := GetDefaultApprovalOperationKF(ao.JinjianId, model.ApprovalStatusCustomPass)

		// 上传合同
		file := model.GetDefaultApprovalFile()
		file.JinjianId = ao.JinjianId
		file.FileType = "contract"
		assert.NoError(t, UploadApprovalFile(*file))

		// 执行操作
		assert.NoError(t, operation.Pass(), "客服通过审批操作失败")

		// 校验结果
		aR, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, model.ApprovalStatusCustomPass, aR.ApprovalStatus)
		assert.Equal(t, model.AgencyStatusPass, aR.AgencyStatus)
		assert.Equal(t, model.ApprovalStatusFirstTrailPass, aR.FirstTrailStatus)
		assert.Equal(t, model.ApprovalStatusReTrailPass, aR.ReTrailStatus)
		assert.Equal(t, model.ApprovalStatusCustomPass, aR.CustomServiceStatus)
	})
}

func TestCustomOperationRefuse(t *testing.T) {
	oneStepTest(func() {
		// 从创建基础订单模型
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
		ao.ReTrailStatus = model.ApprovalStatusReTrailPass
		ao.CustomServiceStatus = model.ApprovalStatusWaitCustomConfirm
		ao.AgencyStatus = model.AgencyStatusPass
		ao.ApprovalStatus = "客服中"
		assert.NoError(t, ao.Create())

		// 创建基础操作模型
		operation := GetDefaultApprovalOperationKF(ao.JinjianId, model.ApprovalStatusCustomRefuse)

		// 执行操作
		assert.NoError(t, operation.Refuse())

		// 校验结果
		aR, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, model.ApprovalStatusCustomRefuse, aR.ApprovalStatus)
		assert.Equal(t, model.AgencyStatusKHRefuse, aR.AgencyStatus)
		assert.Equal(t, model.ApprovalStatusFirstTrailPass, aR.FirstTrailStatus)
		assert.Equal(t, model.ApprovalStatusReTrailPass, aR.ReTrailStatus)
		assert.Equal(t, model.ApprovalStatusCustomRefuse, aR.CustomServiceStatus)
	})
}

func TestCustomOperationBack(t *testing.T) {
	oneStepTest(func() {
		// 从创建基础订单模型
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
		ao.ReTrailStatus = model.ApprovalStatusReTrailPass
		ao.CustomServiceStatus = model.ApprovalStatusWaitCustomConfirm
		ao.AgencyStatus = model.AgencyStatusPass
		ao.ApprovalStatus = "客服中"
		assert.NoError(t, ao.Create())

		// 创建基础操作模型
		operation := GetDefaultApprovalOperationKF(ao.JinjianId, model.ApprovalStatusCustomServiceBack)

		// 执行操作
		assert.NoError(t, operation.Back())

		// 校验结果
		aR, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, "终审中", aR.ApprovalStatus)
		assert.Equal(t, model.AgencyStatusPass, aR.AgencyStatus)
		assert.Equal(t, model.ApprovalStatusFirstTrailPass, aR.FirstTrailStatus)
		assert.Equal(t, model.ApprovalStatusCustomServiceBack, aR.ReTrailStatus)
		assert.Equal(t, model.ApprovalStatusCustomServiceBack, aR.CustomServiceStatus)
	})
}

func TestCustomOperationExchange(t *testing.T) {
	oneStepTest(func() {
		// 从创建基础订单模型
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
		ao.ReTrailStatus = model.ApprovalStatusReTrailPass
		ao.CustomServiceStatus = model.ApprovalStatusWaitCustomConfirm
		ao.AgencyStatus = model.AgencyStatusPass
		ao.ApprovalStatus = "客服中"
		assert.NoError(t, ao.Create())

		// 创建基础操作模型
		operation := GetDefaultApprovalOperationKF(ao.JinjianId, model.ApprovalStatusCustomServiceExchange)

		// 执行操作
		assert.NoError(t, operation.Exchange())

		// 校验结果
		aR, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, "客服中", aR.ApprovalStatus)
		assert.Equal(t, model.AgencyStatusPass, aR.AgencyStatus)
		assert.Equal(t, model.ApprovalStatusFirstTrailPass, aR.FirstTrailStatus)
		assert.Equal(t, model.ApprovalStatusReTrailPass, aR.ReTrailStatus)
		assert.Equal(t, model.ApprovalStatusCustomServiceExchange, aR.CustomServiceStatus)
		assert.Equal(t, operation.ExchangeId, aR.CustomServiceId)
		assert.Equal(t, operation.ExchangeName, aR.CustomServiceName)
	})
}

func TestCustomOperationSuspend(t *testing.T) {
	oneStepTest(func() {
		// 从创建基础订单模型
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
		ao.ReTrailStatus = model.ApprovalStatusReTrailPass
		ao.CustomServiceStatus = model.ApprovalStatusWaitCustomConfirm
		ao.AgencyStatus = model.AgencyStatusPass
		ao.ApprovalStatus = "客服中"
		assert.NoError(t, ao.Create())

		// 创建基础操作模型
		operation := GetDefaultApprovalOperationKF(ao.JinjianId, model.ApprovalSuspend)

		// 执行操作
		assert.NoError(t, operation.Suspend())

		// 校验结果
		aR, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, "on", aR.Suspending)
	})
}
