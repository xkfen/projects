package service

import (
	"testing"
	ivModel "gapproval/interview/model"
	"github.com/stretchr/testify/assert"
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"gcoresys/common/util"
	"fmt"
)

func TestGetAllFiles(t *testing.T) {
	oneStepTest(
		func() {
			ao := model.GetDefaultApprovalOrder()
			// 创建审批端数据
			af := model.GetDefaultApprovalFile()
			af.JinjianId = ao.JinjianId
			af.FileType = "contract_manage/user_contract"
			af.FileUrl = "/assets/测试路径1"
			assert.NoError(t, UploadApprovalFile(*af))
			af.ID = 0
			af.FileName = "其他文件"
			af.FileType = "other"
			af.FileUrl = "/assets/测试路径2"
			assert.NoError(t, UploadApprovalFile(*af))

			interview := ivModel.GetTestInterviewComplete()
			interviewStr := ivModel.GetTestInterviewCompleteString()
			ao.InterView = interviewStr
			assert.NoError(t, config.GetDb().Model(&ao).Create(&ao).Error)
			files, err := GetAllFiles(ao.JinjianId)
			assert.NoError(t, err)
			// 详细比较
			var allInfo map[string]interface{}
			assert.NoError(t, util.ParseJson(ao.AllInfo, &allInfo))
			if face, ok := allInfo["idcard_info"].(map[string]interface{})["facePhoto"].(string); ok {
				assert.Equal(t, face, files.IdCardFiles[0].FilePath)
			} else {
				assert.Equal(t, true, ok)
			}
			if back, ok := allInfo["idcard_info"].(map[string]interface{})["backPhoto"].(string); ok {
				assert.Equal(t, back, files.IdCardFiles[1].FilePath)
			} else {
				assert.Equal(t, true, ok)
			}

			assert.Equal(t, interview.IdCardFile[0].FilePath, files.IdCardFiles[2].FilePath)
			assert.Equal(t, interview.IdCardFile[0].FileType, files.IdCardFiles[2].FileType)
			assert.Equal(t, interview.IdCardFile[1].FilePath, files.IdCardFiles[3].FilePath)
			assert.Equal(t, interview.IdCardFile[1].FileType, files.IdCardFiles[3].FileType)
			assert.Equal(t, interview.IdCardFile[2].FilePath, files.IdCardFiles[4].FilePath)
			assert.Equal(t, interview.IdCardFile[2].FileType, files.IdCardFiles[4].FileType)

			assert.Equal(t, 0, len(files.VideoPath))
			for i := range interview.JinjianPlanFiles {
				assert.Equal(t, interview.JinjianPlanFiles[i].FileType, files.HouseLoanFiles[i].FileType)
				assert.Equal(t, interview.JinjianPlanFiles[i].FilePath, files.HouseLoanFiles[i].FilePath)
			}
			var l1, l2 int
			for i := range interview.ContractFile {
				assert.Equal(t, interview.ContractFile[i].FileType, files.ContractFiles[i].FileType)
				assert.Equal(t, interview.ContractFile[i].FilePath, files.ContractFiles[i].FilePath)
				l1 = i + 1
			}
			for i := range interview.OtherFile {
				assert.Equal(t, interview.OtherFile[i].FileType, files.OtherFiles[i].FileType)
				assert.Equal(t, interview.OtherFile[i].FilePath, files.OtherFiles[i].FilePath)
				l2 = i + 1
			}
			assert.Equal(t, "contract_manage/user_contract", files.ContractFiles[l1].FileType)
			assert.Equal(t, "/assets/测试路径1", files.ContractFiles[l1].FilePath)
			fmt.Println(l2)
			//assert.Equal(t, "other", files.OtherFiles[l2].FileType)
			//assert.Equal(t, "/assets/测试路径2", files.OtherFiles[l2].FilePath)
			for i := range interview.CreditReportFile {
				assert.Equal(t, interview.CreditReportFile[i].FileType, files.CreditReportFiles[i].FileType)
				assert.Equal(t, interview.CreditReportFile[i].FilePath, files.CreditReportFiles[i].FilePath)
			}
			assert.Equal(t, interview.LoanBank[0].FilesUrl[0].FileType, files.LoanBankFiles[0].FileType)
			assert.Equal(t, interview.LoanBank[0].FilesUrl[0].FilePath, files.LoanBankFiles[0].FilePath)
		})
}

func TestGetFilesFromApprovalStage(t *testing.T) {
	oneStepTest(func() {
		// 创建审批端数据
		af := model.GetDefaultApprovalFile()
		af.JinjianId = "order_1234"
		af.FileType = "contract_manage/user_contract"
		af.FileUrl = "/assets/测试路径1"
		assert.NoError(t, UploadApprovalFile(*af))
		af.ID = 0
		af.FileName = "其他文件"
		af.FileType = "other"
		af.FileUrl = "/assets/测试路径2"
		assert.NoError(t, UploadApprovalFile(*af))
		af.ID = 0
		af.FileName = "xxx"
		af.FileType = "interview_statement"
		af.FileUrl = "/assets/测试路径3"
		assert.NoError(t, UploadApprovalFile(*af))
		af.ID = 0
		af.FileName = "xxx"
		af.FileType = "id_card"
		af.FileUrl = "/assets/测试路径4"
		assert.NoError(t, UploadApprovalFile(*af))

		var files AllFiles
		getFilesFromApprovalStage(&files, "order_1234")
		assert.Equal(t, 1, len(files.InterviewStatementFiles))
		assert.Equal(t, "/assets/测试路径3", files.InterviewStatementFiles[0].FilePath)
		assert.Equal(t, "/assets/测试路径1", files.ContractFiles[0].FilePath)

		af.ID = 0
		af.FileName = "xxx444"
		af.FileType = "interview_statement"
		af.FileUrl = "/assets/测试路径4"
		assert.NoError(t, UploadApprovalFile(*af))

		var files2 AllFiles
		getFilesFromApprovalStage(&files2, "order_1234")
		assert.Equal(t, 2, len(files2.InterviewStatementFiles))
		assert.Equal(t, "/assets/测试路径3", files2.InterviewStatementFiles[0].FilePath)
		assert.Equal(t, "/assets/测试路径4", files2.InterviewStatementFiles[1].FilePath)
	})
}

func TestPackCompressedApprovalFile(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		// 创建审批端数据
		af := model.GetDefaultApprovalFile()
		af.JinjianId = ao.JinjianId
		af.FileType = "contract_manage/user_contract"
		af.FileUrl = "/assets/测试路径1"
		assert.NoError(t, UploadApprovalFile(*af))
		af.ID = 0
		af.FileName = "其他文件"
		af.FileType = "other"
		af.FileUrl = "/assets/测试路径2"
		assert.NoError(t, UploadApprovalFile(*af))

		interview := ivModel.GetTestInterviewComplete()
		interviewStr := ivModel.GetTestInterviewCompleteString()
		ao.InterView = interviewStr
		assert.NoError(t, config.GetDb().Model(&ao).Create(&ao).Error)

		fileUrls, err := PackCompressedApprovalFile(ao.JinjianId)
		assert.NoError(t, err)
		var files []model.ApprovalFile
		util.ParseJson(fileUrls, &files)

		// 详细比较
		var allInfo map[string]interface{}
		assert.NoError(t, util.ParseJson(ao.AllInfo, &allInfo))
		if face, ok := allInfo["idcard_info"].(map[string]interface{})["facePhoto"].(string); ok {
			assert.Equal(t, face, files[0].FileUrl)
		} else {
			assert.Equal(t, true, ok)
		}
		if back, ok := allInfo["idcard_info"].(map[string]interface{})["backPhoto"].(string); ok {
			assert.Equal(t, back, files[1].FileUrl)
		} else {
			assert.Equal(t, true, ok)
		}

		assert.Equal(t, ivAsset(interview.IdCardFile[0].FilePath), files[2].FileUrl)
		assert.Equal(t, ivAsset(interview.IdCardFile[1].FilePath), files[3].FileUrl)
		assert.Equal(t, ivAsset(interview.IdCardFile[2].FilePath), files[4].FileUrl)

		var urls []string
		for _, x := range files {
			urls = append(urls, x.FileUrl)
		}

		assert.Contains(t, urls, interview.VideoPath)
		assert.NotContains(t, urls, "/assets/123")
	})
}