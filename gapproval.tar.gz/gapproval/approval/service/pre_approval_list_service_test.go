package service

import (
	"testing"
	"github.com/stretchr/testify/assert"
	"gapproval/approval/model"
)

////********************预审批我的订单列表****************************//
//// 测试预审批列表：我的订单
//func TestQueryMyPreApprovalList1(t *testing.T) {
//	oneStepTest(func() {
//		pao := model.GetDefaultPreApprovalOrder()
//		assert.NoError(t, CreatePreApproval(pao))
//		assert.NoError(t, serviceV1.GrabPreApproval("test001", "测试001"))
//		paoR, err := serviceV1.GetPreApprovalInfo(pao.PreApprovalID)
//		assert.NoError(t, err)
//		assert.Equal(t, pao.PreApprovalID, paoR.PreApprovalID)
//		assert.Equal(t, "test001", paoR.PreTrailId)
//		assert.Equal(t, "测试001", paoR.PreTrailName)
//		req := QueryPreOrderListReq{
//			Key:"me",
//			ApplyType:"all",
//			Enter:"未进件",
//			Condition:"",
//			EndTime:"asc",
//			Page:1,
//		}
//		list, totalPages, totalCount, err := QueryPreApprovalListByKey("test001", "测试001", req)
//		assert.NoError(t, err)
//		assert.Equal(t, 1, totalPages)
//		assert.Equal(t, 1, totalCount)
//		assert.Equal(t, 1, len(list))
//	})
//}
//
//// 我的订单，模糊查询
//func TestQueryMyPreApprovalList2(t *testing.T) {
//	oneStepTest(func() {
//		pao := model.GetDefaultPreApprovalOrder()
//		assert.NoError(t, CreatePreApproval(pao))
//		pao1 := model.GetDefaultPreApprovalOrder()
//		pao1.UserName = "测试1"
//		assert.NoError(t, CreatePreApproval(pao1))
//		pao2 := model.GetDefaultPreApprovalOrder()
//		pao2.UserName = "测试2"
//		assert.NoError(t, CreatePreApproval(pao2))
//		assert.NoError(t, serviceV1.GrabPreApproval("test001", "测试001"))
//		paoR, err := serviceV1.GetPreApprovalInfo(pao.PreApprovalID)
//		assert.NoError(t, err)
//		assert.Equal(t, pao.PreApprovalID, paoR.PreApprovalID)
//		assert.Equal(t, "test001", paoR.PreTrailId)
//		assert.Equal(t, "测试001", paoR.PreTrailName)
//		req := QueryPreOrderListReq{
//			Key:"me",
//			ApplyType:"all",
//			Enter:"未进件",
//			Condition:"",
//			EndTime:"asc",
//			Page:1,
//		}
//		list, totalPages, totalCount, err := QueryPreApprovalListByKey("test001", "测试001", req)
//		assert.NoError(t, err)
//		assert.Equal(t, 1, totalPages)
//		assert.Equal(t, 1, totalCount)
//		assert.Equal(t, 1, len(list))
//	})
//}
//********************预审批我的订单列表****************************//
//// 测试预审批列表：我的订单
//func TestQueryMyPreApprovalList1(t *testing.T) {
//	oneStepTest(func() {
//		pao := model.GetDefaultPreApprovalOrder()
//		assert.NoError(t, serviceV1.CreatePreApproval(pao))
//		assert.NoError(t, serviceV1.GrabPreApproval("test001", "测试001"))
//		paoR, err := serviceV1.GetPreApprovalInfo(pao.PreApprovalID)
//		assert.NoError(t, err)
//		assert.Equal(t, pao.PreApprovalID, paoR.PreApprovalID)
//		assert.Equal(t, "test001", paoR.PreTrailId)
//		assert.Equal(t, "测试001", paoR.PreTrailName)
//		req := QueryPreOrderListReq{
//			Key:"me",
//			ApplyType:"all",
//			Enter:"未进件",
//			Condition:"",
//			EndTime:"asc",
//			Page:1,
//		}
//		list, totalPages, totalCount, err := QueryPreApprovalListByKey("test001", "测试001", req)
//		assert.NoError(t, err)
//		assert.Equal(t, 1, totalPages)
//		assert.Equal(t, 1, totalCount)
//		assert.Equal(t, 1, len(list))
//	})
//}
//
//// 我的订单----预审中
//func TestQueryMyPreApprovalList2(t *testing.T) {
//	oneStepTest(func() {
//		// 创建订单pao
//		pao := model.GetDefaultPreApprovalOrder()
//		pao.PreApprovalID = "1"
//		// 抢单是暂时没有初审人员id和初审人员name的
//		//pao.PreTrailId = "test001"
//		//pao.PreTrailName = "测试001"
//		assert.NoError(t, serviceV1.CreatePreApproval(pao))
//		// 抢单
//		assert.NoError(t, serviceV1.GrabPreApproval("test001", "测试001"))
//		paoR, err := serviceV1.GetPreApprovalInfo(pao.PreApprovalID)
//		assert.Equal(t, pao.PreApprovalID, paoR.PreApprovalID)
//		assert.Equal(t, "test001", paoR.PreTrailId)
//		assert.Equal(t, "测试001", paoR.PreTrailName)
//
//		pao1 := model.GetDefaultPreApprovalOrder()
//		pao1.PreApprovalID = "2"
//		//pao1.PreTrailId = "test001"
//		//pao1.PreTrailName = "测试001"
//		assert.NoError(t, serviceV1.CreatePreApproval(pao1))
//		// 抢单
//		assert.NoError(t, serviceV1.GrabPreApproval("test001", "测试001"))
//		paoR1, err := serviceV1.GetPreApprovalInfo(pao1.PreApprovalID)
//
//
//
//		pao2 := model.GetDefaultPreApprovalOrder()
//		pao2.PreApprovalID = "测试2"
//		//pao2.PreTrailId = "test001"
//		//pao2.PreTrailName = "测试001"
//		assert.NoError(t, serviceV1.CreatePreApproval(pao2))
//		// 抢单
//		assert.NoError(t, serviceV1.GrabPreApproval("test001", "测试001"))
//		paoR2, err := serviceV1.GetPreApprovalInfo(pao2.PreApprovalID)
//		assert.NoError(t, err)
//
//		assert.Equal(t, pao1.PreApprovalID, paoR1.PreApprovalID)
//		assert.Equal(t, "test001", paoR1.PreTrailId)
//		assert.Equal(t, "测试001", paoR1.PreTrailName)
//		assert.Equal(t, pao2.PreApprovalID, paoR2.PreApprovalID)
//		assert.Equal(t, "test001", paoR2.PreTrailId)
//		assert.Equal(t, "测试001", paoR2.PreTrailName)
//
//		req := QueryPreOrderListReq{
//			Key:"me",
//			ApplyType:"all",
//			Enter:"未进件",
//			Condition:"",
//			EndTime:"asc",
//			Page:1,
//		}
//		list, totalPages, totalCount, err := QueryPreApprovalListByKey("test001", "测试001", req)
//		assert.NoError(t, err)
//		assert.Equal(t, 1, totalPages)
//		assert.Equal(t, 3, totalCount)
//		assert.Equal(t, 3, len(list))
//	})
//}
//
//// 我的订单，预审中，预审打回
//func TestQueryMyPreApprovalList3(t *testing.T) {
//	oneStepTest(func() {
//		// 创建订单pao
//		pao := model.GetDefaultPreApprovalOrder()
//		pao.PreApprovalID = "1"
//		assert.NoError(t, serviceV1.CreatePreApproval(pao))
//		// 抢单
//		assert.NoError(t, serviceV1.GrabPreApproval("test001", "测试001"))
//		paoR, err := serviceV1.GetPreApprovalInfo(pao.PreApprovalID)
//		assert.Equal(t, pao.PreApprovalID, paoR.PreApprovalID)
//		assert.Equal(t, "test001", paoR.PreTrailId)
//		assert.Equal(t, "测试001", paoR.PreTrailName)
//
//		pao1 := model.GetDefaultPreApprovalOrder()
//		pao1.PreApprovalID = "2"
//		assert.NoError(t, serviceV1.CreatePreApproval(pao1))
//		// 抢单
//		assert.NoError(t, serviceV1.GrabPreApproval("test001", "测试001"))
//		paoR1, err := serviceV1.GetPreApprovalInfo(pao1.PreApprovalID)
//
//
//
//		pao2 := model.GetDefaultPreApprovalOrder()
//		pao2.PreApprovalID = "测试2"
//		assert.NoError(t, serviceV1.CreatePreApproval(pao2))
//		// 抢单
//		assert.NoError(t, serviceV1.GrabPreApproval("test001", "测试001"))
//		paoR2, err := serviceV1.GetPreApprovalInfo(pao2.PreApprovalID)
//		assert.NoError(t, err)
//
//		assert.Equal(t, pao1.PreApprovalID, paoR1.PreApprovalID)
//		assert.Equal(t, "test001", paoR1.PreTrailId)
//		assert.Equal(t, "测试001", paoR1.PreTrailName)
//		assert.Equal(t, pao2.PreApprovalID, paoR2.PreApprovalID)
//		assert.Equal(t, "test001", paoR2.PreTrailId)
//		assert.Equal(t, "测试001", paoR2.PreTrailName)
//
//		// 打回
//		assert.NoError(t, serviceV1.PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: pao.PreApprovalID,
//			PreApprovalStatus: model.PREAPPROVALREPULSE, OpDesc: "ssss"}))
//		paoR1, err = serviceV1.GetPreApprovalInfo(pao.PreApprovalID)
//		assert.NotNil(t, paoR1.RepulseTime)
//		assert.NoError(t, err)
//		assert.Equal(t, model.PREAPPROVALREPULSE, paoR1.PreApprovalStatus)
//
//		req := QueryPreOrderListReq{
//			Key:"me",
//			ApplyType:"all",
//			Enter:"未进件",
//			Condition:"",
//			EndTime:"asc",
//			Page:1,
//		}
//		list, totalPages, totalCount, err := QueryPreApprovalListByKey("test001", "测试001", req)
//		assert.NoError(t, err)
//		assert.Equal(t, 1, totalPages)
//		assert.Equal(t, 3, totalCount)
//		assert.Equal(t, 3, len(list))
//	})
//}
//
//// 预审批历史订单
//func TestPreHistoryList1(t *testing.T){
//	oneStepTest(func() {
////		for i := 0; i < 11; i++{
////			if i % 2== 0 {
////				// 创建订单
////				pao := model.GetDefaultPreApprovalOrder()
////				// 预审通过需要提交量化变量
////				pao.QuantizationMap = `
////{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`
////
////				pao.QuantizationCache = `
////{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`
////				pao.QuantizationPoint = 400
////				pao.QuantizationLevel = 5
////				assert.NoError(t, serviceV1.CreatePreApproval(pao))
////				p0, err := serviceV1.GetPreApprovalInfo(pao.PreApprovalID)
////				assert.Equal(t, model.WAITPREAPPROVAL, p0.PreApprovalStatus)
////				assert.NotNil(t, p0.QuantizationCache)
////				// 预审抢单
////				assert.NoError(t, serviceV1.GrabPreApproval("test001", "测试001"))
////				p1, err := serviceV1.GetPreApprovalInfo(pao.PreApprovalID)
////				assert.Equal(t, model.PREAPPROVALING, p1.PreApprovalStatus)
////
////
////				// 预审通过
////				assert.NoError(t, serviceV1.PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: p1.PreApprovalID, PreApprovalStatus:model.PREAPPROVALPASS, OpDesc:"与社会你通过",IntroductionFundSide:"洋葱"}))
////				p2, err := serviceV1.GetPreApprovalInfo(pao.PreApprovalID)
////				assert.NoError(t, err)
////				assert.Equal(t, model.PREAPPROVALPASS , p2.PreApprovalStatus)
////				pao.PreApprovalID = pao.PreApprovalID + strconv.Itoa(i)
////			}else {
////				// 创建订单
////				pao := model.GetDefaultPreApprovalOrder()
////				pao.PreApprovalID = pao.PreApprovalID + strconv.Itoa(i)
////				assert.NoError(t, serviceV1.CreatePreApproval(pao))
////				// 预审抢单
////				assert.NoError(t, serviceV1.GrabPreApproval("test001", "测试001"))
////				// 拒绝
////				assert.NoError(t, serviceV1.PreTrailOperation(&model.PreApprovalOrder{PreApprovalID:pao.PreApprovalID, PreApprovalStatus:model.PREAPPROVALREFUSE, OpDesc:"预审决绝", RefuseReason:"swdd",ExternalReason:"外部由于啊"}))
////			}
////		}
//
//		pao := model.GetDefaultPreApprovalOrder()
//		// 预审通过需要提交量化变量
//		pao.QuantizationMap = `
//		{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`
//
//		pao.QuantizationCache = `
//		{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`
//		pao.QuantizationPoint = 400
//		pao.QuantizationLevel = 5
//		assert.NoError(t, serviceV1.CreatePreApproval(pao))
//		p0, err := serviceV1.GetPreApprovalInfo(pao.PreApprovalID)
//		assert.Equal(t, model.WAITPREAPPROVAL, p0.PreApprovalStatus)
//		assert.NotNil(t, p0.QuantizationCache)
//		// 预审抢单
//		assert.NoError(t, serviceV1.GrabPreApproval("test001", "测试001"))
//		p1, err := serviceV1.GetPreApprovalInfo(pao.PreApprovalID)
//		assert.Equal(t, model.PREAPPROVALING, p1.PreApprovalStatus)
//		// 预审通过
//		assert.NoError(t, serviceV1.PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: p1.PreApprovalID, PreApprovalStatus:model.PREAPPROVALPASS, OpDesc:"与社会你通过",IntroductionFundSide:"洋葱"}))
//		p2, err := serviceV1.GetPreApprovalInfo(pao.PreApprovalID)
//		assert.NoError(t, err)
//		assert.Equal(t, model.PREAPPROVALPASS , p2.PreApprovalStatus)
//
//		req := QueryPreOrderListReq{
//			Key:"history",
//			PreStatus:"all",
//			CommitTime:"desc",
//			Page:1,
//		}
//		list, totalPages, totalCount, err := QueryPreApprovalListByKey("test001", "测试001", req)
//		assert.NoError(t, err)
//		assert.Equal(t, 1, totalCount)
//		assert.Equal(t, 1, totalPages)
//		assert.Equal(t, 1, len(list))
//
//	})
//}

// 测试预审批[查询]列表
func TestQueryPreApprovalListByKey2(t *testing.T) {
	oneStepTest(func() {
		pao1 := model.GetDefaultPreApprovalOrder()
		pao1.PreApprovalID = "poiuy890"
		assert.NoError(t, CreatePreApproval(pao1))
		pao2 := model.GetDefaultPreApprovalOrder()
		pao2.PreApprovalID = "nfdgu5654"
		assert.NoError(t, CreatePreApproval(pao2))
		pao3 := model.GetDefaultPreApprovalOrder()
		pao3.PreApprovalID = "hjlkhbn543"
		assert.NoError(t, CreatePreApproval(pao3))

		req := QueryPreOrderListReq{
			Key:"query",
			ApplyType:"all",
			Enter:"未进件",
			Condition:"",
			Page:1,
			PreStatus:"all",
			OrderStatus:"all",
		}
		list, totalPages, totalCount, err := QueryPreApprovalListByKey("test001", "测试001", req)
		assert.NoError(t, err)
		assert.Equal(t, 1, totalPages)
		assert.Equal(t, 3, totalCount)
		assert.Equal(t, 3, len(list))
	})
}


//func TestGormDistinct(t *testing.T){
//	oneStepTest(func() {
//		o1 := model.GetDefaultPreApprovalOrder()
//		assert.NoError(t, CreatePreApproval(o1))
//
//		o2 := model.GetDefaultPreApprovalOrder()
//		o2.PreApprovalID = "111"
//		assert.NoError(t, CreatePreApproval(o2))
//		var os []model.PreApprovalOrder
//		config.GetDb().Model(&model.PreApprovalOrder{}).Select("distinct (pre_approval_id) and ").Find(&os)
//		assert.Equal(t, 2, len(os))
//		// 首先查到所有订单
//
//	})
//}