package service

import (
	"gapproval/approval/model"
	"errors"
	"gcoresys/common/logger"
	"time"
	"gapproval/approval/db/config"
	"gcoresys/common"
	"strings"
	"github.com/jinzhu/gorm"
)

type ApprovalOperationKF struct {
	JinjianId string `json:"jinjian_id"`
	// 审批操作
	Status string `json:"status"`
	// 操作备注
	StatusDes string `json:"status_des"`
	// 流转账号
	ExchangeId string `json:"exchange_id"`
	// 流转姓名
	ExchangeName string `json:"exchange_name"`
	// 主要原因
	RefuseReason string `json:"refuse_reason"`
}

//  客服操作
func CustomOperation(operation ApprovalOperationKF) (err error) {

	switch operation.Status {
	case model.ApprovalStatusCustomPass: // "客户接受"
		return operation.Pass()

	case model.ApprovalStatusCustomServiceBack: // "客服退回"
		return operation.Back()

	case model.ApprovalStatusCustomServiceExchange: // "客服流转"
		return operation.Exchange()

	case model.ApprovalStatusCustomRefuse: // "客户拒绝"
		return operation.Refuse()

	case model.ApprovalSuspend: // 挂起
		return operation.Suspend()

	default:
		return errors.New("客服不存在该操作:" + operation.Status)
	}
}

func (operation *ApprovalOperationKF) Pass() error {

	if operation.StatusDes == "" {
		return errors.New("备注不能为空")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	// 校验审批单数据
	if ao.CustomServiceStatus != model.ApprovalStatusWaitCustomConfirm && ao.CustomServiceStatus != model.ApprovalStatusCustomServiceExchange && ao.CustomServiceStatus != model.ApprovalStatusFinanceBack {
		logger.Error("==================客服通过状态错误： ", "当前状态: ", ao.CustomServiceStatus)
		return errors.New("客服当前状态为:" + ao.CustomServiceStatus + ",提交失败")
	}
	var file model.ApprovalFile
	if err = config.GetDb().Model(&model.ApprovalFile{}).Where("jinjian_id=? AND file_type LIKE ?", operation.JinjianId, "%contract%").First(&file).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			return errors.New("请先上传合同")
		}
		return err
	}
	ao.ContractId = strings.Replace(ao.ShowId, "S_", "H_", 1)

	// 校验初审补充用户信息
	var uis model.ApprovalUserInfoSup
	if err = config.GetDb().Model(&uis).Where("jinjian_id = ?", ao.JinjianId).First(&uis).Error; err != nil {
		logger.Error("======================查询审批补充用户信息出错 :", "err", err.Error())
		if err.Error() == "record not found" {
			return errors.New("初审未补充用户信息")
		}
		return err
	}

	// 创建账户
	var accountId uint
	if common.GetUseDocker() != 0 {
		account, err := PostCoreSysNewAccount(ao)
		if err != nil {
			return err
		}
		accountId = account.AccountId
	} else {
		accountId = 1234 //单元测试用
	}

	// post 财务系统
	if common.GetUseDocker() != 0 {
		postMap := map[string]interface{}{"approval_order": ao, "user_info": uis}
		if err = PostFinSys(postMap); err != nil {
			return err
		}
	}

	// 更新审批单表
	ao.CustomServiceStatus = operation.Status // 因为ao.GetAoCurrStatus方法要校验CustomServiceStatus, 所以要提前更新掉
	if err := ao.Update(map[string]interface{}{
		"custom_service_status":     operation.Status, // 修改客服状态为客服退回
		"custom_service_status_des": operation.StatusDes,
		"account_id":                accountId,
		"approval_status":           ao.GetAoCurrStatus(),
		"contract_id":               ao.ContractId,
	}); err != nil {
		return err
	}

	AsyncApprovalTimeRecord(ao.JinjianId, model.TP_KF, model.TP_CW)

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.CustomServiceName,
		ApprovalStatus: "用户接受", ApprovalType: "kf", ApprovalDesc: operation.StatusDes})

	return nil
}

func (operation *ApprovalOperationKF) Refuse() error {

	if operation.StatusDes == "" {
		return errors.New("备注不能为空")
	}

	if operation.RefuseReason == "" {
		return errors.New("拒绝原因不能为空")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	if ao.CustomServiceStatus != model.ApprovalStatusWaitCustomConfirm && ao.CustomServiceStatus != model.ApprovalStatusCustomServiceExchange && ao.CustomServiceStatus != model.ApprovalStatusFinanceBack {
		logger.Error("==================客服拒绝状态错误： ", "当前状态: ", ao.CustomServiceStatus)
		return errors.New("客服当前状态为:" + ao.CustomServiceStatus + ",提交失败")
	}

	nowTime := time.Now()
	ao.CustomServiceStatus = operation.Status // 因为ao.GetAoCurrStatus方法要校验CustomServiceStatus, 所以要提前更新掉
	if err := ao.Update(map[string]interface{}{
		"custom_service_status":     operation.Status, // 修改客服状态 客服拒绝
		"custom_service_status_des": operation.StatusDes,
		"refuse_reason":             operation.RefuseReason,
		"agency_status":             model.AgencyStatusKHRefuse,
		"approval_refuse_time":      &nowTime,
		"approval_status":           ao.GetAoCurrStatus(),
	}); err != nil {
		return err
	}

	AsyncApprovalTimeRecord(ao.JinjianId, model.TP_KF)

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.CustomServiceName,
		ApprovalStatus: "用户拒绝", ApprovalType: "kf", ApprovalDesc: operation.StatusDes})

	return nil
}

func (operation *ApprovalOperationKF) Back() error {

	if operation.StatusDes == "" {
		return errors.New("客服退回说明不能为空")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	if ao.CustomServiceStatus != model.ApprovalStatusWaitCustomConfirm && ao.CustomServiceStatus != model.ApprovalStatusCustomServiceExchange && ao.CustomServiceStatus != model.ApprovalStatusFinanceBack {
		logger.Error("==================客服流转状态错误： ", "当前状态: ", ao.CustomServiceStatus)
		return errors.New("客服当前状态为:" + ao.CustomServiceStatus + ",提交失败")
	}

	ao.CustomServiceStatus = operation.Status // 因为ao.GetAoCurrStatus方法要校验CustomServiceStatus, 所以要提前更新掉
	ao.ReTrailStatus = operation.Status
	if err := ao.Update(map[string]interface{}{
		"custom_service_status":     operation.Status, // 修改客服状态为客服退回
		"custom_service_status_des": operation.StatusDes,
		"re_trail_status":           operation.Status, // 修改终审状态为客服退回
		"approval_status":           ao.GetAoCurrStatus(),
	}); err != nil {
		return err
	}

	AsyncApprovalTimeRecord(ao.JinjianId, model.TP_ZS, model.TP_CS)

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.CustomServiceName,
		ApprovalStatus: "客服退回给" + ao.ReTrailName, ApprovalType: "kf", ApprovalDesc: operation.StatusDes})

	return nil
}

func (operation *ApprovalOperationKF) Exchange() error {

	if operation.StatusDes == "" {
		return errors.New("备注不能为空")
	}
	if operation.ExchangeId == "" || operation.ExchangeId == "Null" {
		return errors.New("流转账号不能为空")
	}
	if operation.ExchangeName == "" || operation.ExchangeName == "Null" {
		return errors.New("流转姓名不能为空")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	if ao.CustomServiceStatus != model.ApprovalStatusWaitCustomConfirm && ao.CustomServiceStatus != model.ApprovalStatusCustomServiceExchange && ao.CustomServiceStatus != model.ApprovalStatusFinanceBack {
		logger.Error("==================客服流转状态错误： ", "当前状态: ", ao.CustomServiceStatus)
		return errors.New("客服当前状态为:" + ao.CustomServiceStatus + ",提交失败")
	}

	if err := ao.Update(map[string]interface{}{
		"custom_service_status":     operation.Status, // 修改客服状态 客服流转
		"custom_service_status_des": operation.StatusDes,
		"custom_service_id":         operation.ExchangeId,
		"custom_service_name":       operation.ExchangeName,
	}); err != nil {
		return err
	}

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.CustomServiceName,
		ApprovalStatus: operation.Status, ApprovalType: "kf", ApprovalDesc: operation.StatusDes})

	return nil
}

func (operation *ApprovalOperationKF) Suspend() error {

	if operation.StatusDes == "" {
		return errors.New("挂起原因不能为空")
	}

	ao, err := model.GetApprovalOrderByJinjianId(operation.JinjianId)
	if err != nil {
		return err
	}

	if err := ao.Update(map[string]interface{}{
		"suspending":    "on",
		"suspense_desc": operation.StatusDes,
	}); err != nil {
		return err
	}

	AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.CustomServiceName,
		ApprovalStatus: "客服挂起", ApprovalType: "kf", ApprovalDesc: operation.StatusDes})

	return nil
}


// 返回客服状态筛选需要的参数
func CustomServiceStatusList(typeKey string, status string) (statusList []string) {
	switch typeKey {
	case "all":
		switch status {
		case model.ApprovalStatusWaitCustomConfirm: // 待沟通
			statusList = []string{model.ApprovalStatusWaitCustomConfirm}
			return statusList
		default:
			statusList = []string{model.ApprovalStatusWaitCustomConfirm}
			return statusList
		}
	case "history":
		switch status {
		case model.ApprovalStatusCustomPass: // 客户接受
			statusList = []string{model.ApprovalStatusCustomPass}
			return statusList
		case model.ApprovalStatusCustomRefuse: // 客户拒绝
			statusList = []string{model.ApprovalStatusCustomRefuse}
			return statusList
		case model.ApprovalStatusCustomCancel: // 已撤销
			statusList = []string{model.ApprovalStatusCustomCancel}
			return statusList
		case model.ApprovalStatusFinanceBack: // 财务退回
			statusList = []string{model.ApprovalStatusFinanceBack}
			return statusList
		default:
			statusList = []string{model.ApprovalStatusCustomPass, model.ApprovalStatusCustomRefuse,
				model.ApprovalStatusCustomCancel, model.ApprovalStatusFinanceBack}
			return statusList
		}
	case "me":
		switch status {
		case model.ApprovalStatusWaitCustomConfirm: // 待沟通
			statusList = []string{model.ApprovalStatusWaitCustomConfirm}
			return statusList
		case model.ApprovalStatusCustomServiceExchange: // 客服流转
			statusList = []string{model.ApprovalStatusCustomServiceExchange}
			return statusList
		default:
			statusList = []string{model.ApprovalStatusWaitCustomConfirm, model.ApprovalStatusCustomServiceExchange}
			return statusList
		}
	case "query":
		switch status {
		case "all":
			statusList = []string{model.ApprovalStatusWaitCustomConfirm, model.ApprovalStatusCustomServiceExchange,
				model.ApprovalStatusCustomPass, model.ApprovalStatusCustomRefuse, model.ApprovalStatusCustomCancel,
				model.ApprovalStatusFinanceBack}
			return statusList
		case "handling":
			statusList = []string{model.ApprovalStatusWaitCustomConfirm, model.ApprovalStatusCustomServiceExchange,
				model.ApprovalStatusFinanceBack}
			return statusList
		case "ending":
			statusList = []string{model.ApprovalStatusCustomPass, model.ApprovalStatusCustomRefuse,
				model.ApprovalStatusCustomCancel}
			return statusList
		}
	}
	return
}

