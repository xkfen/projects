package service

import (
	"testing"
	"github.com/stretchr/testify/assert"
)

func TestApprovalReportForm(t *testing.T) {

	oneStepTest(func() {

		data, err := ApprovalReportForm("2018-01-01 01:01:01", "2018-04-04 04:04:04")

		assert.Equal(t, nil, err)
		assert.Equal(t, "[]", data)
	})

	oneStepTest(func() {

		data, err := ApprovalReportForm("2018-01-01", "2018-04-04")

		assert.Equal(t, nil, err)
		assert.Equal(t, "[]", data)
	})

	oneStepTest(func() {

		data, err := ApprovalReportForm("", "")

		assert.Equal(t, nil, err)
		assert.Equal(t, "[]", data)
	})

	oneStepTest(func() {

		data, err := ApprovalReportForm("2018-05-12", "")

		if assert.NotEqual(t, nil, err) {
			assert.Equal(t, "开始时间错误，请检查", err.Error())
			assert.Equal(t, "", data)
		}
	})

	oneStepTest(func() {

		data, err := ApprovalReportForm("", "2018-05-12")

		assert.Equal(t, nil, err)
		assert.Equal(t, "[]", data)
	})

	oneStepTest(func() {

		data, err := ApprovalReportForm("2018-04-11", "")

		assert.Equal(t, nil, err)
		assert.Equal(t, "[]", data)
	})
}
