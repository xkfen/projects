package service

import (
	"gapproval/approval/model"
	"errors"
	"time"
)

type PreApprovalOperationReq struct {
	PreApprovalID string `json:"pre_approval_id"`
	// 审批操作
	Status string `json:"status"`
	// 操作备注
	StatusDes string `json:"status_des"`
	// 流转账号
	ExchangeId string `json:"exchange_id"`
	// 流转姓名
	ExchangeName string `json:"exchange_name"`
	// 主要原因
	RefuseReason string `json:"refuse_reason"`
	// 推荐资金方
	IntroductionFundSide string `json:"introduction_fund_side"`
}

//  预审操作
func PreApprovalOperation(operation PreApprovalOperationReq) (err error) {

	switch operation.Status {

	case model.PREAPPROVALPASS:
		return operation.Pass()

	case model.PREAPPROVALEXCHANGE:
		return operation.Exchange()

	case model.PREAPPROVALREFUSE:
		return operation.Refuse()

	case model.PREAPPROVALCANCEL:
		return operation.Cancel()

	default:
		return errors.New("终审不存在该操作:" + operation.Status)
	}
}

func (operation *PreApprovalOperationReq) Pass() (err error) {
	pao, err := model.GetPreApprovalOrderByPreApprovalId(operation.PreApprovalID)
	if err != nil {
		return
	}

	if pao.PreApprovalType == model.QD_PREAPPROVAL && pao.IsFast != model.FS_PREAPPROVAL {
		if pao.QuantizationMap == "" || pao.QuantizationPoint == 0 || pao.QuantizationCache == "" {
			return errors.New("请先填写量化变量，并且提交，获取结果")
		}
	}

	if pao.PreApprovalType == model.QD_PREAPPROVAL {

		if operation.IntroductionFundSide == "" {
			return errors.New("请推荐资金方")
		}
	}

	if operation.StatusDes == "" {
		return errors.New("预审操作备注不能为空，请填写备注")
	}

	nowTime := time.Now()
	pao.IntroductionFundSide = operation.IntroductionFundSide
	//preAo.IntroductionPlanNum = changePao.IntroductionPlanNum
	pao.OpDesc = operation.StatusDes
	pao.PreApprovalStatus = model.PREAPPROVALPASS
	pao.PassTime = &nowTime

	if err := pao.Update(); err != nil {
		return err
	}

	SendPvSms(pao, "pass")

	AsyncNewPreApprovalLog(&model.PreApprovalLog{
		PreApprovalId:     pao.PreApprovalID,
		PreApprovalName:   pao.PreTrailName,
		PreApprovalStatus: pao.PreApprovalStatus,
	})

	return
}

func (operation *PreApprovalOperationReq) Exchange() (err error) {
	pao, err := model.GetPreApprovalOrderByPreApprovalId(operation.PreApprovalID)
	if err != nil {
		return
	}

	if operation.StatusDes == "" {
		return errors.New("预审操作备注不能为空，请填写备注")
	}
	if operation.ExchangeName == "" || operation.ExchangeId == "" {
		return errors.New("预审流转, 流转姓名和id不能为空")
	}

	pao.OpDesc = operation.StatusDes
	pao.PreApprovalStatus = model.PREAPPROVALEXCHANGE
	if err := pao.Update(); err != nil {
		return err
	}

	AsyncNewPreApprovalLog(&model.PreApprovalLog{
		PreApprovalId:     pao.PreApprovalID,
		PreApprovalName:   pao.PreTrailName,
		PreApprovalStatus: "预审流转给" + operation.ExchangeName,
	})

	return
}

func (operation *PreApprovalOperationReq) Refuse() (err error) {
	pao, err := model.GetPreApprovalOrderByPreApprovalId(operation.PreApprovalID)
	if err != nil {
		return
	}

	if operation.StatusDes == "" {
		return errors.New("预审操作备注不能为空，请填写备注")
	}

	nowTime := time.Now()
	pao.OpDesc = operation.StatusDes
	pao.PreApprovalStatus = model.PREAPPROVALREFUSE
	pao.RefuseTime = &nowTime

	if err := pao.Update(); err != nil {
		return err
	}

	SendPvSms(pao, "refuse")

	AsyncNewPreApprovalLog(&model.PreApprovalLog{
		PreApprovalId:     pao.PreApprovalID,
		PreApprovalName:   pao.PreTrailName,
		PreApprovalStatus: pao.PreApprovalStatus,
	})

	return
}

func (operation *PreApprovalOperationReq) Cancel() (err error) {
	pao, err := model.GetPreApprovalOrderByPreApprovalId(operation.PreApprovalID)
	if err != nil {
		return
	}

	if pao.PreApprovalType != model.QD_PREAPPROVAL {
		return errors.New("非渠道申请，无法撤销")
	} else {
		if pao.IsFast == model.FS_PREAPPROVAL {
			return errors.New("快速预审批，无法撤销")
		}
	}

	if operation.StatusDes == "" {
		return errors.New("预审操作备注不能为空，请填写备注")
	}
	nowTime := time.Now()
	pao.OpDesc = operation.StatusDes
	pao.PreApprovalStatus = model.PREAPPROVALCANCEL //  撤销
	pao.CancelTime = &nowTime

	if err := pao.Update(); err != nil {
		return err
	}

	AsyncNewPreApprovalLog(&model.PreApprovalLog{
		PreApprovalId:     pao.PreApprovalID,
		PreApprovalName:   pao.PreTrailName,
		PreApprovalStatus: pao.PreApprovalStatus,
	})
	return
}
