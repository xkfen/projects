package service

import "gapproval/approval/model"

func GetTestApprovalOperationCS(s ...string) ApprovalOperationCS {
	var status, refuseReason, exchangeId, exchangeName, repulseData string
	var operation = map[string]string{"pass": model.ApprovalStatusFirstTrailPass,
		"refuse": model.ApprovalStatusFirstTrailRefuse,
		"repulse": model.ApprovalStatusFirstTrailRepulse,
		"cancel": model.ApprovalStatusCustomCancel,
		"back": model.ApprovalStatusFirstTrailBackIv,
		"exchange": model.ApprovalStatusFirstTrailExchange,
		"suspend": model.ApprovalSuspend,
	}
	switch len(s) {
	case 0:
		status = model.ApprovalStatusFirstTrailPass
	default:
		status = operation[s[0]]
		switch operation[s[0]] {
		case model.ApprovalStatusFirstTrailRefuse:
			refuseReason = "拒绝拒绝拒接"
		case model.ApprovalStatusFirstTrailExchange:
			exchangeId = "123"
			exchangeName = "test123456789"
		case model.ApprovalStatusFirstTrailRepulse:
			repulseData = "打回原因"
		default:
		}
	}

	return ApprovalOperationCS{
		JinjianId:      "测试123进件ID",
		Status:         status,
		StatusDes:      "测试测试测试 状态说明",
		RefuseReason:   refuseReason,
		ExchangeId:     exchangeId,
		ExchangeName:   exchangeName,
		RepulseData:    repulseData,
		//ExternalReason: "", // todo *****
	}
}

func GetDefaultApprovalOperationZS(jjId, status string) *ApprovalOperationZS {
	var refuseReason, exchangeId, exchangeName, externalReason string
	var sendUserMsgSwitch bool
	if status == "" {
		status = model.ApprovalStatusReTrailPass
	}
	switch status {
	case model.ApprovalStatusReTrailPass:
		sendUserMsgSwitch = true
	case model.ApprovalStatusReTrailRefuse:
		sendUserMsgSwitch = true
		refuseReason = "拒绝拒绝"
		externalReason = "外部原因"
	case model.ApprovalStatusCustomCancel:
		// 暂时无需添加
	case model.ApprovalStatusReTrailBackIv:
		// 暂时无需添加
	case model.ApprovalSuspend:
		// 暂时无需添加
	case model.ApprovalStatusReTrailExchange:
		exchangeId = "123"
		exchangeName = "exchangeNameTest"
	case model.ApprovalStatusReTrailBack:
		// 暂时无需添加
	default:
	}

	return &ApprovalOperationZS{
		JinjianId:         jjId,
		Status:            status,            // 审批操作
		StatusDes:         "测试状态说明",      // 操作备注
		ExchangeId:        exchangeId,        // 流转账号
		ExchangeName:      exchangeName,      // 流转姓名
		RefuseReason:      refuseReason,      // 主要原因
		ExternalReason:    externalReason,    // 外部原因
		SendUserMsgSwitch: sendUserMsgSwitch, // 发送消息开关
	}
}

func GetDefaultApprovalOperationKF(jjId, status string) *ApprovalOperationKF {
	var refuseReason, exchangeId, exchangeName string
	if status == "" {
		status = model.ApprovalStatusCustomPass
	}
	switch status {
	case model.ApprovalStatusCustomPass:
		// 暂时无需添加
	case model.ApprovalStatusCustomRefuse:
		refuseReason = "拒绝拒绝"
	case model.ApprovalSuspend:
		// 暂时无需添加
	case model.ApprovalStatusCustomServiceExchange:
		exchangeId = "123"
		exchangeName = "exchangeNameTest"
	case model.ApprovalStatusCustomServiceBack:
	default:
	}

	return &ApprovalOperationKF{
		JinjianId:         jjId,
		Status:            status,            // 审批操作
		StatusDes:         "测试状态说明",      // 操作备注
		ExchangeId:        exchangeId,        // 流转账号
		ExchangeName:      exchangeName,      // 流转姓名
		RefuseReason:      refuseReason,      // 主要原因
	}
}