package service

import (
	"gapproval/approval/model"
	"gcoresys/common/util"
	"gapproval/approval/db/config"
	"errors"
	"time"
	"gcoresys/common/logger"
)

const perPage  = 10

// 查询预审批订单请求参数
type QueryPreApprovalOrderListReq struct {
	// 申请方式
	ApplyType string `json:"apply_type"`
	// 查询条件
	Condition string `json:"condition"`
	// 排序:预审提交时间
	CommitTime string `json:"commit_time"`
	// 页数
	Page int `json:"page"`
}

// 历史订单列表项请求参数
type HistoryPreOrderListReq struct {
	//  申请方式
	ApplyType string `json:"apply_type"`
	// 进件筛选:已进件，未进件
	Enter string `json:"enter"`
	// 模糊查询条件
	Condition string `json:"condition"`
	// 预审提交时间
	CommitTime string `json:"commit_time"`
	// 预审批结束时间
	EndTime string `json:"end_time"`
	// 客户进件时间
	JinjianTime string `json:"jinjian_time"`
	// 页数
	Page int `json:"page"`
}

// 预审批查询--查询请求参数
type PreApprovalQueryParam struct {
	// 审核人
	Auditor string `json:"auditor"`
	// 审核人ID
	AuditorId string `json:"auditor_id"`
	// 用户姓名
	JinJianUserName string `json:"jin_jian_user_name"`
	// 用户身份证号
	UserIdNum string `json:"user_id_num"`
	// 预审状态
	PreStatus string `json:"pre_status"`
	// 所属渠道
	AgencyName string `json:"agency_name"`
	// 业务员
	AgencyEmployee string `json:"agency_employee"`
	// 申请预审开始时间
	ApplyStartTime *time.Time `json:"apply_start_time"`
	// 申请预审结束时间
	ApplyEndTime *time.Time `json:"apply_end_time"`
	// 预审结束开始时间
	FinishStartTime *time.Time `json:"finish_start_time"`
	// 预审结束结束时间
	FinishEndTime *time.Time `json:"finish_end_time"`
	JinJianStartTime *time.Time `json:"jin_jian_start_time"`
	JinJianEndTime *time.Time `json:"jin_jian_end_time"`
	// page
	Page int `json:"page"`
	DownloadAll  bool   `json:"download_all"`
}

// 预审批列表
func queryPreApprovalOrderList(username, name string , req QueryPreOrderListReq)(list []model.PreApprovalOrder, totalPages, totalCount int, err error){
	logger.Debug("------------------我的预审批订单列表-----------------")
	offset := util.GetOffset(req.Page, perPage)
	baseSql := config.GetDb().Model(&model.PreApprovalOrder{}).Where("pre_trail_id = ? and pre_trail_name = ? and pre_approval_status in (?)", username, name , []string{model.PREAPPROVALING, model.PREAPPROVALREPULSE})
	// 申请方式
	if req.ApplyType != "all"{
		baseSql = baseSql.Where("is_fast = ?", req.ApplyType)
	}
	// 模糊查询
	if req.Condition != "" {
		req.Condition = "%" + req.Condition + "%"
		baseSql = baseSql.Where("user_name LIKE ? OR user_id_num LIKE ? OR pre_approval_id LIKE ? ", req.Condition, req.Condition, req.Condition )
	}
	if req.Sort != "" {
		baseSql = baseSql.Order(req.Sort)
	}else {
		baseSql = baseSql.Order("commit_time desc" )
	}

	// 判断页数
	if req.Page <= 0 {
		return nil, 0, 0, errors.New("页数不对")
	}
	// 获取总页数
	totalPages, totalCount = util.GetTotalPagesAndCount(baseSql, &list, perPage)
	// 获取预审列表 -- 分页后的数据
	if err := baseSql.Offset(offset).Limit(perPage).Find(&list).Error; err != nil {
		logger.Error("获取我的预审列表出错", "err", err.Error())
	}

	return
}


// 历史订单状态
func getHistoryPreOrderStatus() []string{
	return []string{model.PREAPPROVALPASS, model.PREAPPROVALREFUSE, model.PREAPPROVALCANCEL}
}

// 历史订单列表
func queryHistoryPreOrderList(req QueryPreOrderListReq, username, name string)(historyOrderList []model.PreApprovalOrder, totalPages, totalCount int ,err error){
	logger.Debug("------------------预审批历史订单列表-----------------")
	offset := util.GetOffset(req.Page, perPage)
	baseSql := config.GetDb().Model(&model.PreApprovalOrder{}).Where("pre_trail_id = ? AND pre_trail_name = ? AND pre_approval_status in (?)", username, name,  getHistoryPreOrderStatus())
	// 申请方式
	if req.ApplyType != "all" {
		baseSql = baseSql.Where("is_fast = ?", req.ApplyType)
	}
	// 判断是否进件
	switch req.Enter {
	case "未进件":
		baseSql = baseSql.Where("jinjian_id = ?", "")
	case "已进件":
		baseSql = baseSql.Where("jinjian_id <> ?", "")
	}

	// 模糊查询
	if req.Condition != "" {
		req.Condition = "%" + req.Condition + "%"
		baseSql = baseSql.Where("user_name LIKE ? OR user_id_num LIKE ? OR pre_approval_id LIKE ? ", req.Condition, req.Condition, req.Condition )
	}

	if req.Sort != "" {
		baseSql = baseSql.Order(req.Sort)
	}else{
		baseSql = baseSql.Order("commit_time desc")
	}

	// 判断页数
	if req.Page <= 0 {
		return nil, 0, 0, errors.New("页数不对")
	}
	// 获取总页数
	totalPages, totalCount = util.GetTotalPagesAndCount(baseSql, &historyOrderList, perPage)
	// 获取预审列表 -- 分页后的数据
	if err := baseSql.Offset(offset).Limit(perPage).Find(&historyOrderList).Error; err != nil {
		logger.Error("获取历史预审列表出错", "err", err.Error())
	}
	return
}


// 查询模块--列表
func queryPreApprovalOrdersByParams(params QueryPreOrderListReq)(orders []model.PreApprovalOrder,totalPages int, totalCount int,  err error){
	logger.Debug("------预审批查询-----------------")
	baseSql := config.GetDb().Model(&model.PreApprovalOrder{})
	if params.PreTrailName != "" {
		baseSql = baseSql.Where("pre_trail_name like ?", params.PreTrailName)
	}
	if params.PreShowId != ""{
		baseSql = baseSql.Where("pre_show_id like ?", params.PreShowId)
	}
	if params.JinJianUserName != "" {
		baseSql = baseSql.Where("user_name like ?", params.JinJianUserName)
	}
	if params.UserIdNum != "" {
		baseSql = baseSql.Where("user_id_num like ? ", params.UserIdNum)
	}
	// 筛选预审批状态
	if params.PreStatus != "all" {
		if params.PreStatus == model.PREAPPROVALING {
			baseSql = baseSql.Where("pre_approval_status = ?", model.PREAPPROVALING)
		}else if params.PreStatus == model.PREAPPROVALPASS{
			baseSql = baseSql.Where("pre_approval_status = ?", model.PREAPPROVALPASS)
		}else if params.PreStatus == model.PREAPPROVALREPULSE{
			baseSql = baseSql.Where("pre_approval_status = ?", model.PREAPPROVALREPULSE)
		}else if params.PreStatus == model.PREAPPROVALREFUSE{
			baseSql = baseSql.Where("pre_approval_status = ?", model.PREAPPROVALREFUSE)
		}else if params.PreStatus == model.PREAPPROVALCANCEL{
			baseSql = baseSql.Where("pre_approval_status = ?", model.PREAPPROVALCANCEL)
		}
	}else {
		baseSql = baseSql.Where("pre_approval_status in (?)",  []string{ model.WAITPREAPPROVAL, model.PREAPPROVALING, model.PREAPPROVALPASS, model.PREAPPROVALREPULSE, model.PREAPPROVALREFUSE, model.PREAPPROVALCANCEL, model.PREAPPROVALEXCHANGE})
	}
	// 业务员
	if params.AgencyEmployee != "" {
		baseSql = baseSql.Where("agency_employee like ?", params.AgencyEmployee)
	}
	// 渠道
	if params.AgencyName != "" {
		baseSql = baseSql.Where("agency_name like ?", params.AgencyName)
	}
	// 客户经理
	if params.CustomerManager != "" {
		baseSql = baseSql.Where("customer_managers like ?", params.CustomerManager)
	}
	// 预审批申请时间
	if params.ApplyStartTime != "" && params.ApplyEndTime == "" {
		startTime, _ := strDate2Time(params.ApplyStartTime)
		baseSql = baseSql.Where("created_at >= ?" , startTime)
	}
	if params.ApplyStartTime == "" && params.ApplyEndTime != "" {
		endTime, _ := strDate2Time(params.ApplyEndTime)
		baseSql = baseSql.Where("created_at <= ?" , endTime)
	}
	if params.ApplyStartTime != "" && params.ApplyEndTime != "" {
		startTime, _ := strDate2Time(params.ApplyStartTime)
		endTime, _ := strDate2Time(params.ApplyEndTime)
		if startTime.After(*endTime) {
			return nil, 0, 0, errors.New("预审批申请开始时间不能晚于预审批申请结束时间")
		}
		baseSql = baseSql.Where("created_at between ? and  ?", startTime, endTime)
	}

	// 预审批结束时间
	if params.FinishStartTime != "" && params.FinishEndTime == "" {
		startTime, _ := strDate2Time(params.FinishStartTime)
		baseSql= baseSql.Where("updated_at >= ?", startTime)
	}
	if params.FinishStartTime == "" && params.FinishEndTime != "" {
		endTime, _ := strDate2Time(params.FinishEndTime)
		baseSql= baseSql.Where("updated_at <= ? ", endTime)
	}
	if params.FinishStartTime != "" && params.FinishEndTime != "" {
		startTime, _ := strDate2Time(params.FinishStartTime)
		endTime, _ := strDate2Time(params.FinishEndTime)
		if startTime.After(*endTime) {
			return nil, 0, 0, errors.New("开始时间不能晚于结束时间")
		}
		baseSql = baseSql.Where("updated_at between ? and ? ", startTime, endTime )
	}
	// 进件时间
	if params.JinJianStartTime != "" && params.JinJianEndTime == "" {
		startTime , _ := strDate2Time(params.JinJianStartTime)
		baseSql = baseSql.Where("jinjian_time >= ?", startTime)
	}

	if params.JinJianStartTime == "" && params.JinJianEndTime != "" {
		endTime, _ := strDate2Time(params.JinJianEndTime)
		baseSql = baseSql.Where("jinjian_time <= ?", endTime)
	}

	if params.JinJianStartTime != "" && params.JinJianEndTime != "" {
		startTime , _ := strDate2Time(params.JinJianStartTime)
		endTime, _ := strDate2Time(params.JinJianEndTime)
		if startTime.After(*endTime){
			return nil, 0, 0, errors.New("进件开始时间不能晚于进件结束时间")
		}
		baseSql = baseSql.Where("jinjian_time between ? and ? ", startTime, endTime)
	}

	if params.OrderStatus == "all" {
		baseSql.Where("pre_approval_status in (?)", []string{model.WAITPREAPPROVAL, model.PREAPPROVALING, model.PREAPPROVALREPULSE, model.PREAPPROVALEXCHANGE, model.PREAPPROVALPASS, model.PREAPPROVALREFUSE, model.PREAPPROVALCANCEL})
	}else if params.OrderStatus == "handling" {
		baseSql = baseSql.Where("pre_approval_status in (?)", []string{model.WAITPREAPPROVAL, model.PREAPPROVALING, model.PREAPPROVALREPULSE, model.PREAPPROVALEXCHANGE})
	}else if params.OrderStatus == "ending" {
		baseSql = baseSql.Where("pre_approval_status in (?)", []string{model.PREAPPROVALPASS, model.PREAPPROVALREFUSE, model.PREAPPROVALCANCEL})
	}

	if params.Sort != "" {
		baseSql = baseSql.Order(params.Sort)
	}else{
		baseSql = baseSql.Order("commit_time desc")
	}

	// 判断页数
	if params.Page <= 0 {
		return nil, 0, 0, errors.New("页数不对")
	}

	// 翻页
	offset := util.GetOffset(params.Page, perPage)
	totalPages, totalCount = util.GetTotalPagesAndCount(baseSql, &orders, perPage)

	if params.DownloadAll {
		baseSql.Find(&orders)
	} else {
		baseSql.Offset(offset).Limit(perPage).Find(&orders)
	}
	return
}

type QueryPreOrderListReq struct {
	Key string `json:"key"`
	// 申请方式
	ApplyType string `json:"apply_type"`
	// 查询条件
	Condition string `json:"condition"`
	// 排序:预审提交时间
	CommitTime string `json:"commit_time"`
	// 页数
	Page int `json:"page"`

	// history
	// 进件筛选:已进件，未进件
	Enter string `json:"enter"`
	// query
	// 审核人
	PreTrailName string `json:"pre_trail_name"`
	// 预审ID
	PreShowId string `json:"pre_show_id"`
	// 用户姓名
	JinJianUserName string `json:"jin_jian_user_name"`
	// 用户身份证号
	UserIdNum string `json:"user_id_num"`
	// 预审状态
	PreStatus string `json:"pre_status"`
	// 所属渠道
	AgencyName string `json:"agency_name"`
	// 业务员
	AgencyEmployee string `json:"agency_employee"`
	// 客户经理
	CustomerManager string `json:"customer_manager"`
	// 申请预审开始时间
	ApplyStartTime string `json:"apply_start_time"`
	// 申请预审结束时间
	ApplyEndTime string `json:"apply_end_time"`
	// 预审结束开始时间
	FinishStartTime string `json:"finish_start_time"`
	// 预审结束结束时间
	FinishEndTime string `json:"finish_end_time"`
	JinJianStartTime string `json:"jin_jian_start_time"`
	JinJianEndTime string `json:"jin_jian_end_time"`
	// 筛选："all":全部业务，"handling":在办业务，"ending":已完业务
	OrderStatus string `json:"order_status"`
	DownloadAll  bool   `json:"download_all"`
	// 排序，我的订单/查询里面的“预审批提交时间”，“预审批结束时间”， ’进件时间‘
	Sort string `json:"sort"`
}

func strDate2Time(dateStr string)(date *time.Time, err error){
	tmp, _ := time.Parse("2006-01-02", dateStr)
	date = &tmp
	return
}

func QueryPreApprovalListByKey(username, name string, req QueryPreOrderListReq)(preOrderList []model.PreApprovalOrder, totalPages, totalCount int, err error){
	switch req.Key {
	case "me":
		preOrderList, totalPages, totalCount, err = queryPreApprovalOrderList(username, name, req)
		return
	case "history":
		preOrderList, totalPages, totalCount, err = queryHistoryPreOrderList(req, username, name)
		return
	case "query":
		preOrderList, totalPages, totalCount, err = queryPreApprovalOrdersByParams(req)
		return
	default:
		return nil, 0, 0, errors.New("预审批查询传入的key非法，应该为me/history/query")
	}
}