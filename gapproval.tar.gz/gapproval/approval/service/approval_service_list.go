package service

//import (
//	gsso "gsso/config"
//	"gapproval/approval/db/config"
//	"gapproval/approval/model"
//	"gapproval/approval/serviceV1"
//)
//
//type OrderCounts struct{
//	Grab      int `json:"grab"`
//	Mine      int `json:"mine"`
//	Suspended int `json:"suspended"`
//	Back      int `json:"back"`
//}
//
//func GetOrderCounts(queryType string, username string, name string) (counts OrderCounts) {
//	sqlBase := config.GetDb().Model(&model.ApprovalOrder{})
//	switch queryType {
//	case gsso.APPROVAL_CS:
//		sqlBase.Where("first_trail_status = ? AND first_trail_id = 'Null' AND first_trail_name = 'Null'", model.ApprovalStatusWaitFirstTrail).Count(counts.Grab)
//		sqlBase.Where("first_trail_status IN (?) AND first_trail_id = ? AND first_trail_name = ?", serviceV1.FirstTrailStatusList("me", ""), username, name).Count(counts.Mine)
//		sqlBase.Where("first_trail_status IN (?) AND first_trail_id = ? AND first_trail_name = ? AND suspending = 'on'", serviceV1.FirstTrailStatusList("me", ""), username, name).Count(counts.Suspended)
//		sqlBase.Where("first_trail_status = ? AND first_trail_id = ? AND first_trail_name = ?", model.ApprovalStatusReTrailBack, username, name).Count(counts.Back)
//	case gsso.APPROVAL_ZS:
//		sqlBase.Where("re_trail_status = ? AND re_trail_id = 'Null' AND re_trail_name = 'Null'", model.ApprovalStatusWaitReTrail).Count(counts.Grab)
//		sqlBase.Where("re_trail_status IN (?) AND re_trail_id = ? AND re_trail_name = ?", serviceV1.ReTrailStatusList("me", ""), username, name).Count(counts.Mine)
//		sqlBase.Where("re_trail_status IN (?) AND re_trail_id = ? AND re_trail_name = ? AND suspending = 'on'", serviceV1.ReTrailStatusList("me", ""), username, name).Count(counts.Suspended)
//		sqlBase.Where("re_trail_status IN (?) AND re_trail_id = ? AND re_trail_name = ?", []string{model.ApprovalStatusCustomServiceBack, model.ApprovalStatusFinanceBack}, username, name).Count(counts.Back)
//	case gsso.APPROVAL_KF:
//		sqlBase.Where("custom_service_status = ? AND custom_service_id = 'Null' AND custom_service_name = 'Null'", model.ApprovalStatusWaitFirstTrail).Count(counts.Grab)
//		sqlBase.Where("custom_service_status IN (?) AND custom_service_id = ? AND custom_service_name = ?", serviceV1.CustomServiceStatusList("me", ""), username, name).Count(counts.Mine)
//		sqlBase.Where("custom_service_status IN (?) AND custom_service_id = ? AND custom_service_name = ? AND suspending = 'on'", serviceV1.CustomServiceStatusList("me", ""), username, name).Count(counts.Suspended)
//		sqlBase.Where("custom_service_status = ? AND custom_service_id = ? AND custom_service_name = ?", model.ApprovalStatusFinanceBack, username, name).Count(counts.Back)
//	}
//	return
//}