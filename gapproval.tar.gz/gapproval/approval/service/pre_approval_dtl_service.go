package service

import (
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"github.com/jinzhu/gorm"
	"gcoresys/common/logger"
)

// 公共方法，根据预审id查询预审订单
func GetPreApprovalOrderById(preApprovalId string)(preOrder model.PreApprovalOrder, err error){
	if err = config.GetDb().Model(&model.PreApprovalOrder{}).Where("pre_approval_id = ?", preApprovalId).First(&preOrder).Error; err != nil && err != gorm.ErrRecordNotFound{
		logger.Error("err", "根据预审单id查询预审批订单出错", err.Error())
		return
	}
	return
}

// 订单简要信息，显示进件方案，产品方案，预审编号，客户姓名，身份证号，订单状态
func GetBriefPreOrderInfo(preApprovalId string)(preOrder model.PreApprovalOrder, err error){
	logger.Debug("------订单简要信息，显示进件方案，产品方案，预审编号，客户姓名，身份证号，订单状态------")
	if err = config.GetDb().Model(&model.PreApprovalOrder{}).Select([]string{
		"pre_show_id",
		"jinjian_plan",
		"introduction_plan_num",
		"user_name",
		"user_id_num",
		"pre_approval_status",
	}).Where("pre_approval_id = ?", preApprovalId).First(&preOrder).Error; err != nil && err != gorm.ErrRecordNotFound{
		logger.Error("err", "根据预审单id查询预审批订单简要信息出错", err.Error())
		return
	}
	return
}

// 修改预审信息请求参数：进件方案、姓名、身份证号、电话
type UpdatePreInfoReq struct {
	PreApprovalId string `json:"pre_approval_id"`
	JinjianPlan string `json:"jinjian_plan"`
	UserName string `json:"user_name"`
	UserIdNum string `json:"user_id_num"`
	PhoneNumber string `json:"phone_number"`
}

// 预审修改：进件方案、姓名、身份证号、电话为可编辑项
func UpdatePreOrderInfo(req UpdatePreInfoReq)(err error){
	logger.Debug("---------进件方案、姓名、身份证号、电话为可编辑项------------")
	preOrder , err := GetPreApprovalOrderById(req.PreApprovalId)
	if err != nil {
		return
	}
	preOrder.JinjianPlan = req.JinjianPlan
	preOrder.UserName = req.UserName
	preOrder.UserIdNum = req.UserIdNum
	preOrder.PhoneNumber = req.PhoneNumber
	logger.Debug("----更新进件方案、姓名、身份证号、电话-----")
	if err = config.GetDb().Model(&model.PreApprovalOrder{}).Where("pre_approval_id = ?", req.PreApprovalId).Update(&preOrder).Error; err != nil {
		logger.Error("err", "更新进件方案、姓名、身份证号、电话出错", err.Error())
		return
	}
	return
}
