package service

import (
	"testing"
	"github.com/stretchr/testify/assert"
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"gcoresys/common/util"
	"time"
	"fmt"
)

func TestUpdateJinjianAllInfo(t *testing.T) {
	oneStepTest(func() {
		order := model.GetDefaultApprovalOrder()
		order.FirstTrailId = "123"
		order.FirstTrailName = "1231"
		order.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
		fmt.Println("====================================",order.FirstTrailStatus)
		assert.NoError(t, config.GetDb().Create(&order).Error)
		fmt.Println("====================================",order.FirstTrailStatus)

		order.JinjianUserName = "测试"
		order.UserIdNum = "610302199901011234"

		assert.NoError(t, UpdateApprovalOrderInfo("base_info", "cs", *order))

		var resultOrder model.ApprovalOrder
		assert.NoError(t, config.GetDb().Find(&resultOrder, "jinjian_id = ?", order.JinjianId).Error)

		var allInfo map[string]interface{}
		assert.NoError(t, util.ParseJson(resultOrder.AllInfo, &allInfo))

		assert.Equal(t, "测试", resultOrder.JinjianUserName, "匹配失败")
		assert.Equal(t, "610302199901011234", resultOrder.UserIdNum, "匹配失败")

		//assert.NotEqual(t, order.OrderInfo, resultOrder.OrderInfo)
	})
}

func TestSaveLoanInfo(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
		assert.NoError(t, ao.Create())

		m := time.Now()
		changeAO := model.ApprovalOrder{
			JinjianId:           ao.JinjianId,
			ApprovedAmount:      200,
			ApprovedRate:        10,
			PlatformMonthRate:   5,
			SalaryAt:            &m,
			LoanAt:              &m,
			Card1:               "123",
			LoanCard:            "123",
			CardOneChoiceReason: "123",
		}
		assert.NoError(t, SaveLoanInfo(changeAO, "cs"))

		resAO, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.NoError(t, err)

		assert.Equal(t, changeAO.ApprovedAmount, resAO.ApprovedAmount)
		assert.Equal(t, changeAO.LoanCard, resAO.LoanCard)

	})
}