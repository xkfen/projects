package service

import (
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"time"
	"gcoresys/common/logger"
	"errors"
	"gcoresys/common/util"
)

// 创建预审批
func CreatePreApproval(pao *model.PreApprovalOrder) (err error) {
	if err = pao.IsVaildPreApprovalOrder(); err != nil {
		logger.Error("创建预审单错误", "err", err.Error())
		return
	}
	refuseResult, err := CheckPaRefuseByUserIdNum(pao.UserIdNum)
	if err != nil {
		logger.Error("===============CreatePreApproval CheckPaRefuseByUserIdNum", "err ", err.Error())
		return
	}

	if refuseResult != nil {
		logger.Error("========用户预审有拒绝的预审单 ==30天=====CreatePreApproval CheckPaRefuseByUserIdNum", "refuseResult ",
			util.StringifyJson(refuseResult))
		err = errors.New("用户预审有拒绝的预审单，暂时无法创建预审")
		return
	}

	if err = transactCreatePreApproval(pao); err != nil {
		return
	}
	return
}

func transactCreatePreApproval(pao *model.PreApprovalOrder) (err error) {
	// 开启事物
	txSqlBase := config.GetDb().Begin()

	// 设置提交时间

	if pao.CommitTime == nil {
		nowTime := time.Now()
		pao.CommitTime = &nowTime
	}

	// 获取申请次数
	pao.PreApprovalCount = pao.GetPreApprovalCountByUserIdNum() + 1
	// 预审状态  待预审
	pao.PreApprovalStatus = model.WAITPREAPPROVAL

	// 2018-01-29 11:56:24  快速预审批，获取征信报告后，自动预审批通过  （不进入抢单池、订单池）
	if pao.PreApprovalType == model.QD_PREAPPROVAL && pao.IsFast == model.FS_PREAPPROVAL {
		pao.PreTrailId = "auto_pass"
		pao.PreTrailName = "自动通过"
		pao.PreApprovalStatus = model.PREAPPROVALPASS
		nowTime := time.Now()
		pao.PassTime = &nowTime
		pao.OpDesc = "快速预审，自动通过"
	}

	// 创建 预审批单
	if err = txSqlBase.Model(&model.PreApprovalOrder{}).Create(pao).Error; err != nil {
		logger.Error("============创建预审批单出错err: " + err.Error())
		txSqlBase.Rollback()
		return
	}

	// 创建 预审操作日志
	if err = txSqlBase.Model(&model.PreApprovalLog{}).Create(&model.PreApprovalLog{
		PreApprovalId:     pao.PreApprovalID,
		PreApprovalName:   pao.AgencyName + " " + pao.AgencyEmployee,
		PreApprovalStatus: "渠道完成申请",
		PreApprovalDesc:   "",
	}).Error; err != nil {
		logger.Error("============创建预审批log出错err: " + err.Error())
		txSqlBase.Rollback()
		return
	}

	txSqlBase.Commit()
	return
}


// 通过身份证查询在库15天是否有拒绝
func CheckPaRefuseByUserIdNum(idNum string) (result *model.PreApprovalOrder, err error) {
	var pao model.PreApprovalOrder
	nowTime := time.Now()
	before90Time := nowTime.Add(-15 * 24 * time.Hour)
	if err = config.GetDb().Model(&model.PreApprovalOrder{}).Select([]string{
		"id",
		"pre_approval_id",
		"user_id_num",
		"pre_approval_status",
		"commit_time",
		"refuse_time",
	}).Where("user_id_num = ? AND pre_approval_status = ? AND commit_time BETWEEN ? AND ?",
		idNum, model.PREAPPROVALREFUSE, before90Time, nowTime).First(&pao).Error; err != nil {
		if err.Error() == "record not found" {
			return nil, nil
		}
		logger.Error("=============通过身份证查询在库90天是否有拒绝出错============: " + err.Error())
		return
	}
	if pao.ID != 0 {
		result = &pao
		return result, nil
	}
	return
}