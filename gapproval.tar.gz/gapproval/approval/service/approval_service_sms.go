package service

import (
	"fmt"
	"gapproval/approval/model"
	"gcoresys/common/logger"
	"gcoresys/common/util"
	"gapproval/common/httpReq"
	"gapproval/common/global"
	gssoResp "gsso/handler"
	gssoModel "gsso/model"
	"errors"
	coresysSmsModel "gcoresys/common/trace_log/model"
	"gcoresys/common/trace_log"
	"time"
	"gapproval/approval/db/config"
	"gcoresys/common/util/sms"
	preViewReq "gpreview/handler/req_model"
)

// 外部调用
func SendPvSms(pao model.PreApprovalOrder, status string) {
	sendPvSms(pao, status)
}

// 预审发短信
func sendPvSms(pao model.PreApprovalOrder, status string) {
	if !util.IsTestEnv() {
		logger.Info(pao.PreApprovalID + "========预审==短信终审审批状态============: " + status)
		resp, err := GetPreViewChannelManagerAndBroker(pao.AgencyEmployeeId)
		if err == nil {
			if resp != nil {
				// 渠道经理
				switch status {
				case "pass":
					for _, cm := range resp.Managers {
						baseSendSms(pao.PreApprovalID, pao.PreTrailName, cm.Cellphone, cmSmsPaPassMsg(pao, cm.ShowName), "")
					}

					for _, cm := range resp.ChanUsers {
						baseSendSms(pao.PreApprovalID, pao.PreTrailName, cm.Cellphone, cmSmsPaPassMsg(pao, cm.ShowName), "")
					}
				case "refuse":
					for _, cm := range resp.Managers {
						baseSendSms(pao.PreApprovalID, pao.PreTrailName, cm.Cellphone, cmSmsPaRefuseMsg(pao, cm.ShowName), "")
					}

					for _, cm := range resp.ChanUsers {
						baseSendSms(pao.PreApprovalID, pao.PreTrailName, cm.Cellphone, cmSmsPaRefuseMsg(pao, cm.ShowName), "")
					}
				case "repulse":
					for _, cm := range resp.Managers {
						baseSendSms(pao.PreApprovalID, pao.PreTrailName, cm.Cellphone, cmSmsPaRepulseMsg(pao, cm.ShowName), "")
					}

					for _, cm := range resp.ChanUsers {
						baseSendSms(pao.PreApprovalID, pao.PreTrailName, cm.Cellphone, cmSmsPaRepulseMsg(pao, cm.ShowName), "")
					}
				}
			} else {
				logger.Error("请求PreView resp为空")
			}
		} else {
			logger.Error("请求PreView获取渠道经理、中介出错: " + err.Error())
		}
	} else {
		logger.Info("==============sendPvSms========单元测试不能发短信===============")
	}

}

// 外部调用接口
func SendSms(ao model.ApprovalOrder, status string, sendUser bool) {
	sendSms(ao, status, sendUser)
}

//  发送短信
func sendSms(ao model.ApprovalOrder, status string, sendUser bool) {
	logger.Info("==========短信终审审批状态============: "+status, "sendUser", sendUser)

	if !util.IsTestEnv() {
		// 获取渠道经理发送短信
		if users, err := GetChannelManager(ao); err == nil {
			logger.Info("==========渠道经理发送短信============", "渠道经理s", users)
			switch status {
			case "pass":
				for _, cm := range users {
					baseSendSms(ao.JinjianId, ao.ReTrailName, cm.Cellphone, cmSmsPassMsg(ao, cm.Name), time.Now().Add(time.Minute * 30).Format("20060102150405"))
				}
			case "refuse":
				for _, cm := range users {
					baseSendSms(ao.JinjianId, ao.ReTrailName, cm.Cellphone, cmSmsRefuseMsg(ao, cm.Name), "")
				}
			case "cancel":
				for _, cm := range users {
					baseSendSms(ao.JinjianId, "撤销", cm.Cellphone, cmSmsCancelMsg(ao, cm.Name), "")
				}
			}
		} else {
			logger.Error("请求GSSO获取渠道经理出错: " + err.Error())
		}

		// 发给中介
		if brokerName, brokerCellphone, err := GetBroker(ao.JinjianId); err == nil {
			logger.Info("==========中介发送短信============", "中介", brokerName)
			switch status {
			case "pass":
				baseSendSms(ao.JinjianId, ao.ReTrailName, brokerCellphone, cmSmsPassMsg(ao, brokerName), time.Now().Add(time.Minute * 30).Format("20060102150405"))
			case "refuse":
				baseSendSms(ao.JinjianId, ao.ReTrailName, brokerCellphone, cmSmsRefuseMsg(ao, brokerName), "")
			case "cancel":
				baseSendSms(ao.JinjianId, "撤销", brokerCellphone, cmSmsCancelMsg(ao, brokerName), "")
			}
		} else {
			logger.Error("请求NQy获取中介出错: " + err.Error())
		}

		// 发给用户
		logger.Info("==========是否发送给用户短信开关============", "sendUser", sendUser)
		if sendUser {
			switch status {
			case "pass":
				//baseSendSms(ao.JinjianId, ao.ReTrailName, ao.JinjianUserId, ApprovalSuccessSmsMsg,
				//	time.Now().Add(2 * time.Hour).Format("20060102150405"))
			case "refuse":
				baseSendSms(ao.JinjianId, ao.ReTrailName, ao.JinjianUserId, uSmsRefuseMsg(ao),
					time.Now().AddDate(0, 0, 2).Format("20060102150405"))
			case "cancel":
				baseSendSms(ao.JinjianId, "撤销", ao.JinjianUserId, uSmsCancelMsg(ao),
					time.Now().AddDate(0, 0, 2).Format("20060102150405"))
			}
		}
	} else {
		logger.Info("===========sendSms===========单元测试不能发短信===============")
	}

}

//  审批短信模板

//  发给用户  拒绝
func uSmsRefuseMsg(ao model.ApprovalOrder) (msg string) {
	return fmt.Sprintf("尊敬的%v女士/先生，您的借款申请因故未能通过审核。感谢您的理解与支持！核查周期90天后，你可再次在启元优享平台申请借款，详情请关注启元优享公众号！", ao.JinjianUserName)
}

//  发给用户  拒绝
func uSmsCancelMsg(ao model.ApprovalOrder) (msg string) {
	return fmt.Sprintf("尊敬的%v女士/先生，您的借款申请因故未能通过审核。感谢您的理解与支持，详情请关注启元优享公众号！", ao.JinjianUserName)
}

// 渠道终审拒绝模板短信
func cmSmsRefuseMsg(ao model.ApprovalOrder, name string) (msg string) {
	return fmt.Sprintf("尊敬的%v女士/先生:您所经办的借款编号%v，申请时间：%v，借款人%v，未能通过审核，拒绝理由:%v，请您及时关注。",
		name, ao.ShowId, ao.CreatedAt.Format("2006年01月02日"), ao.JinjianUserName, ao.ExternalReason)
}

// 渠道终审通过模板短信
func cmSmsPassMsg(ao model.ApprovalOrder, name string) (msg string) {
	return fmt.Sprintf("尊敬的%v女士/先生:您所经办的借款编号%v，申请时间：%v，借款人%v；审批情况：审批金额%v，还款期数：%v，现进入最后复核阶段，复核通过后直接进行放款，请您及时关注。",
		name, ao.ShowId, ao.CreatedAt.Format("2006年01月02日"), ao.JinjianUserName, ao.ApprovedAmount/100, ao.LoanTerm)
}

// 渠道撤销模板短信
func cmSmsCancelMsg(ao model.ApprovalOrder, name string) (msg string) {
	return fmt.Sprintf("尊敬的%v女士/先生:您所经办的借款编号%v，申请时间：%v，借款人%v，订单已撤消，请您及时关注。",
		name, ao.ShowId, ao.CreatedAt.Format("2006年01月02日"), ao.JinjianUserName)
}

// 预审通过
func cmSmsPaPassMsg(pao model.PreApprovalOrder, cmName string) (msg string) {
	return fmt.Sprintf("尊敬的%v女士/先生：您所经办的预审批，客户名：%v，身份证号码：%v，预审批通过，请及时关注。",
		cmName, pao.UserName, pao.UserIdNum)
}

// 预审拒绝
func cmSmsPaRefuseMsg(pao model.PreApprovalOrder, cmName string) (msg string) {
	return fmt.Sprintf("尊敬的%v女士/先生：您所经办的预审批，客户名：%v，身份证号码：%v，预审批不通过，拒绝理由:%v，感谢您的支持。",
		cmName, pao.UserName, pao.UserIdNum, pao.ExternalReason)
}

// 预审退回
func cmSmsPaRepulseMsg(pao model.PreApprovalOrder, cmName string) (msg string) {
	return fmt.Sprintf("尊敬的%v女士/先生：您所经办的预审批，客户名：%v，身份证号码：%v，预审批回退补充资料，请您及时关注并补充资料。",
		cmName, pao.UserName, pao.UserIdNum)
}

// 预审获取渠道经理和中介发短信
func GetPreViewChannelManagerAndBroker(aeId string) (*preViewReq.GetChanAndManagersInfoResp, error) {
	resp, err := httpReq.GetProxyNoCheck(global.GetPreViewServerUrl() + "/api/v1/preview/chan_and_managers/" + aeId)
	if err != nil {
		logger.Error("===========请求PreView错误: " + err.Error())
		return nil, err
	}

	var respG preViewReq.GetChanAndManagersInfoResp
	if err := util.ParseJson(resp, &respG); err != nil {
		logger.Error("===========解析PreView响应错误: " + err.Error())
		return nil, err
	}

	if !respG.Success {
		err := errors.New("PreView查询渠道经理电话错误")
		logger.Error("========PreView查询渠道经理电话错误")
		return nil, err
	}

	if len(respG.Managers) == 0 {
		err := errors.New("PreView查询渠道经理数组长度为0")
		logger.Error("========PreView查询渠道经理数组长度为0")
		return nil, err
	}

	if len(respG.ChanUsers) == 0 {
		err := errors.New("PreView查询中介数组长度为0")
		logger.Error("========PreView查询中介数组长度为0")
		return nil, err
	}

	return &respG, nil
}

//  获取渠道详情， 去gsso查询
func GetChannelManager(ao model.ApprovalOrder) ([]*gssoModel.User, error) {
	var req []string
	if err := util.ParseJson(ao.ChannelManager, &req); err != nil {
		return nil, err
	}
	resp, err := httpReq.PostJsonProxyNoCheck(map[string][]string{"name": req}, global.GetGssoServerUrl()+"/api/v1/users_by_name")
	if err != nil {
		logger.Error("===========请求Gsso错误: " + err.Error())
		return nil, err
	}
	var respG gssoResp.GetUsersByNameResp
	if err := util.ParseJson(resp, &respG); err != nil {
		logger.Error("===========解析gsso响应错误: " + err.Error())
		return nil, err
	}
	if !respG.Success {
		err := errors.New("GSSO查询渠道经理电话错误")
		logger.Error("========GSSO查询渠道经理电话错误")
		return nil, err
	}

	if len(respG.Users) == 0 {
		err := errors.New("GSSO查询渠道经理数组长度为0")
		logger.Error("========GSSO查询渠道经理数组长度为0")
		return nil, err
	}

	return respG.Users, nil
}

func GetBroker(jinjianId string) (name, cellphone string, err error) {
	resp, err := httpReq.GetProxy(global.GetNqyServerUrl() + "/api/v1/approval/order/" + jinjianId)
	if err != nil {
		logger.Error("获取中介名字和电话错误: " + err.Error())
		return
	}
	if rName, ok := resp["showName"].(string); ok {
		logger.Info("========中介名字: ", "rName ?", rName)
		name = rName
	}
	if rCellphone, ok := resp["cellphone"].(string); ok {
		logger.Info("========中介电话: ", "rCellphone ?", rCellphone)
		cellphone = rCellphone
	}
	if name == "" || cellphone == "" {
		err = errors.New("查询中介信息出错")
		return
	}
	return
}

//  base发送短信
func baseSendSms(jinjianId, opName, phoneNum, content, sendTime string) (err error) {
	if util.IsTestEnv() {
		logger.Info("单元测试不能发短信")
		return errors.New("单元测试不能发短信")
	}
	// 短信白名单
	if err = sms.ValidSmsCellphone(phoneNum); err != nil {
		logger.Error ("===================", "短信白名单", err.Error())
		return err
	}

	if len(content) == 0 || len(phoneNum) == 0 {
		logger.Error("请求发送短信，但手机或内容不正确", "cellphone", phoneNum, "content", content)
		return errors.New("电话号码或内容不正确")
	}
	logger.Info("发送短信", "cellphone", phoneNum, "content", content)
	param := map[string]string{
		"CorpID":   "CDJS002922",
		"Pwd":      "zm0513@",
		"Mobile":   phoneNum,
		"Content":  content,
		"SendTime": sendTime,
	}
	reqUrl := "https://sdk2.028lk.com/utf8/BatchSend2.aspx"
	respCode, respResult, err := httpReq.PostFormDataProxyNoCheck(param, reqUrl)
	if err != nil {
		logger.Error("=================err :" + err.Error())
		return err
	}
	if respCode != 200 {
		logger.Info("短信网关返回错误码: ", "code", respCode)
		return errors.New(fmt.Sprintf("短信网关返回错误码: %v", respCode))
	}
	logger.Info("短信发送成功", "resp", respResult)
	smsRecord := &model.ApprovalSmsRecord{SmsMsg: coresysSmsModel.SmsMsg{Cellphone: phoneNum, Content: content,
		CreatedAt: time.Now().Format("2006-01-02 15:04:05"), FromSystem: "approval"}, JinjianId: jinjianId,
		OpName: opName}
	if err != nil {
		smsRecord.SmsMsg.SendSuccess = false
		smsRecord.SmsMsg.FailedReason = err.Error()
	} else {
		smsRecord.SmsMsg.SendSuccess = true
	}
	if err = config.GetDb().Model(smsRecord).Create(smsRecord).Error; err != nil {
		logger.Error("===================短信消息记录错误: " + err.Error())
	}
	go trace_log.SmsMsgTrace(&smsRecord.SmsMsg)
	return nil
}
