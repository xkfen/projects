package service

import (
	"gapproval/approval/model"
	"github.com/jinzhu/gorm"
	"errors"
	"gapproval/common/tool"
)

func UpdateApprovalOrderInfo(item, approvalType string, order model.ApprovalOrder) (err error) {

	ao, err := model.GetApprovalOrderByJinjianId(order.JinjianId)
	if err != nil {
		return err
	}

	if err = ao.IsValidUpdateInfo(approvalType); err != nil {
		return
	}

	switch item {
	case "base_info":
		// 身份证归属地
		if order.UserIdNum != ao.UserIdNum && order.UserIdNum != "" {
			ao.IdCardPlace = GetPlaceInfoByIdNum(order.UserIdNum)
		}
		// 身份证姓名匹配
		if (order.UserIdNum != "" && order.UserIdNum != ao.UserIdNum) || (order.JinjianUserName != "" && order.JinjianUserName != ao.JinjianUserName) {
			ao.IdCardCheckResult = CheckIdCardAndName(order.JinjianId, order.UserIdNum, order.JinjianUserName)
		}
		err = ao.Update(model.ApprovalOrder{
			JinjianUserName:   order.JinjianUserName,
			UserIdNum:         order.UserIdNum,
			OrderInfo:         order.OrderInfo,
			AllInfo:           order.AllInfo,
			IdCardPlace:       ao.IdCardPlace,
			IdCardCheckResult: ao.IdCardCheckResult,
		})
	case "job_info":
		err = ao.Update(model.ApprovalOrder{
			OrderInfo: order.OrderInfo,
			AllInfo:   order.AllInfo,
		})
	case "fin_info":
		err = ao.Update(model.ApprovalOrder{
			OrderInfo: order.OrderInfo,
			AllInfo:   order.AllInfo,
		})
	case "call_info":
		err = ao.Update(model.ApprovalOrder{
			ApprovalAddContacts: order.ApprovalAddContacts,
		})
	case "contacts_info":
		err = ao.Update(model.ApprovalOrder{
			ApprovalAddContacts: order.ApprovalAddContacts,
			AllInfo:             order.AllInfo,
		})
	case "jinjian_info":
		orderInfo, allInfo , err := syncOrderInfo(ao, order)
		if err != nil {
			return err
		}
		err = ao.Update(model.ApprovalOrder{
			IsStandard: order.IsStandard,
			LoanTerm:   order.LoanTerm,
			LoanAmount: order.LoanAmount,
			OrderInfo:  orderInfo,
			AllInfo:    allInfo,
		})
	}

	return err
}

// 创建或更新审批用户信息
func CreateOrUpdateUserInfo(item string, info model.ApprovalUserInfoSup) error {
	if item != "job_info" && item != "base_info" {
		return nil
	}
	if item == "base_info" && info.EducationInfo == "" {
		return errors.New("学历不能为空")
	}
	if item == "base_info" && info.HouseholdCity == "" {
		return errors.New("户籍城市不能为空")
	}

	if err := info.IsValidApprovalUserInfoSup(); item == "job_info" && err != nil {
		return err
	}

	tmp, err := model.GetApprovalUserInfoSupByJinjianId(info.JinjianId)
	if err != nil && err != gorm.ErrRecordNotFound {
		return err
	}

	if err == gorm.ErrRecordNotFound {
		if err := info.Create(); err != nil {
			return err
		}
	} else {
		info.ID = tmp.ID
		if err := info.Update(); err != nil {
			return err
		}
		if info.CompanyLine == "" { // 非必填,特殊处理
			if err := info.Update(map[string]interface{}{"company_line": ""}); err != nil {
				return err
			}
		}
	}
	return nil
}

// 保存放款信息
func SaveLoanInfo(changeAO model.ApprovalOrder, approvalType string) error {

	ao, err := model.GetApprovalOrderByJinjianId(changeAO.JinjianId)
	if err != nil {
		return err
	}

	if err = ao.IsValidUpdateInfo(approvalType); err != nil {
		return err
	}

	changeAO.FundSide = ao.FundSide
	if err := changeAO.IsValidApprovalLoanInfo(approvalType); err != nil {
		return err
	}

	if err := ao.Update(model.ApprovalOrder{
		ApprovedAmount:      changeAO.ApprovedAmount,
		ApprovedRate:        changeAO.ApprovedRate,
		PlatformMonthRate:   changeAO.PlatformMonthRate,
		SalaryAt:            changeAO.SalaryAt,
		LoanAt:              changeAO.LoanAt,
		Card1Json:           changeAO.Card1Json,
		Card1:               changeAO.Card1,
		Card2:               changeAO.Card2,
		Card3:               changeAO.Card3,
		Card4:               changeAO.Card4,
		Card5:               changeAO.Card5,
		LoanCard:            changeAO.LoanCard,
		LoanBankName:        changeAO.LoanBankName,
		Cellphone:           changeAO.Cellphone,
		BankName:            changeAO.BankName,
		CardOneChoiceReason: changeAO.CardOneChoiceReason,
		CardOnePhone:        changeAO.CardOnePhone,
	}); err != nil {
		return err
	}

	return nil
}

// 同步OrderInfo
func syncOrderInfo(ao, changeAo model.ApprovalOrder) (orderInfo, allInfo string, err error) {

	first, err := tool.UpdateIntoJson(ao.OrderInfo, "amount", changeAo.LoanAmount)
	if err != nil {
		return
	}
	orderInfo, err = tool.UpdateIntoJson(first, "terms", changeAo.LoanTerm)
	if err != nil {
		return
	}
	allInfo, err = tool.UpdateIntoJson(ao.AllInfo, "is_standard", changeAo.IsStandard)
	if err != nil {
		return
	}
	return
}
