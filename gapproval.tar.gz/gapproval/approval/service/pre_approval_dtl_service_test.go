package service

import (
	"testing"
)

func TestGetPreApprovalFiles(t *testing.T) {
	oneStepTest(func() {
		//preOrder := model.GetDefaultPreApprovalOrder()
		//assert.NoError(t, serviceV1.CreatePreApproval(preOrder))
		//files, err := GetPreApprovalFiles(preOrder.PreApprovalID, "credit")
		//assert.NoError(t, err)
		//fmt.Println(util.StringifyJson(files))
	})
}

// 预审批文件
type PreFile struct {
	// 文件名
	FileName string `json:"file_name"`
	// 文件类型
	FileType string `json:"file_type"`
	// 文件URL
	FileUrl string `json:"file_url"`
}

func TestJsonStr2Struct(t *testing.T) {
	oneStepTest(func() {
		//str := `[{"id":1,"created_at":"2018-01-17T14:41:15.637527549+08:00","updated_at":"2018-01-17T14:41:15.637527549+08:00","deleted_at":null,"pre_channel_approval_order_id":"ChanPre_1516171275583115994353111","file_name":"mmexport1516170852565.jpg","file_type":"详版征信","file_url":"/assets/432902197909057849/详版征信/1516171275462517563605874.jpg"},{"id":3,"created_at":"2018-01-17T14:41:15.677614857+08:00","updated_at":"2018-01-17T14:41:15.677614857+08:00","deleted_at":null,"pre_channel_approval_order_id":"ChanPre_1516171275583115994353111","file_name":"mmexport1516170858785.jpg","file_type":"详版征信","file_url":"/assets/432902197909057849/详版征信/1516171275547087085116761.jpg"},{"id":5,"created_at":"2018-01-17T14:41:15.694638537+08:00","updated_at":"2018-01-17T14:41:15.694638537+08:00","deleted_at":null,"pre_channel_approval_order_id":"ChanPre_1516171275583115994353111","file_name":"mmexport1516170866553.jpg","file_type":"详版征信","file_url":"/assets/432902197909057849/详版征信/1516171275549810638307517.jpg"},{"id":7,"created_at":"2018-01-17T14:41:15.723122412+08:00","updated_at":"2018-01-17T14:41:15.723122412+08:00","deleted_at":null,"pre_channel_approval_order_id":"ChanPre_1516171275583115994353111","file_name":"mmexport1516170875235.jpg","file_type":"详版征信","file_url":"/assets/432902197909057849/详版征信/1516171275552287422878057.jpg"},{"id":9,"created_at":"2018-01-17T14:41:15.793353125+08:00","updated_at":"2018-01-17T14:41:15.793353125+08:00","deleted_at":null,"pre_channel_approval_order_id":"ChanPre_1516171275583115994353111","file_name":"mmexport1516170880907.jpg","file_type":"详版征信","file_url":"/assets/432902197909057849/详版征信/1516171275554538638389160.jpg"},{"id":11,"created_at":"2018-01-17T14:41:15.821937141+08:00","updated_at":"2018-01-17T14:41:15.821937141+08:00","deleted_at":null,"pre_channel_approval_order_id":"ChanPre_1516171275583115994353111","file_name":"mmexport1516170900612.jpg","file_type":"详版征信","file_url":"/assets/432902197909057849/详版征信/1516171275565847971657139.jpg"},{"id":13,"created_at":"2018-01-17T14:41:15.851409433+08:00","updated_at":"2018-01-17T14:41:15.851409433+08:00","deleted_at":null,"pre_channel_approval_order_id":"ChanPre_1516171275583115994353111","file_name":"mmexport1516170905583.jpg","file_type":"详版征信","file_url":"/assets/432902197909057849/详版征信/1516171275581538029768406.jpg"}]`
		//var preFiles []PreChannelApprovalFile
		//if err := util.ParseJson(str, &preFiles); err != nil {
		//	panic(err)
		//}
		//fmt.Println(util.StringifyJson(preFiles))
	})

}
