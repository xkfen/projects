package service

import (
	"github.com/stretchr/testify/suite"
	"testing"
	"gcoresys/common/logger"
	"gapproval/approval/db/config"
)

func TestRun(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	suite.Run(t, new(testingSuite))
}

type testingSuite struct {
	suite.Suite
}

// 单步测试
func oneStepTest(testMethods ...func()) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(true)

	for _, testMethods := range testMethods {
		config.ClearAllData()
		testMethods()
		config.ClearAllData()
	}
}

func (s *testingSuite) SetupTest() {
	config.ClearAllData()
}

func (s *testingSuite) TearDownTest() {
	config.ClearAllData()
}

func (s *testingSuite) TestForPass() {
	s.Equal(1,1)
}