package service

import (
	"gapproval/approval/model"
	"time"
	"testing"
	"gcoresys/common"
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
)


func TestSendSms(t  *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	env := common.DefineRunTimeCommonFlag()
	config.GetApprovalDbConfig(env)
	ao := model.GetDefaultApprovalOrder()
	lat := time.Now()
	ao.LoanAt = &lat
	ao.JinjianUserId = "13570582709"
	ao.JinjianUserName = "小星星"
	ao.ReTrailName = "fsdfd"
	ast := time.Now().AddDate(0, 0, 5)
	ao.SalaryAt = &ast
	ao.ApprovedAmount = 100000 * 100
	ao.ApprovedRate = 28
	ao.LoanTerm = 12
	ao.ProductName = "qy_001"
	ao.ProductId = "qy_001"

	//baseSendSms(ao.JinjianId, ao.ReTrailName, "13570582709", cmSmsCancelMsg(*ao,"测试一"), "")

	//baseSendSms(ao.JinjianId, ao.ReTrailName, "13570582709", uSmsRefuseMsgMrOnion(*ao), "")
	//baseSendSms(ao.JinjianId, ao.ReTrailName, "13570582709", cmSmsRefuseMrOnion(*ao, ao.ReTrailName), "")
}