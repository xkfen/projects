package server

//func TestCreatePreApproval(t *testing.T) {
//	var req = `{"pre_show_id":"X-1523516831","pre_approval_id":"ChanPre_1523516831611085269602403","pre_approval_type":"渠道","user_name":"张凯","user_id_num":"610302199403091538","agency_employee_id":"13659236400zj","agency_name":"渠道公司2000","agency_employee":"张凯","pre_approval_file":"[{\"id\":519,\"created_at\":\"2018-04-12T15:07:11.613010351+08:00\",\"updated_at\":\"2018-04-12T15:07:11.613010351+08:00\",\"deleted_at\":null,\"pre_channel_approval_order_id\":\"ChanPre_1523516831611085269602403\",\"file_name\":\"test86015235168312450.pdf\",\"file_type\":\"变量表格\",\"file_url\":\"/assets/610302199403091538/变量表格/1523516831497503969930131.pdf\"},{\"id\":520,\"created_at\":\"2018-04-12T15:07:11.613990267+08:00\",\"updated_at\":\"2018-04-12T15:07:11.613990267+08:00\",\"deleted_at\":null,\"pre_channel_approval_order_id\":\"ChanPre_1523516831611085269602403\",\"file_name\":\"test64915235168312450.pdf\",\"file_type\":\"详版征信\",\"file_url\":\"/assets/610302199403091538/详版征信/1523516831547370598604961.pdf\"}]","commit_time":"2018-04-12T15:07:11.611906782+08:00","education":"博士后","introduction_plan_num":"{\"fund_side\":\"[\\\"海金社\\\",\\\"洋葱先生\\\"]\",\"name\":\"海金社洋葱先生\",\"scheme_id\":\"qy_004\",\"canRegUser\":true}","is_fast":"","phone_number":"13659236400","jinjian_plan":"月供贷","employee_phone_number":"13659236400","customer_managers":["中介2000","李三宝","601"],"customer_manager_nums":["17688760020","13160678888","15236222222"],"legal_person":"札幌点击"}`
//	//var res, err = UniformInterfaceAuthRPC("CreatePreApproval", req, "", "", "", false)
//	var reqModel CreatePreApprovalReq
//	assert.NoError(t, util.ParseJson(req, &reqModel))
//}

