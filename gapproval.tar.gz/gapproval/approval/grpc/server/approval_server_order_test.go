package server

import (
	"testing"
	"github.com/stretchr/testify/assert"
)

var body = `{"item":"job_info","approval_order":{"jinjian_id":"order_1513758484435","jinjian_user_name":"李二","user_id_num":"352229198301011136","all_info":"{\"call_record\":{\"isJump\":false,\"createdAt\":\"2017-12-20 16:31:06\",\"updatedAt\":\"2017-12-20 16:31:06\",\"cellphone\":\"13103931210\",\"userId\":33,\"password\":\"950218\",\"id\":28,\"status\":\"1\",\"orderId\":\"29\",\"isCrawled\":true},\"contacts\":{\"primaryAddr\":\"一直以只44444dd\",\"createdAt\":\"2017-12-20 16:32:00\",\"secondaryPhone\":\"13649595957\",\"primaryRelation\":\"子女\",\"primaryPhone\":\"13794994949\",\"userId\":33,\"secondaryRelation\":\"其他亲属\",\"secondaryAddr\":\"9499494民，\",\"orderId\":\"29\",\"status\":\"1\",\"secondaryName\":\"洗一下\",\"updatedAt\":\"2017-12-20 16:32:00\",\"id\":28,\"primaryName\":\"明细账\"},\"salary_bank\":[{\"userId\":33,\"orgId\":\"\",\"account\":\"\",\"password\":null,\"isJump\":true,\"bank\":\"\",\"bankCity\":null,\"id\":61,\"updatedAt\":\"2017-12-20 16:32:25\",\"createdAt\":\"2017-12-20 16:32:25\",\"bankProv\":null,\"cardNo\":\"\",\"isCrawled\":true,\"status\":\"1\",\"cellphone\":\"\",\"orderId\":\"29\"}],\"credit_files\":null,\"idcard_info\":{\"cellphone\":null,\"createdAt\":\"2017-12-20 16:29:02\",\"id\":29,\"facePhoto\":\"/assets/uploads/images//idCard/PWY7EgVJr5Pbpe9s9KlKedGIqJ0Js82Ai8FcX4MNqA9bjlxCcPrTlVF0Es3UXSBl.jpg\",\"bankNo\":null,\"orderId\":\"29\",\"name\":\"李二\",\"number\":\"352229198301011136\",\"updatedAt\":\"2017-12-20 16:33:10\",\"backPhoto\":\"/assets/uploads/images//idCard/FJlFn6O_Ns42MpCJVIkCwYv6_Dt6hkEXE8X0eW6ED6He-1CwOHZGl0T4bhNbSbnW.jpg\",\"status\":\"1\",\"userId\":33},\"personal_info\":{\"workplacePhone\":\"13659595959\",\"monthlyIncome\":\"13200\",\"workplace\":\"名\",\"orderId\":\"29\",\"hasCar\":\"有\",\"job\":\"嘻嘻ddddd\",\"usage\":\"装修\",\"userId\":33,\"updatedAt\":\"2017-12-20 16:30:06\",\"address\":\"广东省 深圳市 龙华区\",\"detailAddress\":\"工资\",\"companyType\":null,\"wxNo\":\"weixind\",\"jobAt\":null,\"education\":\"小学\",\"companySize\":null,\"workAddress\":\"广东省 深圳市 光明新区\",\"hasHouseLoan\":\"无\",\"hasChildren\":null,\"hasCarLoan\":\"无\",\"monthlyCost\":\"52300\",\"department\":null,\"houseType\":\"买房已结清\",\"addressCity\":null,\"workDetailAddress\":\"洗一下\",\"createdAt\":\"2017-12-20 16:30:06\",\"hasHouse\":\"有\",\"id\":28,\"status\":\"1\",\"marriage\":\"已婚\",\"hasHourse\":\"无\"}}"},"user_info_sup":{"jinjian_id":"order_1513758484435","family_info":"3个及以上","education_info":"小学","household_city":"124","company_size":"124","company_type":"政府机构","company_line":"124","company_department":"124","first_work_time":"1999-09-09"}}`

func TestNeedAuthExecutorUpdateApprovalOrder(t *testing.T) {
	var exe = needAuthExecutor{ApprovalType:"cs", Username:"test", Name:"测试"}
	oneStepTest(func() {
		_, err := exe.UpdateApprovalOrder(body)
		assert.Error(t, err)
	})

}