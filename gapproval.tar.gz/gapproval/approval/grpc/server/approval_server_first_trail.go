package server

import (
	"gcoresys/common/util"
	"gapproval/approval/serviceV1"
	"gapproval/approval/model"
	"github.com/tidwall/gjson"
	"errors"
)

// 方案号
type MarKPlanNumReq struct {
	JinjianId string `json:"jinjian_id"`
	PlanNum   string `json:"plan_num"`
}

func (executor *needAuthExecutor) MarkPlanNum(reqBody string) (respStr string, err error) {
	var req MarKPlanNumReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp("ParseJson MarkPlanNum时出错： " + err.Error())), err
	}
	if req.JinjianId == "" {
		return util.StringifyJson(util.GetErrorBaseResp("进件id不能为空")), err
	}
	if req.PlanNum == "" {
		return util.StringifyJson(util.GetErrorBaseResp("方案号不能为空")), err
	}
	if err = serviceV1.MarkPlanNum(req.JinjianId, req.PlanNum); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp(err.Error())), err
	}
	respStr = util.StringifyJson(util.GetSuccessBaseResp("操作方案号成功"))
	return
}

//----------------------------NewApprovalCsResult-------------------------------
type NewApprovalCsResultReq struct {
	*model.ApprovalCsResult `json:"approval_cs_result"`
}

func (executor *needAuthExecutor) NewApprovalCsResult(body string) (resp string, err error) {
	var req NewApprovalCsResultReq
	if err = util.ParseJson(body, &req); err != nil {
		return resp, err
	}
	if err = serviceV1.NewApprovalCsResult(req.ApprovalCsResult); err != nil {
		return resp, err
	}
	return RespSuccessRpc("创建成功"), nil
}

//----------------------------GetApprovalCsResult-------------------------------

func (executor *needAuthExecutor) GetApprovalCsResult(body string) (resp string, err error) {

	approvalId := gjson.Get(body, "approval_id").Num

	result := serviceV1.GetApprovalCsResult(uint(approvalId))
	if result == nil {
		return resp, errors.New("没有查到审批初审结论")
	}
	return RespSuccessRpc("获取成功", "approval_cd_result", result), nil
}
