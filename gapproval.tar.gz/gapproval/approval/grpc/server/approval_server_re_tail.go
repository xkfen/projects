package server

import (
	"gapproval/approval/serviceV1"
	"gcoresys/common/util"
	"errors"
	"gapproval/approval/model"
	"gcoresys/common/logger"
)

// 终审增加生成简报功能
func (executor *needAuthExecutor) GenerateApprovalReport(reqBody string) (respStr string, err error)  {
	logger.Info("GenerateApprovalReport1")
	var req model.ApprovalOrder
	if err = util.ParseJson(reqBody, &req); err != nil {
		return "", err
	} else if req.JinjianId == "" {
		return "", errors.New("进件id不能为空")
	}
	if result, err := serviceV1.GenerateApprovalReport(req.JinjianId); err != nil {
		return "", err
	} else {
		logger.Info("GenerateApprovalReport2")
		return util.StringifyJson(result), nil
	}
}