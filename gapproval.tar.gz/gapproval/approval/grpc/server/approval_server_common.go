package server

import (
	"gapproval/approval/serviceV1"
	"gapproval/approval/model"
	"gcoresys/common/util"
	"gcoresys/common/http"
	"gcoresys/common/logger"
	"gapproval/tuningbox"
	"github.com/tidwall/gjson"
	"errors"
)

// --------------------------------- GetJjIdByShowId ---------------------------------

// 根据showId获取jinjianId
func (executor *needAuthExecutor) GetJjIdByShowId(reqBody string) (respStr string, err error) {
	contractId := gjson.Get(reqBody, "contract_id").Str

	if contractId == "" {
		return respStr, errors.New("合同Id不能为空")
	}

	id, jinjianId := serviceV1.GetJjIdByShowId(contractId)

	return RespSuccessRpc("获取成功", "id", id, "jinjian_id", jinjianId), nil
}

// --------------------------------- ManageInterViewUploadFile ---------------------------------

type ManageInterViewUploadFileReq struct {
	JinjianId string `json:"jinjian_id"`
	IvSwitch  string `json:"iv_switch"`
}

// 审批开关打开面签历史订单修改资料
func (executor *needAuthExecutor) ManageInterViewUploadFile(reqBody string) (respStr string, err error) {
	var req ManageInterViewUploadFileReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return "", err
	}
	if req.JinjianId == "" {
		return util.StringifyJson(util.GetErrorBaseResp("进件id不能为空")), err
	}

	if req.IvSwitch == "" {
		return util.StringifyJson(util.GetErrorBaseResp("IvSwitch 不能为空")), err
	}

	if err = serviceV1.ManageInterViewUploadFile(req.JinjianId, req.IvSwitch); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp(err.Error())), err
	}

	respStr = util.StringifyJson(util.GetSuccessBaseResp("操作成功"))
	return
}

// --------------------------------- QueryCompanyAndContactName ---------------------------------

// 查询工作单位和联系人姓名
func (executor *noAuthExecutor) QueryCompanyAndContactName(reqBody string) (respStr string, err error) {
	var req model.ApprovalOrder
	if err = util.ParseJson(reqBody, &req); err != nil {
		return "", err
	} else if req.JinjianId == "" {
	}
	if result, err := serviceV1.QueryCompanyAndContactName(req.JinjianId); err != nil {
		return "", err
	} else {
		return util.StringifyJson(result), nil
	}
}

// --------------------------------- GetAoUserPaoList ---------------------------------

type GetAoUserPaoListReq struct {
	UserIdNum string `json:"user_id_num"`
}

type GetAoUserPaoListResp struct {
	http.BaseResp
	PaoList []model.PreApprovalOrder `json:"pao_list"`
}

// 审批根据身份证号获取预审列表
func (executor *needAuthExecutor) GetAoUserPaoList(reqBody string) (respStr string, err error) {
	var req GetAoUserPaoListReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp("ParseJson GetAoUserPaoList时出错：" + err.Error())), err
	}

	paoList, err := serviceV1.GetAoUserPaoList(req.UserIdNum)
	if err != nil {
		return util.StringifyJson(util.GetErrorBaseResp(err.Error())), err
	}

	respStr = util.StringifyJson(&GetAoUserPaoListResp{
		BaseResp: *util.GetSuccessBaseResp("预审信息获取成功"),
		PaoList:  paoList,
	})
	return
}

// --------------------------------- CheckUserQv ---------------------------------

type CheckUserQvReq struct {
	UserIdNum string `json:"user_id_num"`
}

type CheckUserQvResp struct {
	http.BaseResp
	QvSet *serviceV1.CheckQvInDb `json:"qv_set"`
}

// 根据身份证号获取审批和预审批量化等数据
func (executor *noAuthExecutor) CheckUserQv(reqBody string) (respStr string, err error) {
	var req CheckUserQvReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp("ParseJson CheckUserQv时出错：" + err.Error())), err
	}

	if req.UserIdNum == "" {
		return util.StringifyJson(util.GetErrorBaseResp("身份证不能为空")), err
	}

	result := serviceV1.CheckUserQv(req.UserIdNum)

	respStr = util.StringifyJson(&CheckUserQvResp{
		BaseResp: *util.GetSuccessBaseResp("获取成功"),
		QvSet:    &result,
	})
	return
}

// --------------------------------- GetTimeRecord ---------------------------------

type GetTimeRecordReq struct {
	JinjianId string `json:"jinjian_id"`
	KeyType   string `json:"key_type"`
}

type GetTimeRecordResp struct {
	http.BaseResp
	AtrList []model.ApprovalTimeRecord `json:"atr_list"`
}

// 获取时间记录
func (executor *needAuthExecutor) GetTimeRecord(reqBody string) (respStr string, err error) {
	var req GetTimeRecordReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp("ParseJson GetTimeRecord时出错：" + err.Error())), err
	}

	if req.JinjianId == "" {
		return util.StringifyJson(util.GetErrorBaseResp("进件id不能为空")), err
	}

	if req.KeyType == "" {
		return util.StringifyJson(util.GetErrorBaseResp("KeyType不能为空")), err
	}

	result := serviceV1.GetTimeRecord(req.JinjianId, req.KeyType)

	respStr = util.StringifyJson(&GetTimeRecordResp{
		BaseResp: *util.GetSuccessBaseResp("获取成功"),
		AtrList:  result,
	})
	return
}

// --------------------------------- AoTimeStatistics ---------------------------------

type AoTimeStatisticsReq struct {
	JinjianId string `json:"jinjian_id"`
}

type AoTimeStatisticsResp struct {
	http.BaseResp
	Atr map[string]interface{} `json:"atr"`
}

func (executor *noAuthExecutor) AoTimeStatistics(reqBody string) (respStr string, err error) {
	var req AoTimeStatisticsReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp("ParseJson AoTimeStatistics时出错：" + err.Error())), err
	}

	if req.JinjianId == "" {
		return util.StringifyJson(util.GetErrorBaseResp("进件id不能为空")), err
	}

	result := serviceV1.AoTimeStatistics(req.JinjianId)

	respStr = util.StringifyJson(&AoTimeStatisticsResp{
		BaseResp: *util.GetSuccessBaseResp("获取成功"),
		Atr:      result,
	})
	return
}

// --------------------------------- AutoGenerateCustomerCover ---------------------------------

// 自动生成客户封面请求参数
type CoverReq struct {
	JinjianId string `json:"jinjian_id"`
}

// 自动生成客户封面
func (executor *needAuthExecutor) AutoGenerateCustomerCover(reqBody string) (respStr string, err error) {
	logger.Info("##AutoGenerateCustomerCover##")
	var req CoverReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return "", err
	} else if req.JinjianId == "" {
		return util.StringifyJson(util.GetErrorBaseResp("进件id不能为空")), err
	}
	if result, err := serviceV1.AutoGenerateCustomerCover(req.JinjianId); err != nil {
		return "", err
	} else {
		return util.StringifyJson(result), nil
	}
}

// --------------------------------- UpdateApprovalInterviewSwitch ---------------------------------

// 面签补件开关请求参数
type UpdateApprovalInterviewSwitchReq struct {
	JinJianId string `json:"jin_jian_id"`
	Switch    string `json:"switch"`
}

// 面签补件开关
func (executor *needAuthExecutor) UpdateApprovalInterviewSwitch(reqBody string) (respStr string, err error) {
	var req UpdateApprovalInterviewSwitchReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return "", err
	} else if req.JinJianId == "" {
		return util.StringifyJson(util.GetErrorBaseResp("进件id不能为空")), err
	}
	if err := serviceV1.UpdateApprovalInterviewSwitch(req.Switch, req.JinJianId); err != nil {
		return "", err
	} else {
		return util.StringifyJson(util.GetSuccessBaseResp("修改成功")), nil
	}

}

type UpdateOrderCallRecordDescReq struct {
	JinjianId string `json:"jinjian_id"`
	Desc      string `json:"desc"`
}

type UpdateOrderCSCallRecordDescResp struct {
	http.BaseResp
	Atr map[string]interface{} `json:"atr"`
}

// --------------------------------- CheckStats ---------------------------------

type CheckStatsResp struct {
	http.BaseResp
	Stats *tuningbox.Stats `json:"stats"`
}

func (executor *noAuthExecutor) CheckStats(reqBody string) (respStr string, err error) {
	respStr = util.StringifyJson(&CheckStatsResp{
		BaseResp: *util.GetSuccessBaseResp("审批后台状态获取成功"),
		Stats:    tuningbox.GetStats(),
	})
	return
}

// --------------------------------GetThreePartyInfo----------------------------------

func (executor *needAuthExecutor) GetThreePartyInfo(body string) (respStr string, err error) {
	jinjianId := gjson.Get(body, "jinjian_id").Str
	if jinjianId == "" {
		return respStr, errors.New("jinjian_id 不能为空")
	}
	info := serviceV1.GetThreePartyInfo(jinjianId)

	return RespSuccessRpc("获取三方信息成功", "three_party_info", info), nil
}

// ---------------------------------ApprovalUserInfoSup---------------------------------
type ApprovalUserInfoSupReq struct {
	OpName       string                     `json:"op_name"`
	Action       string                     `json:"action"`
	UserInfoSup  *model.ApprovalUserInfoSup `json:"user_info_sup"`
	ApprovalType string                     `json:"approval_type"`
}

func (executor *needAuthExecutor) ApprovalUserInfoSup(body string) (respStr string, err error) {
	var req ApprovalUserInfoSupReq
	if err = util.ParseJson(body, &req); err != nil {
		return respStr, err
	}
	switch req.Action {
	case "new":
		if err = serviceV1.CreateUserInfoSup(req.UserInfoSup, req.OpName); err != nil {
			return respStr, err
		}
		return RespSuccessRpc("创建成功"), nil
	case "update":
		if err := serviceV1.UpdateUserInfoSup(req.UserInfoSup, req.OpName); err != nil {
			return respStr, err
		}
		return RespSuccessRpc("更新成功"), nil
	default:
		return respStr, errors.New("审批补充用户个人信息action错误，请检查")
	}
}

// ---------------------------------ApprovalCallRecord---------------------------------
type ApprovalCallRecordReq struct {
	ApprovalType string `json:"approval_type"`
	CallType     string `json:"call_type"`
	Action       string `json:"action"`
	JinjianId    string `json:"jinjian_id"`
	Number       string `json:"number"`
	Desc         string `json:"desc"`
	Id           uint   `json:"id"`
	OpName       string `json:"op_name"`
}

func (executor *needAuthExecutor) ApprovalCallRecord(body string) (respStr string, err error) {
	var req ApprovalCallRecordReq
	if err = util.ParseJson(body, &req); err != nil {
		return respStr, err
	}
	switch req.Action {
	case "new":
		if req.Number == "" {
			return respStr, errors.New("number不能为空")
		}
		if req.Desc == "" {
			return respStr, errors.New("备注不能为空")
		}
		if req.CallType == "" {
			return respStr, errors.New("电核材料类型不能为空")
		}
		if err = serviceV1.NewCallRecord(req.JinjianId, req.Number, req.Desc, req.OpName, req.CallType); err != nil {
			return respStr, err
		}
		return RespSuccessRpc("创建电核材料成功"), nil
	case "update":
		if req.Desc == "" {
			return respStr, errors.New("备注不能为空")
		}
		if req.OpName == "" {
			return respStr, errors.New("op_name不能为空")
		}
		if req.Id == 0 {
			return respStr, errors.New("电核id错误")
		}
		if err = serviceV1.UpdateCallRecord(req.Id, req.Desc, req.OpName); err != nil {
			return respStr, err
		}
		return RespSuccessRpc("修改电核材料成功"), nil
	case "get":
		return RespSuccessRpc("获取电核材料成功", "dian_he", serviceV1.GetCallRecord(req.JinjianId)), nil
	case "add_desc": // 只添加备注,不关联具体手机号和通话记录
		if req.Desc == "" {
			return respStr, errors.New("备注不能为空")
		}
		if req.OpName == "" {
			return respStr, errors.New("op_name不能为空")
		}
		if req.JinjianId == "" {
			return respStr, errors.New("订单号不能为空")
		}
		if req.Number == "" {
			return respStr, errors.New("number不能为空")
		}
		if err = serviceV1.NewCSCallRecordDesc(req.JinjianId, req.Desc, req.OpName, req.CallType, req.Number); err != nil {
			return respStr, err
		}
		return RespSuccessRpc("添加备注成功"), nil
	case "get_desc":
		return util.StringifyJson(serviceV1.GetCallRecordNoCall(req.JinjianId)), nil
	default:
		return respStr, errors.New("审批电核材料action错误，请检查")
	}
}

// -------------------------------NewOrUpdateThreePartyInfo------------------------

type NewOrUpdateThreePartyInfoReq struct {
	ThreePartyInfo *model.ThreePartyInfo `json:"three_party_info"`
	ApprovalType   string                `json:"approval_type"`
}

func (executor *needAuthExecutor) NewOrUpdateThreePartyInfo(body string) (respStr string, err error) {
	var req NewOrUpdateThreePartyInfoReq
	if err = util.ParseJson(body, &req); err != nil {
		return respStr, err
	}
	if err = serviceV1.NewOrUpdateThreePartyInfo(req.ThreePartyInfo); err != nil {
		return respStr, err
	}

	return RespSuccessRpc("三方信息创建或更新成功"), nil
}

//----------------------------GetApprovalLog-------------------------------

func (executor *needAuthExecutor) GetApprovalLog(body string) (respStr string, err error) {
	jinjianId := gjson.Get(body, "jinjian_id").Str

	logs := serviceV1.GetApprovalLog(jinjianId, executor.ApprovalType)
	return RespSuccessRpc("获取成功", "approval_logs", logs), nil
}

// ----------------------------------------SetQuantizationPoint----------------------------

type SetQuantizationPointReq struct {
	Sr        *serviceV1.ScoreReq `json:"sr"`
	JinjianId string              `json:"jinjian_id"`
	Password  string              `json:"password"`
	GroupId   string              `json:"group_id"`
}

func (executor *needAuthExecutor) SetQuantizationPoint(body string) (respStr string, err error) {
	var req SetQuantizationPointReq
	if err = util.ParseJson(body, &req); err != nil {
		return respStr, err
	}

	if err = serviceV1.GetScoreResult(*req.Sr, req.JinjianId); err != nil {
		return respStr, err
	}
	return RespSuccessRpc("量化变量设定成功"), nil
}
