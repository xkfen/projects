package server
import (
	"gcoresys/common/util"
	"gapproval/approval/service"
	"fmt"
	"gcoresys/common/logger"
	"errors"
	"gapproval/approval/model"
	"github.com/tidwall/gjson"
)

//**************************预审批影像资料*********************
// 获取预审批文件
type PreFilesReq struct {
	PreApprovalId string `json:"pre_approval_id"`
	PreFileType string `json:"pre_file_type"`
}
func (executor *needAuthExecutor) GetPreApprovalFiles(reqBody string)(respStr string, err error){
	var req PreFilesReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return "", err
	}
	files, err := service.GetPreApprovalFiles(req.PreApprovalId)
	if err != nil {
		return RespErrorRpc("预审批获取影像资料出错:"+err.Error()), err
	}
	return RespSuccessRpc("预审批影像资料获取成功", "data", files), nil
}

type PackPreApprovalFileReq struct {
	PreApprovalId string `json:"pre_approval_id"`
}
// 预审批文件打包下载
func (executor *needAuthExecutor) GetPackCompressedPreApprovalFiles(reqBody string) (respStr string, err error) {

	preApprovalId := gjson.Get(reqBody, "pre_approval_id").Str
	if preApprovalId == "" {
		return respStr, errors.New("pre_approval_id 不能为空")
	}

	return service.GetPackCompressedPreApprovalFiles(preApprovalId)
}


type PreApprovalFileActionReq struct {
	model.ApprovalFile
	Stage string `json:"stage"`
	Action string `json:"action"`
}

// 预审批文件操作
func (executor *needAuthExecutor) PreApprovalFile(reqBody string) (respStr string, err error) {
	var req PreApprovalFileActionReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		logger.Error("ApprovalFile json 转换出错", "err", err)
		return "", errors.New("文件json转换出错")
	}

	switch req.Action {
	case "upload":
		if err = service.UploadPreApprovalFile(req.ApprovalFile); err != nil {
			return
		}
	case "update":
		if err = service.UpdatePreApprovalFile(req.Stage, req.ApprovalFile); err != nil {
			return
		}
	case "delete":
		if err = service.DeletePreApprovalFile(req.Stage, req.ApprovalFile); err != nil {
			return
		}
	default:
		err = errors.New("不存在此操作: '" + req.Action + "'")
		return
	}

	return RespSuccessRpc(fmt.Sprintf("预审批文件%s操作成功", service.OperationTranslation(req.Action))), nil
}


//**************预审批查询模块下载*********************//
// 下载文件
//func (executor *needAuthExecutor) PreQueryDownloadExcelFile(reqBody string) (respStr string, err error) {
//	var originReq map[string]interface{}
//	if err = util.ParseJson(reqBody, &originReq); err != nil {
//		return respStr, err
//	}
//
//	url, derr := service.PreQueryDownloadExcelFile(originReq)
//	if derr != nil {
//		return respStr, derr
//	}
//	return RespSuccessRpc("下载成功", "data", url), nil
//}
//
//type SelectPreApprovalIds struct {
//	PreApprovalIds []string `json:"pre_approval_ids"`
//}
//func (executor *needAuthExecutor) DownloadPreOrderExcelFile(reqBody string)(respStr string, err error){
//	var req SelectPreApprovalIds
//	if err = util.ParseJson(reqBody, &req); err != nil {
//		return respStr, errors.New("预审批下载excel请求解析为json出错")
//	}
//	url, err := service.DownloadPreOrderExcel(req.PreApprovalIds)
//	if err != nil {
//		return respStr, err
//	}
//	return RespSuccessRpc("下载成功", "data", url), nil
//}