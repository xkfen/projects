package server

import (
	"gcoresys/common/util"
	"gapproval/approval/serviceV1"
	"gapproval/approval/model"
	"gcoresys/common/http"
	"github.com/tidwall/gjson"
	"errors"
)

// 批量获取审批单
type BatchGetAoListReq struct {
	JinjianIdArray []string `json:"jinjian_id_array"`
}

type BatchGetAoListResp struct {
	http.BaseResp
	ApprovalOrderList []model.ApprovalOrder `json:"approval_order_list"`
}

func (executor *noAuthExecutor) BatchGetAo(reqBody string) (respStr string, err error) {
	var req BatchGetAoListReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp("ParseJson MarkPlanNum时出错： " + err.Error())), err
	}
	if len(req.JinjianIdArray) == 0 {
		return util.StringifyJson(util.GetErrorBaseResp("进件id数组不能为空")), err
	}
	aoList, err := serviceV1.GetAoListByJinjianArray(req.JinjianIdArray)
	if err != nil {
		return util.StringifyJson(util.GetErrorBaseResp(err.Error())), err
	}
	respStr = util.StringifyJson(&BatchGetAoListResp{
		BaseResp:          *util.GetSuccessBaseResp("获取成功"),
		ApprovalOrderList: aoList,
	})
	return
}

//----------------------------AgencyChangeStatus-------------------------------
type AgencyChangeStatusReq struct {
	JinjianId        string                 `json:"jinjian_id"`
	StatusType       string                 `json:"status_type"`
	AgencyChangeInfo map[string]interface{} `json:"agency_change_info"`
}



func (executor *noAuthExecutor) AgencyChangeStatus(body string) (resp string, err error) {
	var req AgencyChangeStatusReq
	if err := util.ParseJson(body, &req); err != nil {
		return resp, err
	}

	if err := serviceV1.AgencyChangeStatus(req.JinjianId, req.StatusType, req.AgencyChangeInfo); err != nil {
		return resp, err
	}
	return RespSuccessRpc("更改成功"), nil
}

//---------------------------- QyGetApprovalOrder -------------------------------

// 获取审批订单详情
func (executor *noAuthExecutor) QyGetApprovalOrder(reqBody string) (respStr string, err error) {

	jinjianId := gjson.Get(reqBody, "approval_order.jinjian_id").Str
	if jinjianId == "" {
		return respStr, errors.New("jinjian_id 不能为空")
	}

	order, err := serviceV1.QyGetApprovalOrder(jinjianId)
	if err != nil {
		return respStr, err
	}

	return RespSuccessRpc("查询成功", "approval_order", order, "user_info_sup", serviceV1.GetUserInfoSup(jinjianId)), nil
}