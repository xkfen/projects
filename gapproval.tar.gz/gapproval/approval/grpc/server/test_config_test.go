package server

import (
	"github.com/stretchr/testify/suite"
	"testing"
	"gcoresys/common/logger"
	"gapproval/approval/db/config"
	"net"
	"gapproval/approval/grpc/client"
	"gapproval/approval/grpc/pb"
	"google.golang.org/grpc"
)

func TestRun(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	suite.Run(t, new(testingSuite))
}

type testingSuite struct {
	suite.Suite
}

// 单步测试
func oneStepTest(testMethods ...func()) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(true)

	for _, testMethods := range testMethods {
		config.ClearAllData()
		testMethods()
		config.ClearAllData()
	}
}

func (s *testingSuite) SetupTest() {
	config.ClearAllData()
}

func (s *testingSuite) TearDownTest() {
	config.ClearAllData()
}

func StartApprovalRPC(port string) {
	go func() {
		ln, err := net.Listen("tcp", ":"+port)
		if err != nil {
			panic("启动rpc服务出错:" + err.Error())
		}
		s := grpc.NewServer()
		server := MakeGRPCApprovalServer()
		pb.RegisterApprovalServer(s, server)
		s.Serve(ln)
	}()
}

func (s *testingSuite) TestClient() {
	StartApprovalRPC("8091")
	client.GetApprovalClient()
}
