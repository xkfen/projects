package server

import (
	"gcoresys/common/util"
	"errors"
	"gapproval/approval/service"
	"gapproval/approval/model"
	"github.com/tidwall/gjson"
	"gcoresys/common/logger"
	"fmt"
	"gapproval/approval/serviceV1"
)

// ---------------------------------GetAllFiles---------------------------------

// 获取订单所有影像资料
func (executor *needAuthExecutor) GetAllFiles(reqBody string) (respStr string, err error) {
	var req map[string]string
	if err = util.ParseJson(reqBody, &req); err != nil {
		return respStr, errors.New("GetAllFiles body json 错误 " + err.Error())
	}

	jinjianId, ok := req["jinjian_id"]
	if !ok || jinjianId == "" {
		return respStr, errors.New("进件id不能为空")
	}

	result, err := service.GetAllFiles(jinjianId)
	if err != nil {
		return
	}

	return RespSuccessRpc("获取成功", result), nil
}

// ---------------------------------ApprovalFile---------------------------------

type ApprovalFileActionReq struct {
	model.ApprovalFile
	Action string `json:"action"`
}

func (executor *needAuthExecutor) ApprovalFile(reqBody string) (respStr string, err error) {
	var req ApprovalFileActionReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		logger.Error("ApprovalFile json 转换出错", "err", err)
		return "", errors.New("文件json转换出错")
	}

	switch req.Action {
	case "upload":
		if err = service.UploadApprovalFile(req.ApprovalFile); err != nil {
			return
		}
	case "update":
		if err = service.UpdateApprovalFile(req.ApprovalFile); err != nil {
			return
		}
	case "delete":
		if err = service.DeleteApprovalFile(req.ApprovalFile); err != nil {
			return
		}
	default:
		err = errors.New("不存在此操作: '" + req.Action + "'")
		return
	}

	return RespSuccessRpc(fmt.Sprintf("文件%s操作成功", service.OperationTranslation(req.Action))), nil
}

// ---------------------------------GetPackCompressedFiles---------------------------------

// 获取审批打包压缩的文件
func (executor *needAuthExecutor) GetPackCompressedFiles(body string) (respStr string, err error) {

	jinjianId := gjson.Get(body, "jinjian_id").Str
	if jinjianId == "" {
		return respStr, errors.New("jinjian_id 不能为空")
	}

	return service.PackCompressedApprovalFile(jinjianId)
}

// ---------------------------------OldApprovalFile---------------------------------

type ApprovalFileReq struct {
	ApprovalFile *model.ApprovalFile `json:"approval_file"`
	Action       string              `json:"action"`
	JinjianId    string              `json:"jinjian_id"`
	OpName       string              `json:"op_name"`
}

func (executor *needAuthExecutor) OldApprovalFile(body string) (respStr string, err error) {

	var req ApprovalFileReq
	if err = util.ParseJson(body, &req); err != nil {
		return respStr, err
	}
	switch req.Action {
	case "upload":
		if err = serviceV1.UploadApprovalFileV1(req.ApprovalFile, req.OpName); err != nil {
			return respStr, err
		}
		return RespSuccessRpc("上传文件成功"), nil
	case "update":
		if err := serviceV1.UpdateApprovalFile(req.ApprovalFile, req.OpName); err != nil {
			return respStr, err
		}
		return RespSuccessRpc("更新文件成功"), nil
	case "get":
		if req.JinjianId == "" {
			return respStr, errors.New("审批获取上传文件进件id不能为空")
		}
		return RespSuccessRpc("获取成功", "approval_files", serviceV1.GetApprovalFileV1(req.JinjianId)), nil
	default:
		return respStr, errors.New("审批上传文件action错误，请检查")
	}
}

//----------------------------UploadApprovalFile-------------------------------
type UploadApprovalFileReq struct {
	*model.ApprovalUploadFile `json:"approval_upload_file"`
}

func (executor *needAuthExecutor) UploadApprovalFile(body string) (respStr string, err error) {
	var req UploadApprovalFileReq
	if err = util.ParseJson(body, &req); err != nil {
		return respStr, err
	}
	if err = serviceV1.UploadApprovalFile(req.ApprovalUploadFile); err != nil {
		return respStr, err
	}
	return RespSuccessRpc("上传成功"), nil
}
