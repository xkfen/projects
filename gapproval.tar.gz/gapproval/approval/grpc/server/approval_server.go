package server

import (
	"context"
	"gapproval/approval/grpc/pb"
	"gapproval/approval/model"
	qyhttp "gcoresys/common/http"
	"gcoresys/common/logger"
	"gcoresys/common/util"
	"github.com/go-kit/kit/endpoint"
	grpctransport "github.com/go-kit/kit/transport/grpc"
	oldcontext "golang.org/x/net/context"
	"gapproval/approval/serviceV1"
)

type grpcApprovalServer struct {
	approvalOperation grpctransport.Handler
}

func DecodeGRPRequest(_ context.Context, grpcReq interface{}) (interface{}, error) {
	logger.Info("收到请求", "req", grpcReq.(*pb.ApprovalRequestMsg).RpcRequest)
	return grpcReq.(*pb.ApprovalRequestMsg).RpcRequest, nil
}

func EncodeGRPCResponse(_ context.Context, response interface{}) (interface{}, error) {
	respStr := util.StringifyJson(response)
	logger.Debug("返回请求", "resp", respStr)
	return &pb.ApprovalReplyMsg{RpcReply: respStr}, nil
}

func MakeGRPCApprovalServer() pb.ApprovalServer {
	return &grpcApprovalServer{
		approvalOperation: grpctransport.NewServer(
			MakeApprovalOperationEndpoint(),
			DecodeGRPRequest,
			EncodeGRPCResponse,
		),
	}
}

type Files struct {
	Lianghua []*model.ApprovalUploadFile `json:"lianghua"`
	Mianqian []*model.ApprovalUploadFile `json:"mianqian"`
	Dianhe   []*model.ApprovalUploadFile `json:"dianhe"`
	Zhengxin []*model.ApprovalUploadFile `json:"zhengxin"`
	Fangchan []*model.ApprovalUploadFile `json:"fangchan"`
}

//----------------------------ApprovalOperation-------------------------------
type ApprovalOperationReq struct {
	ApprovalOrder     *model.ApprovalOrder   `json:"approval_order"`
	OperationType     string                 `json:"operation_type"`
	ArSwitch          string                 `json:"ar_switch"` // 补录开关
	ArType            string                 `json:"ar_type"`   //  补录类型
	Way               string                 `json:"way"`
	AllInfo           map[string]interface{} `json:"all_info"`
	FinBackDesc       string                 `json:"fin_back_desc"`
	FinBackUsername   string                 `json:"fin_back_username"`
	SendUserMsgSwitch bool                   `json:"send_user_msg_switch"`

	// 操作流水
	JinjianId     string                 `json:"jinjian_id"`
	FlowTagMethod string                 `json:"flow_tag_method"`
	FlowTagParam  map[string]interface{} `json:"flow_tag_param"`
	OperationName string                 `json:"operation_name"`
	ApprovalType  string                 `json:"approval_type"`
}

type ApprovalOperationResp struct {
	qyhttp.BaseResp
}

func MakeApprovalOperationEndpoint() endpoint.Endpoint {
	return func(ctx context.Context, request interface{}) (interface{}, error) {
		var req ApprovalOperationReq
		if err := util.ParseJson(request.(string), &req); err != nil {
			return util.GetParseJsonErrResp(), nil
		}
		switch req.OperationType {
		case "rt":
			if req.ArType != "bank" && req.ArType != "call" {
				return util.GetErrorBaseResp("补录类型 必须为 bank 或者 call， 当前为：" + req.ArType), nil
			}
			// 进件端实时更新补录
			if err := serviceV1.RealTimeUpdateBuluInfo(req.ApprovalOrder.JinjianId, req.ArType, req.AllInfo); err != nil {
				return util.GetErrorBaseResp(err.Error()), nil
			}
			return util.GetSuccessBaseResp("修改成功"), nil
		case "cs":
			// 判定是否为空， 审批补录开关标志  ArSwitch
			if req.ArSwitch != "" {
				if req.ArType != "bank" && req.ArType != "call" {
					return util.GetErrorBaseResp("补录类型 必须为 bank 或者 call， 当前为：" + req.ArType), nil
				}
				if err := serviceV1.IvManageAdditionalRecord(req.ApprovalOrder.JinjianId, req.ArType, "", req.ArSwitch,
					req.Way, req.AllInfo); err != nil {
					return util.GetErrorBaseResp(err.Error()), nil
				}
			} else {
				if err := serviceV1.FirstTrailOperation(req.ApprovalOrder); err != nil {
					return util.GetErrorBaseResp(err.Error()), nil
				}
			}
		case "zs":
			if err := serviceV1.ReTrailOperation(req.ApprovalOrder, req.SendUserMsgSwitch); err != nil {
				return util.GetErrorBaseResp(err.Error()), nil
			}
		case "kf":
			//if err := service.GetApprovalService().ApprovalKfOperation(req.ApprovalOrder); err != nil {
			//	return util.GetErrorBaseResp(err.Error()), nil
			//}
			if err := serviceV1.CustomServiceOperation(req.ApprovalOrder); err != nil {
				return util.GetErrorBaseResp(err.Error()), nil
			}
		case "cw":
			if req.ApprovalOrder.AccountID == 0 || req.FinBackUsername == "" || req.FinBackDesc == "" {
				logger.Info("================approval_order", "approval_order Is nil ?", req.ApprovalOrder == nil)
				logger.Info("================AccountID", "AccountID Is 0 ?", req.ApprovalOrder.AccountID == 0)
				logger.Info("================fin_back_username", "fin_back_username Is nil ?", req.FinBackUsername == "")
				logger.Info("================fin_back_desc", "fin_back_desc Is nil ?", req.FinBackDesc == "")
				return util.GetErrorBaseResp("财务撤回参数错误，请检查"), nil
			}
			if err := serviceV1.FinBack(req.ApprovalOrder.AccountID, req.FinBackUsername, req.FinBackDesc); err != nil {
				return util.GetErrorBaseResp(err.Error()), nil
			}
		case "flow":
			//if req.JinjianId == "" {
			//	return util.GetErrorBaseResp("进件id不能为空"), nil
			//}
			if req.FlowTagMethod == "" {
				return util.GetErrorBaseResp("风控流水method不能为空"), nil
			}
			if req.FlowTagParam == nil {
				return util.GetErrorBaseResp("风控流水param不能为空"), nil
			}
			respResult, err := serviceV1.ProxyRisCtrlFlowTag(req.JinjianId, req.OperationName, req.FlowTagMethod, req.FlowTagParam)
			if err != nil {
				return util.GetErrorBaseResp(err.Error()), nil
			}
			return respResult, nil
		default:
			return util.GetErrorBaseResp("审批操作类型出错"), nil
		}
		return ApprovalOperationResp{
			BaseResp: *util.GetSuccessBaseResp("审批操作成功"),
		}, nil
	}
}

func (s *grpcApprovalServer) ApprovalRpcHandler(ctx oldcontext.Context, req *pb.ApprovalRpcReqMsg) (*pb.ApprovalReplyMsg, error) {
	respStr, err := UniformInterfaceAuthRPC(req.Method, req.RpcRequest, req.ApprovalType, req.Username, req.Name, req.IsAuth)
	if err != nil {
		logger.Error("执行 serverV2 UniformInterfaceAuthRPC 返回结果不正常", "err", err.Error())
	}
	return &pb.ApprovalReplyMsg{RpcReply: respStr}, nil
}

func (s *grpcApprovalServer) ApprovalOperation(ctx oldcontext.Context, req *pb.ApprovalRequestMsg) (*pb.ApprovalReplyMsg, error) {
	_, rep, err := s.approvalOperation.ServeGRPC(ctx, req)
	if err != nil {
		return nil, err
	}
	return rep.(*pb.ApprovalReplyMsg), nil
}
