package server

import (
	"gapproval/approval/service"
)

//******************订单概括***************************//

// 订单概括
func (executor *needAuthExecutor) StatisticOrderCount(reqBody string) (respStr string, err error) {
	// 调用service方法查询订单概括信息
	info, err := service.StatisticOrderCount(executor.Username, executor.Name, executor.ApprovalType)
	if err != nil {
		return RespErrorRpc("订单概括统计失败:" + err.Error()), err
	}
	return RespSuccessRpc("订单概括统计成功", info), nil
}

// ****************历史订单*****************************//
func (executor *needAuthExecutor) StatisticHistoryOrderCount(reqBody string) (respStr string, err error) {
	// 调用service处理
	info := service.HistoryStatistic(executor.Username, executor.Name, executor.ApprovalType)

	return RespSuccessRpc("历史订单统计成功", info), nil
}
