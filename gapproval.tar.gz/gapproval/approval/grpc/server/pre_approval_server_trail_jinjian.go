package server

import (
	"gapproval/approval/model"
	"gapproval/approval/serviceV1"
	"gcoresys/common/util"
	"gcoresys/common/http"
	"time"
	"gapproval/approval/service"
)

// 进件（渠道） 获取预审信息
type GetPreApprovalInfoQyReq struct {
	PreApprovalID string `json:"pre_approval_id"`
}

type GetPreApprovalInfoQyResp struct {
	http.BaseResp
	PreApprovalOrder *model.PreApprovalOrder `json:"pre_approval_order"`
}

func (executor *noAuthExecutor) GetPreApprovalInfoQy(reqBody string) (respStr string, err error) {
	var req GetPreApprovalInfoQyReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp("ParseJson GetPreApprovalInfoQy时出错：" + err.Error())), err
	}

	if req.PreApprovalID == "" {
		return util.StringifyJson(util.GetErrorBaseResp("预审id不能为空")), err
	}

	pao, err := serviceV1.GetPreApprovalInfoQy(req.PreApprovalID)
	if err != nil {
		return util.StringifyJson(util.GetErrorBaseResp(err.Error())), err
	}

	respStr = util.StringifyJson(&GetPreApprovalInfoQyResp{
		BaseResp:         *util.GetSuccessBaseResp("预审信息获取成功"),
		PreApprovalOrder: &pao,
	})
	return
}

// 创建预审批
type CreatePreApprovalReq struct {
	model.PreApprovalOrder
}

func (executor *noAuthExecutor) CreatePreApproval(reqBody string) (respStr string, err error) {
	var req CreatePreApprovalReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp("ParseJson CreatePreApproval时出错：" + err.Error())), err
	}

	if err = service.CreatePreApproval(&req.PreApprovalOrder); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp(err.Error())), err
	}
	respStr = util.StringifyJson(util.GetSuccessBaseResp("创建预审单成功"))
	return
}

// 进件（渠道） 更新预审打回
type UpdatePreApprovalFileReq struct {
	PreApprovalID   string `json:"pre_approval_id"`
	PreApprovalFile string `json:"pre_approval_file"`
}

type UpdatePreApprovalFileResp struct {
	http.BaseResp
	CancelTime *time.Time `json:"cancel_time"`
}

func (executor *noAuthExecutor) UpdatePreApprovalFile(reqBody string) (respStr string, err error) {
	var req UpdatePreApprovalFileReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp("ParseJson UpdatePreApprovalFile时出错：" + err.Error())), err
	}

	if req.PreApprovalID == "" {
		return util.StringifyJson(util.GetErrorBaseResp("进件id不能为空")), err
	}
	if req.PreApprovalFile == "" {
		return util.StringifyJson(util.GetErrorBaseResp("方案号不能为空")), err
	}

	if ct, err := serviceV1.UpdatePreApprovalFile(req.PreApprovalID, req.PreApprovalFile); err != nil {
		if ct != nil {
			return util.StringifyJson(&UpdatePreApprovalFileResp{
				BaseResp:   *util.GetErrorBaseResp(err.Error()),
				CancelTime: ct,
			}), err
		}
		return util.StringifyJson(util.GetErrorBaseResp(err.Error())), err
	}
	respStr = util.StringifyJson(util.GetSuccessBaseResp("更新预审单成功"))
	return
}

// 通过身份证查询在库90天是否有拒绝
type CheckPaRefuseByUserIdNumReq struct {
	UserIdNum string `json:"user_id_num"`
}

type CheckPaRefuseByUserIdNumResp struct {
	http.BaseResp
	HasRecord *model.PreApprovalOrder `json:"has_record"` // false 无拒绝单    true 有
}

func (executor *noAuthExecutor) CheckPaRefuse(reqBody string) (respStr string, err error) {
	var req CheckPaRefuseByUserIdNumReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp("ParseJson CheckPaRefuse时出错：" + err.Error())), err
	}

	if req.UserIdNum == "" {
		return util.StringifyJson(util.GetErrorBaseResp("预审id不能为空")), err
	}

	result, err := service.CheckPaRefuseByUserIdNum(req.UserIdNum)
	if err != nil {
		return util.StringifyJson(util.GetErrorBaseResp(err.Error())), err
	}

	respStr = util.StringifyJson(&CheckPaRefuseByUserIdNumResp{
		BaseResp:  *util.GetSuccessBaseResp("查询成功"),
		HasRecord: result,
	})
	return
}

// 批量查询
type BatchGetPreApprovalInfoQyReq struct {
	PreApprovalIds []string `json:"pre_approval_ids"`
}

type BatchGetPreApprovalInfoQyResp struct {
	http.BaseResp
	PaoList []model.PreApprovalOrder `json:"pao_list"`
}

func (executor *noAuthExecutor) BatchGetPreApprovalInfoQy(reqBody string) (respStr string, err error) {
	var req BatchGetPreApprovalInfoQyReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp("ParseJson BatchGetPreApprovalInfoQy时出错：" + err.Error())), err
	}

	if len(req.PreApprovalIds) == 0 {
		return util.StringifyJson(util.GetErrorBaseResp("预审id数组不能为空")), err
	}

	list, err := serviceV1.BatchGetPreApprovalInfoQy(req.PreApprovalIds)
	if err != nil {
		return util.StringifyJson(util.GetErrorBaseResp(err.Error())), err
	}

	respStr = util.StringifyJson(&BatchGetPreApprovalInfoQyResp{
		BaseResp: *util.GetSuccessBaseResp("查询成功"),
		PaoList:  list,
	})
	return
}
