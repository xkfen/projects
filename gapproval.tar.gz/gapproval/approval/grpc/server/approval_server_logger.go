package server

import (
	"gapproval/approval/serviceV1"
	"gcoresys/common/http"
	"gapproval/approval/model"
	"gcoresys/common/util"
	"errors"
)

type NewApprovalLoggerReq struct {
	model.ApprovalLogger
}
func (req *NewApprovalLoggerReq) IsValid() error {
	if req.OperatorID == 0 {
		return errors.New("操作员ID不能为空")
	}
	if req.OperatorName == "" {
		return errors.New("操作员姓名不能为空")
	}
	if req.ShowID == "" {
		return errors.New("show_id不能为空")
	}
	if req.JinjianID == "" {
		return errors.New("进件ID不能为空")
	}
	if req.StatisticalType == "" {
		return errors.New("统计类型不能为空")
	}
	if req.Segment == "" {
		return errors.New("环节不能为空")
	}
	if req.Page == "" {
		return errors.New("页面不能为空")
	}
	if req.Action == "" {
		return errors.New("动作不能为空")
	}
	return nil
}

type NewApprovalLoggerResp struct {
	http.BaseResp
}

func (executor *needAuthExecutor) NewApprovalLogger(reqBody string) (respStr string, err error) {
	var req NewApprovalLoggerReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return "", err
	}
	if err := req.IsValid(); err != nil {
		return "", err
	}
	if err := serviceV1.NewApprovalLoggerService(&req.ApprovalLogger); err != nil {
		return "", err
	} else {
		return util.StringifyJson(NewApprovalLoggerResp{
			BaseResp: http.BaseResp{
				Success: true,
				Info: "请求成功",
			},
		}), nil
	}
}