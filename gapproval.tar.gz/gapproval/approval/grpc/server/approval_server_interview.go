package server

import (
	"gapproval/approval/serviceV1"
	"gcoresys/common/util"
)

// 审批开关打开面签历史订单修改资料请求参数
type UpdateInterViewFileReq struct {
	JinjianId string                 `json:"jinjian_id"`
	OpName    string                 `json:"op_name"`
	AddFile   map[string]interface{} `json:"add_file"`
}

func (executor *needAuthExecutor) UpdateInterViewFile(reqBody string) (respStr string, err error) {
	var req UpdateInterViewFileReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return "", err
	}

	if req.AddFile == nil {
		return util.StringifyJson(util.GetErrorBaseResp("add_file不能为空")), err
	}

	if req.OpName == "" {
		return util.StringifyJson(util.GetErrorBaseResp("操作人不能为空")), err
	}

	if req.JinjianId == "" {
		return util.StringifyJson(util.GetErrorBaseResp("进件id不能为空")), err
	}

	if err = serviceV1.UpdateInterViewFile(req.JinjianId, req.OpName, req.AddFile); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp(err.Error())), err
	}
	respStr = util.StringifyJson(util.GetSuccessBaseResp("上传成功"))
	return
}
