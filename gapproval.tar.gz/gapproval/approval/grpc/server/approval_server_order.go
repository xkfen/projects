package server

import (
	"gapproval/approval/service"
	"gcoresys/common/util"
	"errors"
	"gapproval/approval/model"
	"gcoresys/common/logger"
	"gapproval/approval/serviceV1"
	"github.com/tidwall/gjson"
	"time"
)

//----------------------------NewApprovalOrder-------------------------------
type NewApprovalOrderReq struct {
	ApprovalOrder *model.ApprovalOrder   `json:"approval_order"`
	StatusType    string                 `json:"status_type"`
	AllInfo       map[string]interface{} `json:"all_info"`
	OrderInfo     map[string]interface{} `json:"order_info"`
}

func (executor *noAuthExecutor) NewApprovalOrder(body string) (resp string, err error) {
	var req NewApprovalOrderReq
	if err = util.ParseJson(body, &req); err != nil {
		return resp, err
	}
	if req.AllInfo == nil || req.OrderInfo == nil {
		return resp, errors.New("进件all_info或者order map 为空，请检查")
	}
	logger.Info("===============================req.AllInfo", "req.AllInfo", req.AllInfo)
	if req.StatusType == "change_back" {
		if err = serviceV1.UpdateApprovalOrderBack(req.ApprovalOrder.JinjianId, req.AllInfo); err != nil {
			return resp, err
		}
		return RespSuccessRpc("修改成功"), nil
	}
	if req.AllInfo["call_record"] == nil || req.AllInfo["contacts"] == nil ||
		req.AllInfo["idcard_info"] == nil || req.AllInfo["personal_info"] == nil ||
		req.AllInfo["salary_bank"] == nil {
		logger.Error("========进件all_info出错，请检查============")
		return resp, errors.New("进件all_info出错，请检查")
	}
	req.ApprovalOrder.AllInfo = util.StringifyJson(req.AllInfo)
	req.ApprovalOrder.OrderInfo = util.StringifyJson(req.OrderInfo)
	if err = serviceV1.NewApprovalOrder(req.ApprovalOrder); err != nil {
		return resp, err
	}

	return RespSuccessRpc("创建成功", "approval_order_id", req.ApprovalOrder.ID), nil
}

//----------------------------GrabApproval-------------------------------

func (executor *needAuthExecutor) GrabApproval(body string) (resp string, err error) {
	switch executor.ApprovalType {
	case "cs":
		ao := model.ApprovalOrder{FirstTrailId: executor.Username, FirstTrailName: executor.Name}
		if err = serviceV1.GrabApprovalOrder("cs", &ao, executor.Username, executor.Name); err != nil {
			return resp, err
		}
	case "zs":
		ao := model.ApprovalOrder{ReTrailId: executor.Username, ReTrailName: executor.Name}
		if err = serviceV1.GrabApprovalOrder("zs", &ao, executor.Username, executor.Name); err != nil {
			return resp, err
		}
	case "kf":
		ao := model.ApprovalOrder{CustomServiceId: executor.Username, CustomServiceName: executor.Name}
		if err = serviceV1.GrabApprovalOrder("kf", &ao, executor.Username, executor.Name); err != nil {
			return resp, err
		}
	}
	return RespSuccessRpc("抢单成功"), nil
}

//---------------------------- GetApprovalOrderInfo -------------------------------

type GetApprovalOrderResp struct {
	Success               bool                           `json:"success"`
	Info                  string                         `json:"info"`
	ApprovalOrder         *model.ApprovalOrder           `json:"approval_order"`
	ThreePartyInfo        *model.ThreePartyInfo          `json:"three_party_info"`
	IsRightThreePartyInfo bool                           `json:"is_right_three_party_info"`
	Files                 Files                          `json:"files"`
	DianHe                []model.ApprovalCallRecord     `json:"dian_he"`
	ContractSysInfo       map[string]interface{}         `json:"contract_sys_info"`
	UserInfoSup           *model.ApprovalUserInfoSup     `json:"user_info_sup"`
	QuantizationVar       *model.ApprovalQuantizationVar `json:"quantization_var"`
	ApprovalFile          []*model.ApprovalFile          `json:"approval_file"`
}

// 获取审批单详情
func (executor *needAuthExecutor) GetApprovalOrderInfo(body string) (resp string, err error) {
	jinjianId := gjson.Get(body, "approval_order.jinjian_id").Str
	if jinjianId == "" {
		return resp, errors.New("jinjian_id 不能为空")
	}

	result, satisfy, err := serviceV1.GetApprovalOrder(jinjianId)
	if err != nil {
		return resp, err
	}

	data := GetApprovalOrderResp{
		Success:               true,
		Info:                  "查询成功",
		ApprovalOrder:         &result,
		Files:                 Files{Dianhe: serviceV1.GetApprovalFile(jinjianId, model.FT_DIANHE)},
		ThreePartyInfo:        serviceV1.GetThreePartyInfo(jinjianId),
		IsRightThreePartyInfo: satisfy,
		DianHe:                serviceV1.GetCallRecord(jinjianId),
		ContractSysInfo:       serviceV1.GetContractUrl(jinjianId),
		UserInfoSup:           serviceV1.GetUserInfoSup(jinjianId),
		QuantizationVar:       serviceV1.GetQuantizationVar(jinjianId),
		ApprovalFile:          serviceV1.GetApprovalFileV1(jinjianId),
	}

	return util.StringifyJson(data), nil
}

//----------------------------GetApprovalOrderList-------------------------------
type GetApprovalOrderListReq struct {
	Page          int                  `json:"page"`
	IndexType     bool                 `json:"index_type"`
	ApprovalOrder *model.ApprovalOrder `json:"approval_orders_query"`
}

func (executor *noAuthExecutor) GetApprovalOrderList(body string) (resp string, err error) {
	var req GetApprovalOrderListReq
	if err = util.ParseJson(body, &req); err != nil {
		return resp, err
	}

	result, totalPage := serviceV1.GetApprovalOrderList(req.IndexType, req.ApprovalOrder, req.Page)
	return RespSuccessRpc("获取成功", "approval_orders", result, "total_page", totalPage), nil
}

// --------------------------------- UpdateApprovedOrder ---------------------------------
type updateApprovedOrderReq struct {
	Item                string                    `json:"item"`
	ApprovalOrder       model.ApprovalOrder       `json:"approval_order"`
	ApprovalUserInfoSup model.ApprovalUserInfoSup `json:"user_info_sup"`
}

// 保存或更新审批单信息
func (executor *needAuthExecutor) UpdateApprovalOrder(body string) (respStr string, err error) {
	var req updateApprovedOrderReq
	if err := util.ParseJson(body, &req); err != nil {
		return respStr, errors.New("parse json err:" + err.Error())
	}

	if err = service.CreateOrUpdateUserInfo(req.Item, req.ApprovalUserInfoSup); err != nil {
		return
	}

	err = service.UpdateApprovalOrderInfo(req.Item, executor.ApprovalType, req.ApprovalOrder)
	if err != nil {
		return respStr, err
	}

	return RespSuccessRpc("保存成功"), nil
}

// 保存放款信息
func (executor *needAuthExecutor) SaveLoanInfo(reqBody string) (respStr string, err error) {

	var req model.ApprovalOrder
	if err = util.ParseJson(reqBody, &req); err != nil {
		return respStr, errors.New("SetLoanInfo body json 错误 " + err.Error())
	}

	if err = service.SaveLoanInfo(req, executor.ApprovalType); err != nil {
		return
	}

	return RespSuccessRpc("保存成功"), nil
}

// ----------------------------------------ApprovalSuspend----------------------------

type ApprovalSuspendReq struct {
	JinjianId string `json:"jinjian_id"`
	SsSwitch  string `json:"ss_switch"`
	SsDesc    string `json:"ss_desc"`
}

// 审批挂起
func (executor *needAuthExecutor) ApprovalSuspend(reqBody string) (respStr string, err error) {
	var req ApprovalSuspendReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return respStr, err
	}
	if err = serviceV1.ApprovalSuspending(req.JinjianId, req.SsSwitch, req.SsDesc, executor.ApprovalType); err != nil {
		return respStr, err
	}
	return RespSuccessRpc("审批挂起操作成功"), nil
}

// ---------------------------------MarkIsStandard---------------------------------
type MarkIsStandardReq struct {
	JinjianId string `json:"jinjian_id"`
	Status    string `json:"status"`
}

// 修改是否标准件
func (executor *needAuthExecutor) MarkIsStandard(reqBody string) (respStr string, err error) {
	var req MarkIsStandardReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return respStr, err
	}
	if req.JinjianId == "" {
		return respStr, errors.New("jinjian_id 不能为空")
	}
	if req.Status == "" {
		return respStr, errors.New("非标件Status不能为空")
	}
	if err = serviceV1.MarkIsStandard(req.JinjianId, req.Status); err != nil {
		return respStr, err
	}
	return RespSuccessRpc("修改是否非标件成功"), nil
}

// ---------------------------------AddOrUpdateAddContact---------------------------------
type AddOrUpdateAddContactReq struct {
	Action       string `json:"action"`
	JinjianId    string `json:"jinjian_id"`
	Name         string `json:"name"`
	Phone        string `json:"phone"`
	Relationship string `json:"relationship"`
	Address      string `json:"Address"`
	Key          string `json:"key"`
	Value        string `json:"value"`
	Index        int    `json:"index"`
}

//  添加或更新联系人
func (executor *needAuthExecutor) AddOrUpdateAddContact(reqBody string) (respStr string, err error) {
	var req AddOrUpdateAddContactReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return respStr, err
	}
	switch req.Action {
	case "add":
		if req.Name == "" {
			return respStr, errors.New("姓名不能为空")
		}
		if req.Phone == "" {
			return respStr, errors.New("电话不能为空")
		}
		if req.Relationship == "" {
			return respStr, errors.New("关系不能为空")
		}
		if err = serviceV1.AddContact(req.JinjianId, req.Name, req.Phone, req.Relationship, req.Address); err != nil {
			return respStr, err
		}
		return RespSuccessRpc("新增联系人成功"), nil

	case "update":
		logger.Info("修改新增联系人信息", "index", req.Index)
		if req.Key == "" {
			return respStr, errors.New("key不能为空")
		}
		if req.Value == "" {
			return respStr, errors.New("value不能为空")
		}
		if err = serviceV1.UpdateAddContact(req.JinjianId, req.Key, req.Value, req.Index); err != nil {
			return respStr, err
		}
		return RespSuccessRpc("修改新增联系人信息成功"), nil
	default:
		return respStr, errors.New("审批新增联系action错误，请检查")
	}
}

// ---------------------------------NewOrUpdateRiskParam---------------------------------
type NewOrUpdateRiskParamReq struct {
	Action            string                 `json:"action"`
	JinjianId         string                 `json:"jinjian_id"`
	ApprovalAmount    uint64                 `json:"approval_amount"`
	PlatformMonthRate float64                `json:"platform_month_rate"`
	PlanNum           string                 `json:"plan_num"`
	RiskParam         map[string]interface{} `json:"risk_param"`
	Keys              map[string]string      `json:"keys"`
}

func (executor *needAuthExecutor) NewOrUpdateRiskParam(reqBody string) (respStr string, err error) {
	var req NewOrUpdateRiskParamReq
	if err := util.ParseJson(reqBody, &req); err != nil {
		return respStr, err
	}
	switch req.Action {
	case "new":
		if err = serviceV1.SaveRiskParam(req.JinjianId, req.RiskParam, req.ApprovalAmount, req.PlatformMonthRate, req.PlanNum); err != nil {
			return respStr, err
		}
		return RespSuccessRpc("上传风险变量成功"), nil
	case "update":
		if err = serviceV1.UpdateRiskParam(req.JinjianId, req.Keys, req.RiskParam, req.ApprovalAmount, req.PlatformMonthRate, req.PlanNum); err != nil {
			return respStr, err
		}
		return RespSuccessRpc("修改风险变量成功"), nil
	default:
		return respStr, errors.New("审批风险变量action错误，请检查")
	}
}

// ---------------------------------NewOrUpdateExtensionNumber---------------------------------
type NewOrUpdateExtensionNumberReq struct {
	JinjianId       string `json:"jinjian_id"`
	ExtensionNumber string `json:"extension_number"`
}

func (executor *needAuthExecutor) NewOrUpdateExtensionNumber(reqBody string) (respStr string, err error) {
	var req NewOrUpdateExtensionNumberReq
	if err := util.ParseJson(reqBody, &req); err != nil {
		return respStr, err
	}
	if err = serviceV1.NewOrUpdateExtensionNumber(req.JinjianId, req.ExtensionNumber); err != nil {
		return respStr, err
	}
	return RespSuccessRpc("修改分机号成功"), nil
}

// --------------------------------UpdateJinjianAllInfo-----------------------------------

type UpdateJinjianAllInfoReq struct {
	JinjianId string `json:"jinjian_id"`
	Key       string `json:"key"`
	Value     string `json:"value"`
	GroupId   string `json:"group_id"`
	Password  string `json:"password"`
}

func (executor *needAuthExecutor) UpdateJinjianAllInfo(reqBody string) (respStr string, err error) {
	var req UpdateJinjianAllInfoReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return respStr, err
	}
	if req.JinjianId == "" {
		return respStr, errors.New("进件id不能为空")
	}
	if req.Value == "" {
		return respStr, errors.New("修改值不能为空")
	}
	if err = serviceV1.UpdateJinjianAllInfo(req.JinjianId, req.Key, req.Value); err != nil {
		return respStr, err
	}
	return RespSuccessRpc("修改审批信息成功"), nil
}

// -------------------------------AddPayCard----------------------------------------------
type AddPayCardReq struct {
	JinjianId string `json:"jinjian_id"`
	BankName  string `json:"bank_name"`
	CardNum   string `json:"card_num"`
	Cellphone string `json:"cellphone"`
}
func (payCard *AddPayCardReq) IsValid() (err error) {
	switch {
	case payCard.JinjianId == "":
		return errors.New("进件id不能为空")
	case payCard.BankName == "":
		return errors.New("银卡名称不能为空")
	case payCard.CardNum == "":
		return errors.New("银行卡号不能为空")
	case payCard.Cellphone == "":
		return errors.New("手机号不能为空")
	}
	return
}

func (executor *needAuthExecutor) AddPayCard(reqBody string) (respStr string, err error) {
	var req AddPayCardReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return
	}
	if err = req.IsValid(); err != nil {
		return
	}
	if err = serviceV1.AddPayCard(req.JinjianId, req.BankName, req.CardNum, req.Cellphone); err != nil {
		return
	}
	return RespSuccessRpc("添加扣款卡成功"), nil
}

//----------------------------GetApprovalList-------------------------------
type GetApprovalListReq struct {
	Page       int    `json:"page"`
	Status     string `json:"status"`
	Query      string `json:"query"`
	SearchType string `json:"search_type"`
	Condition  string `json:"condition"`
	Sort       string `json:"sort"`
}

func (executor *needAuthExecutor) GetApprovalList(reqBody string) (respStr string, err error) {
	var req GetApprovalListReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return respStr, err
	}
	if req.Query != "all" && req.Query != "me" && req.Query != "history" && req.Query != "today" {
		return respStr, errors.New("query参数错误")
	}
	if req.Sort != "created_at" && req.Sort != "created_at desc" && req.Sort != "loan_amount" && req.Sort != "loan_amount desc" &&
		req.Sort != "loan_term" && req.Sort != "loan_term desc" && req.Sort != "" {
		return respStr, errors.New("sort参数错误")
	}
	var result []model.ApprovalOrder
	var pageCount, totalCount int
	switch executor.ApprovalType {
	case "cs":
		result, pageCount , totalCount = serviceV1.GetFirstTrailApprovalOrderList(req.Query, req.Status, executor.Username, executor.Name,
			req.Sort, req.Condition, req.Page)
	case "zs":
		result, pageCount, totalCount = serviceV1.GetReTrailApprovalOrderList(req.Query, req.Status, executor.Username, executor.Name,
			req.Sort, req.Condition, req.Page)
	case "kf":
		result, pageCount , totalCount = serviceV1.GetCustomServiceApprovalOrderList(req.Query, req.Status, executor.Username, executor.Name,
			req.Sort, req.Condition, req.Page)
	}
	return RespSuccessRpc("获取成功", "approval_orders", result, "page_count", pageCount, "total_count", totalCount), nil
}

// ----------------------------------------Query----------------------------

type QueryReq struct {
	serviceV1.QueryParam
}

func (executor *needAuthExecutor) Query(reqBody string) (respStr string, err error) {
	var req QueryReq
	if err := util.ParseJson(reqBody, &req); err != nil {
		return respStr, err
	}
	if req.QueryParam.StartTime != "" {
		startTime, _ := time.Parse("2006-01-02", req.QueryParam.StartTime)
		req.QueryParam.MinApprovalTime = &startTime
	}

	if req.QueryParam.EndTime != "" {
		endTime, _ := time.Parse("2006-01-02", req.QueryParam.EndTime)
		endTime = endTime.AddDate(0, 0, 1) // 加了一天,这里需要好好思考
		req.QueryParam.MaxApprovalTime = &endTime
	}

	list, count, page, err := serviceV1.Query(req.QueryParam)
	if err != nil {
		return respStr, err
	}
	return RespSuccessRpc("审批查询成功", "query_result_list", list, "total_count", count, "total_page", page), nil
}
