package server

import (
	"gcoresys/common/util"
	"gapproval/approval/service"
)

/**
	这个文件是查询列表，包括全部列表，历史订单列表，查询模块的列表
 */

//*************预审批列表查询**********************//
// 预审批--查询
func (executor *needAuthExecutor) QueryPreApprovalListByKey(reqBody string) (respStr string, err error) {
	var req service.QueryPreOrderListReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return "", err
	}
	// service处理请求
	orderList, totalPages, totalCount, err := service.QueryPreApprovalListByKey(executor.Username, executor.Name, req)
	if err != nil {
		return RespErrorRpc("根据参数查询预审批出错：" + err.Error()), err
	}
	// 响应参数
	return RespSuccessRpc("查询成功", "data", orderList, "total_page", totalPages, "total_count", totalCount), nil
}