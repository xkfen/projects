package server

import (
	"gcoresys/common/util"
	"reflect"
	"gcoresys/common/logger"
)

type noAuthExecutor struct{}
type needAuthExecutor struct {
	ApprovalType string
	Username     string
	Name         string
}

// 统一处理 RPC
func UniformInterfaceAuthRPC(method, reqBody, approvalType, username, name string, isAuth bool) (respStr string, err error) {
	// 方法下划线转驼峰
	method = util.StrToTF1(method)
	logger.Info("===================== 前端请求统一处理RPC调用方法", "method", method)
	logger.Info("=====================", "body", reqBody)

	var tmpM reflect.Value
	// 判断是否需要鉴权, 需要鉴权的方法由 needAuth 去实现多态
	if isAuth {
		curExecutor := &needAuthExecutor{
			ApprovalType: approvalType,
			Username:     username,
			Name:         name,
		}
		tmpM = reflect.ValueOf(curExecutor).MethodByName(method)
	} else {
		curExecutor := &noAuthExecutor{}
		tmpM = reflect.ValueOf(curExecutor).MethodByName(method)
	}

	// 判断是否存在该方法
	if tmpM.Kind() != reflect.Func {
		return RespErrorRpc("尚未实现该操作:" + method), nil
	}

	// 调用方法
	results := tmpM.Call([]reflect.Value{reflect.ValueOf(reqBody)})

	// 处理返回结果
	respStr = results[0].String()
	if !results[1].IsNil() {
		e := results[1].Interface().(error)
		respStr = RespErrorRpc(e.Error())
	}
	return
}

func RespSuccessRpc(info string, data ...interface{}) string {
	result := map[string]interface{}{"success": true, "info": info}
	for i := 0; i < len(data)-1; i += 2 {
		key, ok := data[i].(string)
		if !ok {
			logger.Error("RespSuccessRpc key值请传string", "key", data[i])
		}
		result[key] = data[i+1]
	}
	if len(data) == 1 {
		result["data"] = data[0]
	}
	return util.StringifyJson(result)
}

func RespErrorRpc(info string) string {
	return util.StringifyJson(map[string]interface{}{
		"info":    info,
		"success": false,
	})
}
