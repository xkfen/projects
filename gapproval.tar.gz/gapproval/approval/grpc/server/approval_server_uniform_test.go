package server

import (
	"github.com/stretchr/testify/assert"
	"testing"
	"fmt"
	"gapproval/approval/model"
	"gapproval/approval/serviceV1"
)

func TestUniformInterfaceAuthRPC(t *testing.T) {
	oneStepTest(func() {

		ao := model.GetDefaultApprovalOrder()
		ao.JinjianId = "test123"

		assert.Equal(t, nil, serviceV1.NewApprovalOrder(ao))

		str, err := UniformInterfaceAuthRPC("UpdateApprovalOrder", `{"item":"submit_info", "approval_order":{"jinjian_id":"test123","is_standard":"0", "loan_term":12, "loan_amount":111}}`, "cs", "test", "测试", true)

		fmt.Println(str)
		assert.Equal(t, nil, err)

		ao2, err := model.GetApprovalOrderByJinjianId(ao.JinjianId)
		assert.Equal(t, nil, err)

		assert.Equal(t, "0", ao2.IsStandard)

	})
}
