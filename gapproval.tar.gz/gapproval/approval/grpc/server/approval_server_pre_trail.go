package server

import (
	"gapproval/approval/serviceV1"
	"gcoresys/common/util"
	"gcoresys/common/http"
	"gapproval/approval/model"
	"github.com/tidwall/gjson"
	"errors"
)

// 预审抢单
func (executor *needAuthExecutor) GrabPreApproval(reqBody string) (respStr string, err error) {
	if err = serviceV1.GrabPreApproval(executor.Username, executor.Name); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp(err.Error())), err
	}

	respStr = util.StringifyJson(util.GetSuccessBaseResp("抢单成功"))
	return
}

// 获取预审批记录
type GetPreApprovalLogReq struct {
	PreApprovalID string `json:"pre_approval_id"`
}

type GetPreApprovalLogResp struct {
	http.BaseResp
	LogList []model.PreApprovalLog `json:"log_list"`
}

func (executor *needAuthExecutor) GetPreApprovalLog(reqBody string) (respStr string, err error) {
	var req GetPreApprovalLogReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp("ParseJson GetPreApprovalLog时出错：" + err.Error())), err
	}

	if req.PreApprovalID == "" {
		return util.StringifyJson(util.GetErrorBaseResp("预审id不能为空")), err
	}

	respStr = util.StringifyJson(&GetPreApprovalLogResp{
		BaseResp: *util.GetSuccessBaseResp("预审操作日志获取成功"),
		LogList:  serviceV1.GetPreApprovalLog(req.PreApprovalID),
	})
	return
}

// 预审操作
type PreTrailOperationReq struct {
	PreApprovalOrder *model.PreApprovalOrder `json:"pre_approval_order"`
}

func (executor *needAuthExecutor) PreTrailOperation(reqBody string) (respStr string, err error) {
	var req PreTrailOperationReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp("ParseJson PreTrailOperation时出错：" + err.Error())), err
	}

	if err = serviceV1.PreTrailOperation(req.PreApprovalOrder); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp(err.Error())), err
	}

	respStr = util.StringifyJson(util.GetSuccessBaseResp("操作成功"))
	return
}

// 获取预审列表
type GetPreApprovalListReq struct {
	ReqParam serviceV1.GetPreApprovalListParam `json:"req_param"`
}

type GetPreApprovalListResp struct {
	http.BaseResp
	PaoList    []model.PreApprovalOrder `json:"pao_list"`
	TotalPage  int                      `json:"total_page"`
	TotalCount int                      `json:"total_count"`
}

func (executor *needAuthExecutor) GetPreApprovalList(reqBody string) (respStr string, err error) {
	var req GetPreApprovalListReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp("ParseJson GetPreApprovalList时出错：" + err.Error())), err
	}

	req.ReqParam.Username = executor.Username
	req.ReqParam.Name = executor.Name
	paoList, tp, tc, err := serviceV1.GetPreApprovalList(req.ReqParam)
	if err != nil {
		return util.StringifyJson(util.GetErrorBaseResp(err.Error())), err
	}

	respStr = util.StringifyJson(&GetPreApprovalListResp{
		BaseResp:   *util.GetSuccessBaseResp("预审信息获取成功"),
		PaoList:    paoList,
		TotalPage:  tp,
		TotalCount: tc,
	})
	return
}

// 获取预审批单详情
func (executor *needAuthExecutor) GetPreApprovalInfo(reqBody string) (respStr string, err error) {
	preApprovalId := gjson.Get(reqBody, "pre_approval_id").Str
	if preApprovalId == "" {
		return respStr, errors.New("预审id不能为空")
	}

	pao, err := serviceV1.GetPreApprovalInfo(preApprovalId)
	if err != nil {
		return respStr, err
	}

	return RespSuccessRpc("预审信息查询成功", "pre_approval_order", pao), nil

}

// 获取预审分数
type GetPreApprovalScoreResultReq struct {
	ScoreReq      serviceV1.ScoreReq `json:"score_req"`
	PreApprovalID string             `json:"pre_approval_id"`
}

func (executor *needAuthExecutor) GetPaScore(reqBody string) (respStr string, err error) {
	var req GetPreApprovalScoreResultReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp("ParseJson GetPaScore时出错：" + err.Error())), err
	}

	if req.PreApprovalID == "" {
		return util.StringifyJson(util.GetErrorBaseResp("预审id不能为空")), err
	}
	if err = serviceV1.GetPreApprovalScoreResult(req.ScoreReq, req.PreApprovalID); err != nil {
		return util.StringifyJson(util.GetErrorBaseResp(err.Error())), err
	}

	respStr = util.StringifyJson(util.GetSuccessBaseResp("提交成功"))
	return
}
