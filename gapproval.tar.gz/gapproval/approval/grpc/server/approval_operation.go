package server

import (
	"gapproval/approval/service"
	"gcoresys/common/util"
	"errors"
	"github.com/tidwall/gjson"
)

// 审批操作
func (executor *needAuthExecutor) ApprovalOperation(reqBody string) (respStr string, err error) {

	switch executor.ApprovalType {

	case "ys":
		var operation service.PreApprovalOperationReq
		if err = util.ParseJson(reqBody, &operation); err != nil {
			return
		}
		if err = service.PreApprovalOperation(operation); err != nil {
			return
		}

	case "cs":
		var operation service.ApprovalOperationCS
		if err = util.ParseJson(reqBody, &operation); err != nil {
			return
		}
		if err = service.FirstTrailOperation(operation); err != nil {
			return
		}
	case "zs":
		var operation service.ApprovalOperationZS
		if err = util.ParseJson(reqBody, &operation); err != nil {
			return
		}
		if err = service.ReTrailOperation(operation); err != nil {
			return
		}
	case "kf":
		var operation service.ApprovalOperationKF
		if err = util.ParseJson(reqBody, &operation); err != nil {
			return
		}
		if err = service.CustomOperation(operation); err != nil {
			return
		}
	default:
		return respStr, errors.New("审批权限错误：" + executor.ApprovalType)
	}
	return RespSuccessRpc("操作成功"), nil

}

// 审批报表
func (executor *noAuthExecutor) ApprovalReportForm(body string) (respStr string, err error) {
	startTime := gjson.Get(body, "start_time").Str
	endTime := gjson.Get(body, "end_time").Str

	return service.ApprovalReportForm(startTime, endTime)
}
