package server

import (
	"errors"
	"gapproval/approval/service"
	"github.com/tidwall/gjson"
	"gcoresys/common/util"
)

/**
这个文件是订单详情里面的信息
 */

// 预审订单简要信息，显示进件方案，产品方案，预审编号，客户姓名，身份证号，订单状态；
func (executor *needAuthExecutor) GetBriefPreOrderInfo(reqBody string) (respStr string, err error) {
	preApprovalId := gjson.Get(reqBody, "pre_approval_id").Str
	if preApprovalId == "" {
		return "", errors.New("预审id不能为空")
	}
	// 查询预审订单简要信息
	preOrder, err := service.GetBriefPreOrderInfo(preApprovalId)
	if err != nil {
		return
	}
	return RespSuccessRpc("订单简要信息查询成功", "data", preOrder), nil
}

//**************************进件方案、姓名、身份证号、电话*********************
// 预审修改：进件方案、姓名、身份证号、电话为可编辑项
func (executor *needAuthExecutor) UpdatePreOrderInfo(reqBody string) (respStr string, err error) {
	var req service.UpdatePreInfoReq
	if err = util.ParseJson(reqBody, &req); err != nil {
		return "", err
	}

	err = service.UpdatePreOrderInfo(req)

	if err != nil {
		return
	}
	return RespSuccessRpc("预审信息更新成功"), nil
}