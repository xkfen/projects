package grpc

import (
	"gapproval/approval/grpc/pb"
	"gapproval/approval/grpc/server"
	"gcoresys/common/logger"
	"google.golang.org/grpc"
	"gcoresys/common"
	"net"
)

func StartApprovalRpcServer() {
	port := common.GetHttpServerPort("8091")
	logger.Info("启动 approval RPC 服务", "port", port)
	ln, err := net.Listen("tcp", ":"+port)
	if err != nil {
		panic("启动rpc服务出错:" + err.Error())
	}
	s := grpc.NewServer()
	rpcServer := server.MakeGRPCApprovalServer()
	pb.RegisterApprovalServer(s, rpcServer)
	s.Serve(ln)
}
