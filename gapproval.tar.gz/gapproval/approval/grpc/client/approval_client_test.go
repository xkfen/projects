package client

import (
	"testing"
	"github.com/stretchr/testify/assert"
)

func TestGetApprovalClient(t *testing.T) {
	client := GetApprovalClient()
	assert.NotEqual(t, nil, client)
}
