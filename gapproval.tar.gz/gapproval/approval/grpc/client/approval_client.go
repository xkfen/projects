package client

import (
	"gapproval/approval/grpc/pb"
	"google.golang.org/grpc"
	"gcoresys/common"
)

var approvalClient pb.ApprovalClient

// GRPC是HTTP2实现的，为多路复用，因此所有请求都使用该单例即可
func GetApprovalClient() pb.ApprovalClient {
	if approvalClient == nil {
		host := "localhost"
		if common.GetUseDocker() != 0 {
			host = common.GapprovalMicroDns
		}

		port := common.GetHttpServerPort("8091")
		conn, err := grpc.Dial(host+":"+port, grpc.WithInsecure())

		if err != nil {
			panic("创建 RPC 客户端出错")
		}
		approvalClient = pb.NewApprovalClient(conn)
	}
	return approvalClient
}
