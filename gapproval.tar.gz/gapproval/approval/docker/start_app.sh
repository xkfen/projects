#!/usr/bin/env bash

gapproval_db --action=create --env=$QY_ENV --docker_env=$QY_DOCKER_ENV;gapproval_db --action=migrate --env=$QY_ENV --docker_env=$QY_DOCKER_ENV;gapproval --env=$QY_ENV --docker_env=$QY_DOCKER_ENV