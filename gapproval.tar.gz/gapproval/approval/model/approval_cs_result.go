package model

import (
	"errors"
	"gcoresys/common/mysql"
)

// 初审结论
type ApprovalCsResult struct {
	mysql.BaseModel
	//认定收入
	CognizanceIncome string `gorm:"not null;type:text" json:"cognizance_income"`
	//认定负债
	CognizanceLiabilities string `gorm:"not null;type:text" json:"cognizance_liabilities"`
	//资产情况
	AssetSituation string `gorm:"not null;type:text" json:"asset_situation"`
	//贷记卡是否最低还款
	DebitCardIsMinRepay string `gorm:"not null;type:text" json:"debit_card_is_min_repay"`
	//征信逾期情况
	OverdueInvestigation string `gorm:"not null;type:text" json:"overdue_investigation"`
	//逾期原因
	OverdueReason string `gorm:"not null;type:text" json:"overdue_reason"`
	//电核和流水判断
	DhLs string `gorm:"not null;type:text" json:"dh_ls"`
	//其他
	Other string `gorm:"not null;type:text" json:"other"`
	//客户姓名
	Name string `gorm:"not null" json:"name"`
	//审批id
	ApprovalId uint `gorm:"not null" json:"approval_id"`
	//审批编号
	ApprovalNumber string `gorm:"not null" json:"approval_number"`
	//审批是否通过
	ApprovalStatusIsPass string `gorm:"not null" json:"approval_status_is_pass"`
	//固定还款日
	RepaymentDate string `gorm:"not null" json:"repayment_date"`
	//贷款金额
	LoanAmount string `gorm:"not null" json:"loan_amount"`
	// 贷款期限（月，不含调节期）
	LoanTerm string `gorm:"not null" json:"loan_term"`
	//初审人员
	CsName string `gorm:"not null" json:"cs_name"`
	// 还款银行
	PayBankName string `gorm:"not null" json:"pay_bank_name"`
	// 银行卡号
	PayBankNum string `gorm:"not null" json:"pay_bank_num"`
	// 选择此卡的原因
	ChoiceReason string `gorm:"not null" json:"choice_reason"`
}

func (a *ApprovalCsResult) IsValidApprovalCsResult() (err error) {
	switch {
	case a.ApprovalId == 0:
		err = errors.New("审批id不能为0")
	case a.LoanAmount == "":
		err = errors.New("贷款金额不能为空")
	case a.CsName == "":
		err = errors.New("审核人不能为空")
	case a.ApprovalStatusIsPass == "":
		err = errors.New("审核状态不能为空不能为空")
	case a.LoanTerm == "":
		err = errors.New("贷款期数不能为空")
	}
	return
}
