package model

import (
	"gcoresys/common"
	"errors"
	"gcoresys/common/logger"
	"github.com/jinzhu/gorm"
	"gapproval/approval/db/config"
	"reflect"
	"gapproval/common/httpReq"
	"gapproval/common/global"
	"github.com/tidwall/gjson"
)

func (approvalOrder *ApprovalOrder) Create() error {
	if err := config.GetDb().Model(approvalOrder).Create(approvalOrder).Error; err != nil {
		logger.Error("================ model ApprovalOrder Create", "err", err.Error())
		return err
	}
	return nil
}

func GetApprovalOrderByJinjianId(jinjianId string) (approvalOrder ApprovalOrder, err error) {
	if err = config.GetDb().Model(&approvalOrder).Where("jinjian_id = ?", jinjianId).First(&approvalOrder).Error; err != nil {
		logger.Error("============= model ApprovalOrder GetApprovalOrderByJinjianId", "err", err.Error())
		return
	}
	return
}

func (approvalOrder *ApprovalOrder) Update(update ...interface{}) error {
	if len(update) == 0 {
		if err := config.GetDb().Model(approvalOrder).Where("id = ?", approvalOrder.ID).Updates(approvalOrder).Error; err != nil {
			logger.Error("=================== model ApprovalOrder Update Updates", "err", err.Error())
			return err
		}
	} else {
		// 类型判断
		switch u := update[0]; u.(type) {
		case map[string]interface{}:
			if err := config.GetDb().Model(approvalOrder).Where("id = ?", approvalOrder.ID).Update(u).Error; err != nil {
				logger.Error("=================== model ApprovalOrder Update Map[string]interface", "err", err.Error())
				return err
			}
		case interface{}:
			if err := config.GetDb().Model(approvalOrder).Where("id = ?", approvalOrder.ID).Update(u).Error; err != nil {
				logger.Error("=================== model ApprovalOrder Update interface{}", "err", err.Error())
				return err
			}
		default:
			logger.Error("更新 ApprovalOrder 时类型错误", "data", reflect.TypeOf(u))
			return errors.New("更新 ApprovalOrder 时类型错误，请检查")
		}
	}

	return nil
}

/**
  @Description: 初审基础规则，无论是通过或者是拒绝都需要判断
  @Date: 14:48 2017/12/14
*/
func (ao *ApprovalOrder) FirstTrailBaseRule() (err error) {
	// 检查是否有量化评分
	if common.GetUseDocker() != 0 && ao.QuantizationPoint == 0 {
		return errors.New("量化变量未上传")
	}

	// 非标件
	if ao.IsStandard == "" {
		return errors.New("请先标记是否为非标件")
	}

	return
}

func (ao *ApprovalOrder) FirstTrailPassRule() error {

	if err := ao.FirstTrailBaseRule(); err != nil {
		return err
	}

	// 检查三方信息
	if _, err := GetThreePartyInfoByJinjianId(ao.JinjianId); err != nil {
		return err
	}

	if ao.RiskParam == "" {
		return errors.New(" 风险参数不能为空")
	}

	// 检查是否有通话记录
	callRecordResult, err := ao.CheckCallRecord()
	if err != nil {
		return err
	}

	// 通话记录
	if !callRecordResult {
		return errors.New("未查询到通话记录，请先电核用户！")
	}

	// 这里去判断多资金方 初审通过规则
	if ao.FundSide == CLFundSide {
		return nil
	}

	if info, err := GetApprovalUserInfoSupByJinjianId(ao.JinjianId); (err != nil && err != gorm.ErrRecordNotFound) || info.ID == 0 {
		return errors.New("用户个人信息必须补充")
	}

	switch {
	case ao.Card1 == "":
		return errors.New("主卡不能为空")
	case ao.Cellphone == "":
		return errors.New("手机不能为空")
	case ao.BankName == "":
		return errors.New("银行名字不能为空")
	case ao.UserIdNum == "":
		return errors.New("身份证不能为空")
	case ao.LoanBankName == "":
		return errors.New("放款银行不能为空")
	case ao.LoanCard == "":
		return errors.New("放款卡号不能为空")
	case ao.CardOnePhone == "":
		return errors.New("扣款卡手机号不能为空")
	case ao.PlatformMonthRate == 0:
		return errors.New("请填写平台服务月利率")
	}

	return nil
}

func (ao *ApprovalOrder) RtPassRuleByFundSide() error {
	if err := ao.FirstTrailPassRule(); err != nil {
		return err
	}

	switch ao.FundSide {
	case CLFundSide:
		return nil
	case XDZFundSide:
		return ao.IsValidApprovalOrder()
	case HAIJINSHEFundSide:
		return ao.checkHJSPass()
	default:
		return ao.IsValidZsPassOperationMrOnionNew() // 现在基本的都走这个
	}
}

func (ao *ApprovalOrder) checkHJSPass() (err error) {
	if err = ao.IsValidZsPassOperationMrOnion(); err != nil {
		return
	}
	//if ao.RiskLevel == "" {
	//	return errors.New("海金社终审通过风险等级不能为空")
	//}
	//
	//if ao.RiskResult == "" {
	//	return errors.New("海金社终审通过风险结论不能为空")
	//}

	return
}

// 检查通话记录
func (ao *ApprovalOrder) CheckCallRecord() (result bool, err error) {

	if common.GetUseDocker() != 2 {
		return true, nil
	}

	var phoneNum string
	if gjson.Get(ao.AllInfo, "call_record.isJump").Bool() {
		phoneNum = gjson.Get(ao.AllInfo, "other_call.0.cellphone").Str
	} else {
		phoneNum = gjson.Get(ao.AllInfo, "call_record.cellphone").Str
	}

	if phoneNum == "" {
		return false, errors.New("未检查到手机号")
	}

	req := map[string]string{"jin_jian_id": ao.JinjianId, "phone": phoneNum}
	resultResp, err := httpReq.PostJsonProxy(req, global.GetCallCenterUrl()+"/api/v1/records/has_oneself")
	if err != nil {
		logger.Error("========查询通话记录返回结果出错: ", "resp", resultResp, "err", err.Error())
		return false, err
	}

	return resultResp["result"].(bool), nil
}
