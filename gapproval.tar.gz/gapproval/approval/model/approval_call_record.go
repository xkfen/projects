package model

import (
	"gcoresys/common/mysql"
)

const (
	NoCallRecord = "no"
)

// 通话记录备注
type ApprovalCallRecord struct {
	mysql.BaseModel
	JinjianId       string `gorm:"not null;index" json:"jinjian_id"`
	Number          string `json:"number"`
	CallType        string `json:"call_type"`
	Desc            string `gorm:"type:text" json:"desc"`
	OPName          string `json:"op_name"`
	ExistCallRecord string `gorm:"default:'yes'" json:"exist_call_record"` //是否有通话记录
}
