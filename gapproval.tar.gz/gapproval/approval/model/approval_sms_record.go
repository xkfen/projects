package model

import (
	coresysSmsModel "gcoresys/common/trace_log/model"
)

// 短信发送记录
type ApprovalSmsRecord struct {
	// 进件id
	JinjianId string `gorm:"not null;index" json:"jinjian_id"`
	// 触发发送短信操作人
	OpName string `gorm:"not null" json:"op_name"`
	coresysSmsModel.SmsMsg
}
