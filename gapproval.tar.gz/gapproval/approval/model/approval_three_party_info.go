package model

import (
	"errors"
	"gcoresys/common/mysql"
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
)

//go:generate gormgen -gen=model -type=ThreePartyInfo
type ThreePartyInfo struct {
	mysql.BaseModel
	// 进件id
	JinjianId string `gorm:"not null;unique_index" json:"jinjian_id"`

	// 居住地址
	UserAddress string `gorm:"not null" json:"user_address"`
	// 身份证号
	UserIdNum string `gorm:"not null" json:"user_id_num"`
	// 客户手机号
	UserCellphone string `gorm:"not null" json:"user_cellphone"`
	// 联系人手机号
	ContactCellphone string `gorm:"not null" json:"contact_cellphone"`
	// 次要联系人手机号
	SecContactCellphone string `gorm:"not null" json:"sec_contact_cellphone"`
	// 单位名称
	Company string `gorm:"not null" json:"company"`
	// 单位地址
	CompanyAddress string `gorm:"not null" json:"company_address"`
	// 单位电话
	CompanyPhone string `gorm:"not null" json:"company_phone"`
	// ----------------------------------------------

	// 三非
	ThreeFalse int `gorm:"not null" json:"three_false"`

	// 12月版本 客户类型
	UserType string `json:"user_type"`

	// 工商网
	GsCompanyResult     int    `gorm:"not null" json:"gs_company_result"`
	GsCompanyResultDesc string `gorm:"not null;type:text" json:"gs_company_result_desc"`
	// 百度
	BdAddressResult     int    `gorm:"not null" json:"bd_address_result"`
	BdAddressResultDesc string `gorm:"not null;type:text" json:"bd_address_result_desc"`

	BdIdNumResult     int    `gorm:"not null" json:"bd_id_num_result"`
	BdIdNumResultDesc string `gorm:"not null;type:text" json:"bd_id_num_result_desc"`

	BdUserPhoneResult     int    `gorm:"not null" json:"bd_user_phone_result"`
	BdUserPhoneResultDesc string `gorm:"not null;type:text" json:"bd_user_phone_result_desc"`

	BdContactPhoneResult     int    `gorm:"not null" json:"bd_contact_phone_result"`
	BdContactPhoneResultDesc string `gorm:"not null;type:text" json:"bd_contact_phone_result_desc"`

	BdSecContactPhoneResult     int    `gorm:"not null" json:"bd_sec_contact_phone_result"`
	BdSecContactPhoneResultDesc string `gorm:"not null;type:text" json:"bd_sec_contact_phone_result_desc"`

	BdCompanyResult     int    `gorm:"not null" json:"bd_company_result"`
	BdCompanyResultDesc string `gorm:"not null;type:text" json:"bd_company_result_desc"`

	BdCompanyAddressResult     int    `gorm:"not null" json:"bd_company_address_result"`
	BdCompanyAddressResultDesc string `gorm:"not null;type:text" json:"bd_company_address_result_desc"`

	BdCompanyPhoneResult     int    `gorm:"not null" json:"bd_company_phone_result"`
	BdCompanyPhoneResultDesc string `gorm:"not null;type:text" json:"bd_company_phone_result_desc"`
	// 人法
	RfIdNumResult     int    `gorm:"not null" json:"rf_id_num_result"`
	RfIdNumResultDesc string `gorm:"not null;type:text" json:"rf_id_num_result_desc"`

	RfCompanyResult     int    `gorm:"not null" json:"rf_company_result"`
	RfCompanyResultDesc string `gorm:"not null;type:text" json:"rf_company_result_desc"`
	// 失信
	SxIdNumResult     int    `gorm:"not null" json:"sx_id_num_result"`
	SxIdNumResultDesc string `gorm:"not null;type:text" json:"sx_id_num_result_desc"`

	SxCompanyResult     int    `gorm:"not null" json:"sx_company_result"`
	SxCompanyResultDesc string `gorm:"not null;type:text" json:"sx_company_result_desc"`

	Desc string `gorm:"not null;type:text" json:"desc"`
}

func (t *ThreePartyInfo) IsValidThreePartyInfo() (err error) {
	switch {
	case t.UserIdNum == "":
		err = errors.New("用户身份证不能为空")
	case t.Company == "":
		err = errors.New("公司名不能为空")
	case t.CompanyAddress == "":
		err = errors.New("公司地址不能为空")
	case t.UserAddress == "":
		err = errors.New("用户地址不能为空")
	case t.CompanyPhone == "":
		err = errors.New("公司电话不能为空")
	case t.ContactCellphone == "":
		err = errors.New("联系人电话不能为空")
	case t.JinjianId == "":
		err = errors.New("进件id不能为空")
	case t.SecContactCellphone == "":
		err = errors.New("次要联系人电话不能为空")
	case t.GsCompanyResult == 2 && t.GsCompanyResultDesc == "":
		err = errors.New("异常状态，备注不能为空")
	case t.BdAddressResult == 2 && t.BdAddressResultDesc == "":
		err = errors.New("异常状态，备注不能为空")
	case t.BdIdNumResult == 2 && t.BdIdNumResultDesc == "":
		err = errors.New("异常状态，备注不能为空")
	case t.BdUserPhoneResult == 2 && t.BdUserPhoneResultDesc == "":
		err = errors.New("异常状态，备注不能为空")
	case t.BdContactPhoneResult == 2 && t.BdContactPhoneResultDesc == "":
		err = errors.New("异常状态，备注不能为空")
	case t.BdSecContactPhoneResult == 2 && t.BdSecContactPhoneResultDesc == "":
		err = errors.New("异常状态，备注不能为空")
	case t.BdCompanyResult == 2 && t.BdCompanyResultDesc == "":
		err = errors.New("异常状态，备注不能为空")
	case t.BdCompanyAddressResult == 2 && t.BdCompanyAddressResultDesc == "":
		err = errors.New("异常状态，备注不能为空")
	case t.BdCompanyPhoneResult == 2 && t.BdCompanyPhoneResultDesc == "":
		err = errors.New("异常状态，备注不能为空")
	case t.RfIdNumResult == 2 && t.RfIdNumResultDesc == "":
		err = errors.New("异常状态，备注不能为空")
	case t.RfCompanyResult == 2 && t.RfCompanyResultDesc == "":
		err = errors.New("异常状态，备注不能为空")
	case t.SxIdNumResult == 2 && t.SxIdNumResultDesc == "":
		err = errors.New("异常状态，备注不能为空")
	case t.SxCompanyResult == 2 && t.SxCompanyResultDesc == "":
		err = errors.New("异常状态，备注不能为空")
	}
	return
}

func GetThreePartyInfoByJinjianId(jinjianId string) (threePartyInfo ThreePartyInfo, err error) {
	if err = config.GetDb().Model(&threePartyInfo).Where("jinjian_id = ?", jinjianId).First(&threePartyInfo).Error; err != nil {
		logger.Error("============= model ThreePartyInfo GetThreePartyInfoByJinjianId", "err", err.Error())
		return
	}
	return
}

func (info *ThreePartyInfo) Create() error {
	if err := config.GetDb().Model(info).Create(info).Error; err != nil {
		logger.Error("================ model ThreePartyInfo Create", "err", err.Error())
		return err
	}
	return nil
}
