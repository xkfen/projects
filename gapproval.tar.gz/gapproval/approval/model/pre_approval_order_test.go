package model

import (
	"testing"
	"gcoresys/common/logger"
	"gapproval/approval/db/config"
	"github.com/stretchr/testify/assert"
)

/**
 @FileDescription: test
 @author: WangXi
 @create: 19:37 2018/1/2
*/

func TestPreApprovalOrder_GetPreApprovalCountByUserIdNum(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(true)
	pao1 := GetDefaultPreApprovalOrder()
	pao2 := GetDefaultPreApprovalOrder()
	pao2.PreApprovalID = "TTT090888"
	pao3 := GetDefaultPreApprovalOrder()
	pao3.PreApprovalID = "OOOMNJ89807"
	config.GetDb().Create(pao1)
	config.GetDb().Create(pao2)
	config.GetDb().Create(pao3)
	assert.Equal(t, 3, pao1.GetPreApprovalCountByUserIdNum())
	config.ClearAllData()
}