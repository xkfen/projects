package model

import (
	"gcoresys/common/mysql"
)

// 渠道经理
type ApprovalChannelManager struct {
	mysql.BaseModel
	ApprovalOrderID uint   `gorm:"not null;index" json:"approval_order_id"`
	ChannelManager  string `gorm:"not null;index" json:"channel_manager"`
}
