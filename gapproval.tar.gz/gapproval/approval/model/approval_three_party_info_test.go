package model

/**
 @FileDescription: 
 @author: WangXi
 @create: 14:05 2017/12/25
*/

import (
	"testing"
	"github.com/stretchr/testify/assert"
)

func TestThreePartyInfo_IsVaildThreePartyInfo(t *testing.T) {
	tpi := GetDefaultThreePartyInfo()
	assert.NoError(t, tpi.IsValidThreePartyInfo())
	ttpi := tpi

	ttpi.UserIdNum = ""
	assert.EqualError(t, ttpi.IsValidThreePartyInfo(), "用户身份证不能为空")

}