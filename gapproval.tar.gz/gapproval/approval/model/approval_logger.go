package model

import "gcoresys/common/mysql"

// 操作日志
// 1. 针对初审与终身
// 2. 字段都不能为空，且不做校验
type ApprovalLogger struct {
	mysql.BaseModel
	// 操作员ID
	OperatorID uint `gorm:"not null" json:"operator_id"`
	// 操作员姓名
	OperatorName string `gorm:"not null" json:"operator_name"`
	// 显示的订单ID
	ShowID string `gorm:"not null" json:"show_id"`
	// 进件ID
	JinjianID string `gorm:"not null" json:"jinjian_id"`
	// 统计类型
	StatisticalType string `gorm:"not null" json:"statistical_type"`
	// 环节
	Segment string `gorm:"not null" json:"segment"`
	// 页面
	Page string `gorm:"not null" json:"page"`
	// 动作
	Action string `json:"action"`
}
