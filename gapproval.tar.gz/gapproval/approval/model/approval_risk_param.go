package model

import (
	"gcoresys/common/mysql"
	"reflect"
)

// 审批风险参数
type ApprovalRiskParam struct {
	mysql.BaseModel
	// 进件方案类型
	R1 string `json:"r1"`
	// 进件方案内容
	R2 string `json:"r2"`
	R2Name string `json:"r2_name"`
	// 保单生效日
	R2PolicyEffectiveDate string `json:"r2_policy_effective_date"`
	// 期缴保费（元）
	R2PolicyAmount float64 `json:"r2_policy_amount"`
	// 缴费方式
	R2PaymentMethod string `json:"r2_payment_method"`
	// 实缴次数
	R2PaymentTimes int `json:"r2_payment_times"`
	// 是否有效 0无效 1有效
	R2IsValid string `json:"r2_is_valid"`
	// 保险名称
	R2PolicyName string `json:"r2_policy_name"`
	// 保单号
	R2PolicyNumber string `json:"r2_policy_number"`
	// 认定月收入
	R3 float64 `json:"r3"`
	// 方案额度
	R4 float64 `json:"r4"`
	// 增信资料
	R5 string `json:"r5"`
	// 借记卡余额
	R6 float64 `json:"r6"`
	// 总资产
	R7 float64 `json:"r7"`
	// 自称最大偿还能力
	R8 float64 `json:"r8"`
	// 信用卡总额度
	R9 float64 `json:"r9"`
	// 信用卡已使用额度
	R10 float64 `json:"r10"`
	// 信用卡使用率
	R11 float64 `json:"r11"`
	// 信用卡平均6个月使用额
	R12 float64 `json:"r12"`
	// 信用卡平均6个月使用率
	R13 float64 `json:"r13"`
	// 准贷记卡已使用额度
	R14 float64 `json:"r14"`
	// 贷款
	R15 float64 `json:"r15"`
	// 信用贷款总额
	R16 float64 `json:"r16"`
	// 信用贷款余额
	R17 float64 `json:"r17"`
	// 信用贷款总月还
	R18 float64 `json:"r18"`
	// 非信用贷款总额
	R19 float64 `json:"r19"`
	// 非信用贷款余额
	R20 float64 `json:"r20"`
	// 非信用贷款总月还
	R21 float64 `json:"r21"`
	// 所有贷款总额
	R22 float64 `json:"r22"`
	// 所有贷款余额
	R23 float64 `json:"r23"`
	// 所有贷款总月还
	R24 float64 `json:"r24"`
	// DTI
	R25 float64 `json:"r25"`
	// 总负债/总资产收入比，前端传的百分比
	R26 float64 `json:"r26"`
	// 最大偿还比
	R27 float64 `json:"r27"`
	// 核准金额
	R28 float64 `json:"r28"`
	// 期数
	R29 int `json:"r29"`
	// 月平台费率
	R30 float64 `json:"r30"`
	// 进件方案更新时间
	R31 string `json:"r31"`
}

func (m *ApprovalRiskParam) MapJsonToModel(mapJSON map[string]interface{}) {
	t := reflect.TypeOf(m).Elem()
	//v := reflect.ValueOf(m).Elem()
	for i := 1; i < t.NumField(); i++ {

	}
}
