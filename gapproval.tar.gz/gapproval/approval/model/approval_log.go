package model

import (
	"gcoresys/common/mysql"
	"time"
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
)

// 审批状态记录日志
//go:generate gormgen -gen=model -type=ApprovalLog
type ApprovalLog struct {
	mysql.BaseModel
	ApprovalJinjianId string     `gorm:"not null;index" json:"approval_jinjian_id"`
	ApprovalStatus    string     `gorm:"not null;" json:"approval_status"`
	ApprovalName      string     `gorm:"not null;index" json:"approval_name"`
	ApprovalDesc      string     `gorm:"not null;type:text" json:"approval_desc"`
	ApprovalType      string     `gorm:"not null;" json:"approval_type"`
	ApprovalStartTime *time.Time `json:"approval_start_time"`
	ApprovalEndTime   *time.Time `json:"approval_end_time"`
	// 今日完成就标记为“1”
	//TodayFinished  string `json:"today_finished"`
}

func (approvalLog *ApprovalLog) Create() error {
	if err := config.GetDb().Model(approvalLog).Create(approvalLog).Error; err != nil {
		logger.Error("================ model ApprovalLog Create", "err", err.Error())
		return err
	}
	return nil
}

/* ##################################################################################################### */
/* ##################################################################################################### */

// 预审日志记录
//go:generate gormgen -gen=model -type=PreApprovalLog
type PreApprovalLog struct {
	mysql.BaseModel
	PreApprovalId     string `gorm:"not null;index" json:"pre_approval_id"`
	PreApprovalStatus string `gorm:"not null;" json:"pre_approval_status"`
	PreApprovalName   string `gorm:"not null;index" json:"pre_approval_name"`
	PreApprovalDesc   string `gorm:"not null;type:text" json:"pre_approval_desc"`
}

func (preApprovalLog *PreApprovalLog) Create() error {
	if err := config.GetDb().Model(preApprovalLog).Create(preApprovalLog).Error; err != nil {
		logger.Error("================ model PreApprovalLog Create", "err", err.Error())
		return err
	}
	return nil
}
