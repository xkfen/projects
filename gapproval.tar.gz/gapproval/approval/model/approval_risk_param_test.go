package model

import (
	"testing"
	"encoding/json"
	"fmt"
)

var testJSON = `{"r4":50000,"r17":5000,"r5":[{"amount":"10000","name":"额达"}],"r16":500,"r11":"100","r12":"0","r3":17500,"r18":5000,"r24":5000,"r1":"OTHER_LOAN","r21":0,"r28":"150000","r30":0.6,"r22":500,"r9":"1111","r10":"1111","r14":"5000","version":"v1.0","r20":0,"r29":12,"r6":"1000","r2":[{"name":"房产贷（俩人共有）","content":{"house_register_data":"1994-12-24","house_address":"众里","house_valuation":"500000"}}],"r31":1521098150989,"r15":[{"type":"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK","content":{"remainingPeriod":"10","loanDate":"1994-12-24","loanAmount":"500","loanAgency":"的","monthlyRepayment":"5000","loanBalance":"5000"}}],"r13":"0","r23":5000,"r19":0,"r25":140.28,"r8":"1000","r26":99.67,"r7":151000,"r27":1943.88}`

func TestApprovalCsResult_CheckApprovalIdExist(t *testing.T) {
	data := make(map[string]interface{})
	json.Unmarshal([]byte(testJSON), &data)
	fmt.Println(data["r001"])
}

func TestApprovalRiskParam_MapJsonToModel(t *testing.T) {
	data := make(map[string]interface{})
	v := ApprovalRiskParam{}
	v.MapJsonToModel(data)
}