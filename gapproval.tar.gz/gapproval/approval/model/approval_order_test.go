package model

import (
	"errors"
	"gapproval/approval/db/config"
	"gcoresys/common/util"
	"github.com/stretchr/testify/suite"
	"testing"
	"fmt"
	"gcoresys/common/logger"
)

func TestRun(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	suite.Run(t, new(testingSuite))
}

type testingSuite struct {
	suite.Suite
}

func (s *testingSuite) SetupTest() {
}

func (s *testingSuite) TearDownTest() {
	config.ClearAllData()
}

func (s *testingSuite) TestGetDefaultApprovalOrder() {
	a := GetDefaultApprovalOrder()
	err := a.IsValidApprovalOrder()
	s.NoError(err)
}

func (s *testingSuite) TestAccountToJson() {
	a := GetDefaultApprovalOrder()
	if util.StringifyJson(a) == "" {
		s.Error(errors.New("json 转化出错"))
	}
}

func (s *testingSuite) TestGetDefaultApprovalLog() {
	a := GetDefaultApprovalLog()
	if a == nil {
		s.Error(errors.New("不应该为空"))
	}

}

func (s *testingSuite) TestGetDefaultApprovalCsResult() {
	a := GetDefaultApprovalCsResult()
	if a == nil {
		s.Error(errors.New("不应该为空"))
	}

}

func (s *testingSuite) TestGetDefaultUploadApprovalFile() {
	a := GetDefaultUploadApprovalFile()
	if a == nil {
		s.Error(errors.New("不应该为空"))
	}

}

func (s *testingSuite) TestCreateApprovalQuantizationVar() {
	var jsonStr = `{"CIPB025":"无","CIPB008":"未婚","CIPB057":"0","CIPB003":"身份证","CIPB022":"0","CIPB014":"0","CIPB035":"129934","CIPB077":"0","CIPB094":"8","CIPB088":"无","CIPB029":"1680","CIPB068":"0","CIPB001":"2017-11-6","CIPB091":"1","CIPB009":"初中","CIPB092":"0","CIPB011":"住宿和餐饮业","CIPB023":"0","CIPB093":"0","CIPB078":"1","CIPB021":"0","CIPB063":"0","CIPB070":"0","CIPB004":"360722198904062760","CIPB083":"0","CIPB044":"0","CIPB033":"5306","CIPB084":"0","CIPB100":"0","CIPB080":"无","CIPB089":"2","CIPB071":"0","CIPB002":"邱水英","CIPB061":"2019-6-19","CIPB056":"0","CIPB017":"2013.09","CIPB016":"2016.04","CIPB013":"0","CIPB012":"0","CIPB058":"0","CIPB059":"无","CIPB051":"0","CIPB075":"0","CIPB076":"0","CIPB041":"正常","CIPB007":"1989-04-06","CIPB096":"0","CIPB095":"1","CIPB045":"0","CIPB026":"无","CIPB090":"6","CIPB079":"0","CIPB027":"0","CIPB032":"30000","CIPB052":"0","CIPB039":"无","CIPB018":"无准贷记卡","CIPB086":"无","CIPB049":"0","CIPB102":"0","CIPB064":"0","CIPB043":"0","CIPB065":"37","CIPB082":"无","CIPB048":"0","CIPB015":"6","CIPB036":"52000","CIPB072":"0","CIPB081":"无","CIPB087":"无","CIPB047":"0","CIPB024":"0","CIPB085":"无","CIPB005":"2036-3-23","CIPB040":"无","CIPB055":"0","CIPB050":"0","CIPB046":"0","CIPB073":"0","CIPB042":"0","CIPB067":"0","CIPB098":"5065.70","CIPB030":"1","CIPB054":"0","CIPB034":"4","CIPB006":"女","CIPB053":"0","CIPB020":"0","CIPB066":"0","CIPB037":"50657","CIPB038":"42532","CIPB097":"0","CIPB069":"0","CIPB019":"0","CIPB031":"2","CIPB010":"生产、运输设备操作人员及有关人员","CIPB062":"30000","CIPB074":"0","CIPB028":"0","CIPB099":"无","CIPB060":"0"}`

	var aqv ApprovalQuantizationVar
	s.NoError(util.ParseJson(jsonStr, &aqv))

	fmt.Println("----------")
	fmt.Println(util.StringifyJson(aqv))

}

func (s *testingSuite) TestCreateApprovalQuantizationVar2() {
	var jsonStr = `{"CIPB025":"无","CIPB008":"未婚","CIPB057":"0","CIPB003":"身份证","CIPB022":"0","CIPB014":"0","CIPB035":"129934","CIPB077":"0","CIPB094":"8","CIPB088":"无","CIPB029":"1680","CIPB068":"0","CIPB001":"2017-11-6","CIPB091":"1","CIPB009":"初中","CIPB092":"0","CIPB011":"住宿和餐饮业","CIPB023":"0","CIPB093":"0","CIPB078":"1","CIPB021":"0","CIPB063":"0","CIPB070":"0","CIPB004":"360722198904062760","CIPB083":"0","CIPB044":"0","CIPB033":"5306","CIPB084":"0","CIPB100":"0","CIPB080":"无","CIPB089":"2","CIPB071":"0","CIPB002":"邱水英","CIPB061":"2019-6-19","CIPB056":"0","CIPB017":"2013.09","CIPB016":"2016.04","CIPB013":"0","CIPB012":"0","CIPB058":"0","CIPB059":"无","CIPB051":"0","CIPB075":"0","CIPB076":"0","CIPB041":"正常","CIPB007":"1989-04-06","CIPB096":"0","CIPB095":"1","CIPB045":"0","CIPB026":"无","CIPB090":"6","CIPB079":"0","CIPB027":"0","CIPB032":"30000","CIPB052":"0","CIPB039":"无","CIPB018":"无准贷记卡","CIPB086":"无","CIPB049":"0","CIPB102":"0","CIPB064":"0","CIPB043":"0","CIPB065":"37","CIPB082":"无","CIPB048":"0","CIPB015":"6","CIPB036":"52000","CIPB072":"0","CIPB081":"无","CIPB087":"无","CIPB047":"0","CIPB024":"0","CIPB085":"无","CIPB005":"2036-3-23","CIPB040":"无","CIPB055":"0","CIPB050":"0","CIPB046":"0","CIPB073":"0","CIPB042":"0","CIPB067":"0","CIPB098":"5065.70","CIPB030":"1","CIPB054":"0","CIPB034":"4","CIPB006":"女","CIPB053":"0","CIPB020":"0","CIPB066":"0","CIPB037":"50657","CIPB038":"42532","CIPB097":"0","CIPB069":"0","CIPB019":"0","CIPB031":"2","CIPB010":"生产、运输设备操作人员及有关人员","CIPB062":"30000","CIPB074":"0","CIPB028":"0","CIPB099":"无","CIPB060":"0","CIPB0144":"无","CIPB0233":"0"}`

	var aqv ApprovalQuantizationVar
	s.NoError(util.ParseJson(jsonStr, &aqv))
	fmt.Println("----------")

	aqv.JinjianId = "123"
	fmt.Println(util.StringifyJson(aqv))
	s.NoError(config.GetDb().Model(aqv).Create(&aqv).Error)

	var aqv1 ApprovalQuantizationVar
	s.NoError(config.GetDb().Model(aqv).Where("jinjian_id = ?", aqv.JinjianId).First(&aqv1).Error)
	fmt.Println("================")
	fmt.Println(util.StringifyJson(aqv1))

}

func (s *testingSuite) TestGetAoCurrStatus() {
	var jsonStr = `{
        "account_id": 0,
        "additional_record": false,
        "agency_employee": "杨正伟",
        "agency_employee_id": "13129545656",
        "agency_name": "有道咨询服",
        "agency_status": "审核拒绝",
        "all_info": "{\"credit_files\":null,\"idcard_info\":{\"id\":485,\"status\":\"1\",\"name\":\"陈海城\",\"orderId\":\"497\",\"createdAt\":\"2017-11-16 10:58:55\",\"number\":\"441522197310253573\",\"userId\":561,\"cellphone\":null,\"facePhoto\":\"/assets/uploads/images//idCard/6TOobf2QMqQhptowr2dXU8qQ097KawICCiWDBPaXSdq7m8WkF77nrD5qRw3Wig0K.jpg\",\"updatedAt\":\"2017-11-16 10:58:55\",\"backPhoto\":\"/assets/uploads/images//idCard/ar9VVxsCvLOvFldVwl4jgyJz0Q-s5Zt90VGeuri9OEawSzXcmvBja2ge0LRgAOFB.jpg\",\"bankNo\":null},\"personal_info\":{\"createdAt\":\"2017-11-16 11:08:16\",\"userId\":561,\"detailAddress\":\"宝安区西乡街道径贝新村235号402\",\"id\":481,\"wxNo\":\"13510025538\",\"workAddress\":\"广东省 深圳市 市辖区\",\"workplace\":\"深圳市百港城盛世华尊百货有限公司\",\"job\":\"经理\",\"usage\":\"装修\",\"education\":\"高中\",\"status\":\"1\",\"houseType\":\"租房\",\"marriage\":\"已婚\",\"monthlyIncome\":\"20000\",\"updatedAt\":\"2017-11-16 11:08:16\",\"workplacePhone\":\"0755-27209813\",\"monthlyCost\":\"2500\",\"orderId\":\"497\",\"address\":\"广东省 深圳市 市辖区\",\"workDetailAddress\":\"宝安区福永街道和平社区永和路18-19号\"},\"call_record\":{\"cellphone\":\"13510025538\",\"status\":\"1\",\"orderId\":\"497\",\"updatedAt\":\"2017-11-16 11:09:47\",\"userId\":561,\"isCrawled\":true,\"isJump\":false,\"createdAt\":\"2017-11-16 11:09:47\",\"password\":\"138138\",\"id\":479,\"cellphoneQCellCore\":\"广东移动 深圳\"},\"contacts\":{\"id\":473,\"secondaryRelation\":\"同事\",\"secondaryPhoneQCellCore\":\"广东移动 深圳\",\"updatedAt\":\"2017-11-16 11:14:05\",\"orderId\":\"497\",\"primaryPhoneQCellCore\":\"广东电信 深圳\",\"createdAt\":\"2017-11-16 11:14:05\",\"primaryName\":\"林秋波\",\"status\":\"1\",\"userId\":561,\"secondaryName\":\"傅金良\",\"primaryPhone\":\"18938040538\",\"primaryRelation\":\"配偶\",\"secondaryPhone\":\"13714351333\"},\"salary_bank\":[{\"orderId\":\"497\",\"updatedAt\":\"2017-11-16 11:17:40\",\"isJump\":false,\"userId\":561,\"createdAt\":\"2017-11-16 11:17:40\",\"cellphone\":\"13510025538\",\"id\":591,\"cardNo\":\"9558884000001404259\",\"bank\":\"工商银行\",\"orgId\":\"010003\",\"account\":\"9558884000001404259\",\"isCrawled\":true,\"status\":\"1\",\"password\":\"138138aa\"},{\"account\":\"441522197310253573\",\"orgId\":\"010009\",\"status\":\"1\",\"cardNo\":\"6230580000102722159\",\"isJump\":false,\"isCrawled\":true,\"password\":\"138171aa\",\"userId\":561,\"cellphone\":\"13510025538\",\"id\":593,\"bank\":\"平安银行\",\"createdAt\":\"2017-11-16 11:34:12\",\"updatedAt\":\"2017-11-16 11:34:12\",\"orderId\":\"497\"}]}",
        "approval_add_contacts": "",
        "approval_pass_time": null,
        "approval_refuse_time": "2017-11-21T17:50:20+08:00",
        "approval_start_time": null,
        "approved_amount": 0,
        "approved_rate": 29,
        "bank_name": "Null",
        "ca_switch": "off",
        "cancel_time": null,
        "card1": "Null",
        "card2": "Null",
        "card3": "Null",
        "card4": "Null",
        "card5": "Null",
        "card_one_phone": "Null",
        "cell_phone": "Null",
        "channel_manager": "[\"李兴隆\"]",
        "commit_time": "2017-11-16T14:53:43+08:00",
        "contract_id": "Null",
        "contract_templete_id": 0,
        "created_at": "2017-11-16T11:35:10+08:00",
        "custom_service_id": "Null",
        "custom_service_name": "Null",
        "custom_service_status": "待沟通",
        "custom_service_status_des": "",
        "customer_refuse_time": null,
        "deleted_at": null,
        "desc": "",
        "extension_number": "",
        "external_reason": "综合评分不过",
        "fin_back_desc": "",
        "first_term_pay": 0,
        "first_trail_id": "xiaomengmeng",
        "first_trail_name": "肖梦梦",
        "first_trail_status": "初审拒绝",
        "first_trail_status_des": "1、评分低分\n2、方案：保单贷，认定收入：163600元，额度：20万\n3、非深户无房，受薪",
        "first_trail_status_repulse": "",
        "fund_side": "洋葱先生",
        "id": 565,
        "inter_view": "{\"contracts\":[{\"id\":5837,\"created_at\":\"2017-11-16T12:08:34+08:00\",\"updated_at\":\"2017-11-16T12:08:34+08:00\",\"deleted_at\":null,\"orderId\":\"order_1510800914837\",\"fileType\":\"contract\",\"file\":\"/assets/uploads/order_1510800914837/file_1510805313697021471.JPG\",\"username\":\"lixinglong\"},{\"id\":5843,\"created_at\":\"2017-11-16T12:09:01+08:00\",\"updated_at\":\"2017-11-16T12:09:01+08:00\",\"deleted_at\":null,\"orderId\":\"order_1510800914837\",\"fileType\":\"contract\",\"file\":\"/assets/uploads/order_1510800914837/file_1510805340650244812.JPG\",\"username\":\"lixinglong\"},{\"id\":5847,\"created_at\":\"2017-11-16T12:09:23+08:00\",\"updated_at\":\"2017-11-16T12:09:23+08:00\",\"deleted_at\":null,\"orderId\":\"order_1510800914837\",\"fileType\":\"contract\",\"file\":\"/assets/uploads/order_1510800914837/file_1510805362689476753.JPG\",\"username\":\"lixinglong\"},{\"id\":5851,\"created_at\":\"2017-11-16T12:09:55+08:00\",\"updated_at\":\"2017-11-16T12:09:55+08:00\",\"deleted_at\":null,\"orderId\":\"order_1510800914837\",\"fileType\":\"contract\",\"file\":\"/assets/uploads/order_1510800914837/file_1510805395005754096.JPG\",\"username\":\"lixinglong\"},{\"id\":5857,\"created_at\":\"2017-11-16T12:10:16+08:00\",\"updated_at\":\"2017-11-16T12:10:16+08:00\",\"deleted_at\":null,\"orderId\":\"order_1510800914837\",\"fileType\":\"contract\",\"file\":\"/assets/uploads/order_1510800914837/file_1510805416210139187.JPG\",\"username\":\"lixinglong\"},{\"id\":5861,\"created_at\":\"2017-11-16T12:10:34+08:00\",\"updated_at\":\"2017-11-16T12:10:34+08:00\",\"deleted_at\":null,\"orderId\":\"order_1510800914837\",\"fileType\":\"contract\",\"file\":\"/assets/uploads/order_1510800914837/file_1510805433713417121.JPG\",\"username\":\"lixinglong\"},{\"id\":5863,\"created_at\":\"2017-11-16T12:10:52+08:00\",\"updated_at\":\"2017-11-16T12:10:52+08:00\",\"deleted_at\":null,\"orderId\":\"order_1510800914837\",\"fileType\":\"contract\",\"file\":\"/assets/uploads/order_1510800914837/file_1510805451649302818.JPG\",\"username\":\"lixinglong\"},{\"id\":5867,\"created_at\":\"2017-11-16T12:11:10+08:00\",\"updated_at\":\"2017-11-16T12:11:10+08:00\",\"deleted_at\":null,\"orderId\":\"order_1510800914837\",\"fileType\":\"contract\",\"file\":\"/assets/uploads/order_1510800914837/file_1510805470048987217.JPG\",\"username\":\"lixinglong\"},{\"id\":5871,\"created_at\":\"2017-11-16T12:11:30+08:00\",\"updated_at\":\"2017-11-16T12:11:30+08:00\",\"deleted_at\":null,\"orderId\":\"order_1510800914837\",\"fileType\":\"contract\",\"file\":\"/assets/uploads/order_1510800914837/file_1510805489552741433.JPG\",\"username\":\"lixinglong\"},{\"id\":5875,\"created_at\":\"2017-11-16T12:11:49+08:00\",\"updated_at\":\"2017-11-16T12:11:49+08:00\",\"deleted_at\":null,\"orderId\":\"order_1510800914837\",\"fileType\":\"contract\",\"file\":\"/assets/uploads/order_1510800914837/file_1510805508992506727.JPG\",\"username\":\"lixinglong\"},{\"id\":5877,\"created_at\":\"2017-11-16T12:12:08+08:00\",\"updated_at\":\"2017-11-16T12:12:08+08:00\",\"deleted_at\":null,\"orderId\":\"order_1510800914837\",\"fileType\":\"contract\",\"file\":\"/assets/uploads/order_1510800914837/file_1510805527762799494.JPG\",\"username\":\"lixinglong\"},{\"id\":5879,\"created_at\":\"2017-11-16T12:12:25+08:00\",\"updated_at\":\"2017-11-16T12:12:25+08:00\",\"deleted_at\":null,\"orderId\":\"order_1510800914837\",\"fileType\":\"contract\",\"file\":\"/assets/uploads/order_1510800914837/file_1510805544779661187.JPG\",\"username\":\"lixinglong\"}],\"idCards\":[{\"id\":5839,\"created_at\":\"2017-11-16T12:08:42+08:00\",\"updated_at\":\"2017-11-16T12:08:42+08:00\",\"deleted_at\":null,\"orderId\":\"order_1510800914837\",\"fileType\":\"id_card_a\",\"file\":\"/assets/uploads/order_1510800914837/file_1510805321857950867.JPG\",\"username\":\"lixinglong\"},{\"id\":5841,\"created_at\":\"2017-11-16T12:08:48+08:00\",\"updated_at\":\"2017-11-16T12:08:48+08:00\",\"deleted_at\":null,\"orderId\":\"order_1510800914837\",\"fileType\":\"id_card_b\",\"file\":\"/assets/uploads/order_1510800914837/file_1510805328464098954.JPG\",\"username\":\"lixinglong\"}],\"houseDeeds\":[],\"creditReport\":[{\"id\":5907,\"created_at\":\"2017-11-16T12:15:33+08:00\",\"updated_at\":\"2017-11-16T12:15:33+08:00\",\"deleted_at\":null,\"orderId\":\"order_1510800914837\",\"fileType\":\"credit_report_zip\",\"file\":\"/assets/uploads/order_1510800914837/archive.zip\",\"username\":\"lixinglong\"}],\"comment\":\"客户陈海城，平安新一贷保单进件，批款20万。\",\"score\":\"4分\",\"remark\":\"\"}",
        "is_standard": "",
        "jinjian_id": "order_1510800914837",
        "jinjian_user_id": "13510025538",
        "jinjian_user_name": "陈海城",
        "loan_amount": 20000000,
        "loan_at": null,
        "loan_bank_name": "",
        "loan_card": "",
        "loan_term": 24,
        "loan_time": null,
        "operator_id": "Null",
        "operator_name": "Null",
        "operator_status": "Null",
        "order_info": "{\"rate\":null,\"brokerPhone\":\"13129545656\",\"bankName\":\"平安银行\",\"createdAt\":\"2017-11-16 10:55:14\",\"approvalStatus\":null,\"isSpBuLu\":false,\"loanCard\":null,\"finishBulu\":false,\"statusUpdatedAt\":\"2017-11-16 14:53:43\",\"orderId\":\"order_1510800914837\",\"backItem\":null,\"managers\":[\"李兴隆\"],\"applyResult\":1,\"customerRejectTime\":null,\"loanTime\":null,\"realAmount\":null,\"rstUserId\":null,\"loanType\":\"房供贷\",\"updatedAt\":\"2017-11-16 14:53:43\",\"refuseReason\":null,\"loanBank\":null,\"brokerId\":24,\"approvalAmount\":null,\"commitTime\":\"2017-11-16 11:35:09\",\"userPhone\":\"13510025538\",\"accountId\":null,\"isOpenSignature\":false,\"userId\":561,\"loanAmount\":0,\"repayDate\":null,\"signAt\":null,\"rejectTime\":null,\"terms\":24,\"id\":497,\"amount\":20000000,\"isBuLu\":false,\"showOrderId\":\"S_qy20171116005\",\"idNo\":\"441522197310253573\",\"userName\":\"陈海城\",\"passTime\":null,\"backInfo\":null,\"adjustRepayAmount\":null,\"creditReportPath\":null,\"brokerCompanyId\":18,\"brokerCompany\":\"有道咨询服\",\"brokerName\":\"杨正伟\",\"cancelTime\":null,\"status\":8,\"pendingTime\":null}",
        "other_every_term_pay": 0,
        "pay_card_list": "",
        "product_id": "qy_001",
        "product_name": "洋葱先生",
        "product_plan": "{\"id\":3,\"created_at\":\"2017-11-16T21:04:39+08:00\",\"updated_at\":\"2017-11-16T21:05:28+08:00\",\"deleted_at\":null,\"scheme_id\":\"qy_001\",\"name\":\"洋葱先生\",\"config_info\":\"{\\\"terms_array\\\":[12,24],\\\"annual_rate_array\\\":[15,15],\\\"amount_start\\\":5,\\\"amount_stop\\\":20,\\\"adjustment_number\\\":1,\\\"overdue\\\":1,\\\"periods_number\\\":24,\\\"service_charge\\\":3,\\\"repayment\\\":\\\"等额本息\\\",\\\"rate_day\\\":0.1,\\\"penalty_number\\\":0}\",\"config_info_version\":1,\"jump_password\":\"\",\"remarks\":\"\",\"repay_method\":\"罚-利-本\",\"signature\":false,\"contract_mould_id\":1,\"auth_book_mould_id\":0,\"fu_shu\":100,\"rong_360\":0,\"fund_side\":\"洋葱先生\",\"status\":\"is use\",\"mould_list\":[]}",
        "quantization_cache": "{\"Title\":{\"k1\":\"2017-11-13\",\"k2\":\"陈海城\",\"k3\":\"身份证\",\"k4\":\"441522197310253573\",\"k5\":\"2026-6-18\",\"k6\":\"男\",\"k7\":\"1973-10-25\",\"k8\":\"已婚\",\"k9\":\"高中\",\"k10\":\"-\",\"k11\":\"-\"},\"InfoSummary\":{\"k12\":\"0\",\"k13\":\"0\",\"k14\":\"0\",\"k15\":\"7\",\"k16\":\"2016.07\",\"k17\":\"2007.01\",\"k18\":\"无准贷记卡\",\"k19\":\"0\",\"k20\":\"0\",\"k21\":\"0\",\"k22\":\"0\",\"k23\":\"0\",\"k24\":\"0\",\"k25\":\"无\",\"k26\":\"无\",\"k27\":\"0\",\"k28\":\"0\",\"k29\":\"27077\",\"k30\":\"1\",\"k31\":\"3\",\"k32\":\"567500\",\"k33\":\"452472\",\"k34\":\"9\",\"k35\":\"267555\",\"k36\":\"55000\",\"k37\":\"94070\",\"k38\":\"106323\"},\"TradeInfo\":{\"k39\":\"无\",\"k40\":\"无\",\"k41\":\"正常\",\"k42\":\"0\",\"k43\":\"0\",\"k44\":\"0\",\"k45\":\"0\",\"k46\":\"0\",\"k47\":\"0\",\"k48\":\"0\",\"k49\":\"0\",\"k50\":\"0\",\"k51\":\"0\",\"k52\":\"0\",\"k53\":\"0\",\"k54\":\"0\",\"k55\":\"567500\",\"k56\":\"0\",\"k57\":\"0\",\"k58\":\"0\",\"k59\":\"18721\",\"k60\":\"无\",\"k61\":\"0\",\"k62\":\"2020-8-2\",\"k63\":\"0\",\"k64\":\"0\",\"k65\":\"7\",\"k66\":\"0\",\"k67\":\"0\",\"k68\":\"0\",\"k69\":\"0\",\"k70\":\"2\",\"k71\":\"0\",\"k72\":\"0\",\"k73\":\"0\",\"k74\":\"5\",\"k75\":\"0\",\"k76\":\"0\",\"k77\":\"0\",\"k78\":\"1\",\"k79\":\"0\"},\"PublicInfo\":{\"k80\":\"无\",\"k81\":\"无\",\"k82\":\"无\",\"k83\":\"0\",\"k84\":\"0\",\"k85\":\"无\",\"k86\":\"无\",\"k87\":\"无\",\"k88\":\"无\"},\"Other\":{\"k89\":\"0\",\"k90\":\"9\",\"k91\":\"5\",\"k92\":\"2\",\"k93\":\"1\",\"k94\":\"15\",\"k95\":\"9\",\"k96\":\"3\",\"k97\":\"2\",\"k98\":\"无\",\"k99\":\"0\",\"k100\":\"0\",\"k101\":\"28128.00\",\"k103\":\"0\",\"k104\":\"0\",\"k105\":\"8\"}}",
        "quantization_level": 1,
        "quantization_map": "{\"CIPB010\":\"-\",\"CIPB015\":\"7\",\"CIPB035\":\"267555\",\"CIPB036\":\"55000\",\"CIPB057\":\"0\",\"CIPB071\":\"0\",\"CIPB013\":\"0\",\"CIPB081\":\"无\",\"CIPB045\":\"0\",\"CIPB022\":\"0\",\"CIPB085\":\"无\",\"CIPB091\":\"5\",\"CIPB076\":\"0\",\"CIPB097\":\"2\",\"CIPB102\":\"0\",\"CIPB026\":\"无\",\"CIPB064\":\"0\",\"CIPB073\":\"0\",\"CIPB016\":\"2016.07\",\"CIPB005\":\"2026-6-18\",\"CIPB074\":\"5\",\"CIPB067\":\"0\",\"CIPB003\":\"身份证\",\"CIPB063\":\"0\",\"CIPB001\":\"2017-11-13\",\"CIPB012\":\"0\",\"CIPB032\":\"567500\",\"CIPB044\":\"0\",\"CIPB060\":\"0\",\"CIPB008\":\"已婚\",\"CIPB077\":\"0\",\"CIPB023\":\"0\",\"CIPB100\":\"0\",\"CIPB095\":\"9\",\"CIPB079\":\"0\",\"CIPB018\":\"无准贷记卡\",\"CIPB056\":\"0\",\"CIPB017\":\"2007.01\",\"CIPB089\":\"0\",\"CIPB084\":\"0\",\"CIPB058\":\"18721\",\"CIPB069\":\"0\",\"CIPB014\":\"0\",\"CIPB027\":\"0\",\"CIPB066\":\"0\",\"CIPB006\":\"男\",\"CIPB070\":\"2\",\"CIPB030\":\"1\",\"CIPB042\":\"0\",\"CIPB092\":\"2\",\"CIPB038\":\"106323\",\"CIPB053\":\"0\",\"CIPB078\":\"1\",\"CIPB033\":\"452472\",\"CIPB068\":\"0\",\"CIPB002\":\"陈海城\",\"CIPB039\":\"无\",\"CIPB034\":\"9\",\"CIPB020\":\"0\",\"CIPB041\":\"正常\",\"CIPB021\":\"0\",\"CIPB024\":\"0\",\"CIPB040\":\"无\",\"CIPB047\":\"0\",\"CIPB087\":\"无\",\"CIPB086\":\"无\",\"CIPB031\":\"3\",\"CIPB011\":\"-\",\"CIPB029\":\"27077\",\"CIPB007\":\"1973-10-25\",\"CIPB088\":\"无\",\"CIPB004\":\"441522197310253573\",\"CIPB061\":\"2020-8-2\",\"CIPB099\":\"无\",\"CIPB019\":\"0\",\"CIPB051\":\"0\",\"CIPB054\":\"0\",\"CIPB075\":\"0\",\"CIPB094\":\"15\",\"CIPB083\":\"0\",\"CIPB093\":\"1\",\"CIPB052\":\"0\",\"CIPB082\":\"无\",\"CIPB037\":\"94070\",\"CIPB043\":\"0\",\"CIPB098\":\"28128.00\",\"CIPB028\":\"0\",\"CIPB062\":\"567500\",\"CIPB046\":\"0\",\"CIPB048\":\"0\",\"CIPB080\":\"无\",\"CIPB055\":\"0\",\"CIPB096\":\"3\",\"CIPB025\":\"无\",\"CIPB059\":\"无\",\"CIPB072\":\"0\",\"CIPB009\":\"高中\",\"CIPB050\":\"0\",\"CIPB049\":\"0\",\"CIPB090\":\"9\",\"CIPB065\":\"7\"}",
        "quantization_point": 410,
        "re_trail_choice": "终审拒绝",
        "refuse_reason": "[{\"label\":\"D0101评分卡低分\",\"value\":\"D0101\",\"mainReason\":{\"label\":\"D1评分卡低分\",\"value\":\"D1\"}}]",
        "repulse_desc": "",
        "retrail_id": "wanglei",
        "retrail_name": "王磊",
        "retrail_status": "终审通过",
        "retrail_status_des": "1、评分低分\n2、方案：保单贷，认定收入：163600元，额度：20万\n3、非深户无房，受薪",
        "risk_param": "",
        "salary_at": null,
        "show_id": "S_qy20171116005",
        "sp_id": "",
        "suspending": "off",
        "suspense_desc": "",
        "updated_at": "2017-11-21T17:50:20+08:00",
        "user_id_num": "441522197310253573"
    }`

	var ao ApprovalOrder
	s.NoError(util.ParseJson(jsonStr, &ao))

	fmt.Println(util.StringifyJson(ao))


	tmp := &ao

	fmt.Println(tmp.GetAoCurrStatus())

}

