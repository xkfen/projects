package model

import (
	"gcoresys/common/mysql"
	"errors"
)

/*
	这里主要作用时间是缓存在风控查询的身份证匹配结果
	暂时不单独保持在数据库中
	以后根据业务需求可以再加上
 */

// 身份证与姓名校验结果
//go:generate gormgen -gen=model -type=IdCardsCheckRecord
type IdCardsCheckRecord struct {
	mysql.BaseModel
	// 进件id
	JinjianId string `json:"jinjian_id"`
	// 身份证
	IdCard string `json:"id_card"`
	// 姓名
	Name string `json:"name"`
	// 身份证匹配结果 matched匹配 unmatched不匹配 unsure不确认
	Result string `json:"result"`
	// 身份证归属地
	IdCardPlace string `json:"id_card_place"`
}

// result 可以传任意值,表明验证结构体时,带上Result
func (icc *IdCardsCheckRecord) IsValidIdCardsCheckRecord(result ... string) (err error) {
	if icc.JinjianId == "" {
		return errors.New("进件id不能为空")
	}
	if icc.Name == "" {
		return errors.New("姓名不能为空")
	}
	if icc.IdCard == "" {
		return errors.New("身份证号码不能为空")
	}
	if len(result) > 0 && icc.Result == "" {
		return errors.New("匹配结果不能为空")
	}
	return nil
}
