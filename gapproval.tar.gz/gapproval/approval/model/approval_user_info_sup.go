package model

import (
	"gcoresys/common/mysql"
	"errors"
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
)

//go:generate gormgen -gen=model -type=ApprovalUserInfoSup
type ApprovalUserInfoSup struct {
	mysql.BaseModel
	JinjianId         string `gorm:"not null;unique_index" json:"jinjian_id"`
	FamilyInfo        string `json:"family_info"`
	EducationInfo     string `json:"education_info"`
	HouseholdCity     string `json:"household_city"`
	CompanySize       string `json:"company_size"`
	CompanyType       string `json:"company_type"`
	CompanyLine       string `json:"company_line"`
	CompanyDepartment string `json:"company_department"`
	FirstWorkTime     string `json:"first_work_time"`

	// 其他平台借贷金额
	OtherLoanAmount float64 `json:"other_loan_amount"`
	// 其他平台借贷次数
	OtherLoanNum float64 `json:"other_loan_num"`
}

func (a *ApprovalUserInfoSup) IsValidApprovalUserInfoSup() (err error) {
	switch {
	case a.JinjianId == "":
		err = errors.New("进件id不能为空")
	//case a.FamilyInfo == "":
	//	err = errors.New("子女情况不能为空")
	//case a.EducationInfo == "":
	//	err = errors.New("学历不能为空")
	//case a.HouseholdCity == "":
	//	err = errors.New("户籍城市不能为空")
	case a.CompanySize == "":
		err = errors.New("公司规模不能为空")
	case a.CompanyType == "":
		err = errors.New("公司性质不能为空")
	//case a.CompanyLine == "":
	//	err = errors.New("公司行业不能为空")
	case a.CompanyDepartment == "":
		err = errors.New("所在部门不能为空")
	case a.FirstWorkTime == "":
		err = errors.New("第一次工作时间不能为空")
	}
	return
}

func GetApprovalUserInfoSupByJinjianId(jinjianId string) (approvalUserInfoSup ApprovalUserInfoSup, err error) {
	if err = config.GetDb().Model(&approvalUserInfoSup).Where("jinjian_id = ?", jinjianId).First(&approvalUserInfoSup).Error; err != nil {
		logger.Error("============= model ApprovalUserInfoSup GetApprovalUserInfoSupByJinjianId", "err", err.Error())
		return
	}
	return
}

func (approvalUserInfoSup *ApprovalUserInfoSup) Create() error {
	if err := config.GetDb().Model(approvalUserInfoSup).Create(approvalUserInfoSup).Error; err != nil {
		logger.Error("================ model ApprovalUserInfoSup Create", "err", err.Error())
		return err
	}
	return nil
}

func (approvalUserInfoSup *ApprovalUserInfoSup) Update(update ...interface{}) error {
	if len(update) == 0 {
		if err := config.GetDb().Model(approvalUserInfoSup).Where("id = ?", approvalUserInfoSup.ID).Updates(approvalUserInfoSup).Error; err != nil {
			logger.Error("=================== model ApprovalUserInfoSup Update Updates", "err", err.Error())
			return err
		}
	} else {
		// 类型判断
		switch u := update[0]; u.(type) {
		case map[string]interface{}:
			if err := config.GetDb().Model(approvalUserInfoSup).Where("id = ?", approvalUserInfoSup.ID).Update(u).Error; err != nil {
				logger.Error("=================== model ApprovalUserInfoSup Update Map[string]interface", "err", err.Error())
				return err
			}
		case uint:
			if err := config.GetDb().Model(approvalUserInfoSup).Where("id = ?", u).Update(approvalUserInfoSup).Error; err != nil {
				logger.Error("=================== model ApprovalUserInfoSup Update Map[string]interface", "err", err.Error())
				return err
			}
		default:
			return errors.New("更新类型错误，请传map或者不传任何参数")
		}
	}

	return nil
}

func (approvalUserInfoSup *ApprovalUserInfoSup) Save() error {
	if err := config.GetDb().Model(approvalUserInfoSup).Where("id = ?", approvalUserInfoSup.ID).Save(approvalUserInfoSup).Error; err != nil {
		logger.Error("=================== model ApprovalUserInfoSup Save", "err", err.Error())
		return err
	}
	return nil
}