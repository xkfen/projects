package model

import (
	"errors"
	"gapproval/approval/db/config"
	"gcoresys/common/mysql"
)

//文件类型
const (
	FT_LIANGHUABIANLIANG = "量化变量"
	FT_MIANQINACAILIAO   = "面签材料"
	FT_DIANHE            = " 电核记录"
	FT_ZHENGXINBAOGAO    = "征信报告"
	FT_FANGCHAN          = "房产信息"
)

type ApprovalUploadFile struct {
	mysql.BaseModel
	//审批id
	ApprovalId uint `gorm:"not null;index" json:"approval_id"`
	//进件id
	JinjianId string `gorm:"not null;index" json:"jinjian_id"`
	//文件名
	FileName string `gorm:"not null;" json:"file_name"`
	//材料类型
	FileType string `gorm:"not null;index" json:"file_type"`
	//材料url
	FileUrl string `gorm:"not null;" json:"file_url"`
}

func (a *ApprovalUploadFile) IsValidApprovalFile() (err error) {

	switch {
	case a.JinjianId == "":
		err = errors.New("进件id不能为空")
		return
	case a.FileName == "":
		err = errors.New("文件名不能为空")
		return
	case a.FileType == "":
		err = errors.New("文件类型不能为空")
		return
	case a.FileUrl == "":
		err = errors.New("文件url不能为空")
		return
	}
	switch a.FileType {
	case FT_LIANGHUABIANLIANG:
		if !CheckFileTypeExist(a.JinjianId, FT_LIANGHUABIANLIANG) {
			err = errors.New(FT_LIANGHUABIANLIANG + "已存在")
			return
		}
	case FT_MIANQINACAILIAO:
		if !CheckFileTypeExist(a.JinjianId, FT_MIANQINACAILIAO) {
			err = errors.New(FT_MIANQINACAILIAO + "已存在")
			return
		}
	case FT_ZHENGXINBAOGAO:
		if !CheckFileTypeExist(a.JinjianId, FT_ZHENGXINBAOGAO) {
			err = errors.New(FT_ZHENGXINBAOGAO + "已存在")
			return
		}
	case FT_DIANHE:
		if !CheckFileTypeExist(a.JinjianId, FT_DIANHE) {
			err = errors.New(FT_DIANHE + "已存在")
			return
		}
	case FT_FANGCHAN:
		if !CheckFileTypeExist(a.JinjianId, FT_FANGCHAN) {
			err = errors.New(FT_FANGCHAN + "已存在")
			return
		}
	}
	return
}

func CheckFileTypeExist(jinjianId string, fileType string) bool {
	results := []*ApprovalUploadFile{}
	config.GetDb().Where("jinjian_id = ? AND file_type =?", jinjianId, fileType).Find(&results)
	if len(results) >= 1 {
		return false
	} else {
		return true
	}
}

func CheckCsUpload(jinjianId string) (err error) {
	//if CheckFileTypeExist(jinjianId, FT_LIANGHUABIANLIANG) {
	//	err = errors.New("缺少量化变量材料，请上传")
	//	return
	//}
	//if CheckFileTypeExist(jinjianId, FT_MIANQINACAILIAO) {
	//	err = errors.New("缺少面签材料，请上传")
	//	return
	//}
	//if CheckFileTypeExist(jinjianId, FT_ZHENGXINBAOGAO) {
	//	err = errors.New("缺少征信报告材料，请上传")
	//	return
	//}
	if CheckFileTypeExist(jinjianId, FT_DIANHE) {
		err = errors.New("缺少电核材料，请上传")
		return
	}
	return
}
