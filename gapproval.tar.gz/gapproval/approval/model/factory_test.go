package model

/**
 @FileDescription: 
 @author: WangXi
 @create: 11:10 2017/12/25
*/

import (
	"testing"
	"gcoresys/common/util"
	"github.com/stretchr/testify/assert"
)

func TestGetDefaultApprovalCallRecord(t *testing.T) {
	assert.Equal(t, true, len(util.StringifyJson(GetDefaultApprovalCallRecord())) > 0 )
}

func TestGetDefaultApprovalChannelManager(t *testing.T) {
	assert.Equal(t, "测试渠道经理", GetDefaultApprovalChannelManager().ChannelManager)
}

func TestGetDefaultApprovalLog(t *testing.T) {
	assert.Equal(t, true, len(util.StringifyJson(GetDefaultApprovalLog())) > 0 )
}

func TestGetDefaultApprovalFile(t *testing.T) {
	assert.Equal(t, true, len(util.StringifyJson(GetDefaultApprovalFile())) > 0 )
}

func TestGetDefaultApprovalOrder(t *testing.T) {
	assert.Equal(t, true, len(util.StringifyJson(GetDefaultApprovalOrder())) > 0 )
}


