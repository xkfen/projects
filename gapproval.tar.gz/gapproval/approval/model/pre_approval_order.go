package model

/**
 @FileDescription: 预审批
 @author: WangXi
 @create: 13:41 2018/1/2
*/

import (
	"gcoresys/common/mysql"
	"time"
	"errors"
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
	//"gpreview/model"
	"reflect"
)

const (
	WAITPREAPPROVAL     = "待预审"
	PREAPPROVALING      = "预审中"
	PREAPPROVALPASS     = "预审通过"
	PREAPPROVALREPULSE  = "预审打回"
	PREAPPROVALREFUSE   = "预审拒绝"
	PREAPPROVALEXCHANGE = "预审流转"

	PREAPPROVALCANCEL = "预审撤销" // 2018-01-23 12:06:02  添加预审撤销 （不受15天检测, 打回、预审中 都可以撤销）
)

const (
	ZZ_PREAPPROVAL = "自主"
	QD_PREAPPROVAL = "渠道"

	FS_PREAPPROVAL = "1" // 判断是否是快速预审
)

// 进件筛选
const (
	Entered  = "已进件"
	NotEnter = "未进件"
)

// nqiyuan中user表
type NqiyuanUserInfo struct {
	// 中介公司，不空则说明该用户为客户经理
	BrokerCompanies string `json:"broker_companies"`
	// 中介公司的id，不为空则说明该用户为中介用户
	BrokerCompanyId uint `json:"broker_company_id"`
	// 用户的名称
	ShowName string `json:"show_name"`
	// 手机号
	Cellphone string `json:"cellphone"`
	// 用户的登录名
	Username string `json:"username"`
	// 是否是启元的客户经理
	IsQy bool `json:"is_qy"`
}

type PreApprovalOrder struct {
	mysql.BaseModel
	PreShowId string `json:"pre_show_id"`
	// 预审批申请id
	PreApprovalID string `gorm:"unique_index" json:"pre_approval_id"`
	// 预审批申请方式(自主,渠道)
	PreApprovalType string `json:"pre_approval_type"`
	// 是否是快速预审(1,随意)
	IsFast string `json:"is_fast"`
	// 用户姓名
	UserName string `json:"user_name"`
	// 用户身份证号
	UserIdNum string `gorm:"index" json:"user_id_num"`
	// 学历
	Education string `json:"education"`
	// 业务员Id
	AgencyEmployeeId string `json:"agency_employee_id"`
	// 渠道名
	AgencyName string `json:"agency_name"`
	// 业务员
	AgencyEmployee string `json:"agency_employee"`
	// 预审材料
	PreApprovalFile string `gorm:"type:text" json:"pre_approval_file"`
	// 预审批提交时间
	CommitTime *time.Time `json:"commit_time"`
	// 预审批更新时间
	UpdateTime *time.Time `json:"update_time"`
	// 进件时间
	JinjianTime *time.Time `json:"jinjian_time"`
	// 预审通过时间
	PassTime *time.Time `json:"pass_time"`
	// 预审打回时间
	RepulseTime *time.Time `json:"repulse_time"`
	// 预审拒绝时间
	RefuseTime *time.Time `json:"refuse_time"`
	// 开始预审时间
	StartTime *time.Time `json:"start_time"`
	// 撤销时间  2018-01-23 13:38:46
	CancelTime *time.Time `json:"cancel_time"`
	// 预审批人id
	PreTrailId string `gorm:"not null;default:'Null'" json:"pre_trail_id"`
	// 预审批人名
	PreTrailName string `gorm:"not null;index;default:'Null'" json:"pre_trail_name"`
	// 量化评分
	QuantizationPoint int `gorm:"not null" json:"quantization_point"`
	// 量化变量map
	QuantizationMap string `gorm:"not null;type:text" json:"quantization_map"`
	// 量化等级
	QuantizationLevel int `gorm:"not null;" json:"quantization_level"`
	// 前端存储量化数据
	QuantizationCache string `gorm:"not null;type:text" json:"quantization_cache"`
	//  预审状态
	PreApprovalStatus string `json:"pre_approval_status"`
	// 推荐方案号
	IntroductionPlanNum string `gorm:"type:text" json:"introduction_plan_num"`
	// 推荐资金方
	IntroductionFundSide string `json:"introduction_fund_side"`
	// 产品方案
	JinjianPlan string `gorm:"type:text" json:"jinjian_plan"`
	// 备注
	OpDesc string `gorm:"type:text" json:"op_desc"`
	// 预审批申请次数
	PreApprovalCount int `json:"pre_approval_count"`
	// 手机号
	PhoneNumber string `json:"phone_number"`
	// 进件id
	JinjianId string `json:"jinjian_id"`
	//   虚拟列  虚拟字段
	VirtualColumn string `json:"virtual_column"`
	// v3.4.1 预审批提交的
	// 业务员电话
	EmployeePhoneNumber string `json:"employee_phone_number"`
	// 客户经理
	CustomerManagers string `json:"customer_managers"`
	// 客户经理编号
	CustomerManagerNums string `json:"customer_manager_nums"`
	// 渠道公司法人
	LegalPerson string `json:"legal_person"`

	// 预审新增 ---- 2018-4-10
	// 拒绝原因
	RefuseReason string `gorm:"type:text" json:"refuse_reason"`
	// 拒绝外部原因
	ExternalReason string `json:"external_reason"`
}

// 获取预审批申请次数
func (pao *PreApprovalOrder) GetPreApprovalCountByUserIdNum() (count int) {
	if err := config.GetDb().Model(&PreApprovalOrder{}).Where("user_id_num = ?", pao.UserIdNum).
		Count(&count).Error; err != nil {
		logger.Error("获取预审申请次数出错", "err", err.Error())
	}
	return
}

//
func (pao *PreApprovalOrder) Update(update ...interface{}) error {
	if len(update) == 0 {
		if err := config.GetDb().Model(pao).Where("id = ?", pao.ID).Updates(pao).Error; err != nil {
			logger.Error("=================== model PreApprovalOrder Update Updates", "err", err.Error())
			return err
		}
	} else {
		// 类型判断
		switch u := update[0]; u.(type) {
		case map[string]interface{}:
			if err := config.GetDb().Model(pao).Where("id = ?", pao.ID).Update(u).Error; err != nil {
				logger.Error("=================== model PreApprovalOrder Update Map[string]interface", "err", err.Error())
				return err
			}
		case interface{}:
			if err := config.GetDb().Model(pao).Where("id = ?", pao.ID).Update(u).Error; err != nil {
				logger.Error("=================== model PreApprovalOrder Update interface{}", "err", err.Error())
				return err
			}
		default:
			logger.Error("更新 ApprovalOrder 时类型错误", "data", reflect.TypeOf(u))
			return errors.New("更新 ApprovalOrder 时类型错误，请检查")
		}
	}

	return nil
}

// 通过预审id查询预审详情
func GetPreApprovalOrderByPreApprovalId(id string) (result PreApprovalOrder, err error) {
	if err := config.GetDb().Model(&PreApprovalOrder{}).Where("pre_approval_id = ?", id).
		First(&result).Error; err != nil {
		logger.Error("GetPreApprovalOrderByPreApprovalId 出错", "err:", err.Error())
	}
	return
}

// 验证预审批创建
func (pao *PreApprovalOrder) IsVaildPreApprovalOrder() error {
	switch {
	case pao.PreApprovalID == "":
		return errors.New("预审批id不能为空")
	case pao.PreApprovalType == "":
		return errors.New("预审批type不能为空")
	case pao.UserIdNum == "":
		return errors.New("用户身份证号不能为空")
	case pao.UserName == "":
		return errors.New("用户姓名不能为空")
	case pao.AgencyName == "":
		return errors.New("中介机构名不能为空")
	case pao.AgencyEmployeeId == "":
		return errors.New("中介id不能为空")
	case pao.AgencyEmployee == "":
		return errors.New("中介姓名不能为空")
	case pao.PreApprovalFile == "":
		return errors.New("预审批资料不能为空")
	case pao.IntroductionPlanNum == "{}":
		return errors.New("预审批进件方案不能为空")
	case pao.IntroductionPlanNum == "":
		return errors.New("预审批进件方案不能为空")
	case pao.JinjianPlan == "":
		return errors.New("产品方案不能为空")
	}
	return nil
}

// 验证更新打回
func (pao *PreApprovalOrder) IsUpdatePreApprovalFile() error {
	switch {
	case pao.PreApprovalStatus != PREAPPROVALREPULSE:
		return errors.New("预审状态应该为" + PREAPPROVALREPULSE)
	}
	return nil
}

// 验证预审抢单
func (pao *PreApprovalOrder) IsVaildGrab() error {
	switch {
	case pao.PreTrailId != "Null":
		return errors.New("PreTrailId应该为空")
	case pao.PreTrailName != "Null":
		return errors.New("PreTrailName应该为空")
	case pao.PreApprovalStatus != WAITPREAPPROVAL:
		return errors.New("预审状态应该为" + WAITPREAPPROVAL)
	}
	return nil
}

// 判断是否合法操作预审单
func (pao *PreApprovalOrder) IsValidPreTrailOperation() error {
	switch {
	case pao.PreTrailId == "Null":
		return errors.New("预审操作时预审人id不能为空")
	case pao.PreTrailName == "Null":
		return errors.New("预审操作时预审人name不能为空")
	case pao.PreApprovalStatus == WAITPREAPPROVAL:
		return errors.New("预审操作时预审状态不能为" + WAITPREAPPROVAL)
	case pao.PreApprovalStatus == PREAPPROVALPASS:
		return errors.New("预审操作时预审状态不能为" + PREAPPROVALPASS)
	case pao.PreApprovalStatus == PREAPPROVALREFUSE:
		return errors.New("预审操作时预审状态不能为" + PREAPPROVALREFUSE)
	case pao.PreApprovalStatus == PREAPPROVALCANCEL:
		return errors.New("预审操作时预审状态不能为" + PREAPPROVALCANCEL)
	}
	return nil
}

func PreApprovalStatusList(typeKey string, status string) (statusList []string) {
	switch typeKey {
	case "all":
		statusList = []string{WAITPREAPPROVAL}
		return statusList
	case "history":
		switch status {
		case PREAPPROVALPASS: // 通过
			statusList = []string{PREAPPROVALPASS}
			return statusList
		case PREAPPROVALREFUSE: // 拒绝
			statusList = []string{PREAPPROVALREFUSE}
			return statusList
		case PREAPPROVALCANCEL: // 撤销
			statusList = []string{PREAPPROVALCANCEL}
			return statusList
		default:
			statusList = []string{PREAPPROVALPASS, PREAPPROVALREFUSE, PREAPPROVALCANCEL}
			return statusList
		}
	case "me":
		switch status {
		case PREAPPROVALING: // 预审中
			statusList = []string{PREAPPROVALING}
			return statusList
		case PREAPPROVALREPULSE: // 打回
			statusList = []string{PREAPPROVALREPULSE}
			return statusList
		default:
			statusList = []string{PREAPPROVALING, PREAPPROVALREPULSE}
			return statusList
		}
	case "query":
		switch status {
		case PREAPPROVALPASS: // 通过
			statusList = []string{PREAPPROVALPASS}
			return statusList
		case PREAPPROVALREFUSE: // 拒绝
			statusList = []string{PREAPPROVALREFUSE}
			return statusList
		case PREAPPROVALING: // 预审中
			statusList = []string{PREAPPROVALPASS}
			return statusList
		case PREAPPROVALREPULSE: // 打回
			statusList = []string{PREAPPROVALREPULSE}
			return statusList
		case WAITPREAPPROVAL: // 打回
			statusList = []string{WAITPREAPPROVAL}
			return statusList
		case PREAPPROVALCANCEL: // 撤销
			statusList = []string{PREAPPROVALCANCEL}
			return statusList
		default:
			statusList = []string{WAITPREAPPROVAL, PREAPPROVALING, PREAPPROVALPASS, PREAPPROVALREPULSE, PREAPPROVALREFUSE, PREAPPROVALCANCEL}
			return statusList
		}
	}
	return
}
