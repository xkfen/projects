package model

import (
	"gcoresys/common/mysql"
	"errors"
	"gcoresys/common/logger"
	"gapproval/approval/db/config"
)

// 审批文件材料
type ApprovalFile struct {
	mysql.BaseModel
	// 进件id
	JinjianId string `gorm:"not null;index" json:"jinjian_id"`
	// 文件名称
	FileName string `json:"file_name"`
	// 文件类型
	FileType string `json:"file_type"`
	// 文件地址
	FileUrl string `json:"file_url"`
	// 备注
	Desc string `gorm:"type:text" json:"desc"`
	// 预审批订单编号
	PreApprovalId string `gorm:"index" json:"pre_approval_id"`
}

func (a *ApprovalFile) IsValidApprovalFile() (err error) {

	switch {
	case a.JinjianId == "":
		err = errors.New("进件id不能为空")
		return
	case a.FileName == "":
		err = errors.New("文件名不能为空")
		return
	case a.FileType == "":
		err = errors.New("文件类型不能为空")
		return
	case a.FileUrl == "":
		err = errors.New("文件url不能为空")
		return
	}
	return
}

func (a *ApprovalFile) IsValidPreApprovalFile() (err error) {

	switch {
	case a.PreApprovalId == "":
		err = errors.New("预审批id不能为空")
		return
	case a.FileName == "":
		err = errors.New("文件名不能为空")
		return
	case a.FileType == "":
		err = errors.New("文件类型不能为空")
		return
	case a.FileUrl == "":
		err = errors.New("文件url不能为空")
		return
	}
	return
}

func (approvalFile *ApprovalFile) Create() error {
	logger.Debug("创建文件记录", "FileType", approvalFile.FileType)
	if err := config.GetDb().Model(approvalFile).Create(approvalFile).Error; err != nil {
		logger.Error("================ model ApprovalFile Create", "err", err.Error())
		return err
	}
	return nil
}

func (approvalFile *ApprovalFile) Delete() error {

	if approvalFile.ID <= 0 {
		return errors.New("删除审批文件必须要id")
	}

	if err := config.GetDb().Model(&ApprovalFile{}).Where("id = ?", approvalFile.ID).Delete(&ApprovalFile{}).Error; err != nil {
		logger.Error("================ model ApprovalFile Delete", "err", err.Error())
		return err
	}
	return nil
}

func (approvalFile *ApprovalFile) Update() error {

	if approvalFile.ID <= 0 {
		return errors.New("更新审批文件必须要id")
	}

	if err := config.GetDb().Model(&ApprovalFile{}).Where("id = ?", approvalFile.ID).Update(&approvalFile).Error; err != nil {
		logger.Error("================ model ApprovalFile Update", "err", err.Error())
		return err
	}
	return nil
}

func (approvalFile *ApprovalFile) First(key string, condition interface{}) error {
	if err := config.GetDb().Model(&ApprovalFile{}).Where(key+" = ?", condition).First(&approvalFile).Error; err != nil {
		logger.Error("================ model ApprovalFile First", "err", err.Error())
		return err
	}
	return nil
}

func GetApprovalFileList(jinjianId string) (list []*ApprovalFile) {
	if err := config.GetDb().Model(&ApprovalFile{}).Where("jinjian_id = ?", jinjianId).Find(&list).Error; err != nil {
		logger.Error("================ model ApprovalFile GetApprovalFileList", "err", err.Error())
		return
	}
	return
}

// 更新(删除-创建)
func (approvalFile *ApprovalFile) UpdateNew() error {

	if approvalFile.ID <= 0 {
		return errors.New("更新审批文件必须要id")
	}

	if err := config.GetDb().Model(approvalFile).Where("id = ?", approvalFile.ID).Delete(&ApprovalFile{}).Error; err != nil {
		logger.Error("================ model ApprovalFile UpdateNew", "delete-err", err.Error())
		return err
	}

	if err := config.GetDb().Model(approvalFile).Create(&ApprovalFile{JinjianId: approvalFile.JinjianId, PreApprovalId: approvalFile.PreApprovalId,
		FileUrl: approvalFile.FileUrl, FileType: approvalFile.FileType, FileName: approvalFile.FileName, Desc: approvalFile.Desc}).Error; err != nil {
		logger.Error("================ model ApprovalFile Create", "err", err.Error())
		return err
	}
	return nil
}
