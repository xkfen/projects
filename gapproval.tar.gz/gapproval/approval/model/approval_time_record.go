package model

import (
	"gcoresys/common/mysql"
	"time"
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
)

const (
	TP_JINJIAN    = "进件"
	TP_USERINPUT  = "用户补录"
	TP_GRAB_IV    = "面签单池"
	TP_INTERVIEW  = "面签"
	TP_GRAB_CS    = "初审单池"
	TP_CS         = "初审"
	TP_CS_BACK_IV = "初审退回面签"
	TP_GRAB_ZS    = "终审单池"
	TP_ZS         = "终审"
	TP_ZS_BACK_IV = "终审退回面签"
	TP_UPLOADC    = "终审拒绝上传合同"
	TP_GRAB_KF    = "客服单池"
	TP_KF         = "客服"
	TP_CW         = "财务"
)

//go:generate gormgen -gen=model -type=ApprovalTimeRecord
type ApprovalTimeRecord struct {
	mysql.BaseModel
	JinjianId string `gorm:"index;" json:"jinjian_id"`
	// 时间记录类型
	TimeRecordType string `json:"time_record_type"` // jj mq cs zs cw
	// 时间点
	TimePoint *time.Time `json:"time_point"`
}

func (approvalTimeRecord *ApprovalTimeRecord) Create() error {
	if err := config.GetDb().Model(approvalTimeRecord).Create(approvalTimeRecord).Error; err != nil {
		logger.Error("================ model ApprovalTimeRecord Create", "err", err.Error())
		return err
	}
	return nil
}
