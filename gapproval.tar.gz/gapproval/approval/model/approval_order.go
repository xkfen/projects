package model

import (
	"errors"
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
	"gcoresys/common/mysql"
	"time"
)

// 资金方
const (
	XDZFundSide       = "徐定枝"
	MrOnionFundSide   = "洋葱先生"
	CLFundSide        = "长乐"
	YUECAIFundSide    = "粤财"
	HAIJINSHEFundSide = "海金社"
)

/*
	August New Feature cancel approval order
*/
const (
	// 客户撤销
	ApprovalStatusCustomCancel = "已撤销"

	// 终审阶段、 客服阶段    财务打回
	ApprovalStatusFinanceBack = "财务退回"

	ApprovalSuspend = "挂起"
)

const (
	ApprovalStatusWaitInterView     = "待面签"
	ApprovalStatusInterViewing      = "面签中"
	ApprovalStatusInterViewExchange = "面签流转"
	ApprovalStatusInterViewRepulse  = "面签打回"
	ApprovalStatusInterViewCancel   = "面签撤销"
	ApprovalStatusInterViewPass     = "面签通过"
)

const ApprovalStatusFirstTrailBackIv = "初审退回面签" // 退回给面签
const ApprovalStatusReTrailBackIv = "终审退回面签"

//初审所有状态
const (
	ApprovalStatusWaitAgencyConfirm  = "待渠道放款"
	ApprovalStatusWaitUserInput      = "待补录数据"
	ApprovalStatusWaitFirstTrail     = "待初审"
	ApprovalStatusFirstTrailRepulse  = "初审打回"
	ApprovalStatusFirstTrailRefuse   = "初审拒绝"
	ApprovalStatusFirstTrailExchange = "初审流转"
	ApprovalStatusFirstTrailPass     = "初审通过"
	ApprovalStatusReTrailBack        = "终审退回"
)

//终审所有状态
const (
	ApprovalStatusWaitReTrail       = "待终审"
	ApprovalStatusReTrailPass       = "终审通过"
	ApprovalStatusReTrailRefuse     = "终审拒绝"
	ApprovalStatusReTrailFinish     = "待上传合同"
	ApprovalStatusReTrailExchange   = "终审流转"
	ApprovalStatusCustomServiceBack = "客服退回"
)

//客服所有状态
const (
	ApprovalStatusWaitCustomConfirm     = "待沟通"
	ApprovalStatusCustomPass            = "客户接受"
	ApprovalStatusCustomRefuse          = "客户拒绝"
	ApprovalStatusCustomServiceExchange = "客服流转"
	ApprovalStatusOperatorSuccess       = "放款成功"
	ApprovalStatusOperatorFail          = "放款失败"
)

//运营所有状态
const (
	ApprovalStatusWaitOperatorConfirm = "待申请放款"
	ApprovalStatusOperatorConfirm     = "已申请放款"
)

//中介端需要的状态
const (
	AgencyStatusTJ       = "已提交"
	AgencyStatusSHZ      = "审核中"
	AgencyStatusPass     = "审核通过"
	AgencyStatusRefuse   = "审核拒绝"
	AgencyStatusKHRefuse = "客户拒绝"
	AgencyStatusYFK      = "已放款"
	AgencyStatusRepulse  = "打回"
)

// 审批挂起
const Suspend = "on"

type ApprovalOrder struct {
	mysql.BaseModel
	//审批id
	SpId string `gorm:"not null;" json:"sp_id"`
	//前端显示进件id
	ShowId string `gorm:"not null;" json:"show_id"`
	//进件id
	JinjianId string `gorm:"not null;unique_index" json:"jinjian_id"`
	//进件用户id
	JinjianUserId string `gorm:"not null;index" json:"jinjian_user_id"`
	//进件用户姓名
	JinjianUserName string `gorm:"not null" json:"jinjian_user_name"`
	// 手机号
	Cellphone string `gorm:"not null;default:'Null'" json:"cell_phone"`
	// 身份证
	UserIdNum string `gorm:"not null;default:'Null'" json:"user_id_num"`
	//中介机构名
	AgencyName string `gorm:"not null" json:"agency_name"`
	//业务员Id
	AgencyEmployeeId string `gorm:"not null" json:"agency_employee_id"`
	//业务员
	AgencyEmployee string `gorm:"not null" json:"agency_employee"`
	//贷款金额
	LoanAmount uint64 `gorm:"not null" json:"loan_amount"`
	// 贷款期限（月，不含调节期）
	LoanTerm int `gorm:"not null" json:"loan_term"`
	//初审Id
	FirstTrailId string `gorm:"not null;index;default:'Null'" json:"first_trail_id"`
	//初审人姓名
	FirstTrailName string `gorm:"not null;index;default:'Null'" json:"first_trail_name"`
	//初审状态
	FirstTrailStatus string `gorm:"not null;index;default:'待渠道放款'" json:"first_trail_status"`
	//初审状态 -- 打回
	FirstTrailStatusRepulse string `gorm:"not null;" json:"first_trail_status_repulse"`
	//初审状态说明
	FirstTrailStatusDes string `gorm:"not null;type:text" json:"first_trail_status_des"`
	//终审Id
	ReTrailId string `gorm:"not null;index;default:'Null'" json:"retrail_id"`
	//终审人姓名
	ReTrailName string `gorm:"not null;index;default:'Null'" json:"retrail_name"`
	//核准金额
	ApprovedAmount uint64 `gorm:"not null" json:"approved_amount"`
	//核准利率
	ApprovedRate float64 `gorm:"not null" json:"approved_rate"`
	//首次还款日期
	SalaryAt *time.Time `json:"salary_at"`
	// 放款日期
	LoanAt *time.Time `json:"loan_at"`
	//合同Id
	ContractId string `gorm:"not null;default:'Null'" json:"contract_id"`
	//量化评分
	QuantizationPoint int `gorm:"not null" json:"quantization_point"`
	//终审状态
	ReTrailStatus string `gorm:"not null;index;default:'Null'" json:"retrail_status"`
	//终审状态说明
	ReTrailStatusDes string `gorm:"not null;type:text" json:"retrail_status_des"`
	BankName         string `gorm:"not null;default:'Null'" json:"bank_name"`
	Card1            string `gorm:"not null;default:'Null'" json:"card1"`
	CardOnePhone     string `gorm:"not null;default:'Null'" json:"card_one_phone"`
	Card1Json        string `json:"card1_json"`
	Card2            string `gorm:"not null;index;default:'Null'" json:"card2"`
	Card3            string `gorm:"not null;index;default:'Null'" json:"card3"`
	Card4            string `gorm:"not null;index;default:'Null'" json:"card4"`
	Card5            string `gorm:"not null;index;default:'Null'" json:"card5"`
	//客服id
	CustomServiceId string `gorm:"not null;index;default:'Null'" json:"custom_service_id"`
	//客服姓名
	CustomServiceName string `gorm:"not null;index;default:'Null'" json:"custom_service_name"`
	//客服状态
	CustomServiceStatus string `gorm:"not null;index;default:'Null'" json:"custom_service_status"`
	//客服退回说明
	CustomServiceStatusDes string `gorm:"not null;type:text" json:"custom_service_status_des"`
	//运营id
	OperatorId string `gorm:"not null;index;default:'Null'" json:"operator_id"`
	//运营姓名
	OperatorName string `gorm:"not null;index;default:'Null'" json:"operator_name"`
	//运营状态
	OperatorStatus string `gorm:"not null;index;default:'Null'" json:"operator_status"`

	// 电子渠道需要的字段
	// 核心系统帐户id
	AccountID uint `gorm:"not null" json:"account_id"`
	// 审批开启补录  false 不开启
	AdditionalRecord bool `gorm:"not null;default:false" json:"additional_record"`
	// call 审批开启补录  false 不开启
	CallAdditionalRecord bool `gorm:"not null;default:false" json:"call_additional_record"`

	// 打回说明
	RepulseDesc string `gorm:"not null;" json:"repulse_desc"`
	// 进件提交时间   需要在待渠道放款、补录数据更新时间
	CommitTime *time.Time `json:"commit_time"`
	// 审核中是时间
	ApprovalStartTime *time.Time `json:"approval_start_time"`

	// 添加一个审核打回时间
	ApprovalRepulseTime *time.Time `json:"approval_repulse_time"`

	// 审核通过时间
	ApprovalPassTime *time.Time `json:"approval_pass_time"`
	// 审批拒绝时间
	ApprovalRefuseTime *time.Time `json:"approval_refuse_time"`
	// 客户拒绝时间
	CustomerRefuseTime *time.Time `json:"customer_refuse_time"`
	// 放款时间  运营点击申请放款
	LoanTime *time.Time `json:"loan_time"`
	// 撤销时间
	CancelTime *time.Time `json:"cancel_time"`
	// 第一期
	FirstTermPay float64 `gorm:"not null" json:"first_term_pay"`
	// 每月要还
	OtherEveryTermPay float64 `gorm:"not null" json:"other_every_term_pay"`
	//中介端需要显示的状态
	AgencyStatus string `gorm:"not null;index;default:'已提交'" json:"agency_status"`
	// =============================

	/*
		8月功能点更新
	*/

	// 审批挂起的标识   off 没有挂起   on 挂起
	Suspending string `gorm:"not null;default:'off'" json:"suspending"`
	// 审批挂起说明
	SuspenseDesc string `gorm:"not null;" json:"suspense_desc"`

	// 放款银行   前端给我
	LoanBankName string `gorm:"not null;" json:"loan_bank_name"`
	// 放款卡号
	LoanCard string `gorm:"not null;" json:"loan_card"`

	// 验证添加扣款卡
	PayCardList string `gorm:"not null;type:text" json:"pay_card_list"`

	// 这里要将所有进件信息存储下来
	// 什么样子的形式我还没想好呀
	// 进件信息
	AllInfo   string `gorm:"not null;type:text" json:"all_info"`
	OrderInfo string `gorm:"not null;type:text" json:"order_info"`

	// 渠道经理
	ChannelManager string `gorm:"not null;" json:"channel_manager"`

	// 拒绝原因
	RefuseReason string `gorm:"not null;type:text" json:"refuse_reason"`

	// 量化变量map
	QuantizationMap string `gorm:"not null;type:text" json:"quantization_map"`
	// 量化等级
	QuantizationLevel int `gorm:"not null;" json:"quantization_level"`

	// 面签标识和面签资料url
	InterView string `gorm:"not null;type:text" json:"inter_view"`

	// 前端存储量化数据
	QuantizationCache string `gorm:"not null;type:text" json:"quantization_cache"`

	// 产品id
	ProductId string `json:"product_id"`

	// 产品名
	ProductName string `json:"product_name"`

	// 外部原因
	ExternalReason string `json:"external_reason"`

	// 终审审批结果
	ReTrailChoice string `json:"re_trail_choice"`

	// 添加的联系人
	ApprovalAddContacts string `gorm:"type:text" json:"approval_add_contacts"`

	// 风险参数
	RiskParam string `gorm:"type:text" json:"risk_param"`

	// 分机号
	ExtensionNumber string `json:"extension_number"`

	// 统一说明    update:  11月版本废弃
	Desc string `gorm:"type:text" json:"desc"`

	// CA 合同模板id
	ContractTempleteId uint `json:"contract_templete_id"`

	// 是否开启CA
	CaSwitch string `json:"ca_switch"`

	// 11月需求
	// 资金方
	FundSide string `json:"fund_side"`
	// 财务说明
	FinBackDesc string `json:"fin_back_desc"`
	// 产品方案
	ProductPlan string `gorm:"type:text" json:"product_plan"`

	// 是否是非标件
	IsStandard string `json:"is_standard"`

	/**
	12月版本
	 */
	// 方案号
	PlanNum string `gorm:"type:text" json:"plan_num"`
	// 选择此卡的原因
	CardOneChoiceReason string `gorm:"not null" json:"card_one_choice_reason"`
	// Gscore 算出的利率
	QuantizationRate float64 `json:"quantization_rate"`

	// 平台服务费月利率
	PlatformMonthRate float64 `json:"platform_month_rate"`

	//审批状态
	ApprovalStatus string `json:"approval_status"`

	// 面签经理经理  ||已经废弃
	InterViewManager string `json:"inter_view_manager"`

	/* ******************************************** */

	// 201802月需求
	// 面签历史订单上传资料，由审批打开开关进行控制,默认为off，为on的时候表示打开开关
	InterViewSwitch string `gorm:"not null;default:'off'" json:"inter_view_switch"`

	// 面签人Id
	InterViewTrailId string `gorm:"not null" json:"inter_view_trail_id"`
	// 面签人name
	InterViewTrailName string `gorm:"not null" json:"inter_view_trail_name"`
	// 面签状态
	InterViewStatus string `gorm:"not null" json:"inter_view_status"`
	// 面签状态说明
	InterViewStatusDes string `gorm:"not null;type:text" json:"inter_view_status_des"`
	// 面签挂起的标识   off 没有挂起   on 挂起
	InterViewSuspending string `gorm:"not null;default:'off'" json:"inter_view_suspending"`
	// 面签挂起说明
	InterViewSuspenseDesc string `gorm:"not null;" json:"inter_view_suspense_desc"`
	// 面签结束时间
	InterViewFinishTime *time.Time `json:"inter_view_finish_time"`

	// 适配海金社
	// 风险等级
	RiskLevel string `json:"risk_level"`

	// 风险结论
	RiskResult string `gorm:"type:text" json:"risk_result"`

	// 补录选择的方式
	AdditionalRecordChannel     string `json:"additional_record_channel"`
	CallAdditionalRecordChannel string `json:"call_additional_record_channel"`

	/* ******************************************** */

	// 201803月需求
	// 客户姓名身份证是否匹配
	// matched匹配 unmatched不匹配 unsure不确认
	IdCardCheckResult string `json:"id_card_check_result"`
	// 身份证归属地
	IdCardPlace string `json:"id_card_place"`
	// 渠道公司负责人(法人)
	ChannelLegalPerson string `gorm:"not null;" json:"channel_legal_person"`
	// 渠道经理id(电话)[客户经理编号]
	ChannelManagerId   string `gorm:"not null;" json:"channel_manager_id"`
	// 审批次数(通过身份证判断)[审批类型\借款类型]
	ApprovalTimesByIdNum int  `gorm:"not null;" json:"approval_times_by_id_num"`
}

func (a *ApprovalOrder) IsValidApprovalOrder() (err error) {
	switch {
	case a.JinjianId == "":
		err = errors.New("进件id不能为空")
	case !a.CheckJinjianIDExist():
		err = errors.New("进件id已存在")
	case a.LoanAmount <= 0:
		err = errors.New("贷款金额必须大于0")
	case a.AgencyEmployee == "":
		err = errors.New("业务员不能为空")
	case a.AgencyName == "":
		err = errors.New("中介机构不能为空")
	case a.LoanTerm <= 0:
		err = errors.New("贷款期数必须大于0")
	case a.ShowId == "":
		err = errors.New("前端显示进件id不能为空")
	case a.AllInfo == "":
		err = errors.New("进件allInfo信息不能为空")
	case a.OrderInfo == "":
		err = errors.New("进件order信息不能为空")
	case a.UserIdNum == "":
		err = errors.New("用户身份证号不能为空")
	case a.ChannelManager == "":
		err = errors.New("进件渠道经理不能为空")
	case a.ProductId == "":
		err = errors.New("产品id不能为空")
	case a.ProductName == "":
		err = errors.New("产品名不能为空")
	case a.CaSwitch == "":
		err = errors.New("是否开启Ca不能为空")
	case a.CaSwitch == "on":
		if a.ContractTempleteId == 0 {
			err = errors.New("开启Ca,合同模板id不能为0")
			return
		}
	case a.FundSide == "":
		err = errors.New("资金方不能为空")
	case a.ProductPlan == "":
		err = errors.New("产品方案不能为空")
	}
	return
}

func (a *ApprovalOrder) CheckJinjianIDExist() bool {
	orders := []*ApprovalOrder{}
	config.GetDb().Where("jinjian_id = ?", a.JinjianId).Find(&orders)
	if len(orders) > 0 {
		return false
	} else {
		return true
	}
}

func (a *ApprovalOrder) IsValidCSGrabOrder(approvalOrder *ApprovalOrder) (err error) {
	switch {
	case a.FirstTrailName != "Null":
		err = errors.New("初审审核人应该为空")
	case a.FirstTrailId != "Null":
		err = errors.New("初审id应该为空")
	case a.FirstTrailStatus == ApprovalStatusFirstTrailPass:
		err = errors.New("初审状态应该不是初审同过")
	case a.FirstTrailStatus == ApprovalStatusFirstTrailExchange:
		err = errors.New("初审状态应该不是初审流转")
	case a.FirstTrailStatus == ApprovalStatusFirstTrailRefuse:
		err = errors.New("初审状态应该不是初审拒绝")
	case a.FirstTrailStatus == ApprovalStatusFirstTrailRepulse:
		err = errors.New("初审状态应该不是初审打回")
	case a.FirstTrailStatus == ApprovalStatusReTrailBack:
		err = errors.New("初审状态应该不是终审退回")
	case a.CustomServiceStatus != "Null":
		err = errors.New("客服状态应该为Null")
	case a.OperatorStatus != "Null":
		err = errors.New("运营状态应该为Null")
	case a.ReTrailStatus != "Null":
		err = errors.New("终审状态应该为Null")
	case a.Suspending != "off":
		err = errors.New("审批挂起状态应该为关闭")
	case approvalOrder.FirstTrailName == "":
		err = errors.New("抢单参数错误，初审name")
	case approvalOrder.FirstTrailId == "":
		err = errors.New("抢单参数错误，初审id")
	}
	return
}

func (a *ApprovalOrder) IsValidZSGrabOrder(approvalOrder *ApprovalOrder) (err error) {
	switch {
	case a.ReTrailId != "Null":
		err = errors.New("终审id应该为空")
	case a.ReTrailName != "Null":
		err = errors.New("终审审核人应该为空")
	case a.FirstTrailName == "Null":
		err = errors.New("初审审核人应该不为空")
	case a.ReTrailStatus != ApprovalStatusWaitReTrail:
		err = errors.New("终审状态应该不是终审通过")
	case a.FirstTrailId == "Null":
		err = errors.New("初审id应该不为空")
	case a.FirstTrailStatus == ApprovalStatusWaitAgencyConfirm:
		err = errors.New("初审状态应该不是待渠道放款")
	case a.FirstTrailStatus == ApprovalStatusFirstTrailExchange:
		err = errors.New("初审状态应该不是初审流转")
	case a.FirstTrailStatus == ApprovalStatusWaitUserInput:
		err = errors.New("初审状态应该不是待补录数据")
	case a.FirstTrailStatus == ApprovalStatusWaitFirstTrail:
		err = errors.New("初审状态应该不是待初审")
	case a.FirstTrailStatus == ApprovalStatusReTrailBack:
		err = errors.New("初审状态应该不是终审退回")
	case a.ReTrailStatus == ApprovalStatusReTrailPass:
		err = errors.New("终审状态应该不是终审通过")
	case a.ReTrailStatus == ApprovalStatusReTrailRefuse:
		err = errors.New("终审状态应该不是终审拒绝")
	case a.ReTrailStatus == ApprovalStatusReTrailExchange:
		err = errors.New("终审状态应该不是终审流转")
	case a.ReTrailStatus == ApprovalStatusCustomServiceBack:
		err = errors.New("终审状态应该不是客服退回")
	case a.CustomServiceStatus != "Null":
		err = errors.New("客服状态应该为Null")
	case a.OperatorStatus != "Null":
		err = errors.New("运营状态应该为Null")
	case a.Suspending != "off":
		err = errors.New("审批挂起状态应该为关闭")
	case approvalOrder.ReTrailName == "":
		err = errors.New("抢单参数错误，终审name")
	case approvalOrder.ReTrailId == "":
		err = errors.New("抢单参数错误，终审id")
	}
	return
}

func (a *ApprovalOrder) IsValidKFGrabOrder(approvalOrder *ApprovalOrder) (err error) {
	switch {
	case a.CustomServiceId != "Null":
		err = errors.New("客服id应该为空")
	case a.CustomServiceName != "Null":
		err = errors.New("客服名字应该为空")
	case a.ReTrailId == "Null":
		err = errors.New("终审id应该不为空")
	case a.ReTrailName == "Null":
		err = errors.New("终审审核人应该不为空")
	case a.FirstTrailName == "Null":
		err = errors.New("初审审核人应该不为空")
	case a.ReTrailStatus == ApprovalStatusWaitReTrail:
		err = errors.New("终审状态应该不是待终审")
	case a.FirstTrailId == "Null":
		err = errors.New("初审id应该不为空")
	case a.FirstTrailStatus == ApprovalStatusWaitAgencyConfirm:
		err = errors.New("初审状态应该不是待渠道放款")
	case a.FirstTrailStatus == ApprovalStatusFirstTrailExchange:
		err = errors.New("初审状态应该不是初审流转")
	case a.FirstTrailStatus == ApprovalStatusWaitUserInput:
		err = errors.New("初审状态应该不是待补录数据")
	case a.FirstTrailStatus == ApprovalStatusWaitFirstTrail:
		err = errors.New("初审状态应该不是待初审")
	case a.FirstTrailStatus == ApprovalStatusReTrailBack:
		err = errors.New("初审状态应该不是终审退回")
	case a.CustomServiceStatus != ApprovalStatusWaitCustomConfirm:
		err = errors.New("客服状态应该是待沟通")
	case a.OperatorStatus != "Null":
		err = errors.New("运营状态应该为Null")
	case a.Suspending != "off":
		err = errors.New("审批挂起状态应该为关闭")
	case approvalOrder.CustomServiceName == "":
		err = errors.New("抢单参数错误，客服name")
	case approvalOrder.CustomServiceId == "":
		err = errors.New("抢单参数错误，客服id")
	}
	return
}

func (a *ApprovalOrder) IsValidYYOrder() (err error) {
	switch {
	case a.ReTrailId == "Null":
		err = errors.New("终审id不应该为空")
	case a.ReTrailName != "Null":
		err = errors.New("终审审核人应该为空")
	case a.FirstTrailName == "Null":
		err = errors.New("初审审核人应该不为空")
	case a.FirstTrailId == "Null":
		err = errors.New("初审id应该不为空")
	case a.CustomServiceId == "Null":
		err = errors.New("客服id应该不为空")
	case a.CustomServiceName == "Null":
		err = errors.New("客服名字应该不为空")
	case a.CustomServiceStatus != ApprovalStatusCustomPass:
		err = errors.New("客服状态应该为客户接受")
	case a.Suspending != "off":
		err = errors.New("审批挂起状态应该为关闭")
	}
	return
}

func (a *ApprovalOrder) IsValidCsOperation() (err error) {
	switch {
	case a.FirstTrailStatus == ApprovalStatusWaitAgencyConfirm:
		logger.Info("初审操作状态错误，初审状态不能为" + ApprovalStatusWaitAgencyConfirm)
		err = errors.New("用户信息不完整，不可进行操作")
		return
	case a.FirstTrailStatus == ApprovalStatusWaitUserInput:
		logger.Info("初审操作状态错误，初审状态不能为" + ApprovalStatusWaitUserInput)
		err = errors.New("用户信息不完整，不可进行操作")
		return
	case a.FirstTrailStatus == ApprovalStatusFirstTrailPass:
		err = errors.New("初审操作状态错误，初审状态不能为" + ApprovalStatusFirstTrailPass)
		return
	case a.FirstTrailStatus == ApprovalStatusFirstTrailRefuse:
		err = errors.New("初审操作状态错误，初审状态不能为" + ApprovalStatusFirstTrailRefuse)
		return
	case a.FirstTrailName == "Null":
		err = errors.New("初审人不能为Null")
		return
	case a.FirstTrailId == "Null":
		err = errors.New("初审id不能为Null")
		return
	case a.Suspending != "off":
		err = errors.New("审批挂起状态应该为关闭")
		//case a.InterView == "":
		//	err = errors.New("面签材料不能为空")
		//	return
	}
	return
}

func (a *ApprovalOrder) IsValidZsOperation() (err error) {
	if a.FirstTrailStatus != ApprovalStatusFirstTrailPass {
		if a.FirstTrailStatus != ApprovalStatusFirstTrailRefuse {
			err = errors.New("初审操作状态错误，初审状态应该为拒绝或通过")
			return
		}
	}
	switch {
	case a.ReTrailStatus == ApprovalStatusReTrailPass:
		err = errors.New("终审操作状态错误，终审状态不能为" + ApprovalStatusReTrailPass)
		return
	case a.ReTrailStatus == ApprovalStatusReTrailRefuse:
		err = errors.New("终审操作状态错误，终审状态不能为" + ApprovalStatusReTrailRefuse)
		return
	case a.ReTrailName == "Null":
		err = errors.New("终审人不能为Null")
		return
	case a.ReTrailId == "Null":
		err = errors.New("终审id不能为Null")
		return
	case a.Suspending != "off":
		err = errors.New("审批挂起状态应该为关闭")
	}
	return
}

func (a *ApprovalOrder) IsValidZsPassOperationMrOnion() (err error) {
	switch {
	case a.Card1 == "":
		err = errors.New("主卡不能为空")
		return
	case a.ApprovedAmount == 0:
		err = errors.New("核准金额不能为0")
		return
		//case a.ApprovedRate == 0:
		//	err = errors.New("核准利率不能为0")
		//	return
	case a.ReTrailStatusDes == "":
		err = errors.New("终审状态说明不能为空")
		return
	case a.Cellphone == "":
		err = errors.New("手机不能为空")
		return
	case a.BankName == "":
		err = errors.New("银行名字不能为空")
		return
	case a.UserIdNum == "":
		err = errors.New("身份证不能为空")
		return
	case a.LoanBankName == "":
		err = errors.New("放款银行不能为空")
		return
	case a.LoanCard == "":
		err = errors.New("放款卡号不能为空")
		return
	case a.CardOnePhone == "":
		err = errors.New("扣款卡手机号不能为空")
		return
	case a.PlatformMonthRate == 0:
		err = errors.New("平台服务费月利率不能为空")
		return
	}
	return
}

// 新版审批终审状态是校验后才更改的,所以去掉了 终审状态说明不能为空, 为不影响原逻辑,故新写一个
func (a *ApprovalOrder) IsValidZsPassOperationMrOnionNew() (err error) {
	switch {
	case a.Card1 == "":
		err = errors.New("主卡不能为空")
		return
	case a.ApprovedAmount == 0:
		err = errors.New("核准金额不能为0")
		return
		//case a.ApprovedRate == 0:
		//	err = errors.New("核准利率不能为0")
		//	return
		//case a.ReTrailStatusDes == "":
		//	err = errors.New("终审状态说明不能为空")
		//	return
	case a.Cellphone == "":
		err = errors.New("手机不能为空")
		return
	case a.BankName == "":
		err = errors.New("银行名字不能为空")
		return
	case a.UserIdNum == "":
		err = errors.New("身份证不能为空")
		return
	case a.LoanBankName == "":
		err = errors.New("放款银行不能为空")
		return
	case a.LoanCard == "":
		err = errors.New("放款卡号不能为空")
		return
	case a.CardOnePhone == "":
		err = errors.New("扣款卡手机号不能为空")
		return
	case a.PlatformMonthRate == 0:
		err = errors.New("平台服务费月利率不能为空")
		return
	}
	return
}

func (a *ApprovalOrder) IsValidZsPassOperation() (err error) {
	switch {
	case a.Card1 == "":
		err = errors.New("主卡不能为空")
		return
	case a.ApprovedAmount == 0:
		err = errors.New("核准金额不能为0")
		return
	case a.ApprovedRate == 0:
		err = errors.New("核准利率不能为0")
		return
		//case a.QuantizationPoint == 0:
		//	err = errors.New("量化评分不能为0")
		//	return
	case a.ApprovedRate <= 10:
		err = errors.New("核准利率不能低于10%")
		return
	case a.ReTrailStatusDes == "":
		err = errors.New("终审状态说明不能为空")
		return
	//case a.SalaryAt == nil:
	//	err = errors.New("首次还款时间不能空")
	//	return
	//case a.LoanAt == nil:
	//	err = errors.New("放款时间不能空")
	//	return
	case a.Cellphone == "":
		err = errors.New("手机不能为空")
		return
	case a.BankName == "":
		err = errors.New("银行名字不能为空")
		return
	case a.UserIdNum == "":
		err = errors.New("身份证不能为空")
		return
		//case a.ContractId == "":
		//	err = errors.New("合同号不能为空")
		//	return
	case a.LoanBankName == "":
		err = errors.New("放款银行不能为空")
		return
	case a.LoanCard == "":
		err = errors.New("放款卡号不能为空")
		return
	case a.CardOnePhone == "":
		err = errors.New("扣款卡手机号不能为空")
		return
	}
	return
}

func (a *ApprovalOrder) IsValidKfOperation() (err error) {
	if a.FirstTrailStatus != ApprovalStatusFirstTrailPass {
		if a.FirstTrailStatus != ApprovalStatusFirstTrailRefuse {
			err = errors.New("初审操作状态错误，初审状态应该为拒绝或通过")
			return
		}
	}
	if a.ReTrailStatus != ApprovalStatusReTrailPass {
		err = errors.New("终审操作状态错误，终审状态应该为通过")
		return
	}
	switch {
	case a.CustomServiceStatus == ApprovalStatusCustomPass:
		err = errors.New("客服操作状态错误，客服状态不能为" + ApprovalStatusCustomPass)
		return
	case a.CustomServiceStatus == ApprovalStatusCustomRefuse:
		err = errors.New("终审操作状态错误，终审状态不能为" + ApprovalStatusCustomRefuse)
		return
	case a.CustomServiceName == "Null":
		err = errors.New("客服不能为Null")
		return
	case a.CustomServiceId == "Null":
		err = errors.New("客服id不能为Null")
		return
	case a.Suspending != "off":
		err = errors.New("审批挂起状态应该为关闭")
	}
	return
}

func (a *ApprovalOrder) IsValidYyOperation() (err error) {
	if a.FirstTrailStatus != ApprovalStatusFirstTrailPass {
		if a.FirstTrailStatus != ApprovalStatusFirstTrailRefuse {
			err = errors.New("初审操作状态错误，初审状态应该为拒绝或通过")
			return
		}
	}
	if a.ReTrailStatus != ApprovalStatusReTrailPass {
		err = errors.New("终审操作状态错误，终审状态应该为通过")
		return
	}
	if a.CustomServiceStatus != ApprovalStatusCustomPass {
		err = errors.New("客服操作状态错误，客服状态应该为通过")
		return
	}

	if a.Suspending != "off" {
		err = errors.New("审批挂起状态应该为关闭")
		return
	}
	return
}

func (a *ApprovalOrder) GetAoCurrStatus() string {

	logger.Info("UUUJUJUJNUJUJU", "FirstTrailStatus", a.FirstTrailStatus)

	switch a.FirstTrailStatus {
	case ApprovalStatusCustomCancel:
		// 撤销 状态
		return "撤销"
	case ApprovalStatusFirstTrailRefuse:
		return RfStatus(a.ReTrailStatus, a.CustomServiceStatus, a.OperatorStatus)
	case ApprovalStatusFirstTrailPass:
		return RfStatus(a.ReTrailStatus, a.CustomServiceStatus, a.OperatorStatus)
	default:
		// 在初审
		return "初审中"
	}

}

func RfStatus(sR, sC, sF string) string {
	//  终审状态
	switch sR {
	case ApprovalStatusCustomCancel:
		// 撤销 状态
		return "撤销"
	case ApprovalStatusReTrailPass:
		return CmStatus(sC, sF)
	case ApprovalStatusReTrailRefuse:
		// 终审拒绝
		return ApprovalStatusReTrailRefuse
	case ApprovalStatusReTrailFinish:
		// 终审拒绝
		return ApprovalStatusReTrailRefuse
	default:
		// 在终审
		return "终审中"
	}
}

func CmStatus(sC, sF string) string {
	//  客服状态
	switch sC {
	case ApprovalStatusCustomCancel:
		// 撤销 状态
		return "撤销"
	case ApprovalStatusCustomPass:
		// 获取财务的状态
		return FinStatus(sF)
	case ApprovalStatusCustomRefuse:
		// 客户拒绝
		return ApprovalStatusCustomRefuse
	default:
		// 在客服
		return "客服中"
	}
}

func FinStatus(s string) string {
	//  财务状态
	switch s {
	case ApprovalStatusOperatorSuccess:
		// 已放款
		return ApprovalStatusOperatorSuccess
	default:
		// 客服通过
		return ApprovalStatusCustomPass
	}
}

// 保存放扣款信息时校验
func (a *ApprovalOrder) IsValidApprovalLoanInfo(at string) error {

	if a.FundSide != "个人" && a.PlatformMonthRate == 0 {
		return errors.New("平台月服务费率不能为空")
	}
	if a.FundSide == "个人" && a.ApprovedRate == 0 {
		return errors.New("核准利率不能为空")
	}

	switch {
	case a.JinjianId == "":
		return errors.New("进件id不能为空")

	case a.ApprovedAmount == 0:
		return errors.New("核准金额不能为空")

	//case a.ApprovedRate == 0:
	//	return errors.New("核准利率不能为空")

	//case a.SalaryAt == nil || a.SalaryAt.IsZero():
	//	return errors.New("首次还款日期不能空")
	//
	//case a.LoanAt == nil || a.LoanAt.IsZero():
	//	return errors.New("放款日期不能为空")

	case a.Card1 == "":
		return errors.New("首选扣款卡不能为空")

	case a.LoanCard == "":
		return errors.New("首选放款卡不能为空")

	case a.CardOneChoiceReason == "":
		return errors.New("首选扣款卡原因不能为空")
	}
	return nil
}

func (ao *ApprovalOrder) IsValidUpdateInfo(approvalType string) (err error) {
	switch approvalType {
	case "cs":
		if ao.FirstTrailStatus != ApprovalStatusWaitFirstTrail && ao.FirstTrailStatus != ApprovalStatusFirstTrailExchange && ao.FirstTrailStatus != ApprovalStatusReTrailBack {
			logger.Error("==================初审修改信息状态错误： ", "当前状态: ", ao.InterViewStatus)
			return errors.New("当前订单状态为:" + ao.ReTrailStatus + "无法修改，请检查")
		}
	case "zs":
		if ao.ReTrailStatus != ApprovalStatusWaitReTrail && ao.ReTrailStatus != ApprovalStatusReTrailExchange && ao.ReTrailStatus != ApprovalStatusCustomServiceBack && ao.ReTrailStatus != ApprovalStatusFinanceBack {
			logger.Error("==================终审修改信息状态错误： ", "当前状态: ", ao.ReTrailStatus)
			return errors.New("当前订单状态为:" + ao.ReTrailStatus + "无法修改，请检查")
		}
	case "kf":
		return errors.New("该账号没有修改权限, 请检查")
	default:
		return errors.New("参数错误， 没有此审批类别： " + approvalType)
	}
	return
}