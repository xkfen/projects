package model

func GetDefaultApprovalOrder() *ApprovalOrder {
	return &ApprovalOrder{
		ShowId:           "S_qy20180313002",
		UserIdNum:        "4444444444444444",
		ChannelManager:   `["qqq#"]`,
		InterViewManager: `["qqq#"]`,
		JinjianId:        "J20170616007",
		JinjianUserId:    "13570582709",
		JinjianUserName:  "进进件",
		AgencyName:       "深圳前海神马金融服务有限公司",
		AgencyEmployeeId: "1234567",
		AgencyEmployee:   "业务员1",
		LoanAmount:       100000000,
		LoanTerm:         12,
		ApprovalAddContacts: `[
				{"name":"本人","phone":"13827484056","relationship":"本人"}]`,
		AllInfo:   `{"call_record":{"cellphone":"135765765765","createdAt":"2017-07-27 16:25:49","id":45,"isCrawled":true,"isJump":true,"orderId":"45","password":"123456","status":"1","updatedAt":"2017-07-27 16:25:49","userId":92},"contacts":{"createdAt":"2017-07-27 16:25:49","id":45,"orderId":"45","primaryName":"王英","primaryPhone":"156027657657","primaryRelation":"亲属","secondaryName":"段宏斌","secondaryPhone":"1598765765765","secondaryRelation":"亲属","status":"1","updatedAt":"2017-07-27 16:25:49","userId":92},"idcard_info":{"backPhoto":"/assets/uploads/images/idCard/b200fbc9-9f02-44ad-9210-01c30d09b167.jpg","createdAt":"2017-07-27 16:25:48","facePhoto":"/assets/uploads/images/idCard/c6e9ccfc-31e9-4b05-b242-08167825b57a.jpg","id":45,"name":"张伟","number":"675765756765756","orderId":"45","status":"1","updatedAt":"2017-07-27 16:25:48","userId":92},"other_bank":[],"personal_info":{"address":"广东省 深圳市 福田区","createdAt":"2017-07-27 16:25:49","detailAddress":"百花四路","education":"本科","houseType":"其他住房","id":45,"job":"无","marriage":"未婚","monthlyCost":"无","monthlyIncome":"100000","orderId":"45","status":"1","updatedAt":"2017-07-27 16:25:49","usage":"购物","userId":92,"workAddress":"广东省 深圳市 福田区","workDetailAddress":"百花四路","workplace":"深圳市XX文化传播有限公司","workplacePhone":"0755-6546456456","wxNo":"fdasfsda"},"salary_bank":[{"account":"1234","bank":"招商银行","cardNo":"67567657657567657","cellphone":"135765756756","createdAt":"2017-07-27 16:25:49","id":45,"isCrawled":true,"isJump":true,"orderId":"45","password":"1234","status":"1","updatedAt":"2017-07-27 16:25:49","userId":92}]}`,
		OrderInfo: `{"loanCard":null,"signAt":null,"terms":12,"realAmount":null,"brokerId":1,"backItem":null,"amount":20000000,"userName":"光六","brokerPhone":"15012880331","orderId":"order_1516018603452","rate":null,"userPhone":"15012885106","approvalAmount":null,"brokerName":"中介005","loanTime":null,"pendingTime":null,"finishBulu":false,"managers":["面签005"],"rstUserId":null,"adjustRepayAmount":null,"creditReportPath":null,"loanAmount":null,"showOrderId":"S_qy20180115005","id":52,"repayDate":null,"bankName":null,"isOpenSignature":false,"brokerCompanyId":1,"backInfo":null,"passTime":null,"cancelTime":null,"applyResult":null,"realLoanAmount":null,"isInterviewPass":false,"statusUpdatedAt":"2018-01-15T12:21:18.910Z","isSpBuLu":false,"brokerCompany":"测试005","refuseReason":null,"status":8,"rejectTime":null,"approvalStatus":null,"createdAt":"2018-01-15 20:16:43","idNo":"440306200001010175","updatedAt":"2018-01-15 20:20:37","accountId":null,"loanBank":null,"loanType":null,"userId":56,"commitTime":"1/15/2018, 8:21:18 PM","customerRejectTime":null,"isBuLu":false}`,
		//InterView:  `{"jinjian_id": "J20170616007","score":"1000"}`,
		ProductId:   "ssss",
		ProductName: "sssss",
		CaSwitch:    "off",
		FundSide:    "onion",
		ProductPlan: "jjjjjj",
		IsStandard:  "sss",
		PlanNum:     "001",
		//RiskParam:`{"k10_02":null,"k9_03":4056800,"k5_03":"72.04%","k12_03":"28%","k7_02":"14006.73","k6_02":"25210","k1_03":"他行房贷","k4_01":"0","k2_01":"2015-3-11","k2_06":"3450000","k5_02":"341472","k1_02":"500000","k8_02":"19995","k2_03":"建设","k2_05":"31","k10_01":"45.03%","k7_01":"267800","k3_03":"0","k9_01":1469272,"k13_01":0,"k11_01":"1","k10_03":"85.35%","k13_02":24,"k3_02":"月供*12","k9_02":73363.73,"k1_01":"2017-9-22","k8_01":"2455000","k9_04":93358.73,"k3_01":"162924","k2_02":"2455000","k6_01":"860000","k4_02":4753392,"k2_04":"2015-3-3","k5_01":"474000","k12_01":"审慎"}`,
		//RiskParam: `{"r12":"0","r30":0.6,"r24":5000,"version":"v1.0","r13":"NaN","r27":96.6,"r11":"NaN","r26":18.46,"r22":5000,"r25":23.51,"r16":5000,"r14":"500","r3":35000,"r28":"50000","r9":"50000","r15":[{"type":"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK","content":{"loanDate":"1994-12-11","loanAmount":"5000","monthlyRepayment":"5000","loanBalance":"5000","remainingPeriod":"12","loanAgency":"额达去"}},{"type":"DEBT_TYPE_XXX_LOANS_PEOPLE_BANK","content":{"loanDate":"1994-12-11","loanAmount":"5000","monthlyRepayment":"5000","loanBalance":"5000","remainingPeriod":"12","loanAgency":"额达去111"}}],"r8":"8000","r19":0,"r23":5000,"r21":0,"r17":5000,"r1":"OTHER_LOAN","r20":0,"r5":[{"name":"的","amount":"10000"}],"r4":80000,"r29":24,"r10":"10000000","r6":"8000","r18":5000,"r7":298000,"r2":[{"name":"房产贷（单独所有）","content":{"house_valuation":1000000,"house_address":"深证","house_register_data":"2010-01-02"}}]}`,
		//RiskParam:`{"r12":"0","r30":0.6,"r24":5000,"version":"v1.0","r13":"NaN","r27":96.6,"r11":"NaN","r26":18.46,"r22":5000,"r25":23.51,"r16":5000,"r14":"500","r3":35000,"r28":"50000","r9":"50000","r15":[{"type":"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK","content":{"loanDate":"1994-12-11","loanAmount":"5000","monthlyRepayment":"5000","loanBalance":"5000","remainingPeriod":"12","loanAgency":"额达去"}},{"type":"DEBT_TYPE_XXX_LOANS_PEOPLE_BANK","content":{"loanDate":"1994-12-11","loanAmount":"5000","monthlyRepayment":"5000","loanBalance":"5000","remainingPeriod":"12","loanAgency":"额达去111"}}],"r8":"8000","r19":0,"r23":5000,"r21":0,"r17":5000,"r1":"OTHER_LOAN","r20":0,"r5":[{"name":"的","amount":"10000"}],"r4":80000,"r29":24,"r10":"10000000","r6":"8000","r18":5000,"r7":298000,"r2":[{"name":"房产贷（单独所有）","content":{"house_valuation":1000000,"house_address":"深证","house_register_data":"2010-01-02"}}]}`,
		// 保单贷
		//RiskParam:`{"r10":"2398","r4":200000,"version":"v1.0","r23":564161,"r18":18167,"r25":13,"r2":{"name":"保单贷（满3年）","policyList":[{"payment_method":"月缴","payment_times":"47","is_valid":1,"policy_name":"泰康人寿","policy_number":"229757003","policy_effective_date":"2014-04-14","policy_amount":"1911"},{"policy_name":"泰康人寿","policy_number":"I05020981","policy_effective_date":"2011-11-26","policy_amount":"928.8","payment_method":"月缴","payment_times":"76","is_valid":1},{"policy_name":"泰康人寿","policy_number":"I05020981","policy_effective_date":"2011-11-26","policy_amount":"928.8","payment_method":"月缴","payment_times":"76","is_valid":1}]},"r16":500000,"r1":"POLICY_LOAN","r31":1520580285369,"r20":152940,"r19":284000,"r21":8244,"r28":"150000","r11":"8.27","r24":26411,"r26":57.1,"r27":null,"r8":"","r15":[{"content":{"loanBalance":"411221","remainingPeriod":"28","loanAgency":"平安银行","loanDate":"2017-6-1","loanAmount":"500000","monthlyRepayment":"18167"},"type":"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK"},{"content":{"loanAgency":"上海东正汽车金融有限公司","loanDate":"2016-9-22","loanAmount":"284000","monthlyRepayment":"8244","loanBalance":"152940","remainingPeriod":"19"},"type":"DEBT_TYPE_MORTGAGE"}],"r12":"9059","r17":411221,"r22":784000,"r30":0.6,"r3":204465.6,"r29":24,"r9":"29000","r5":[],"r6":"","r13":"31.24","r7":1635724.8,"r14":"0"}`,
		// 房产带(单独所有)
		//RiskParam:`{"r10":"2398","r4":200000,"version":"v1.0","r23":564161,"r18":18167,"r25":13,"r2":[{"name":"房产贷（单独所有）","content":{"house_valuation":2000,"house_address":"湿哒哒","house_register_data":"2015-02-02"}}],"r16":500000,"r1":"POLICY_LOAN","r31":1520580285369,"r20":152940,"r19":284000,"r21":8244,"r28":"150000","r11":"8.27","r24":26411,"r26":57.1,"r27":null,"r8":"","r15":[{"content":{"loanBalance":"411221","remainingPeriod":"28","loanAgency":"平安银行","loanDate":"2017-6-1","loanAmount":"500000","monthlyRepayment":"18167"},"type":"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK"},{"content":{"loanAgency":"上海东正汽车金融有限公司","loanDate":"2016-9-22","loanAmount":"284000","monthlyRepayment":"8244","loanBalance":"152940","remainingPeriod":"19"},"type":"DEBT_TYPE_MORTGAGE"}],"r12":"9059","r17":411221,"r22":784000,"r30":0.6,"r3":204465.6,"r29":24,"r9":"29000","r5":[],"r6":"","r13":"31.24","r7":1635724.8,"r14":"0"}`,
		// 月供贷
		//RiskParam:`{"r10":"2398","r4":200000,"version":"v1.0","r23":564161,"r18":18167,"r25":13,"r2":[{"name":"月供贷（6-11期，按揭）","content":{"lending_data":"2015-02-02","lending_amount":"23000","monthly_supply_amount":"2300"}},{"name":"月供贷11（6-11期，抵押）","content":{"lending_data":"2015-02-02","lending_amount":"43000","monthly_supply_amount":"4300"}}],"r16":500000,"r1":"POLICY_LOAN","r31":1520580285369,"r20":152940,"r19":284000,"r21":8244,"r28":"150000","r11":"8.27","r24":26411,"r26":57.1,"r27":null,"r8":"","r15":[{"content":{"loanBalance":"411221","remainingPeriod":"28","loanAgency":"平安银行","loanDate":"2017-6-1","loanAmount":"500000","monthlyRepayment":"18167"},"type":"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK"},{"content":{"loanAgency":"上海东正汽车金融有限公司","loanDate":"2016-9-22","loanAmount":"284000","monthlyRepayment":"8244","loanBalance":"152940","remainingPeriod":"19"},"type":"DEBT_TYPE_MORTGAGE"}],"r12":"9059","r17":411221,"r22":784000,"r30":0.6,"r3":204465.6,"r29":24,"r9":"29000","r5":[],"r6":"","r13":"31.24","r7":1635724.8,"r14":"0"}`,


		//RiskParam:`{"r12":"0","r30":0.6,"r24":5000,"version":"v1.0","r13":"NaN","r27":96.6,"r11":"NaN","r26":18.46,"r22":5000,"r25":23.51,"r16":5000,"r14":"500","r3":35000,"r28":"50000","r9":"0","r15":[{"type":"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK","content":{"loanDate":"1994-12-11","loanAmount":"5000","monthlyRepayment":"5000","loanBalance":"5000","remainingPeriod":"12","loanAgency":"额达去"}}],"r8":"8000","r19":0,"r23":5000,"r21":0,"r17":5000,"r1":"OTHER_LOAN","r20":0,"r5":[{"name":"的","amount":"10000"}],"r4":80000,"r29":24,"r10":"0","r6":"8000","r18":5000,"r7":298000,"r2":{"name":"保单贷（满5年）","policyList":[{"policy_valid_total":1,"policy_amount_total":20000,"policy_name":"天天平安","policy_amount":20000,"payment_method":"年缴","policy_effective_date":"2018-01-26","is_valid":1,"payment_times":3,"policy_total":1,"policy_number":"S123456789"}]}}`,
		RiskParam:`{"r19":1089000,"version":"v2.0","r17":408468,"r29":24,"r14":"0","r4":200000,"r12":"101005","r16":553000,"r15":[{"type":"DEBT_TYPE_MORTGAGE","content":{"loanBalance":"907260","remainingPeriod":"177","loanDate":"2015-12-18","loanAmount":"1000000","monthlyRepayment":"7027","loanAgency":"中国银行"}},{"content":{"loanAmount":"100000","monthlyRepayment":"3564","loanBalance":"43082","remainingPeriod":"14","loanAgency":"北银消费金融","loanDate":"2016-5-13"},"type":"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK"},{"content":{"loanAgency":"中银消费金融","loanDate":"2017-3-3","loanAmount":"200000","monthlyRepayment":"7291","loanBalance":"155212","remainingPeriod":"26"},"type":"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK"},{"content":{"loanAgency":"东风标致雪铁龙汽车金融","loanDate":"2017-4-11","loanAmount":"89000","monthlyRepayment":"2868","loanBalance":"66649","remainingPeriod":"26"},"type":"DEBT_TYPE_MORTGAGE"},{"type":"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK","content":{"loanAmount":"253000","monthlyRepayment":"7821","loanBalance":"210174","remainingPeriod":"30","loanAgency":"哈尔滨银行","loanDate":"2017-7-7"}}],"r23":1382377,"r21":9895,"r20":973909,"r30":0.6,"r9":"206633","r13":"48.88","r27":null,"r8":"","r2":[{"name":"月供贷（24期或以上，按揭）","content":{"lending_data":"2015-12-18","lending_amount":"1000000","monthly_supply_amount":"7027"}}],"r11":"40.95","r18":18676,"r26":75.1,"r10":"84610","r7":2319728,"r31":1522830127276,"r24":28571,"r22":1642000,"r28":100000,"r6":"0","r25":57.97,"r5":[{"amount":"1870000","name":"房产证"}],"r3":56216,"r1":"OTHER_LOAN"}`,
		QuantizationMap: `
{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`,
QuantizationCache:`{"Title":{"k1":"1991-12-12","k2":"二十","k3":"身份证","k4":"350525197907136712","k5":"2024-12-01","k6":"男","k7":"1979-07-13","k8":"已婚","k9":"文盲","k10":"工人","k11":"工人"},"InfoSummary":{"k12":"0","k13":"0","k14":"0","k15":"0","k16":"无贷款","k17":"无贷记卡","k18":"无准贷记卡","k19":"0","k20":"0","k21":"0","k22":"0","k23":"0","k24":"0","k25":"50","k26":"50","k27":"50000","k28":"12","k29":"50000","k30":"12","k31":"0","k32":"0","k33":"0","k34":"0","k35":"0","k36":"0","k37":"0","k38":"0"},"TradeInfo":{"k39":"有","k40":"有","k41":"正常","k42":"5","k43":"0","k44":"0","k45":"0","k46":"0","k47":"0","k48":"0","k49":"0","k50":"0","k51":"0","k52":"0","k53":"0","k54":"0","k55":"500000","k56":"5","k57":"5","k58":"50000","k59":"500000","k60":"2018-02-02","k61":"500000","k62":"2018-02-02","k63":"300000","k64":"3","k65":"3","k66":"0","k67":"0","k68":"0","k69":"0","k70":"0","k71":"0","k72":"0","k73":"0","k74":"0","k75":"0","k76":"0","k77":"0","k78":"1","k79":"500000"},"PublicInfo":{"k80":"有","k81":"有","k82":"有","k83":"50000","k84":"50","k85":"缴交","k86":"有","k87":"有","k88":"有"},"Other":{"k89":"10","k90":"0","k91":"0","k92":"0","k93":"0","k94":"0","k95":"0","k96":"0","k97":"0","k98":"2018-02-02","k99":"无","k100":"5000000","k101":"550000.00","k103":"5","k104":"5","k105":""}}`,
	}

}

func GetDefaultApprovalLog() *ApprovalLog {
	return &ApprovalLog{
		ApprovalJinjianId: "ttrdgffdgd765",
		ApprovalStatus:    "初审抢单",
		ApprovalName:      "业务员1",
		ApprovalDesc:      "",
	}
}

func GetDefaultApprovalCsResult() *ApprovalCsResult {
	return &ApprovalCsResult{
		CognizanceIncome: "np",
		//认定负债
		CognizanceLiabilities: "np",
		//资产情况
		AssetSituation: "np",
		//贷记卡是否最低还款
		DebitCardIsMinRepay: "no",
		//征信逾期情况
		OverdueInvestigation: "no",
		//逾期原因
		OverdueReason: "no",
		//电核和流水判断
		DhLs: "no",
		//其他
		Other: "",
		//客户姓名
		Name: "sss",
		//审批id
		ApprovalId:     999,
		ApprovalNumber: "342423423",
		//审批是否通过
		ApprovalStatusIsPass: "y",
		//固定还款日
		RepaymentDate: "2017-06-21",
		//贷款金额
		LoanAmount: "10000000",
		// 贷款期限（月，不含调节期）
		LoanTerm: "12",
		//初审人员
		CsName:       "sdds",
		PayBankName:  "香蕉银行",
		PayBankNum:   "1111233344555666772234234123",
		ChoiceReason: "因为有钱",
	}
}

func GetDefaultUploadApprovalFile() *ApprovalUploadFile {
	return &ApprovalUploadFile{
		ApprovalId: 1,
		//进件id
		JinjianId: "qy-234132131",
		//文件名
		FileName: "xxx量化变量",
		//材料类型
		FileType: "量化变量",
		//材料url
		FileUrl: "/upload/qy-234132131/量化变量.xls",
	}
}

func GetDefaultThreePartyInfo() *ThreePartyInfo {
	return &ThreePartyInfo{
		JinjianId: "test1",
		// 居住地址
		UserAddress: "111111",
		// 身份证号
		UserIdNum: "111111",
		// 客户手机号
		UserCellphone: "111111",
		// 联系人手机号
		ContactCellphone:    "111111",
		SecContactCellphone: "111111",
		// 单位名称
		Company: "111111",
		// 单位地址
		CompanyAddress: "111111",
		// 单位电话
		CompanyPhone: "111111",
		// ----------------------------------------------
		ThreeFalse: 1,
		// 工商网
		GsCompanyResult: 1,
		// 百度
		BdAddressResult: 1,
		BdIdNumResult:   1,

		BdUserPhoneResult: 1,

		BdContactPhoneResult:    1,
		BdSecContactPhoneResult: 1,

		BdCompanyResult:     2,
		BdCompanyResultDesc: "42423fssdfds",

		BdCompanyAddressResult: 1,

		BdCompanyPhoneResult: 3,
		// 人法
		RfIdNumResult: 1,

		RfCompanyResult: 1,
		// 失信
		SxIdNumResult: 1,

		SxCompanyResult: 1,
		Desc:            "ssss",
	}
}

func GetDefaultApprovalUserInfoSup() *ApprovalUserInfoSup {
	return &ApprovalUserInfoSup{
		JinjianId:         "AAAAA",
		FamilyInfo:        "AAAAA",
		EducationInfo:     "AAAAA",
		HouseholdCity:     "AAAAA",
		CompanySize:       "AAAAA",
		CompanyType:       "AAAAA",
		CompanyLine:       "AAAAA",
		CompanyDepartment: "AAAAA",
		FirstWorkTime:     "AAAAA",
	}
}

func GetDefaultApprovalFile() *ApprovalFile {
	return &ApprovalFile{
		JinjianId: "AAAAA",
		FileName:  "测试文件",
		FileType:  "txt",
		FileUrl:   "/usr/local/.db/mysql.pas",
	}
}

func GetDefaultApprovalCallRecord() *ApprovalCallRecord {
	return &ApprovalCallRecord{
		JinjianId: "sdsdsd",
		Number:    "dfsfds",
		CallType:  "cs",
		Desc:      "dffffsfdsfdsfdsfdsfdsfdsf",
	}

}

func GetDefaultApprovalChannelManager() *ApprovalChannelManager {
	return &ApprovalChannelManager{
		ApprovalOrderID: 1000,
		ChannelManager:  "测试渠道经理",
	}
}

func GetDefaultPreApprovalOrder() *PreApprovalOrder {
	return &PreApprovalOrder{
		PreApprovalID:       "31232132",
		PreApprovalType:     QD_PREAPPROVAL,
		IsFast:              "",
		UserIdNum:           "0987",
		UserName:            "测试",
		AgencyName:          "启元优享",
		AgencyEmployeeId:    "uut32",
		AgencyEmployee:      "渠道01",
		PreApprovalFile:     `{"file":[{"f1": "/assets/uploads/images/idCard/b200fbc9-9f02-44ad-9210-01c30d09b167.jpg"}]}`,
		IntroductionPlanNum: `{"a": "a"}`,
		JinjianPlan:         `{}`,
	}
}

// 面签测试使用
func GetTestApprovalOrderByInterview() *ApprovalOrder {
	return &ApprovalOrder{
		ShowId:              "show_258025802580",
		UserIdNum:           "789789789789798",
		ChannelManager:      `["哈哈"]`,
		InterViewManager:    `["嘻嘻"]`,
		JinjianId:           "order_20170616007",
		JinjianUserId:       "13570582709",
		JinjianUserName:     "用户001",
		AgencyName:          "深圳前海神马金融服务有限公司",
		AgencyEmployeeId:    "1234567",
		AgencyEmployee:      "业务员1",
		LoanAmount:          100000000,
		LoanTerm:            12,
		ApprovalAddContacts: "",
		AllInfo:             `{"salary_bank":[{"isCrawled":true,"orgId":"010003_20","password":null,"cardNo":"6222034000005392240","updatedAt":"2018-02-09 17:34:45","cellphone":"18718686929","status":"1","orderId":"1547","bank":"工商银行","bankCity":null,"bankProv":null,"createdAt":"2018-02-09 17:34:45","id":2477,"isJump":false,"userId":1639,"account":"18718686929"},{"bankProv":null,"updatedAt":"2018-02-09 17:46:07","cellphone":"18718686929","status":"1","isJump":true,"userId":1639,"orgId":"010008d_10","bankCity":null,"account":"18718686929","createdAt":"2018-02-09 17:46:07","bank":"招商银行(储蓄卡)","cardNo":"6225880001540120","password":null,"id":2479,"isCrawled":true,"orderId":"1547"}],"other_bank":null,"other_call":null,"credit_files":[{"id":1523,"createdAt":"2018-02-09 17:47:30","updatedAt":"2018-02-09 17:47:47","orderId":1547,"userId":1639,"fileType":"marriage","status":"1","file":"assets/uploads/images/creditFile/0091c7bc-fc81-47f5-bd27-7b639ec7d38c"},{"createdAt":"2018-02-09 17:47:44","updatedAt":"2018-02-09 17:47:47","orderId":1547,"userId":1639,"fileType":"houseFace","status":"1","file":"assets/uploads/images/creditFile/0efd036e-237c-4a61-8063-340cba2e1bd0","id":1525}],"idcard_info":{"cellphone":null,"userId":1639,"id":1521,"backPhoto":"/assets/uploads/images//idCard/Mwi5GUpdb-J7Kvp3VJMYhvj1r3Rjn1KLKZrz8GJN8P1QHuB0CugUwnEtWOwzT4ZW.jpg","bankNo":null,"status":"1","facePhoto":"/assets/uploads/images//idCard/81CJG_TxdSrjKTqTC-GeZyXVfJ7N4dxoPI5Dz7i36i9I_sthELdKxUUZR5W2bro8.jpg","number":"350102198101034117","name":"庄友栩","updatedAt":"2018-02-09 17:16:40","createdAt":"2018-02-09 17:16:40","orderId":"1547"},"personal_info":{"companyType":null,"education":null,"workplacePhone":"0755-32857781","usage":"经营","address":"广东省 深圳市 福田区","companySize":null,"workplace":"深圳市托思达教育文化交流有限公司","addressCity":null,"monthlyCost":"5600000","hasCarLoan":"有","hasHouseLoan":"无","id":1509,"jobAt":null,"hasChildren":null,"job":"股东","orderId":"1547","houseType":"买房已结清","detailAddress":"益田路3006号皇庭世纪花园丽景阁3A","workDetailAddress":"嘉里建设广场1座3层33单元","marriage":"已婚","hasCar":"有","monthlyIncome":"80000","updatedAt":"2018-02-09 17:23:46","workAddress":"广东省 深圳市 福田区","wxNo":"youxuzhuang","userId":1639,"createdAt":"2018-02-09 17:23:46","hasHouse":"有","department":null,"status":"1"},"call_record":{"cellphone":"18617003388","isBuLu":false,"status":"1","orderId":"1547","updatedAt":"2018-02-09 17:26:55","password":null,"isJump":false,"id":1701,"createdAt":"2018-02-09 17:26:55","isCrawled":true,"userId":1639,"cellphoneQCellCore":"广东联通 深圳"},"contacts":{"primaryRelation":"配偶","primaryName":"尹莉","id":1473,"orderId":"1547","secondaryPhone":"18028080818","primaryPhone":"13632555897","secondaryPhoneQCellCore":"广东电信 广州","primaryAddr":"深圳市福田区皇庭世纪花园丽景阁3A","userId":1639,"secondaryName":"王晓文","createdAt":"2018-02-09 17:30:59","secondaryRelation":"朋友","updatedAt":"2018-02-09 17:30:59","status":"1","secondaryAddr":"广州市天河区","primaryPhoneQCellCore":"广东移动 深圳"}}`,
		OrderInfo:           `{"backInfo":null,"isCallBuLu":false,"signAt":null,"creditReportPath":null,"id":1547,"terms":24,"brokerCompany":"有道咨询服","repayDate":null,"amount":20000000,"isOpenSignature":false,"approvalAmount":null,"rejectTime":null,"applyResult":null,"backItem":null,"realLoanAmount":null,"accountId":null,"rstUserId":null,"brokerPhone":"13129545656","userPhone":"18718686929","brokerCompanyId":18,"chanelManagers":["王刘贺","杨丽璇"],"finishCallBulu":false,"approvalStatus":null,"customerRejectTime":null,"loanTime":null,"passTime":null,"brokerId":24,"isBuLu":false,"loanCard":null,"status":8,"userId":1639,"realAmount":null,"createdAt":"2018-02-09 17:14:54","idNo":"350102198101034117","finishBulu":false,"statusUpdatedAt":"2018-02-09T09:47:50.044Z","pendingTime":null,"managers":["李兴隆","黄子杰","万翠蓉","面签廖丽珊","王刘贺"],"loanBank":null,"orderId":"order_1518167694768","isSpBuLu":false,"brokerName":"杨正伟","adjustRepayAmount":null,"isInterviewPass":false,"userName":"庄友栩","isSpCallBuLu":false,"showOrderId":"S_qy20180209004","bankName":null,"commitTime":"2/9/2018, 5:47:50 PM","cancelTime":null,"loanAmount":null,"rate":null,"updatedAt":"2018-02-09 17:16:39","refuseReason":null,"loanType":null}`,
		InterView:           "",
		ProductId:           "qy_001",
		ProductName:         "启元",
		CaSwitch:            "off",
		FundSide:            "洋葱先生",
		ProductPlan:         `{"id":3,"created_at":"2017-11-16T21:04:39+08:00","updated_at":"2018-02-07T16:52:23+08:00","deleted_at":null,"scheme_id":"qy_001","name":"启元优享","config_info":"{\"annual_rate_array\":[15,15],\"terms_array\":[12,24],\"amount_start\":5,\"amount_stop\":20}","terms_array":"[12,24]","amount_start":5,"amount_stop":20,"fund_side":"[\"洋葱先生\",\"粤财\"]","jump_password":"DuwnxBnQ/iTlPJAzjNyLxg==","signature":false,"data_source":"{\"fu_shu_way_call\":\"api\",\"fu_shu_ratio_call\":\"100\",\"rong_360_ratio_call\":\"0\",\"rong_360_way_call\":\"H5\",\"fu_shu_way_bank\":\"api\",\"fu_shu_ratio_bank\":\"100\",\"rong_360_way_bank\":\"H5\",\"rong_360_ratio_bank\":\"0\"}","sms_service":"lingkai","remarks":"","status":"is use","fund_side_config_list":null,"fund_side_config":{"id":3,"created_at":"2018-01-31T20:21:06+08:00","updated_at":"2018-02-06T09:16:10+08:00","deleted_at":null,"fund_side":"洋葱先生","loan_chan":"ycxs","repay_rule":"flb","repayment_strategy":"等额本息 公式：每月还贷款 =（贷款本金*月利率*（1+月利率）^贷款期限/（1+月利率）^贷款期限-1）+ 贷款本金*每月平台服务费率","annual_rate_terms":"{\"12\":15,\"24\":15}","first_do_not_pay_in":0,"overdue_formula":"固定利率","overdue_ratio":0.1,"overdue_platform_pay_base":0,"settle_split":36,"rate_before_settle_split":3,"customer_loan_fees_rate":3,"customer_loan_fees":0,"qiyuan_loan_fees_rate":2.8,"qiyuan_loan_fees":0,"fund_side_loan_fees_rate":0.2,"fund_side_loan_fees":0,"contract_mould_id":0,"auth_book_mould_id":0,"deducted_service":"yeepay_yibao","customer_repayment_service":"yeepay_yibao","customer_repayment_frequency":"","contract_mould_list":null,"auth_book_mould_list":null}}`,
		IsStandard:          "1",
		PlanNum:             "001",
		//RiskParam:`{"k10_02":null,"k9_03":4056800,"k5_03":"72.04%","k12_03":"28%","k7_02":"14006.73","k6_02":"25210","k1_03":"他行房贷","k4_01":"0","k2_01":"2015-3-11","k2_06":"3450000","k5_02":"341472","k1_02":"500000","k8_02":"19995","k2_03":"建设","k2_05":"31","k10_01":"45.03%","k7_01":"267800","k3_03":"0","k9_01":1469272,"k13_01":0,"k11_01":"1","k10_03":"85.35%","k13_02":24,"k3_02":"月供*12","k9_02":73363.73,"k1_01":"2017-9-22","k8_01":"2455000","k9_04":93358.73,"k3_01":"162924","k2_02":"2455000","k6_01":"860000","k4_02":4753392,"k2_04":"2015-3-3","k5_01":"474000","k12_01":"审慎"}`,
		RiskParam: `{"r12":"0","r30":0.6,"r24":5000,"version":"v1.0","r13":"NaN","r27":96.6,"r11":"NaN","r26":18.46,"r22":5000,"r25":23.51,"r16":5000,"r14":"500","r3":35000,"r28":"50000","r9":"50000","r15":[{"type":"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK","content":{"loanDate":"1994-12-11","loanAmount":"5000","monthlyRepayment":"5000","loanBalance":"5000","remainingPeriod":"12","loanAgency":"额达去"}},{"type":"DEBT_TYPE_XXX_LOANS_PEOPLE_BANK","content":{"loanDate":"1994-12-11","loanAmount":"5000","monthlyRepayment":"5000","loanBalance":"5000","remainingPeriod":"12","loanAgency":"额达去111"}}],"r8":"8000","r19":0,"r23":5000,"r21":0,"r17":5000,"r1":"OTHER_LOAN","r20":0,"r5":[{"name":"的","amount":"10000"}],"r4":80000,"r29":24,"r10":"10000000","r6":"8000","r18":5000,"r7":298000,"r2":[{"name":"房产贷（单独所有）","content":{"house_valuation":1000000,"house_address":"深证","house_register_data":"2010-01-02"}}]}`,
		//RiskParam:`{"r12":"0","r30":0.6,"r24":5000,"version":"v1.0","r13":"NaN","r27":96.6,"r11":"NaN","r26":18.46,"r22":5000,"r25":23.51,"r16":5000,"r14":"500","r3":35000,"r28":"50000","r9":"0","r15":[{"type":"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK","content":{"loanDate":"1994-12-11","loanAmount":"5000","monthlyRepayment":"5000","loanBalance":"5000","remainingPeriod":"12","loanAgency":"额达去"}}],"r8":"8000","r19":0,"r23":5000,"r21":0,"r17":5000,"r1":"OTHER_LOAN","r20":0,"r5":[{"name":"的","amount":"10000"}],"r4":80000,"r29":24,"r10":"0","r6":"8000","r18":5000,"r7":298000,"r2":{"name":"保单贷（满5年）","policyList":[{"policy_valid_total":1,"policy_amount_total":20000,"policy_name":"天天平安","policy_amount":20000,"payment_method":"年缴","policy_effective_date":"2018-01-26","is_valid":1,"payment_times":3,"policy_total":1,"policy_number":"S123456789"}]}}`,
		QuantizationMap: `
{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`,
	}

}

// 获取匹配记录
func GetTestMatchedIdCardsCheckRecord() *IdCardsCheckRecord {
	return &IdCardsCheckRecord{
		JinjianId: "J20170616007", IdCard: "51650461012345", Name: "渣渣辉", Result: "matched",
	}
}

// 获取不匹配记录
func GetTestUnmatchedIdCardsCheckRecord() *IdCardsCheckRecord {
	return &IdCardsCheckRecord{
		JinjianId: "J20170616007", IdCard: "51650461012300", Name: "渣渣辉", Result: "unmatched",
	}
}

func GetTestCompleteApprovalOrder() *ApprovalOrder {
	ao := GetDefaultApprovalOrder()
	ao.LoanBankName = "放款银行名字"
    ao.LoanCard = "xxx"
	ao.CardOnePhone = "13145828888"
	ao.PlatformMonthRate = 0.5
	return ao
}