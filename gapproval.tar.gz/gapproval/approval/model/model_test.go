package model

import (
	"testing"
	"fmt"
	"gcoresys/common/util"
)

func TestShowModel(t *testing.T) {
	//fmt.Println(util.StringifyJson(UserByOpenIdHandlerResp{User: &model.PreUser{}}))
	//fmt.Println(util.StringifyJson(NewPreOrderHandlerReq{}))
	//fmt.Println(util.StringifyJson(NewPreOrderHandlerResp{Order: &model.PreOrder{}}))
	//fmt.Println(util.StringifyJson(model.PreChannelApprovalOrder{Files: []*model.PreChannelApprovalFile{{}}}))
	//fmt.Println(util.StringifyJson(CreatePreApprovalOrderResp{}))
	//fmt.Println(util.StringifyJson(GetPreChannelApprovalOrdersResp{Orders: []*model.PreChannelApprovalOrder{{}}}))
	//fmt.Println(util.StringifyJson(GetDetailedOrderInfoByOrderIdResp{Order: &model.PreChannelApprovalOrder{}, }))
	//fmt.Println(util.StringifyJson(WldReq{OutOrderID:"1", ReturnURL:"url"}))
	//fmt.Println(util.StringifyJson(WldResp{URL:""}))
	//fmt.Println(util.StringifyJson(GetChanAndManagersInfoResp{Managers: []*model.NqiyuanUserInfo{{}}, ChanUsers: []*model.NqiyuanUserInfo{{}}}))
	fmt.Println(util.StringifyJson(ApprovalOrder{}))
}