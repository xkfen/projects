package serviceV1

import (
	"gapproval/common/httpReq"
	"gapproval/common/global"
	"gcoresys/common/logger"
	"gcoresys/common/util"
	"gapproval/approval/model"
	"gapproval/approval/service"
)

/**
	@author  wangxi
	@dec	流水标签
	@time 2017年11月20日11:25:19
 */

func ProxyRisCtrlFlowTag(jinjianId, name, method string, param map[string]interface{}) (respResult map[string]interface{}, err error) {
	respResult, err = httpReq.PostJsonProxy(param, global.GetRiskControlServerUrl()+"/api/v1/flow_tag/"+method)
	if err != nil {
		logger.Error("========请求风控流水标签出错: " + err.Error())
		return
	}
	if !respResult["success"].(bool) {
		logger.Error("=======风控流水标签返回出错: " + util.StringifyJson(respResult))
		return
	}
	if jinjianId != "" && name != "" {
		service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: jinjianId, ApprovalName: name,
			ApprovalStatus: name + "操作流水标签" + getASByMethod(method), ApprovalType: "ob"})  // 这里记录先，在前端先不展示，以防万一
	}
	return
}

func getASByMethod(method string) (result string) {
	switch method {
	case "real_new_field_tag":
		result = "实时流水打标"
	case "new_field_tag":
		result = "新增流水标签"
	case "delete_field_tag_key_word":
		result = "删除流水标签关键字"
	case "delete_field_tag":
		result = "删除流水标签"
	case "do_resolve":
		result = "执行标签仲裁"
	case "new_flow_result_tag_lib":
		result = "新增标签"
	case "is_conflict_tags":
		result = "批量检查冲突"
	case "new_field_tags_for_flow":
		result = "批量新增标签"
	}
	return
}
