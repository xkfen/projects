package serviceV1

import (
	"gapproval/approval/model"
	"fmt"
	"testing"
	"github.com/stretchr/testify/assert"
	"gapproval/approval/db/config"
	ivModel "gapproval/interview/model"
	"gcoresys/common/logger"
	"gcoresys/common/util"
)

func (s *testingSuite) TestGetNeedInterviewApprovalList() {
	ao1 := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao1))
	ao2 := model.GetDefaultApprovalOrder()
	ao2.JinjianId = ao2.JinjianId + "2"
	s.NoError(NewApprovalOrder(ao2))
	ao3 := model.GetDefaultApprovalOrder()
	ao3.JinjianId = ao3.JinjianId + "3"
	ao3.InterView = `{}`
	ao3.InterViewStatus = model.ApprovalStatusInterViewing
	ao3.InterViewTrailId = "ttt"
	ao3.InterViewTrailName = "喃喃啊"
	s.NoError(NewApprovalOrder(ao3))

	params := ivModel.InterviewListReqParams{
		TypeKey:  "all",
		Page:     1,
		PerPage:  10,
		Name:     "面签001",
		Username: "iv001",
	}

	list, t, c, err := GetNeedInterviewApprovalList(params)
	s.NoError(err)
	s.Equal(3, len(list))
	s.Equal(3, c)
	s.Equal(1, t)
}

func (s *testingSuite) TestGetNeedInterviewApprovalList1() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))

	params := ivModel.InterviewListReqParams{
		TypeKey:  "all",
		Page:     1,
		PerPage:  10,
		Name:     "面签001",
		Username: "iv001",
	}

	list, t, c, err := GetNeedInterviewApprovalList(params)
	s.NoError(err)
	s.Equal(1, len(list))
	s.Equal(1, c)
	s.Equal(1, t)
}

func (s *testingSuite) TestGetNeedInterviewApprovalList2() {
	ao1 := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao1))
	ao2 := model.GetDefaultApprovalOrder()
	ao2.JinjianId = ao2.JinjianId + "2"
	ao2.ShowId = ao2.ShowId + "2"
	s.NoError(NewApprovalOrder(ao2))
	ao3 := model.GetDefaultApprovalOrder()
	ao3.JinjianId = ao3.JinjianId + "3"
	ao3.ShowId = ao3.ShowId + "3"
	ao3.InterView = `{}`
	ao3.InterViewTrailId = "ttt"
	ao3.InterViewTrailName = "喃喃啊"
	s.NoError(NewApprovalOrder(ao3))

	params := ivModel.InterviewListReqParams{
		TypeKey:   "all",
		Condition: ao2.ShowId,
		Page:      1,
		PerPage:   10,
		Name:      "面签001",
		Username:  "iv001",
	}

	list, t, c, err := GetNeedInterviewApprovalList(params)
	s.NoError(err)
	s.Equal(1, len(list))
	s.Equal(1, c)
	s.Equal(1, t)
}

func (s *testingSuite) TestGetNeedInterviewApprovalList3() {
	params := ivModel.InterviewListReqParams{
		TypeKey: "new",
		Page:    1,
		PerPage: 10,
	}

	_, _, _, err := GetNeedInterviewApprovalList(params)
	s.NotNil(err)
}
func TestInterViewCancel(t *testing.T) {
	oneStepTest(
		func() {
			ao := model.GetDefaultApprovalOrder()
			ao.FirstTrailStatus = model.ApprovalStatusInterViewing
			ao.InterViewStatus = model.ApprovalStatusInterViewing

			ao.InterViewTrailId = "test001"
			ao.InterViewTrailName = "测试面签"

			assert.NoError(t, NewApprovalOrder(ao))
			assert.NoError(t, InterViewCancel(ao.JinjianId, ao.InterViewStatusDes))

			aR, _, err := GetApprovalOrder(ao.JinjianId)

			assert.NoError(t, err)

			assert.Equal(t, model.ApprovalStatusInterViewCancel, aR.InterViewStatus)
			assert.Equal(t, model.ApprovalStatusInterViewCancel, aR.FirstTrailStatus)
			assert.Equal(t, "撤销", aR.ApprovalStatus)
		},
	)
}

func TestInterViewCancelFtBack(t *testing.T) {
	oneStepTest(
		func() {
			ao := model.GetDefaultApprovalOrder()
			ao.FirstTrailStatus = model.ApprovalStatusFirstTrailBackIv
			ao.InterViewStatus = model.ApprovalStatusFirstTrailBackIv

			ao.InterViewTrailId = "test001"
			ao.InterViewTrailName = "测试面签"

			assert.NoError(t, NewApprovalOrder(ao))
			assert.NoError(t, InterViewCancel(ao.JinjianId, ao.InterViewStatusDes))

			aR, _, err := GetApprovalOrder(ao.JinjianId)

			assert.NoError(t, err)

			assert.Equal(t, model.ApprovalStatusInterViewCancel, aR.InterViewStatus)
			assert.Equal(t, model.ApprovalStatusFirstTrailBackIv, aR.FirstTrailStatus)
			assert.Equal(t, "撤销", aR.ApprovalStatus)
		},
	)
}

func TestInterViewCancelRtBack(t *testing.T) {
	oneStepTest(
		func() {
			ao := model.GetDefaultApprovalOrder()
			ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
			ao.ReTrailStatus = model.ApprovalStatusReTrailBackIv
			ao.InterViewStatus = model.ApprovalStatusReTrailBackIv

			ao.InterViewTrailId = "test001"
			ao.InterViewTrailName = "测试面签"

			assert.NoError(t, NewApprovalOrder(ao))
			assert.NoError(t, InterViewCancel(ao.JinjianId, ao.InterViewStatusDes))

			aR, _, err := GetApprovalOrder(ao.JinjianId)

			assert.NoError(t, err)

			assert.Equal(t, model.ApprovalStatusInterViewCancel, aR.InterViewStatus)
			assert.Equal(t, model.ApprovalStatusReTrailBackIv, aR.ReTrailStatus)
			assert.Equal(t, "撤销", aR.ApprovalStatus)
		},
	)
}

func TestInterViewRepulse(t *testing.T) {
	oneStepTest(
		func() {
			ao := model.GetDefaultApprovalOrder()
			ao.FirstTrailStatus = model.ApprovalStatusInterViewing
			ao.InterViewStatus = model.ApprovalStatusInterViewing

			ao.InterViewTrailId = "test001"
			ao.InterViewTrailName = "测试面签"

			assert.NoError(t, NewApprovalOrder(ao))
			assert.NoError(t, InterViewRepulse(ao.JinjianId, `["身份证"]`, "身份证错误"))

			aR, _, err := GetApprovalOrder(ao.JinjianId)

			assert.NoError(t, err)

			assert.Equal(t, model.ApprovalStatusInterViewRepulse, aR.InterViewStatus)
			assert.Equal(t, model.ApprovalStatusInterViewing, aR.FirstTrailStatus)
			assert.Equal(t, model.AgencyStatusRepulse, aR.AgencyStatus)
		},
	)
}

func (s *testingSuite) TestGrabInterview() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	err := GrabInterview(ao.JinjianId, "test", "测试")
	s.NoError(err)

	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.Equal(aR.InterViewTrailId, "test")
	s.Equal(aR.InterViewTrailName, "测试")
	s.Equal(aR.InterViewStatus, model.ApprovalStatusInterViewing)
	s.Equal(aR.FirstTrailStatus, model.ApprovalStatusInterViewing)
}

func TestUpdateInterviewToApproval(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	config.ClearAllData()

	ao := model.GetDefaultApprovalOrder()
	assert.NoError(t, NewApprovalOrder(ao))
	interview := ivModel.GetTestInterviewComplete()
	interview.JinjianId = ao.JinjianId
	ao.InterView = ivModel.GetTestInterviewIncompleteString()
	interview.OtherFile = nil
	assert.NoError(t, UpdateApprovalInterview(interview))

	var db model.ApprovalOrder
	assert.NoError(t, config.GetDb().Model(ao).Where("jinjian_id=?", ao.JinjianId).First(&db).Error)

	var dbIV ivModel.Interview
	assert.NoError(t, util.ParseJson(db.InterView, &dbIV))
	assert.Equal(t, interview.Comment, dbIV.Comment)
	assert.Equal(t, interview.LoanBank, dbIV.LoanBank)
	assert.NotEqual(t, nil, dbIV.OtherFile)

	config.ClearAllData()
}

func TestCopyStructWithValue(t *testing.T) {

	ao := ivModel.GetTestInterviewComplete()
	ao2 := ivModel.GetTestInterviewComplete()
	ao2.IsStandard = "成功"

	copyInterviewWithValue(ao2, &ao)
	assert.Equal(t, "成功", ao.IsStandard)

	ao3 := ivModel.Interview{JinjianPlan: "再次成功"}

	cpao := ao
	cpao.JinjianPlan = ao3.JinjianPlan

	copyInterviewWithValue(ao3, &ao)

	assert.Equal(t, ao3.JinjianPlan, ao.JinjianPlan)
	assert.Equal(t, cpao, ao)
}

func TestUpdateJinjianOrderInfo(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	config.ClearAllData()

	ao := model.GetDefaultApprovalOrder()
	ao.InterViewTrailId = "test"
	assert.Equal(t, nil, NewApprovalOrder(ao))

	params := ivModel.OrderInfoReqParams{
		OrderId: ao.JinjianId,
		Info:    "all_info",
		TopKey:  "personal_info",
		Key:     "wxNo",
		Value:   "ssssssssssssssss",
	}
	order, err := GetApprovalOrderInfoByJinjianId(ao.JinjianId, ao.InterViewTrailId)
	assert.Equal(t, nil, err)
	assert.NotEqual(t, nil, order)

	err = UpdateJinjianOrderInfo(params, order)
	assert.Equal(t, nil, err)

	order2, err := GetApprovalOrderInfoByJinjianId(ao.JinjianId, ao.InterViewTrailId)
	assert.Equal(t, nil, err)
	assert.NotEqual(t, order.AllInfo, order2.AllInfo)
}

func TestAddContactsInfo000(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	config.ClearAllData()

	ao := model.GetDefaultApprovalOrder()
	ao.InterViewTrailId = "test"
	assert.Equal(t, nil, NewApprovalOrder(ao))

	params := []ivModel.ContactsReqParams{
		{
			Name:         "test",
			Phone:        "123123",
			Relationship: "wxNo",
			Address:      "12312313",
		},
	}
	err := AddContactsInfo(params, -1, ao.JinjianId, "test")
	assert.Equal(t, nil, err)

	order2, err := GetApprovalOrderInfoByJinjianId(ao.JinjianId, ao.InterViewTrailId)
	assert.Equal(t, nil, err)
	assert.NotEqual(t, ao.ApprovalAddContacts, order2.ApprovalAddContacts)

	err = util.ParseJson(order2.ApprovalAddContacts, &params)
	assert.Equal(t, nil, err)
	assert.Equal(t, 2, len(params))

	logger.Info("data", "ApprovalAddContacts", order2.ApprovalAddContacts)
}

func TestUpdateAddContactsInfo00022(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	config.ClearAllData()

	ao := model.GetDefaultApprovalOrder()
	ao.InterViewTrailId = "test"
	assert.Equal(t, nil, NewApprovalOrder(ao))

	params := []ivModel.ContactsReqParams{
		{
			Name:         "test",
			Phone:        "123123",
			Relationship: "wxNo",
			Address:      "12312313",
		},
	}
	err := AddContactsInfo(params, 0, ao.JinjianId, "test")
	assert.Equal(t, nil, err)

	order2, err := GetApprovalOrderInfoByJinjianId(ao.JinjianId, ao.InterViewTrailId)
	assert.Equal(t, nil, err)
	assert.NotEqual(t, ao.ApprovalAddContacts, order2.ApprovalAddContacts)
	assert.Equal(t, util.StringifyJson(params), order2.ApprovalAddContacts)
	logger.Info("data", "ApprovalAddContacts", order2.ApprovalAddContacts)
}

func TestInterViewSuspending(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusInterViewing
		ao.InterViewStatus = model.ApprovalStatusInterViewing

		ao.InterViewTrailId = "test001"
		ao.InterViewTrailName = "测试面签"

		assert.NoError(t, NewApprovalOrder(ao))

		assert.NoError(t, InterViewSuspending(ao.JinjianId, "开启挂起"))

		aR, _, err := GetApprovalOrder(ao.JinjianId)

		assert.NoError(t, err)

		assert.Equal(t, "on", aR.InterViewSuspending)
		assert.Equal(t, "开启挂起", aR.InterViewSuspenseDesc)

	})
}

func TestInterViewSuspendingErr(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusInterViewing
		ao.InterViewStatus = model.ApprovalStatusInterViewing

		ao.InterViewTrailId = "test001"
		ao.InterViewTrailName = "测试面签"

		assert.NoError(t, NewApprovalOrder(ao))

		assert.EqualError(t, InterViewSuspending(ao.JinjianId, ""), "挂起原因不能为空")

	})
}

func TestOffInterViewSuspending(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailStatus = model.ApprovalStatusInterViewing
		ao.InterViewStatus = model.ApprovalStatusInterViewing

		ao.InterViewTrailId = "test001"
		ao.InterViewTrailName = "测试面签"

		assert.NoError(t, NewApprovalOrder(ao))

		assert.NoError(t, InterViewSuspending(ao.JinjianId, "开启挂起"))

		aR, _, err := GetApprovalOrder(ao.JinjianId)

		assert.NoError(t, err)

		assert.Equal(t, "on", aR.InterViewSuspending)
		assert.Equal(t, "开启挂起", aR.InterViewSuspenseDesc)

		aR1, err := OffInterViewSuspending(aR)

		assert.NoError(t, err)

		assert.Equal(t, "off", aR1.InterViewSuspending)
		assert.Equal(t, "", aR1.InterViewSuspenseDesc)
	})
}

//func TestUpdateJinJianPlanToInterviewStr(t *testing.T) {
//	oneStepTest(func() {
//		ao := model.GetDefaultApprovalOrder()
//		ao.JinjianId = "123"
//		ao.InterView = ivModel.GetTestInterviewCompleteString()
//		assert.NoError(t, NewApprovalOrder(ao))
//		ivStr, err := updateJinJianPlanToInterviewStr(ao.JinjianId, "测试 修改 是否成功?")
//		assert.Equal(t, nil, err)
//		var jsonMap map[string]interface{}
//		assert.NoError(t, util.ParseJson(ivStr, &jsonMap))
//		assert.Equal(t, "测试 修改 是否成功?", jsonMap["jinjian_plan"])
//		assert.Equal(t, ao.JinjianId, jsonMap["jinjian_id"])
//	})
//}

func TestUpdateJinjianPlan(t *testing.T) {
	oneStepTest(func() {
		newIv, err := updateJinjianPlan(util.StringifyJson(&ivModel.Interview{}), `{"a":"b"}`)

		assert.NoError(t, err)

		fmt.Println(newIv)
	})
}

func TestIvManageAdditionalRecord(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		ao.InterViewTrailId = "iv001"
		ao.InterViewTrailName = "面签001"
		ao.FirstTrailStatus = model.ApprovalStatusInterViewing
		ao.InterViewStatus = model.ApprovalStatusInterViewing
		assert.NoError(t, NewApprovalOrder(ao))
		aR, _, err := GetApprovalOrder(ao.JinjianId)
		assert.NoError(t, err)
		//s.Equal(model.ApprovalStatusWaitFirstTrail, aR.FirstTrailStatus)
		assert.NoError(t, IvManageAdditionalRecord(aR.JinjianId, "bank", "r360","open", "jj", map[string]interface{}{"salary_bank1": "sssfdfss"}))
		aR, _, err = GetApprovalOrder(ao.JinjianId)
		assert.Equal(t, true, aR.AdditionalRecord)
		assert.NoError(t, IvManageAdditionalRecord(aR.JinjianId, "bank", "r360","close", "jj", map[string]interface{}{"salary_bank1": "sssfdfss"}))
		aR, _, err = GetApprovalOrder(ao.JinjianId)
		assert.Equal(t, false, aR.AdditionalRecord)
	})
}

// 测试修改期数
func TestChangeTerms(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		ao.InterViewTrailId = "iv001"
		ao.InterViewTrailName = "面签001"
		ao.FirstTrailStatus = model.ApprovalStatusInterViewing
		ao.InterViewStatus = model.ApprovalStatusInterViewing
		ao.LoanTerm = 24

		assert.NoError(t, NewApprovalOrder(ao))

		params := ivModel.OrderInfoReqParams{
			OrderId: ao.JinjianId,
			Info:    "order_info",
			Key:     "terms",
			Value:   12,
		}
		order, err := GetApprovalOrderInfoByJinjianId(ao.JinjianId, ao.InterViewTrailId)
		assert.Equal(t, nil, err)
		assert.NotEqual(t, nil, order)
		assert.Equal(t, 24, order.LoanTerm)

		err = UpdateJinjianOrderInfo(params, order)
		assert.Equal(t, nil, err)

		orderNew, err := GetApprovalOrderInfoByJinjianId(ao.JinjianId, ao.InterViewTrailId)
		assert.Equal(t, nil, err)
		assert.NotEqual(t, order.OrderInfo, orderNew.OrderInfo)
		assert.Equal(t, 12, orderNew.LoanTerm)
	})
}
