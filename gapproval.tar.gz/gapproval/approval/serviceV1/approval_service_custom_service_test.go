package serviceV1

import (
	"gapproval/approval/model"
	"gcoresys/common/util"
	"testing"
	"github.com/stretchr/testify/assert"
	"fmt"
)

func (s *testingSuite) TestGetCustomServiceApprovalOrderList() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
	ao.ReTrailName = "终审001"
	ao.ReTrailId = "zs001"
	ao.ReTrailStatus = model.ApprovalStatusReTrailPass
	ao.CustomServiceStatus = model.ApprovalStatusWaitCustomConfirm
	s.NoError(NewApprovalOrder(ao))
	ccList, tp ,_:= GetCustomServiceApprovalOrderList("all", "", "", "",
		"", "", 1)
	s.Equal(true, tp > 0)
	s.Equal(1, len(ccList))
}

func TestNewCallRecordDesc(t *testing.T) {
	oneStepTest(func() {
		assert.NoError(t, NewCSCallRecordDesc("ddddd", "3232", "sdf", "ss","123"))
		assert.NoError(t, NewCSCallRecordDesc("ddddd", "3232", "sdf", "ss","123"))
		assert.Equal(t, 2, len(GetCallRecord("ddddd")))
		fmt.Println(util.StringifyJson(GetCallRecord("ddddd")))
	})
}
