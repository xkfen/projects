package serviceV1

import (
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"gcoresys/common/util"
	"gcoresys/common/logger"
	"errors"
	"time"
	ivModel "gapproval/interview/model"
	"fmt"
	"gcoresys/common"
	"reflect"
	"gcoresys/common/db"
	"github.com/jinzhu/gorm"
	"gapproval/approval/service"
)

/**
	@author  wangxi
	@desc	重构后版本： 这里都是面签函数，处理逻辑业务
	@time 2017-09-06 14:57:10
 */

// 面签开启补录 按钮
func IvManageAdditionalRecord(jinjianId, arType, arChannel, onoff, way string, allInfo map[string]interface{}) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return
	}

	if ao.InterViewStatus != model.ApprovalStatusInterViewing &&
		ao.InterViewStatus != model.ApprovalStatusInterViewExchange &&
		ao.InterViewStatus != model.ApprovalStatusFirstTrailBackIv &&
		ao.InterViewStatus != model.ApprovalStatusReTrailBackIv {
		logger.Error("==================面签撤销状态错误： ", "当前状态: ", ao.InterViewStatus)
		return errors.New("面签状态错误，无法开启补录")
	}

	switch onoff {
	case "open":
		return startAdditionalRecord(ao, arType, arChannel)
	case "close":
		return closeAdditionalRecord(ao, arType, way, allInfo)

	}

	return
}

func closeAdditionalRecord(ao model.ApprovalOrder, arType, way string, allInfo map[string]interface{}) (err error) {
	var aoMap map[string]interface{}
	approvalName := ao.InterViewTrailName
	approvalStatus := "面签关闭补录"
	approvalDesc := "面签手动关闭补录"

	if way == "jj" {
		if err = util.ParseJson(ao.AllInfo, &aoMap); err != nil {
			return
		}
		aoMap["other_bank"] = allInfo["other_bank"]
		aoMap["other_call"] = allInfo["other_call"]

		ao.AllInfo = util.StringifyJson(aoMap)
		approvalName = ao.JinjianUserName
		approvalStatus = "用户完成补录"
	}

	if arType == "bank" {
		ao.AdditionalRecord = false

		if way == "jj" {
			approvalDesc = "完成银行流水补录"
		}

		if err = config.GetDb().Model(&ao).Where("jinjian_id = ?", ao.JinjianId).
			Update(map[string]interface{}{"additional_record": ao.AdditionalRecord,
			"all_info": ao.AllInfo}).Error; err != nil {
			return err
		}
	}

	if arType == "call" {
		ao.CallAdditionalRecord = false

		if way == "jj" {
			approvalDesc = "完成运营商补录"
		}

		if err = config.GetDb().Model(&ao).Where("jinjian_id = ?", ao.JinjianId).
			Update(map[string]interface{}{"call_additional_record": ao.CallAdditionalRecord,
			"all_info": ao.AllInfo}).Error; err != nil {
			return err
		}
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: approvalName,
		ApprovalStatus: approvalStatus, ApprovalType: "mq", ApprovalDesc: approvalDesc})

	return
}

func startAdditionalRecord(ao model.ApprovalOrder, arType, arChannel string) (err error) {
	var approvalName, approvalStatus, approvalDesc string
	if arType == "bank" {
		ao.AdditionalRecord = true
		approvalDesc = "开启银行流水补录"
		ao.AdditionalRecordChannel = arChannel
	}

	if arType == "call" {
		ao.CallAdditionalRecord = true
		approvalDesc = "开启运营商补录"
		ao.CallAdditionalRecordChannel = arChannel
	}

	approvalName = ao.InterViewTrailName
	approvalStatus = "面签审批开启补录"

	if arType == "bank" {
		if err = config.GetDb().Model(&ao).Where("jinjian_id = ?", ao.JinjianId).
			Update(map[string]interface{}{"additional_record": ao.AdditionalRecord,
			"additional_record_channel": ao.AdditionalRecordChannel}).Error; err != nil {
			return err
		}
	}

	if arType == "call" {
		if err = config.GetDb().Model(&ao).Where("jinjian_id = ?", ao.JinjianId).
			Update(map[string]interface{}{"call_additional_record": ao.CallAdditionalRecord,
			"call_additional_record_channel": ao.CallAdditionalRecordChannel}).Error; err != nil {
			return err
		}
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: approvalName,
		ApprovalStatus: approvalStatus, ApprovalType: "mq", ApprovalDesc: approvalDesc})

	return
}

// 面签挂起
func InterViewSuspending(jinjianId, desc string) (err error) {
	logger.Info("======================= 执行面签挂起 =======================")
	if desc == "" {
		return errors.New("挂起原因不能为空")
	}

	var ao model.ApprovalOrder
	if err = config.GetDb().Model(ao).Where("jinjian_id = ?", jinjianId).First(&ao).Error; err != nil {
		return errors.New("未查询到面签单, 请检查是否存在")
	}

	if ao.InterViewStatus != model.ApprovalStatusInterViewing &&
		ao.InterViewStatus != model.ApprovalStatusInterViewExchange &&
		ao.InterViewStatus != model.ApprovalStatusFirstTrailBackIv &&
		ao.InterViewStatus != model.ApprovalStatusReTrailBackIv {
		logger.Error("==================面签撤销状态错误： ", "当前状态: ", ao.InterViewStatus)
		return errors.New("面签状态为:" + ao.InterViewStatus + ",不可挂起")
	}

	ao.InterViewSuspending = "on" // 现在只有开启挂起，解挂在获取订单详情时解挂
	ao.InterViewSuspenseDesc = desc

	if err = config.GetDb().Model(&ao).Update(map[string]interface{}{
		"inter_view_suspending":    "on",
		"inter_view_suspense_desc": desc,
	}).Error; err != nil {
		logger.Error("==================面签挂起操作，UpdateERR：" + err.Error())
		return errors.New("面签挂起失败, 请稍候再试")
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.InterViewTrailName,
		ApprovalStatus: "面签挂起", ApprovalType: "mq", ApprovalDesc: desc})

	// 业务留痕
	//service.AsyncApprovalTrace(ao)
	return
}

// 解除挂起
func OffInterViewSuspending(ao model.ApprovalOrder) (model.ApprovalOrder, error) {
	if ao.InterViewSuspending == "on" {
		ao.InterViewSuspending = "off"
		ao.InterViewSuspenseDesc = ""
		if err := config.GetDb().Model(ao).Update(map[string]interface{}{
			"inter_view_suspending":    ao.InterViewSuspending,
			"inter_view_suspense_desc": ao.InterViewSuspenseDesc,
		}).Error; err != nil {
			logger.Error("=========自动解挂错误====: " + err.Error())
			return ao, errors.New("自动解挂失败, 请稍候再试")
		}
		service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.InterViewTrailName,
			ApprovalStatus: "解除挂起", ApprovalType: "mq"})
	}

	return ao, nil
}

// 面签撤销
func InterViewCancel(jinjianId string, repulseDes string) (err error) {
	logger.Info("======================= 执行面签撤销 =======================")

	var ao model.ApprovalOrder
	if err = config.GetDb().Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return errors.New("未查询到面签单, 请检查是否存在")
	}

	if ao.InterViewStatus != model.ApprovalStatusInterViewing &&
		ao.InterViewStatus != model.ApprovalStatusFirstTrailBackIv &&
		ao.InterViewStatus != model.ApprovalStatusReTrailBackIv &&
		ao.InterViewStatus != model.ApprovalStatusInterViewExchange {
		logger.Error("==================面签撤销状态错误： ", "当前状态: ", ao.InterViewStatus)
		return errors.New("面签状态为:" + ao.InterViewStatus + ",不可撤销")
	}

	data := map[string]interface{}{
		"inter_view_status":     model.ApprovalStatusInterViewCancel, // 面签撤销
		"inter_view_status_des": repulseDes,                          // 面签撤销备注

		"agency_status":          "已撤销",
		"cancel_time":            time.Now(),
		"inter_view_finish_time": time.Now(),
		"approval_status":        "撤销",
	}

	if ao.FirstTrailStatus == model.ApprovalStatusInterViewing {
		data["first_trail_status"] = model.ApprovalStatusInterViewCancel // 面签撤销
	}

	// 更新数据
	if err = config.GetDb().Model(&ao).Update(data).Error; err != nil {
		logger.Error("面签撤销失败", "err", err.Error())
		return errors.New("面签撤销失败, 请稍候再试")
	}

	// 发短信   撤销
	service.SendSms(ao, "cancel", true)

	service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_INTERVIEW)

	// 创建审批记录
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.InterViewTrailName,
		ApprovalStatus: "面签撤销", ApprovalType: "mq", ApprovalDesc: repulseDes})

	return
}

// 面签打回
func InterViewRepulse(jinjianId, repulse, repulseDes string) (err error) {
	logger.Info("======================= 执行面签打回 =======================")

	var ao model.ApprovalOrder
	if err = config.GetDb().Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return errors.New("未查询到面签单, 请检查是否存在")
	}

	if ao.InterViewStatus != model.ApprovalStatusInterViewing &&
		ao.InterViewStatus != model.ApprovalStatusFirstTrailBackIv &&
		ao.InterViewStatus != model.ApprovalStatusReTrailBackIv &&
		ao.InterViewStatus != model.ApprovalStatusInterViewExchange {
		logger.Error("==================面签打回状态错误： ", "当前状态: ", ao.InterViewStatus)
		return errors.New("面签状态为:" + ao.InterViewStatus + ",不可打回")
	}

	if repulse == "" {
		return errors.New("面签打回项不能为空")
	}

	if repulseDes == "" {
		return errors.New("面签打回状态说明不能为空")
	}

	if err = config.GetDb().Model(&ao).Update(map[string]interface{}{
		"first_trail_status_repulse": repulse,
		"first_trail_status_des":     repulseDes,
		"repulse_desc":               repulseDes,
		"agency_status":              model.AgencyStatusRepulse,

		"inter_view_status":     model.ApprovalStatusInterViewRepulse, // 面签打回
		"inter_view_status_des": repulseDes,                           // 面签打回备注

		"approval_repulse_time": time.Now(), // 打回时间
	}).Error; err != nil {
		logger.Error("面签打回失败", "err", err.Error())
		return errors.New("面签打回失败, 请稍候再试")
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.InterViewTrailName,
		ApprovalStatus: "面签打回给用户", ApprovalType: "mq", ApprovalDesc: repulseDes})

	service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_INTERVIEW, model.TP_USERINPUT)

	return
}

// 面签流转 isPassword 判断是普通流转还是密码流转
func InterViewExchange(jinjianId, name, exchangeUser, exchangeName, repulseDes string, isPassword bool) (err error) {
	logger.Info("======================= 执行面签流转 =======================")

	var ao model.ApprovalOrder
	if err = config.GetDb().Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return errors.New("未查询到面签单, 请检查是否存在")
	}

	if ao.InterViewTrailId == "" || ao.InterViewTrailName == "" {
		return errors.New("该订单无人面签,不需要流转")
	}

	if ao.InterViewStatus != model.ApprovalStatusInterViewing &&
		ao.InterViewStatus != model.ApprovalStatusInterViewExchange &&
		ao.InterViewStatus != model.ApprovalStatusFirstTrailBackIv &&
		ao.InterViewStatus != model.ApprovalStatusReTrailBackIv {
		logger.Error("==================面签流转状态错误： ", "当前状态: ", ao.InterViewStatus)
		return errors.New("面签状态为:" + ao.InterViewStatus + ",不可流转")
	}

	// 判断该订单是否属于这个人
	if ao.InterViewTrailName != name && !isPassword {
		return errors.New("面签流转错误, 您无权对该面签单操作")
	}

	if err = config.GetDb().Model(&ao).Update(map[string]interface{}{
		"inter_view_trail_id":   exchangeUser,
		"inter_view_trail_name": exchangeName,
		"inter_view_status":     model.ApprovalStatusInterViewExchange, // 面签流转
		"inter_view_status_des": repulseDes,                            // 面签流转备注
	}).Error; err != nil {
		logger.Info("面签流转失败", "err", err.Error())
		return errors.New("面签流转失败,请稍后再试")
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: jinjianId, ApprovalName: ao.InterViewTrailName,
		ApprovalStatus: "面签流转", ApprovalType: "mq",
		ApprovalDesc: fmt.Sprintf("%v流转给%v, ", name, exchangeName) + repulseDes})

	return
}

// 面签抢单
func GrabInterview(jinjianId, username, name string) (err error) {
	logger.Info("======================= 执行面签抢单 =======================")

	var ao model.ApprovalOrder
	if err = config.GetDb().Model(ao).Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return errors.New("未查询到订单,请检查是否存在")
	}

	if ao.InterViewTrailId != "" || ao.InterViewTrailName != "" {
		return errors.New("抢单失败, 该面签单已被锁定")
	}

	if ao.InterViewStatus != model.ApprovalStatusWaitInterView && ao.InterViewStatus != model.ApprovalStatusWaitUserInput {
		logger.Error("==================面签提交 状态错误： ", "当前状态: ", ao.InterViewStatus)
		return errors.New("面签状态为:" + ao.InterViewStatus + ",不可抢单")
	}

	if err = config.GetDb().Model(&ao).Update(map[string]interface{}{
		"inter_view_trail_id":   username,
		"inter_view_trail_name": name,
		"inter_view_status":     model.ApprovalStatusInterViewing,
		"first_trail_status":    model.ApprovalStatusInterViewing,
	}).Error; err != nil {
		logger.Error("========== 更新面签状态错误", "err", err.Error())
		return errors.New("抢单失败,请稍候再试")
	}

	// 开始面签 计时
	service.AsyncApprovalTimeRecord(jinjianId, model.TP_GRAB_IV, model.TP_INTERVIEW)

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: jinjianId, ApprovalName: name,
		ApprovalStatus: "面签抢单", ApprovalType: "mq", ApprovalDesc: name + "抢单成功"})

	return
}

// 提交面签(面签通过)
func CommitInterView(jinjianId, repulseDes string) (err error) {
	logger.Info("======================= 执行面签通过 =======================")

	var ao model.ApprovalOrder
	if err = config.GetDb().Model(ao).Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return errors.New("未查询到面签单, 请检查是否存在")
	}

	if ao.InterViewStatus != model.ApprovalStatusInterViewing && ao.InterViewStatus != model.ApprovalStatusInterViewExchange &&
		ao.InterViewStatus != model.ApprovalStatusFirstTrailBackIv && ao.InterViewStatus != model.ApprovalStatusReTrailBackIv {
		logger.Error("==================面签提交 状态错误： ", "当前状态: ", ao.InterViewStatus)
		return errors.New("面签状态为:" + ao.InterViewStatus + ",提交失败")
	}

	logger.Info("interview===================", "interview", ao.InterView)
	// 验证面签数据是否完整
	if err = ivModel.IsValidInterview(ao.InterView); err != nil {
		return err
	}

	var status string
	logger.Info("======面签提交时资金方======== order_id :" + ao.JinjianId + "fund_side : " + ao.FundSide)
	if ao.FirstTrailStatus == model.ApprovalStatusWaitUserInput {
		status = ", 面签关闭进件补录"
	}

	data := map[string]interface{}{
		"first_trail_status": model.ApprovalStatusWaitFirstTrail, //  待初审

		"inter_view_status":     model.ApprovalStatusInterViewPass, // 面签通过
		"inter_view_status_des": repulseDes,                        // 面签备注

		"approval_start_time":    time.Now(),
		"inter_view_finish_time": time.Now(),
		"agency_status":          model.AgencyStatusSHZ, // 将中介状态 变成 待审查
	}

	// 正常面签
	tag := 0

	// 初审退回
	if ao.FirstTrailStatus == model.ApprovalStatusFirstTrailBackIv {
		tag = 1
		delete(data, "approval_start_time")
		//data["first_trail_status_des"] = repulseDes
	}

	// 终审退回
	if ao.ReTrailStatus == model.ApprovalStatusReTrailBackIv {
		tag = 2
		delete(data, "first_trail_status")
		delete(data, "approval_start_time")
		//data["re_trail_status_des"] = repulseDes
		data["re_trail_status"] = model.ApprovalStatusWaitReTrail
	}

	if err = config.GetDb().Model(&ao).Update(data).Error; err != nil {
		logger.Error("============提交面签材料错误", "err", err.Error())
		return errors.New("面签提交失败,请稍候再试")
	}

	var approvalStatus, endTimeType, startTimeType, approvalType string
	switch tag {
	case 0:
		approvalStatus = "面签提交"
		endTimeType = model.TP_INTERVIEW
		startTimeType = model.TP_GRAB_CS
		approvalType = "mq"

		service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.InterViewTrailName,
			ApprovalStatus: approvalStatus, ApprovalType: approvalType,
			ApprovalDesc: "面签人员:" + ao.InterViewTrailName + "上传面签材料" + status + "，选择资金方： " + ao.FundSide})
	case 1:
		approvalStatus = "初审退回，面签再提交"
		endTimeType = model.TP_CS_BACK_IV
		startTimeType = model.TP_CS
		approvalType = "cs"
	case 2:
		approvalStatus = "终审退回，面签再提交"
		endTimeType = model.TP_ZS_BACK_IV
		startTimeType = model.TP_ZS
		approvalType = "zs"

	}

	if tag > 0 {
		service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.InterViewTrailName,
			ApprovalStatus: approvalStatus, ApprovalType: approvalType,
			ApprovalDesc: "面签人员:" + ao.InterViewTrailName + "上传面签材料" + status + "，选择资金方： " + ao.FundSide})
	}

	service.AsyncApprovalTimeRecord(ao.JinjianId, endTimeType, startTimeType)

	return
}

//  面签端获取待面签列表
func GetNeedInterviewApprovalList(reqParams ivModel.InterviewListReqParams) (list []model.ApprovalOrder, totalPage int, count int, err error) {
	logger.Info("查询列表数据==========", "Params", reqParams)
	if err = reqParams.IsValidInterviewListReqParams(); err != nil {
		return
	}

	sqlBase := config.GetDb().Model(&model.ApprovalOrder{})

	if res := interViewStatusList(reqParams.TypeKey, reqParams.Status); len(res) > 0 {
		// 筛选面签订单状态
		sqlBase = sqlBase.Where("inter_view_status in (?)", res)
		logger.Info("         === 查询条件为面签端状态 ===")
	} else {
		sqlBase = sqlBase.Where(approvalStatusList(reqParams.Status))
		logger.Info("         === 查询条件为审批端状态 ===")
		//logger.Debug("sql", "sql", approvalStatusList(reqParams.Status))
	}

	// 查询订单池或查询页面 不验证查询人信息
	if reqParams.TypeKey != "all" && reqParams.TypeKey != "query" {
		logger.Info("查询自己的订单", "Username", reqParams.Username, "Name", reqParams.Name)
		sqlBase = sqlBase.Where("(inter_view_trail_id = ? AND inter_view_trail_name = ?)", reqParams.Username, reqParams.Name)
	}

	// 筛选挂起
	if reqParams.InterViewSuspending != "" {
		sqlBase = sqlBase.Where("inter_view_suspending = ?", reqParams.InterViewSuspending)
	}

	// 筛选开始时间
	if !reqParams.StartTime.IsZero() {
		sqlBase = sqlBase.Where("commit_time >= ?", reqParams.StartTime.Format("2006-01-02 15:04:05"))
	}
	// 筛选结束时间
	if !reqParams.EndTime.IsZero() {
		sqlBase = sqlBase.Where("commit_time <= ?", reqParams.EndTime.Format("2006-01-02 15:04:05"))
	}

	// 模糊搜索
	if condition := reqParams.Condition; condition != "" {
		condition = "%" + condition + "%"
		sqlBase = sqlBase.Where(
			"((jinjian_user_name LIKE ?) OR (show_id LIKE ?) OR (agency_name LIKE ?) "+
				"OR (agency_employee LIKE ?) OR (user_id_num LIKE ?) OR (inter_view_trail_name LIKE ?))",
			condition, condition, condition, condition, condition, condition)
	}

	// 筛选渠道公司
	if reqParams.Agency != "" {
		sqlBase = sqlBase.Where("agency_name = ?", reqParams.Agency)
	}

	// 进件时间排序
	if reqParams.Sort != "" {
		sqlBase = sqlBase.Order(reqParams.Sort)
	}

	// 分页
	offset := util.GetOffset(reqParams.Page, reqParams.PerPage)
	totalPage, count = util.GetTotalPagesAndCount(sqlBase, &list, reqParams.PerPage)

	if err = sqlBase.Offset(offset).Limit(reqParams.PerPage).Find(&list).Error; err != nil {
		logger.Error("===================获取面签列表出错: " + err.Error())
		err = errors.New("列表查询失败,请稍候再试")
		return
	}

	return
}

// 筛选审批订单状态
func approvalStatusList(status string) (sql string) {
	switch status {
	case "待初审抢单":
		return "first_trail_status = '待初审' and first_trail_id = 'Null' and first_trail_name = 'Null'"
	case "初审中":
		return "first_trail_status in ('待初审','初审流转','终审退回','待补录数据') and first_trail_id != 'Null' and first_trail_name != 'Null'"
	case "待终审抢单":
		return "re_trail_status = '待终审' and re_trail_id = 'Null' and re_trail_name = 'Null'"
	case "终审中":
		return "re_trail_status in ('待终审','终审流转','客服退回','待上传合同') and re_trail_id != 'Null' and re_trail_name != 'Null'"
	case "待客服抢单":
		return "custom_service_status = '待沟通'"
	case "客户接受":
		return "custom_service_status = '客户接受'"
	case "客户拒绝":
		return "custom_service_status = '客户拒绝'"
	case "初审撤销":
		return "first_trail_status = '已撤销'"
	case "终审撤销":
		return "re_trail_status = '已撤销'"
	case "终审拒绝":
		return "re_trail_status = '终审拒绝'"
	default: // todo, 是否返回一个无法查询到的条件, 而不是空值; 还是返回一个错误
		return
	}
}

// 执行 all 和 query 查询所有单
func interViewStatusList(typeKey, status string) (statusList []string) {
	switch typeKey {
	case "all":
		switch status {
		case model.ApprovalStatusWaitInterView:
			statusList = []string{model.ApprovalStatusWaitInterView}
			return
		case model.ApprovalStatusWaitUserInput:
			statusList = []string{model.ApprovalStatusWaitUserInput}
			return
		default:
			statusList = []string{model.ApprovalStatusWaitInterView, model.ApprovalStatusWaitUserInput}
			return
		}
	case "history":
		switch status {
		case model.ApprovalStatusInterViewCancel:
			statusList = []string{model.ApprovalStatusInterViewCancel}
			return
		case model.ApprovalStatusInterViewPass:
			statusList = []string{model.ApprovalStatusInterViewPass}
			return
		default:
			statusList = []string{model.ApprovalStatusInterViewCancel, model.ApprovalStatusInterViewPass}
			return
		}
	case "me":
		switch status {
		case model.ApprovalStatusInterViewing:
			statusList = []string{model.ApprovalStatusInterViewing, model.ApprovalStatusInterViewExchange}
			return
		case model.ApprovalStatusFirstTrailBackIv:
			statusList = []string{model.ApprovalStatusFirstTrailBackIv}
			return
		case model.ApprovalStatusReTrailBackIv:
			statusList = []string{model.ApprovalStatusReTrailBackIv}
			return
		case model.ApprovalStatusInterViewRepulse:
			statusList = []string{model.ApprovalStatusInterViewRepulse}
			return
		default:
			statusList = []string{model.ApprovalStatusInterViewing, model.ApprovalStatusInterViewExchange, model.ApprovalStatusFirstTrailBackIv, model.ApprovalStatusReTrailBackIv, model.ApprovalStatusInterViewRepulse}
			return
		}
	case "query":
		switch status {
		case model.ApprovalStatusWaitInterView:
			statusList = []string{model.ApprovalStatusWaitInterView}
			return
		case model.ApprovalStatusInterViewing:
			statusList = []string{model.ApprovalStatusInterViewing, model.ApprovalStatusInterViewExchange}
			return
		case model.ApprovalStatusFirstTrailBackIv:
			statusList = []string{model.ApprovalStatusFirstTrailBackIv}
			return
		case model.ApprovalStatusReTrailBackIv:
			statusList = []string{model.ApprovalStatusReTrailBackIv}
			return
		case model.ApprovalStatusInterViewRepulse:
			statusList = []string{model.ApprovalStatusInterViewRepulse}
			return
		case model.ApprovalStatusInterViewCancel:
			statusList = []string{model.ApprovalStatusInterViewCancel}
			return
		default:
			// 返回空数组用于判断
			return
		}
	}
	logger.Error("前面有对 typeKey 做验证，按道理是不会走这里的")
	return
}

// 获取面签状态记录列表
func GetInterviewStatusRecord(orderId string) (list []model.ApprovalLog, err error) {
	if err = config.GetDb().Model(&model.ApprovalLog{}).Where("approval_jinjian_id = ? AND approval_type = 'mq'", orderId).Order("created_at desc").Find(&list).Error; err != nil {
		logger.Error("查询面签状态记录列表失败", "err", err.Error())
		return list, errors.New("查询面签状态记录列表失败,请稍后再试")
	}
	return list, nil
}

// 根据 jinjian_id 和 inter_view_trail_id 获取面签单信息
func GetApprovalOrderInfoByJinjianId(jinjianId, username string) (ao model.ApprovalOrder, err error) {
	if jinjianId == "" && username == "" {
		return ao, errors.New("进件id和面签人员不能为空")
	}

	if err = config.GetDb().Model(&model.ApprovalOrder{}).Where("jinjian_id = ? and inter_view_trail_id = ?", jinjianId, username).First(&ao).Error; err != nil {
		logger.Error("========== 根据进件id查询ApprovalOrder失败", "jinjianId", jinjianId, "err", err.Error())
		return ao, errors.New("未查询到订单,请检测订单是否存在")
	}

	return OffInterViewSuspending(ao)
}

// 查询详情时, 隐藏不需要的数据后 再 给前端
func GetApprovalOrderInfoToFront(ao model.ApprovalOrder) (aoToFront model.ApprovalOrder) {
	// 用户基本信息
	aoToFront.BaseModel = ao.BaseModel
	aoToFront.ApprovalAddContacts = ao.ApprovalAddContacts
	aoToFront.ShowId = ao.ShowId
	aoToFront.JinjianUserName = ao.JinjianUserName
	aoToFront.JinjianUserId = ao.JinjianUserId
	aoToFront.ProductName = ao.ProductName
	aoToFront.Cellphone = ao.Cellphone
	aoToFront.UserIdNum = ao.UserIdNum

	// 进件基本信息
	aoToFront.JinjianId = ao.JinjianId
	aoToFront.OrderInfo = ao.OrderInfo
	aoToFront.AllInfo = ao.AllInfo
	aoToFront.IsStandard = ao.IsStandard
	aoToFront.ProductId = ao.ProductId
	aoToFront.FundSide = ao.FundSide

	// 补录开关
	aoToFront.CallAdditionalRecord = ao.CallAdditionalRecord
	aoToFront.CallAdditionalRecordChannel = ao.CallAdditionalRecordChannel
	aoToFront.AdditionalRecord = ao.AdditionalRecord
	aoToFront.AdditionalRecordChannel = ao.AdditionalRecordChannel

	// 初审状态
	aoToFront.FirstTrailStatus = ao.FirstTrailStatus
	aoToFront.FirstTrailStatusDes = ao.FirstTrailStatusDes
	aoToFront.FirstTrailStatusRepulse = ao.FirstTrailStatusRepulse
	// 终审状态
	aoToFront.ReTrailStatus = ao.ReTrailStatus
	aoToFront.ReTrailStatusDes = ao.ReTrailStatusDes

	// 面签信息
	aoToFront.InterView = ao.InterView
	aoToFront.InterViewTrailId = ao.InterViewTrailId
	aoToFront.InterViewStatus = ao.InterViewStatus
	aoToFront.InterViewStatusDes = ao.InterViewStatusDes
	aoToFront.InterViewSuspending = ao.InterViewSuspending
	aoToFront.InterViewSuspenseDesc = ao.InterViewSuspenseDesc
	aoToFront.InterViewFinishTime = ao.InterViewFinishTime

	// new
	aoToFront.IdCardCheckResult = ao.IdCardCheckResult
	return
}

// 查询预审批资金方
func GetPreTrailFundSide(orderId string) (string, error) {
	var ao model.ApprovalOrder
	var preAo model.PreApprovalOrder
	connectedDb := db.GetApprovalReadDb()
	if err := connectedDb.Model(&ao).Where("jinjian_id=?", orderId).First(&ao).Error; err != nil {
		logger.Error("查询approval order出错: ", "err", err)
		return "", err
	}
	if err := connectedDb.Model(&preAo).Where("user_id_num=?", ao.UserIdNum).First(&preAo).Error;
		err != nil && err != gorm.ErrRecordNotFound {
		logger.Error("查询Pre approval order出错: ", "err", err)
		return "", err
	}
	return preAo.IntroductionFundSide, nil
}

// 修改进件信息 字段 order_info | all_info
func UpdateJinjianOrderInfo(params ivModel.OrderInfoReqParams, ao model.ApprovalOrder) (err error) {
	logger.Info("======================= 修改进件信息 =======================")

	if params.OrderId == "" || params.Info == "" || params.Key == "" {
		return errors.New("缺少参数,请检查")
	}

	var info map[string]interface{}

	switch params.Info {

	case "order_info":
		if err := util.ParseJson(ao.OrderInfo, &info); err != nil {
			return errors.New("OrderInfo 信息解析错误")
		}
		if info[params.Key] == nil {
			return errors.New("未找到key " + params.Key + ",请检查")
		}

		info[params.Key] = params.Value
		ao.OrderInfo = util.StringifyJson(info)

	case "all_info":
		if err := util.ParseJson(ao.AllInfo, &info); err != nil {
			return errors.New("AllInfo 信息解析错误")
		}

		if params.TopKey == "" && info[params.Key] != nil {
			info[params.Key] = params.Value
		} else {
			data := util.GetJsonFromJson(info, params.TopKey)
			if len(data) == 0 {
				return errors.New("未找到top_key " + params.TopKey + ",请检查")
			}

			if data[params.Key] == nil {
				return errors.New("未找到key " + params.Key + ",请检查")
			}

			data[params.Key] = params.Value
			info[params.TopKey] = data
		}

		ao.AllInfo = util.StringifyJson(info)
	default:
		return errors.New("参数 info 错误 " + params.Info + ",请检查")
	}

	if params.TopKey == "idcard_info" && params.Key == "name" {
		params.Info = "order_info"
		params.Key = "userName"
		ao.JinjianUserName = fmt.Sprintf("%v", params.Value)
		ao.IdCardCheckResult = CheckIdCardAndName(params.OrderId, ao.UserIdNum, params.Value.(string))
		return UpdateJinjianOrderInfo(params, ao)
	}

	if params.TopKey == "idcard_info" && params.Key == "number" {
		params.Info = "order_info"
		params.Key = "idNo"
		ao.UserIdNum = fmt.Sprintf("%v", params.Value)
		ao.IdCardCheckResult = CheckIdCardAndName(params.OrderId, params.Value.(string), ao.JinjianUserName)
		return UpdateJinjianOrderInfo(params, ao)
	}
	// todo, 搞清楚为什么terms 会变成float64 类型???????
	if params.Info == "order_info" && params.Key == "terms" {
		logger.Info("terms", "terms", params.Value, "type", reflect.TypeOf(params.Value))
		if res, ok := params.Value.(int); ok {
			ao.LoanTerm = res
		}
		if res, ok := params.Value.(float64); ok {
			ao.LoanTerm = int(res)
		}
	}

	if params.Info == "order_info" && params.Key == "amount" {
		logger.Info("LoanAmount", "LoanAmount", params.Value, "type", reflect.TypeOf(params.Value))
		if res, ok := params.Value.(uint64); ok {
			ao.LoanAmount = res
		}
		if res, ok := params.Value.(float64); ok {
			ao.LoanAmount = uint64(res)
		}
	}

	if err = config.GetDb().Model(&model.ApprovalOrder{}).
		Where("jinjian_id = ? ", ao.JinjianId).
		Update(&model.ApprovalOrder{
		JinjianUserName:   ao.JinjianUserName,
		UserIdNum:         ao.UserIdNum,
		OrderInfo:         ao.OrderInfo,
		AllInfo:           ao.AllInfo,
		LoanTerm:          ao.LoanTerm,
		LoanAmount:        ao.LoanAmount,
		IdCardCheckResult: ao.IdCardCheckResult,
	}).Error; err != nil {
		logger.Error("========== 更新进件信息失败", "err", err.Error())
		return errors.New("更新进件信息失败,请稍候再试")
	}

	return
}

// 修改联系人信息 approval_add_contacts
func AddContactsInfo(contacts []ivModel.ContactsReqParams, num int, jinjianId, username string) (err error) {
	logger.Info("======================= 修改联系人信息 =======================")

	if len(contacts) != 1 || num < -1 {
		return errors.New("添加联系人请求参数格式,请检查")
	}

	ao, err := GetApprovalOrderInfoByJinjianId(jinjianId, username)
	if err != nil {
		return err
	}

	if common.GetUseDocker() == 2 && contacts[0].Relationship != "公司电话" {
		contacts[0].QCellCore = getPhoneNumQCellCore(contacts[0].Phone)
	}

	if ao.ApprovalAddContacts == "" && num != -1 {
		return errors.New("参数num错误,请检查")
	}

	if ao.ApprovalAddContacts == "" {
		ao.ApprovalAddContacts = util.StringifyJson(contacts)
	} else {
		var tmp []ivModel.ContactsReqParams
		if err = util.ParseJson(ao.ApprovalAddContacts, &tmp); err != nil || num >= len(tmp) {
			return errors.New("原始联系人信息解析错误或num错误")
		}
		if num != -1 { //更新
			tmp[num] = contacts[0]
		} else { //添加
			tmp = append(tmp, contacts[0])
		}
		ao.ApprovalAddContacts = util.StringifyJson(tmp)
	}

	if err = config.GetDb().Model(&model.ApprovalOrder{}).
		Where("jinjian_id = ?", jinjianId).
		Update(map[string]string{
		"approval_add_contacts": ao.ApprovalAddContacts,
	}).Error; err != nil {
		logger.Error("========== 更新联系人信息失败", "err", err.Error())
		return errors.New("更新联系人信息失败,请稍候再试")
	}

	return
}

// 保存面签信息到approval order
func UpdateApprovalInterviewInfo(interview ivModel.Interview) (err error) {
	logger.Info("======================= 修改面签信息 =======================", "interview model", interview)

	if err = interview.IsValidSaveInterview(); err != nil {
		return
	}

	var ao model.ApprovalOrder
	if err = config.GetDb().Model(model.ApprovalOrder{}).Where("jinjian_id = ?", interview.JinjianId).First(&ao).Error; err != nil {
		return errors.New("订单查询失败, 请检查")
	}
	interview.OldInterview = ao.InterView

	if interview.InterviewUsername != ao.InterViewTrailId {
		return errors.New("您无权修改该面签单")
	}

	if ao.InterViewStatus != model.ApprovalStatusInterViewing && ao.InterViewStatus != model.ApprovalStatusInterViewExchange &&
		ao.InterViewStatus != model.ApprovalStatusFirstTrailBackIv && ao.InterViewStatus != model.ApprovalStatusReTrailBackIv {
		logger.Error("==================面签提交 状态错误： ", "当前状态: ", ao.InterViewStatus)
		return errors.New("面签状态为:" + ao.InterViewStatus + ",保存失败")
	}

	if err = config.GetDb().Model(ao).Update(&model.ApprovalOrder{
		FundSide:    interview.FundSide,
		IsStandard:  interview.IsStandard,
		ProductPlan: interview.ProductPlan}).Error; err != nil {
		logger.Error("========== 更新fund_side失败", "err", err.Error())
		return errors.New("更新审批信息失败,请稍后再试")
	}

	return UpdateApprovalInterview(interview)
}

// 同步更新interview到approvalOrder!（不做校验）
func UpdateApprovalInterview(interview ivModel.Interview) (err error) {
	logger.Info("======================= 修改面签文件信息 =======================", "interview model", interview)

	str, err := GetNewInterviewString(interview, interview.OldInterview)
	if err != nil {
		return
	}

	logger.Info("#########################", "interview", str)
	if err = config.GetDb().Model(&model.ApprovalOrder{}).Where("jinjian_id=?", interview.JinjianId).Update("inter_view", str).Error; err != nil {
		logger.Error("========== 更新inter_view失败", "进件ID", interview.JinjianId, "info", err.Error())
		return errors.New("更新面签信息失败,请稍后再试")
	}
	return
}

// 传入新的 interview model 和 原 interview string 返回新的 interview string
func GetNewInterviewString(interview ivModel.Interview, oldInterviewStr string) (string, error) {

	iv := ivModel.Interview{}
	if oldInterviewStr != "" && util.ParseJson(oldInterviewStr, &iv) != nil {
		logger.Error("inter_view json 格式错误", "inter_view", oldInterviewStr)
		return "", errors.New("json转换成对象失败")
	}

	if iv.JinjianId != "" && interview.JinjianId != iv.JinjianId {
		return "", errors.New("要修改的进件id和原数据的进件id不相等")
	}

	//把interview中有值的字段copy到iv中
	copyInterviewWithValue(interview, &iv)

	return util.StringifyJson(iv), nil
}

func updateJinjianPlan(ivStr, newJjPlan string) (newIv string, err error) {
	var iv ivModel.Interview

	if err = util.ParseJson(ivStr, &iv); err != nil {
		logger.Error("inter_view json 格式错误", "err", err.Error(), "iv", ivStr)
		return "", err
	}

	// 替换新的进件方案
	iv.JinjianPlan = newJjPlan

	newIv = util.StringifyJson(iv)

	return

}

//将结构体中有值的变量, Copy到另一个结构体中.
func copyInterviewWithValue(from ivModel.Interview, copyTo *ivModel.Interview) {
	ft := reflect.TypeOf(from)
	fv := reflect.ValueOf(from)
	cv := reflect.ValueOf(copyTo).Elem()
	for i := 0; i < ft.NumField(); i++ {
		x := fv.Field(i).Interface()
		if x == nil || x == "" || x == int64(0) {
			continue
		}
		if b, ok := x.([]ivModel.LoanBank); ok {
			if len(b) == 0 {
				continue
			}
		}
		if b, ok := x.([]*ivModel.InterviewFile); ok {
			if len(b) == 0 {
				continue
			}
			//删除文件特殊处理, 通过IsEmpty字段判断
			if b[0].IsEmpty {
				cv.Field(i).Set(reflect.ValueOf([]*ivModel.InterviewFile{}))
				continue
			}
		}
		cv.Field(i).Set(reflect.ValueOf(x))
	}
	//Comment 单独处理, 接收空格则置为空
	if from.Comment == " " {
		copyTo.Comment = ""
	}
}

/*********************************************************************************/
// 没有用到
/*********************************************************************************/

//传struct进去, 第一个参数传原值, 第二个参数传指针*****************需要完善,暂不开放
//func CopyStructWithValue(from interface{}, copyto interface{}) (err error){
//	ft := reflect.TypeOf(from)
//	fv := reflect.ValueOf(from)
//	//ct := reflect.TypeOf(copyto)
//	cv := reflect.ValueOf(copyto).Elem()
//	//if ft != ct {
//	//	fmt.Println(ft,ct)
//	//	return errors.New("different struct, please use same struct")
//	//}
//	for i := 0; i < ft.NumField(); i++ {
//		x := fv.Field(i).Interface()
//		switch {
//		case x != nil && x != "" && x != 0 :
//			fmt.Println("what the fuck",x,"typeof",reflect.TypeOf(x))
//			cv.Field(i).Set(reflect.ValueOf(x))
//		//case
//		default:
//			//fmt.Println("wTF", reflect.TypeOf(x))
//		}
//	}
//	return nil
//}

// 面签历史订单上传资料
func UpdateInterViewFile(jinjianId, username string, newFile map[string]interface{}) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Model(ao).Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return err
	}

	if ao.InterViewSwitch == "off" {
		return errors.New("未开启资料上传, 无法上传")
	}

	var iv map[string]interface{}

	if err = util.ParseJson(ao.InterView, &iv); err != nil {
		return
	}

	iv["iv_add_file"] = newFile //这里需要注意，每次都要补充材料全量的数据

	if err = config.GetDb().Model(ao).Where("id = ?", ao.ID).
		Update(map[string]interface{}{
		"inter_view":        util.StringifyJson(iv),
		"inter_view_switch": "off",
	}).Error; err != nil {
		logger.Error("============更新面签材料错误: " + err.Error())
		return
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: username,
		ApprovalStatus: "面签经理" + username + "更新面签材料",
		ApprovalType: "cs", ApprovalDesc: "更新面签材料"})

	return
}
