package serviceV1

/**
 @FileDescription: 预审批 进件端
 @author: WangXi
 @create: 19:45 2018/1/2
*/

import (
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"time"
	"gcoresys/common/logger"
	"errors"
	"gapproval/approval/service"
)

// 进件 预审批更新打回 (预审批征信材料)
func UpdatePreApprovalFile(paId, paFile string) (cancelTime *time.Time, err error) {
	if paFile == "" {
		return nil, errors.New("更新打回，预审材料不能为空")
	}

	var pao model.PreApprovalOrder
	if err = config.GetDb().Model(&model.PreApprovalOrder{}).
		Where("pre_approval_id = ?", paId).First(&pao).Error; err != nil {
		return
	}

	if pao.PreApprovalStatus == model.PREAPPROVALCANCEL {
		return pao.CancelTime, errors.New("预审已撤销")
	}

	if pao.PreApprovalStatus != model.PREAPPROVALREPULSE {
		return nil, errors.New("预审状态应该为" + model.PREAPPROVALREPULSE)
	}

	newTime := time.Now()
	pao.UpdateTime = &newTime
	pao.PreApprovalFile = paFile
	pao.PreApprovalStatus = model.PREAPPROVALING

	if err = config.GetDb().Model(pao).Updates(pao).Error; err != nil {
		logger.Error("=============Updates Err: " + err.Error())
		return nil, err
	}

	service.AsyncNewPreApprovalLog(&model.PreApprovalLog{
		PreApprovalId:     pao.PreApprovalID,
		PreApprovalName:   pao.AgencyEmployee,
		PreApprovalStatus: "更新打回",
	})
	return
}

//  获取预审批单详情
func GetPreApprovalInfoQy(preApprovalId string) (pao model.PreApprovalOrder, err error) {
	if err = config.GetDb().Model(&model.PreApprovalOrder{}).Where("pre_approval_id = ?", preApprovalId).First(&pao).Error; err != nil {
		logger.Error("=============获取预审批单详情出错============: " + err.Error())
		return
	}
	return
}

// 批量查询  
func BatchGetPreApprovalInfoQy(pids []string) (paoList []model.PreApprovalOrder, err error) {

	var limitCount = 1000

	if len(pids) > limitCount {
		err = errors.New("批量查询上限1000")
		return
	}

	if err = config.GetDb().Model(&model.PreApprovalOrder{}).Select([]string{
		"pre_approval_id",
		"commit_time",
		"start_time",
		"pass_time",
		"cancel_time",
		"repulse_time",
		"refuse_time",
		"pre_approval_status",
		"introduction_plan_num",
		"introduction_fund_side",
		"op_desc",
	}).Where("pre_approval_id in (?)", pids).Limit(limitCount).Find(&paoList).Error; err != nil {
		logger.Error("=============批量获取预审批单详情出错============: " + err.Error())
		return
	}
	return
}
