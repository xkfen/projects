package serviceV1

import (
	"gapproval/approval/model"
	"fmt"
	"gcoresys/common/util"
	"strconv"
	"time"
	"gapproval/approval/service"
)

/**
 @FileDescription:
 @author: WangXi
 @create: 19:56 2018/1/2
*/

func (s *testingSuite) TestNewPreApprovalLog() {
	pal := &model.PreApprovalLog{
		PreApprovalId:     "sssss",
		PreApprovalName:   "ssdsg",
		PreApprovalDesc:   "hhahah",
		PreApprovalStatus: "fdfdfd",
	}
	service.AsyncNewPreApprovalLog(pal)
}

func (s *testingSuite) TestAsyncNewPreApprovalLog() {
	pal := &model.PreApprovalLog{
		PreApprovalId:     "sssss",
		PreApprovalName:   "ssdsg",
		PreApprovalDesc:   "hhahah",
		PreApprovalStatus: "fdfdfd",
	}
	service.AsyncNewPreApprovalLog(pal)
}

func (s *testingSuite) TestGetPreApprovalLog() {
	pal := &model.PreApprovalLog{
		PreApprovalId:     "sssss",
		PreApprovalName:   "ssdsg",
		PreApprovalDesc:   "hhahah",
		PreApprovalStatus: "fdfdfd",
	}
	service.AsyncNewPreApprovalLog(pal)
	time.Sleep(500 * time.Microsecond)
	s.Equal(1, len(GetPreApprovalLog(pal.PreApprovalId)))
}

func (s *testingSuite) TestGetPreApprovalInfo() {
	pao := model.GetDefaultPreApprovalOrder()
	s.NoError(service.CreatePreApproval(pao))
	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	fmt.Println(util.StringifyJson(paoR))
}

func (s *testingSuite) TestGetPreApprovalListParam() {
	pao1 := model.GetDefaultPreApprovalOrder()
	pao1.PreApprovalID = "poiuy890"
	s.NoError(service.CreatePreApproval(pao1))
	pao2 := model.GetDefaultPreApprovalOrder()
	pao2.PreApprovalID = "nfdgu5654"
	s.NoError(service.CreatePreApproval(pao2))
	pao3 := model.GetDefaultPreApprovalOrder()
	pao3.PreApprovalID = "hjlkhbn543"
	s.NoError(service.CreatePreApproval(pao3))

	p := GetPreApprovalListParam{
		TypeKey: "all",
		Page:    1,
	}
	paoList, tp, tc, err := GetPreApprovalList(p)
	s.Equal(nil, err)
	s.Equal(3, len(paoList))
	s.Equal(1, tp)
	s.Equal(3, tc)
}

func (s *testingSuite) TestGetPreApprovalListParam2() {
	pao1 := model.GetDefaultPreApprovalOrder()
	pao1.PreApprovalID = "poiuy890"
	s.NoError(service.CreatePreApproval(pao1))
	pao2 := model.GetDefaultPreApprovalOrder()
	pao2.PreApprovalID = "nfdgu5654"
	s.NoError(service.CreatePreApproval(pao2))
	pao3 := model.GetDefaultPreApprovalOrder()
	pao3.PreApprovalID = "hjlkhbn543"
	s.NoError(service.CreatePreApproval(pao3))

	p := GetPreApprovalListParam{
		TypeKey:  "me",
		Username: "gfdsfds",
		Name:     "ytrgfbhgfd",
		Page:     1,
	}

	paoList, tp, tc, err := GetPreApprovalList(p)
	s.Equal(nil, err)
	s.Equal(0, len(paoList))
	s.Equal(0, tp)
	s.Equal(0, tc)

}

func (s *testingSuite) TestGrabPreApproval() {
	pao := model.GetDefaultPreApprovalOrder()
	s.NoError(service.CreatePreApproval(pao))
	s.NoError(GrabPreApproval("test001", "测试001"))
	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	s.Equal("test001", paoR.PreTrailId)
	s.Equal("测试001", paoR.PreTrailName)
}

func (s *testingSuite) TestGrabPreApproval1() {
	pao := model.GetDefaultPreApprovalOrder()
	s.NoError(service.CreatePreApproval(pao))
	s.EqualError(GrabPreApproval("", "测试001"), "预审id不能为空")
	s.EqualError(GrabPreApproval("test001", ""), "预审name不能为空")
	s.NoError(GrabPreApproval("test001", "测试001"))
	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	s.Equal("test001", paoR.PreTrailId)
	s.Equal("测试001", paoR.PreTrailName)

	for i := 1; i < 15; i ++ {
		paoF := model.GetDefaultPreApprovalOrder()
		paoF.PreApprovalID = "12345670" + strconv.Itoa(i)
		s.NoError(service.CreatePreApproval(paoF))
		time.Sleep(10 * time.Millisecond)
	}

	for i := 1; i < 10; i ++ {
		go s.NoError(GrabPreApproval("test001", "测试001"))
	}

	time.Sleep(200 * time.Millisecond)
	s.EqualError(GrabPreApproval("test001", "测试001"), "你的预审批单数量已经达到10个，无法再添加预审批单啦")
}

func (s *testingSuite) TestGrabPreApproval2() {
	s.EqualError(GrabPreApproval("test001", "测试001"), "目前没有预审批单可抢，请稍候尝试")
}

func (s *testingSuite) TestPreTrailOperation1() {
	pao := model.GetDefaultPreApprovalOrder()
	pao.IsFast = ""
	s.NoError(service.CreatePreApproval(pao))
	s.NoError(GrabPreApproval("test001", "测试001"))
	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	s.Equal("test001", paoR.PreTrailId)
	s.Equal("测试001", paoR.PreTrailName)
	s.Equal(model.PREAPPROVALING, paoR.PreApprovalStatus)
	// 打回
	s.EqualError(PreTrailOperation(&model.PreApprovalOrder{PreApprovalStatus: model.PREAPPROVALREPULSE}), "预审id不能为空")
	s.EqualError(PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: pao.PreApprovalID,
		PreApprovalStatus: model.PREAPPROVALREPULSE}), "预审操作备注不能为空，请填写备注")
}

func (s *testingSuite) TestPreTrailOperation2() {
	pao1 := model.GetDefaultPreApprovalOrder()
	pao1.PreApprovalID = "fffffhbgdss"
	pao1.PreApprovalType = model.ZZ_PREAPPROVAL
	s.NoError(service.CreatePreApproval(pao1))
	s.NoError(GrabPreApproval("test001", "测试001"))
	// 打回
	s.EqualError(PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: pao1.PreApprovalID,
		PreApprovalStatus: model.PREAPPROVALREPULSE}), "用户自主申请，无法打回")
}

func (s *testingSuite) TestPreTrailOperation3() {
	pao := model.GetDefaultPreApprovalOrder()
	pao.IsFast = ""
	s.NoError(service.CreatePreApproval(pao))
	s.NoError(GrabPreApproval("test001", "测试001"))
	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	s.Equal("test001", paoR.PreTrailId)
	s.Equal("测试001", paoR.PreTrailName)
	s.Equal(model.PREAPPROVALING, paoR.PreApprovalStatus)
	// 打回
	s.NoError(PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: pao.PreApprovalID,
		PreApprovalStatus: model.PREAPPROVALREPULSE, OpDesc: "ssss"}))
	paoR1, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NotNil(paoR1.RepulseTime)
	s.NoError(err)
	s.Equal(model.PREAPPROVALREPULSE, paoR1.PreApprovalStatus)
}

func (s *testingSuite) TestPreTrailOperation4() {
	pao := model.GetDefaultPreApprovalOrder()
	pao.IsFast = ""
	s.NoError(service.CreatePreApproval(pao))
	s.NoError(GrabPreApproval("test001", "测试001"))
	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	s.Equal("test001", paoR.PreTrailId)
	s.Equal("测试001", paoR.PreTrailName)
	s.Equal(model.PREAPPROVALING, paoR.PreApprovalStatus)
	// 拒绝
	s.EqualError(PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: pao.PreApprovalID,
		PreApprovalStatus: model.PREAPPROVALREFUSE}), "预审操作备注不能为空，请填写备注")
}

func (s *testingSuite) TestPreTrailOperation5() {
	pao := model.GetDefaultPreApprovalOrder()
	pao.QuantizationMap = `
{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`

	pao.QuantizationCache = `
{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`

	pao.QuantizationPoint = 400
	pao.QuantizationLevel = 5
	s.NoError(service.CreatePreApproval(pao))
	s.NoError(GrabPreApproval("test001", "测试001"))
	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	s.Equal("test001", paoR.PreTrailId)
	s.Equal("测试001", paoR.PreTrailName)
	s.NotNil(paoR.StartTime)
	s.Equal(model.PREAPPROVALING, paoR.PreApprovalStatus)
	// 拒绝
	s.EqualError(PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: pao.PreApprovalID,
		PreApprovalStatus: model.PREAPPROVALREFUSE}), "预审操作备注不能为空，请填写备注")
}

func (s *testingSuite) TestPreTrailOperation6() {
	pao := model.GetDefaultPreApprovalOrder()
	pao.QuantizationMap = `
{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`

	pao.QuantizationCache = `
{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`

	pao.QuantizationPoint = 400
	pao.QuantizationLevel = 5
	s.NoError(service.CreatePreApproval(pao))
	s.NoError(GrabPreApproval("test001", "测试001"))
	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	s.Equal("test001", paoR.PreTrailId)
	s.Equal("测试001", paoR.PreTrailName)
	s.NotNil(paoR.StartTime)
	s.Equal(model.PREAPPROVALING, paoR.PreApprovalStatus)
	// 拒绝
	s.NoError(PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: pao.PreApprovalID,
		PreApprovalStatus: model.PREAPPROVALREFUSE, OpDesc: "sss",RefuseReason:"123",ExternalReason:"123"}))

	paoR1, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.NotNil(paoR1.RefuseTime)
	s.Equal(model.PREAPPROVALREFUSE, paoR1.PreApprovalStatus)
}
