package serviceV1

/**
 @FileDescription: 这里是都是 初审、终审、客服 的业务处理逻辑
 @author: WangXi
 @create: 14:34 2017/12/14
*/

import (
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	coresysCommon "gcoresys/common"
	"gcoresys/common/logger"
	"errors"
	"gapproval/approval/service"
)

/**
  @Description: 初审基础规则，无论是通过或者是拒绝都需要判断
  @Date: 14:48 2017/12/14
*/
func firstTrailBaseRule(ao model.ApprovalOrder) (err error) {
	// 检查是否有量化评分
	if coresysCommon.GetUseDocker() != 0 {
		if ao.QuantizationPoint == 0 {
			err = errors.New("量化变量未上传")
			return
		}
	}
	// 非标件
	if ao.IsStandard == "" {
		err = errors.New("请先标记是否为非标件")
		return
	}
	// 方案号       v3.0.2 12月29上线， v3.0.1 这个版本先临时注释掉
	//if ao.PlanNum == "" {
	//	err = errors.New("请先选择进件方案")
	//	return
	//}
	return
}

/**
  @Description: 初审通过和初审拒绝
  @Date: 15:03 2017/12/14
*/
func firstTrailPassOrRefuse(ao model.ApprovalOrder, changeAo *model.ApprovalOrder) (err error) {
	var approvalStatus string
	switch changeAo.FirstTrailStatus {
	case model.ApprovalStatusFirstTrailPass:
		// 检查ao是否符合操作规则
		if err = firstTrailPassRule(ao, changeAo); err != nil {
			return
		}
		ao = updateAoInfoByChangeAo(ao, changeAo)
		// 核准金额  现在初审就可以设定
		ao.ApprovedAmount = changeAo.ApprovedAmount
		// 核准利率  现在初审就可以设定
		ao.ApprovedRate = changeAo.ApprovedRate
		// 平台服务月利率
		ao.PlatformMonthRate = changeAo.PlatformMonthRate
		approvalStatus = model.ApprovalStatusFirstTrailPass      // 初审通过
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass // 初审通过

	case model.ApprovalStatusFirstTrailRefuse:
		// 检查规则
		if err = firstTrailBaseRule(ao); err != nil {
			return
		}
		if changeAo.FirstTrailStatusDes == "" {
			err = errors.New("初审拒绝，拒绝说明不能为空")
			return
		}
		if changeAo.RefuseReason == "" {
			err = errors.New("初审拒绝，拒绝原因不能为空")
			return
		}
		ao = updateAoInfoByChangeAo(ao, changeAo)
		ao.RefuseReason = changeAo.RefuseReason
		approvalStatus = model.ApprovalStatusFirstTrailRefuse      // 初审拒绝
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailRefuse // 初审拒绝

	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.FirstTrailName,
		ApprovalStatus: approvalStatus,
		ApprovalType: "cs", ApprovalDesc: changeAo.FirstTrailStatusDes})
	ao.FirstTrailStatusDes = changeAo.FirstTrailStatusDes
	// 开启终审
	ao.ReTrailStatus = model.ApprovalStatusWaitReTrail
	ao.ApprovalStatus = ao.GetAoCurrStatus()
	service.AsyncApprovalTrace(ao)

	if err = config.GetDb().Model(ao).Updates(ao).Update("salary_at", changeAo.SalaryAt).
		Update("loan_at", changeAo.LoanAt).Update("approved_amount", changeAo.ApprovedAmount).
		Update("approved_rate", changeAo.ApprovedRate).Update("approved_amount", changeAo.ApprovedAmount).
		Update("platform_month_rate", changeAo.PlatformMonthRate).Error; err != nil {
		return
	}

	if ao.ReTrailId != "Null" && ao.ReTrailName != "Null" {
		service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_CS, model.TP_ZS)
	} else {
		service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_CS, model.TP_GRAB_ZS)
	}

	return
}

//  初审通过操作规则
func firstTrailPassRule(ao model.ApprovalOrder, changeAo *model.ApprovalOrder) (err error) {
	// base rule
	if err = firstTrailBaseRule(ao); err != nil {
		return
	}
	// 检查三方信息
	var info model.ThreePartyInfo
	if err = config.GetDb().Where("jinjian_id =?", ao.JinjianId).First(&info).Error; err != nil {
		logger.Error("查询三方信息出错: " + err.Error())
		return
	}
	if ao.RiskParam == "" {
		err = errors.New(" 风险参数不能为空")
		return
	}
	// 检查是否有通话记录
	callRecordResult, err := service.CheckCallRecord(ao.JinjianId, ao.AllInfo)
	if err != nil {
		return
	}
	// 通话记录
	if !callRecordResult {
		err = errors.New("未查询到通话记录，请先电核用户！")
		return
	}
	// 这里去判断多资金方 初审通过规则
	if err = ftPassRuleByFundSide(ao, changeAo); err != nil {
		return
	}
	return
}

/**
  @Description: 这是根据资金方去调整初审审批
  @Date: 16:48 2017/12/14
*/
func ftPassRuleByFundSide(ao model.ApprovalOrder, changeAo *model.ApprovalOrder) (err error) {
	switch ao.FundSide {
	case model.CLFundSide:
		return nil
	default:

		/**
			默认来这
		 */

		if GetUserInfoSup(ao.JinjianId) == nil {
			err = errors.New("用户个人信息必须补充")
			return
		}

		if err = checkFirstTrailPassAoMrOnion(changeAo); err != nil {
			return
		}
	}
	return
}

func checkFirstTrailPassAoMrOnion(a *model.ApprovalOrder) (err error) {
	switch {
	case a.Card1 == "":
		err = errors.New("主卡不能为空")
		return
	case a.Cellphone == "":
		err = errors.New("手机不能为空")
		return
	case a.BankName == "":
		err = errors.New("银行名字不能为空")
		return
	case a.UserIdNum == "":
		err = errors.New("身份证不能为空")
		return
	case a.LoanBankName == "":
		err = errors.New("放款银行不能为空")
		return
	case a.LoanCard == "":
		err = errors.New("放款卡号不能为空")
		return
	case a.CardOnePhone == "":
		err = errors.New("扣款卡手机号不能为空")
		return
	case a.PlatformMonthRate == 0:
		err = errors.New("请填写平台服务月利率")
	}
	return
}
