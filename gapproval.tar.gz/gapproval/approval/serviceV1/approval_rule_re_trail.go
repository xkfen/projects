package serviceV1

/**
 @FileDescription:
 @author: WangXi
 @create: 19:31 2017/12/14
*/

import (
	"gapproval/approval/model"
	"errors"
)

/**
  @Description: 终审通过注释
  @Date: 19:37 2017/12/14
*/
func rtPassRuleByFundSide(ao model.ApprovalOrder, changeAo *model.ApprovalOrder) (error) {

	if err := firstTrailPassRule(ao, changeAo); err != nil {
		return err
	}

	switch ao.FundSide {
	case model.CLFundSide:
		return nil
	case model.XDZFundSide, "个人":
		return changeAo.IsValidZsPassOperation()
	case model.HAIJINSHEFundSide:
		return checkHJSPass(changeAo)
	default:
		/**
			现在基本的都走这个
		 */

		return checkReTrailPassBase(changeAo)

	}
}

func checkReTrailPassBase(changeAo *model.ApprovalOrder) (err error) {

	if err = changeAo.IsValidZsPassOperationMrOnion(); err != nil {
		return
	}

	return
}

func checkHJSPass(changeAo *model.ApprovalOrder) (err error) {
	if err = changeAo.IsValidZsPassOperationMrOnion(); err != nil {
		return
	}

	if changeAo.RiskLevel == "" {
		return errors.New("海金社终审通过风险等级不能为空")
	}

	if changeAo.RiskResult == "" {
		return errors.New("海金社终审通过风险结论不能为空")
	}

	return
}
