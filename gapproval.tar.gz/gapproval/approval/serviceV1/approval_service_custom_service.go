package serviceV1

import (
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"errors"
	"time"
	"gcoresys/common/logger"
	"gapproval/approval/service"
)

//  客服操作
func CustomServiceOperation(changeAo *model.ApprovalOrder) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Where("jinjian_id =?", changeAo.JinjianId).First(&ao).Error; err != nil {
		return err
	}
	if err = ao.IsValidKfOperation(); err != nil {
		return
	}

	switch changeAo.CustomServiceStatus {
	case model.ApprovalStatusCustomPass: // 客户接受   检查合同
		if err = customServicePass(ao, changeAo); err != nil {
			return err
		}
	case model.ApprovalStatusCustomRefuse: // 客户拒绝   检查合同
		if err = customServiceRefuse(ao, changeAo); err != nil {
			return err
		}
	case model.ApprovalStatusCustomServiceBack: // 客服退回
		if err = customServiceBack(ao, changeAo); err != nil {
			return err
		}
	case model.ApprovalStatusCustomServiceExchange: // 客服流转
		if err = exchange(ao, changeAo, "kf"); err != nil {
			return err
		}
	case model.ApprovalStatusCustomCancel: // 客户撤销
		if err = cancel(ao, changeAo, "kf"); err != nil {
			return err
		}
	default:
		err = errors.New("状态参数错误，请检查客服Status")
		return
	}
	return
}

//  客户接受  客户接受（post core system and fin system）
func customServicePass(ao model.ApprovalOrder, changeAo *model.ApprovalOrder) (err error) {
	if changeAo.ContractId == "" {
		err = errors.New("合同号不能为空, 请上传合同")
		return
	}
	ao.ContractId = changeAo.ContractId
	// post 核心系统
	account, err1 := service.PostCoreSysNewAccount(ao)
	if err1 != nil {
		return err1
	}
	ao.CustomServiceStatus = model.ApprovalStatusCustomPass
	ao.CustomServiceStatusDes = changeAo.CustomServiceStatusDes
	//ao.OperatorStatus = model.ApprovalStatusWaitOperatorConfirm
	ao.AccountID = account.AccountId
	ao.ApprovalStatus = ao.GetAoCurrStatus()
	var uis model.ApprovalUserInfoSup
	if err = config.GetDb().Model(uis).Where("jinjian_id = ?", ao.JinjianId).First(&uis).Error; err != nil {
		logger.Error("======================查询审批补充用户信息出错 :", "err", err.Error())
		if err.Error() == "record not found" {
			return errors.New("初审未补充用户信息")
		}
		return err
	}

	postMap := map[string]interface{}{"approval_order": ao, "user_info": uis}

	// post 财务系统
	if err = service.PostFinSys(postMap); err != nil {

		return err
	}
	if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
		return err
	}

	service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_KF, model.TP_CW)

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.CustomServiceName,
		ApprovalStatus: "用户接受",
		ApprovalType: "kf", ApprovalDesc: changeAo.CustomServiceStatusDes})

	// 业务留痕
	service.AsyncApprovalTrace(ao)
	return
}

//  客户拒绝  客户不接受
func customServiceRefuse(ao model.ApprovalOrder, changeAo *model.ApprovalOrder) (err error) {
	if changeAo.ContractId == "" {
		err = errors.New("合同号不能为空, 请上传合同")
		return
	}
	ao.ContractId = changeAo.ContractId
	ao.CustomServiceStatus = model.ApprovalStatusCustomRefuse
	// 设置客户拒绝时间  中介和进件系统需要的字段
	ao.CustomServiceStatusDes = changeAo.CustomServiceStatusDes
	nowTime := time.Now()
	ao.CustomerRefuseTime = &nowTime
	ao.AgencyStatus = model.AgencyStatusKHRefuse
	ao.ApprovalStatus = ao.GetAoCurrStatus()
	if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
		return err
	}
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.CustomServiceName,
		ApprovalStatus: "用户拒绝",
		ApprovalType: "kf", ApprovalDesc: changeAo.CustomServiceStatusDes})

	service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_KF)

	// 业务留痕
	service.AsyncApprovalTrace(ao)
	return
}

//  客服退回  退回给终审
func customServiceBack(ao model.ApprovalOrder, changeAo *model.ApprovalOrder) (err error) {
	if changeAo.CustomServiceStatusDes == "" {
		err = errors.New("客服退回状态说明不能为空")
		return
	}
	ao.CustomServiceStatus = model.ApprovalStatusCustomServiceBack
	ao.ReTrailStatus = model.ApprovalStatusCustomServiceBack
	ao.CustomServiceStatusDes = changeAo.CustomServiceStatusDes
	ao.ApprovalStatus = ao.GetAoCurrStatus()
	if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
		return err
	}
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.CustomServiceName,
		ApprovalStatus: "客服退回给" + ao.ReTrailName,
		ApprovalType: "zs", ApprovalDesc: changeAo.CustomServiceStatusDes})

	service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_KF, model.TP_ZS)

	// 业务留痕
	service.AsyncApprovalTrace(ao)
	return
}

//  获取客服列表（包含搜索）
func GetCustomServiceApprovalOrderList(typeKey string, status string, username string, name string,
	sort string, condition string, page int) ([]model.ApprovalOrder, int, int) {
	return transactGetApprovalList("kf", typeKey, status, username, name, sort, condition, page)
}

//  创建催收电核备注信息
func NewCSCallRecordDesc(jinjianId, desc, opName, callType, number string) (err error) {
	var acr model.ApprovalCallRecord
	acr.JinjianId = jinjianId
	acr.Desc = desc
	acr.CallType = callType
	acr.Number = number
	acr.ExistCallRecord = model.NoCallRecord
	if err = config.GetDb().Model(acr).Create(&acr).Error; err != nil {
		return
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: jinjianId, ApprovalName: opName,
		ApprovalStatus: "创建电核备注信息",
		ApprovalType: callType, ApprovalDesc: "Desc: " + desc})
	return
}
