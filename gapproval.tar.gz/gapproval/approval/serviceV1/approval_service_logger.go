package serviceV1

import (
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
)

func NewApprovalLoggerService(m *model.ApprovalLogger) error {
	if err := config.GetDb().Create(m).Error; err != nil {
		logger.Error("NewApprovalLoggerService#数据库创建失败", "err", err.Error(), "model", m)
		return err
	}
	return nil
}
