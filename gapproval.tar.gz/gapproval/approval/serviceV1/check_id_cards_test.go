package serviceV1

//import (
//	"testing"
//	"gapproval/approval/model"
//	"github.com/stretchr/testify/assert"
//	"gapproval/approval/db/config"
//)
//
//func TestCheckIdCard(t *testing.T) {
//	oneStepTest(func() {
//		ao := model.GetDefaultApprovalOrder()
//		assert.NoError(t, NewApprovalOrder(ao))
//		result, err := GetCheckIdCardResult(ao.JinjianId, "516504610", "擦擦擦")
//		assert.NoError(t, err)
//		assert.Equal(t, "matched", result)
//	}, func() {
//		record := model.GetTestMatchedIdCardsCheckRecord()
//		// 插入一条匹配的记录
//		assert.NoError(t, config.GetDb().Model(&model.IdCardsCheckRecord{}).Create(record).Error)
//		result, err := GetCheckIdCardResult(record.JinjianId, record.IdCard, record.Name)
//		assert.NoError(t, err)
//		assert.Equal(t, "matched", result)
//		result, err = GetCheckIdCardResult(record.JinjianId, record.IdCard, "不正确的名字")
//		assert.NoError(t, err)
//		assert.Equal(t, "unmatched", result)
//		result, err = GetCheckIdCardResult(record.JinjianId, "换个身份证号码(有可能同名不同证[虽然几率很小])", record.Name)
//		assert.NoError(t, err)
//		assert.Equal(t, "matched", result)
//
//	}, func() {
//		record := model.GetTestUnmatchedIdCardsCheckRecord()
//		// 插入一条不匹配的记录
//		assert.NoError(t, config.GetDb().Model(&model.IdCardsCheckRecord{}).Create(record).Error)
//		result, err := GetCheckIdCardResult(record.JinjianId, record.IdCard, record.Name)
//		assert.NoError(t, err)
//		assert.Equal(t, "unmatched", result)
//		result, err = GetCheckIdCardResult(record.JinjianId, record.IdCard, "换个数据库中没有的名字(并且是正确的)")
//		assert.NoError(t, err)
//		assert.Equal(t, "matched", result)
//		result, err = GetCheckIdCardResult(record.JinjianId, "换个身份证号码(有可能同名不同证[虽然几率很小])", record.Name)
//		assert.NoError(t, err)
//		assert.Equal(t, "matched", result)
//	}, )
//}
