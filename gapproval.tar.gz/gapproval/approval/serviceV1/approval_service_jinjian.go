package serviceV1

import (
	"gapproval/approval/model"
	"errors"
	"time"
	"gcoresys/common/util"
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
	"gapproval/approval/service"
)

/**
	@author  wangxi
	@desc	重构后版本： 这里都是 进件端、中介端需要的方法
	@time 2017-09-06 16:41:44
 */

// 黄经理提的，补录时实时更新
func RealTimeUpdateBuluInfo(jinjianId, allInfoType string, allInfo map[string]interface{}) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return
	}
	var aoMap map[string]interface{}
	if err = util.ParseJson(ao.AllInfo, &aoMap); err != nil {
		return
	}

	if allInfoType == "bank" {
		if allInfo["other_bank"] == nil {
			logger.Error("补录时实时更新, other_bank为空", "jinjianId", jinjianId)
			return errors.New("other_bank不能为空")
		}
		aoMap["other_bank"] = allInfo["other_bank"]
	}

	if allInfoType == "call" {
		if allInfo["other_call"] == nil {
			logger.Error("补录时实时更新, other_call为空", "jinjianId", jinjianId)
			return errors.New("other_call不能为空")
		}
		aoMap["other_call"] = allInfo["other_call"]
	}

	allInfoStr := util.StringifyJson(aoMap)
	if err = config.GetDb().Model(ao).Where("id = ?", ao.ID).Update("all_info", allInfoStr).Error; err != nil {
		return err
	}
	return
}

//  创建审批单
func NewApprovalOrder(order *model.ApprovalOrder) (err error) {
	if err = order.IsValidApprovalOrder(); err != nil {
		return
	}
	if err = transactNewApprovalOrder(order); err != nil {
		return
	}
	return
}

//  进件系统更新打回状态
func UpdateApprovalOrderBack(jinjianId string, allInfo map[string]interface{}) (err error) {
	if jinjianId == "" {
		err = errors.New("更新打回状态，进件id不能为空，请检查参数")
		return
	}
	if err = transactUpdateApprovalOrderBack(jinjianId, allInfo); err != nil {
		return
	}
	return
}

//  中介端更改状态 --> 待渠道放款 --> 待用户补录数据 --> 待初审
func AgencyChangeStatus(jinjianId string, statusType string, agencyChangeInfo map[string]interface{}) (err error) {
	if jinjianId == "" {
		err = errors.New("中介端更新审批单状态，进件id不能为空，请检查参数")
		return
	}
	if err = transactAgencyChangeStatus(jinjianId, statusType, agencyChangeInfo); err != nil {
		return
	}
	return
}

//  进件端和中介端获取审批单详情
func QyGetApprovalOrder(jinjianId string) (ao model.ApprovalOrder, err error) {
	if err = config.GetDb().Model(ao).Where("jinjian_id = ?", jinjianId).First(&ao).Error; err != nil {
		logger.Error("进件id: " + jinjianId + "=====QyGetApprovalOrder========获取审批单详情出错============: " + err.Error())
	}
	return
}

//  transact func 中介端更新状态
func transactAgencyChangeStatus(jinjianId string, statusType string, agencyChangeInfo map[string]interface{}) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return err
	}
	switch statusType {
	case "agency_confirm":
		//if ao.FundSide != model.MrOnionFundSide {
		//	if err = agencyConfirm(ao, agencyChangeInfo, time.Now()); err != nil {
		//		return
		//	}
		//}
		return
	case "user_input":
		if err = userInput(ao, agencyChangeInfo, time.Now()); err != nil {
			return
		}
	default:
		err = errors.New("状态参数错误，请检查statusType")
		return
	}
	// 业务留痕
	service.AsyncApprovalTrace(ao)
	return
}

// 渠道反馈     现在已近 接近废弃
func agencyConfirm(ao model.ApprovalOrder, agencyChangeInfo map[string]interface{}, now time.Time) (err error) {
	// 检查状态是不是待渠道反馈
	if ao.FirstTrailStatus != model.ApprovalStatusWaitAgencyConfirm {
		err = errors.New("审批单状态错误，请检查，状态不是" + model.ApprovalStatusWaitAgencyConfirm)
		return
	}
	// 更新中介端更新order_info
	ao.OrderInfo = util.StringifyJson(agencyChangeInfo)
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.AgencyEmployee,
		ApprovalStatus: "反馈他行审批状态", ApprovalType: "cs"})
	// 设置提交时间  中介和进件系统需要的字段
	ao.CommitTime = &now
	ao.FirstTrailStatus = model.ApprovalStatusWaitUserInput // 将状态 变成 待补录数据
	if err = config.GetDb().Model(ao).Updates(&ao).Error; err != nil {
		return err
	}
	return
}

// 中介开的用户补录数据  用户补录
func userInput(ao model.ApprovalOrder, agencyChangeInfo map[string]interface{}, now time.Time) (err error) {
	// 检查状态是不是 待补录数据
	if ao.FirstTrailStatus != model.ApprovalStatusWaitUserInput {
		err = errors.New("审批单状态错误，请检查，状态不是" + model.ApprovalStatusWaitUserInput)
		return
	}
	var aoMap map[string]interface{}
	if err = util.ParseJson(ao.AllInfo, &aoMap); err != nil {
		return
	}
	resultMap, err := updateMap(aoMap, agencyChangeInfo)
	if err != nil {
		return err
	}
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.JinjianUserName,
		ApprovalStatus: "用户完成补录", ApprovalType: "cs"})
	ao.AllInfo = util.StringifyJson(resultMap)
	// 设置审核中时间  中介和进件系统需要的字段
	ao.ApprovalStartTime = &now
	ao.FirstTrailStatus = model.ApprovalStatusWaitInterView // 将状态 变成 待面签
	ao.AgencyStatus = model.AgencyStatusSHZ                 // 将中介状态 变成 待审查
	if err = config.GetDb().Model(ao).Updates(&ao).Error; err != nil {
		return err
	}

	return
}

//  transact func  更新打回状态
func transactUpdateApprovalOrderBack(jinjianId string, allInfo map[string]interface{}) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return err
	}

	statusDesc := "审批打回"

	if ao.InterViewStatus == model.ApprovalStatusInterViewRepulse {
		statusDesc = "面签打回"
	}

	var aoMap map[string]interface{}
	if err = util.ParseJson(ao.AllInfo, &aoMap); err != nil {
		return
	}
	// 检查map
	resultMap, err := updateMap(aoMap, allInfo)
	if err != nil {
		return
	}

	if idcardInfoMap, ok := resultMap["idcard_info"].(map[string]interface{}); ok {
		if name, ok := idcardInfoMap["name"].(string); ok {
			ao.JinjianUserName = name
		}
	}

	if idcardInfoMap, ok := resultMap["idcard_info"].(map[string]interface{}); ok {
		if number, ok := idcardInfoMap["number"].(string); ok {
			ao.UserIdNum = number
		}
	}

	ao.AllInfo = util.StringifyJson(resultMap)
	tmp := ao.FirstTrailStatusRepulse
	ao.FirstTrailStatusRepulse = ""
	ao.FirstTrailStatusDes = ""

	if statusDesc == "审批打回" {
		ao.AgencyStatus = model.AgencyStatusSHZ
		ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail // 初审状态 从 初审打回 变成 待初审
	}

	if statusDesc == "面签打回" {
		ao.AgencyStatus = "已提交"
		ao.InterViewStatus = model.ApprovalStatusInterViewing
		if ao.FirstTrailStatus == model.ApprovalStatusFirstTrailBackIv {
			ao.InterViewStatus = model.ApprovalStatusFirstTrailBackIv
		}
		if ao.ReTrailStatus == model.ApprovalStatusReTrailBackIv {
			ao.InterViewStatus = model.ApprovalStatusReTrailBackIv
		}
	}

	if err = config.GetDb().Model(ao).Update("first_trail_status_repulse", ao.FirstTrailStatusRepulse).
		Update("first_trail_status_des", ao.FirstTrailStatusDes).
		Updates(ao).Error; err != nil {
		return err
	}

	if statusDesc == "面签打回" {
		service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_USERINPUT, model.TP_INTERVIEW)
		// 创建审批记录
		service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.JinjianUserName,
			ApprovalStatus: "用户更新打回资料 ",
			ApprovalType: "mq", ApprovalDesc: "面签打回项：" + tmp})
	}

	if statusDesc == "审批打回" {
		service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_USERINPUT, model.TP_CS)
		// 创建审批记录
		service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.JinjianUserName,
			ApprovalStatus: "用户更新打回资料 ",
			ApprovalType: "cs", ApprovalDesc: "审批打回项：" + tmp})
	}

	// 业务留痕
	service.AsyncApprovalTrace(ao)
	return
}

func updateMap(aoMap, upMap map[string]interface{}) (map[string]interface{}, error) {
	var shouldUpdate bool = false
	if upMap["call_record"] != nil {
		shouldUpdate = true
		aoMap["call_record"] = upMap["call_record"]
	}
	if upMap["contacts"] != nil {
		shouldUpdate = true
		aoMap["contacts"] = upMap["contacts"]
	}
	if upMap["idcard_info"] != nil {
		shouldUpdate = true
		aoMap["idcard_info"] = upMap["idcard_info"]
	}
	if upMap["other_bank"] != nil {
		shouldUpdate = true
		aoMap["other_bank"] = upMap["other_bank"]
	}
	if upMap["other_call"] != nil {
		shouldUpdate = true
		aoMap["other_call"] = upMap["other_call"]
	}
	if upMap["personal_info"] != nil {
		shouldUpdate = true
		aoMap["personal_info"] = upMap["personal_info"]
	}
	if upMap["salary_bank"] != nil {
		shouldUpdate = true
		aoMap["salary_bank"] = upMap["salary_bank"]
	}
	if upMap["credit_files"] != nil {
		shouldUpdate = true
		aoMap["credit_files"] = upMap["credit_files"]
	}
	if !shouldUpdate {
		err := errors.New("请检查map，未更新approval jinjian map")
		return nil, err
	}
	return aoMap, nil
}

//   transact func  处理创建审批单的逻辑
func transactNewApprovalOrder(newAo *model.ApprovalOrder) (err error) {
	// 开启事物
	txSqlBase := config.GetDb().Begin()
	defer util.ClearTransaction(txSqlBase)
	// 创建审批记录
	txSqlBase.Model(&model.ApprovalLog{}).Create(&model.ApprovalLog{ApprovalJinjianId: newAo.JinjianId,
		ApprovalName: newAo.JinjianUserName, ApprovalStatus: "用户完成进件", ApprovalType: "cs"})
	// 设置提交时间  中介和进件系统需要的字段
	nowTime := time.Now()
	newAo.CommitTime = &nowTime
	// 移除待反馈
	if newAo.FirstTrailStatus == "" {
		// 11月新需求， 移除待反馈放款
		newAo.FirstTrailStatus = model.ApprovalStatusWaitUserInput
		newAo.InterViewStatus = model.ApprovalStatusWaitInterView
	}

	// 获取身份证归属地信息 和 身份证姓名是否匹配
	newAo.IdCardPlace = GetPlaceInfoByIdNum(newAo.UserIdNum)
	newAo.IdCardCheckResult = CheckIdCardAndName(newAo.JinjianId, newAo.UserIdNum, newAo.JinjianUserName)

	// 计算审批次数
	var count int
	if err = config.GetDb().Model(newAo).Where("user_id_num=?", newAo.UserIdNum).Count(&count).Error; err != nil {
		logger.Error("============查询审批单出错err: " + err.Error())
		txSqlBase.Rollback()
		return
	}
	newAo.ApprovalTimesByIdNum = count + 1 // todo, 旧数据

	// 创建审批单
	if err = txSqlBase.Model(newAo).Create(newAo).Error; err != nil {
		logger.Error("============创建审批单出错err: " + err.Error())
		txSqlBase.Rollback()
		return
	}
	// 处理渠道经理
	var cm []string
	if err = util.ParseJson(newAo.ChannelManager, &cm); err != nil {
		logger.Error("==========解析数组字符串出错", err, err.Error())
		txSqlBase.Rollback()
		return
	}

	if len(cm) == 0 {
		err = errors.New("渠道经理数组长度为0")
		logger.Error("==========渠道经理数组长度为0")
		txSqlBase.Rollback()
		return
	}

	for _, channelManager := range cm {
		if channelManager == "" {
			err = errors.New("渠道经理为空")
			logger.Error("==========创建渠道经理记录错误", "err", err.Error())
			txSqlBase.Rollback()
			return
		}
		acm := &model.ApprovalChannelManager{ApprovalOrderID: newAo.ID, ChannelManager: channelManager}
		if err = txSqlBase.Model(acm).Create(acm).Error; err != nil {
			logger.Error("==========创建渠道经理记录错误", "err", err.Error())
			txSqlBase.Rollback()
			return
		}
	}

	//  这里需要 jinjian绑定 预审  15天内
	before90Time := nowTime.AddDate(0, 0, -15)
	if err = txSqlBase.Model(&model.PreApprovalOrder{}).
		Where("user_id_num = ? AND pre_approval_status = ? AND jinjian_id = ? AND pass_time BETWEEN ? AND ?",
		newAo.UserIdNum, model.PREAPPROVALPASS, "", before90Time, nowTime).
		Order("created_at desc").Limit(1).Update("jinjian_id", newAo.JinjianId).Error; err != nil {
		logger.Error("==========预审绑定错误", "err", err.Error())
		txSqlBase.Rollback()
	}

	txSqlBase.Commit()

	// 时间统计
	service.AsyncApprovalTimeRecord(newAo.JinjianId, model.TP_JINJIAN, model.TP_JINJIAN, model.TP_GRAB_IV)

	// 业务留痕
	service.AsyncApprovalTrace(*newAo)

	return
}

// 进件系统需要的接口
func GetApprovalOrderList(indexType bool, order *model.ApprovalOrder, page int) ([]*model.ApprovalOrder, int) {
	orders := []*model.ApprovalOrder{}
	offset := util.GetOffset(page, perPage)
	var totalPage int
	if indexType {
		config.GetDb().Limit(2).Where(order).Order("updated_at desc").Find(&orders)
	} else {
		selectDb := config.GetDb().Where(order)
		selectDb.Offset(offset).Limit(perPage).Find(&orders)
		tp, _ := util.GetTotalPagesAndCount(selectDb, &model.ApprovalOrder{}, perPage)
		totalPage = tp
	}
	return orders, totalPage
}
