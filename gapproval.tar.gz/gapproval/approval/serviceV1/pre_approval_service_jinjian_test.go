package serviceV1

/**
 @FileDescription: 
 @author: WangXi
 @create: 10:39 2018/1/3
*/

import (
	"gapproval/approval/model"
	"time"
	"strconv"
	"gapproval/approval/service"
)

func (s *testingSuite) TestCreatePreApproval() {
	pao := model.GetDefaultPreApprovalOrder()
	s.NoError(service.CreatePreApproval(pao))
}

func (s *testingSuite) TestUpdatePreApprovalFile1() {
	pao := model.GetDefaultPreApprovalOrder()
	pao.IsFast = ""
	s.NoError(service.CreatePreApproval(pao))
	s.NoError(GrabPreApproval("test001", "测试001"))
	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	s.Equal("test001", paoR.PreTrailId)
	s.Equal("测试001", paoR.PreTrailName)
	s.Equal(model.PREAPPROVALING, paoR.PreApprovalStatus)
	// 打回
	s.NoError(PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: pao.PreApprovalID,
		PreApprovalStatus: model.PREAPPROVALREPULSE, OpDesc: "ssss"}))
	paoR1, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NotNil(paoR1.RepulseTime)
	s.NoError(err)
	s.Equal(model.PREAPPROVALREPULSE, paoR1.PreApprovalStatus)

	ct, err := UpdatePreApprovalFile(paoR1.PreApprovalID, `{"a": "ddddd"}`)
	s.Nil(ct)
	s.NoError(err)

	paoR2, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NotNil(paoR2.UpdateTime)
	s.NoError(err)
	s.Equal(model.PREAPPROVALING, paoR2.PreApprovalStatus)
}

func (s *testingSuite) TestUpdatePreApprovalFile2() {
	pao := model.GetDefaultPreApprovalOrder()
	pao.IsFast = ""
	s.NoError(service.CreatePreApproval(pao))
	s.NoError(GrabPreApproval("test001", "测试001"))
	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	s.Equal("test001", paoR.PreTrailId)
	s.Equal("测试001", paoR.PreTrailName)
	s.Equal(model.PREAPPROVALING, paoR.PreApprovalStatus)
	// 打回
	s.NoError(PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: pao.PreApprovalID,
		PreApprovalStatus: model.PREAPPROVALREPULSE, OpDesc: "ssss"}))
	paoR1, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NotNil(paoR1.RepulseTime)
	s.NoError(err)
	s.Equal(model.PREAPPROVALREPULSE, paoR1.PreApprovalStatus)

	ct, err := UpdatePreApprovalFile(paoR1.PreApprovalID, "")
	s.Nil(ct)
	s.EqualError(err, "更新打回，预审材料不能为空")
}

func (s *testingSuite) TestUpdatePreApprovalFile3() {
	pao := model.GetDefaultPreApprovalOrder()
	s.NoError(service.CreatePreApproval(pao))
	s.NoError(GrabPreApproval("test001", "测试001"))
	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	s.Equal("test001", paoR.PreTrailId)
	s.Equal("测试001", paoR.PreTrailName)
	s.Equal(model.PREAPPROVALING, paoR.PreApprovalStatus)
	paoR1, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(model.PREAPPROVALING, paoR1.PreApprovalStatus)

	ct, err := UpdatePreApprovalFile(paoR1.PreApprovalID, `{"a": "ddddd"}`)
	s.Nil(ct)
	s.EqualError(err, "预审状态应该为"+model.PREAPPROVALREPULSE)
}

func (s *testingSuite) TestCheckPaRefuseByUserIdNum() {
	pao := model.GetDefaultPreApprovalOrder()
	pao.QuantizationMap = `
{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`

	pao.QuantizationCache = `
{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`

	pao.QuantizationPoint = 400
	pao.QuantizationLevel = 5
	s.NoError(service.CreatePreApproval(pao))
	s.NoError(GrabPreApproval("test001", "测试001"))
	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	s.Equal("test001", paoR.PreTrailId)
	s.Equal("测试001", paoR.PreTrailName)
	s.NotNil(paoR.StartTime)
	s.Equal(model.PREAPPROVALING, paoR.PreApprovalStatus)
	// 拒绝
	s.NoError(PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: pao.PreApprovalID,
		PreApprovalStatus: model.PREAPPROVALREFUSE, OpDesc: "sss", RefuseReason: "123123",ExternalReason:"123"}))

	paoR1, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.NotNil(paoR1.RefuseTime)
	s.Equal(model.PREAPPROVALREFUSE, paoR1.PreApprovalStatus)

	time.Sleep(1 * time.Second)

	rB, err := service.CheckPaRefuseByUserIdNum(pao.UserIdNum)
	s.NoError(err)
	s.NotNil(rB)
}

func (s *testingSuite) TestBatchGetPreApprovalInfoQy() {
	for i := 1; i < 15; i ++ {
		paoF := model.GetDefaultPreApprovalOrder()
		paoF.PreApprovalID = "12345670" + strconv.Itoa(i)
		s.NoError(service.CreatePreApproval(paoF))
		time.Sleep(10 * time.Millisecond)
	}

	arr := []string{"123456701", "123456702", "123456703"}

	list, err := BatchGetPreApprovalInfoQy(arr)
	s.NoError(err)

	s.Equal(3, len(list))

}

func (s *testingSuite) TestCreatePreApprovalIsFast() {
	pao := model.GetDefaultPreApprovalOrder()

	pao.IsFast = model.FS_PREAPPROVAL

	s.NoError(service.CreatePreApproval(pao))

	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	s.Equal("auto_pass", paoR.PreTrailId)
	s.Equal("自动通过", paoR.PreTrailName)
	s.NotNil(paoR.PassTime)
	s.Equal(model.PREAPPROVALPASS, paoR.PreApprovalStatus)

}
