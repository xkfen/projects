package serviceV1

import (
	"gapproval/approval/model"
	"fmt"
	"gcoresys/common/util"
	"time"
	"gapproval/approval/service"
)

func (s *testingSuite) TestNewApprovalOrder() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))

}

func (s *testingSuite) TestUpdateMap() {
	var upMap map[string]interface{}
	upMap = make(map[string]interface{})
	upMap["other_bank"] = `{"test":"test"}`
	upMap["call_record"] = `{"test1":"test1"}`
	upMap["contacts"] = `{"test2":"test2"}`
	upMap["idcard_info"] = `{"test3":"test3"}`
	upMap["personal_info"] = `{"test4":"test4"}`
	upMap["salary_bank"] = `{"test5":"test5"}`

	var aoMap map[string]interface{}
	aoMap = make(map[string]interface{})
	resultMap, err := updateMap(aoMap, upMap)
	s.NoError(err)
	s.NoError(err)
	s.NotNil(resultMap)

}

func (s *testingSuite) TestUpdateApprovalOrderBack() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	var upMap map[string]interface{}
	upMap = make(map[string]interface{})
	upMap["other_bank"] = `{"test":"test"}`
	upMap["call_record"] = `{"test1":"test1"}`
	upMap["contacts"] = `{"test2":"test2"}`
	upMap["idcard_info"] = `{"test3":"test3"}`
	upMap["personal_info"] = `{"test4":"test4"}`
	upMap["salary_bank"] = `{"test5":"test5"}`
	s.NoError(UpdateApprovalOrderBack(ao.JinjianId, upMap))
}

func (s *testingSuite) TestAgencyChangeStatus_agency_confirm() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "agency_confirm", map[string]interface{}{"sss":"dfff"}))
}

func (s *testingSuite) TestAgencyChangeStatus_user_inputs() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "agency_confirm", map[string]interface{}{"sss":"dfff"}))
	s.NoError(AgencyChangeStatus(ao.JinjianId, "user_input", map[string]interface{}{"salary_bank": "dfff"}))
}

func (s *testingSuite) TestQyGetApprovalOrder() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	r, err := QyGetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal(true, r.ID != 0)
}

func (s *testingSuite) TestNewApprovalOrderPaoBindJinjianId() {
	pao := model.GetDefaultPreApprovalOrder()
	pao.QuantizationMap = `
{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`

	pao.QuantizationCache = `
{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`

	pao.QuantizationPoint = 400
	pao.QuantizationLevel = 5
	s.NoError(service.CreatePreApproval(pao))
	s.NoError(GrabPreApproval("test001", "测试001"))
	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	s.Equal("test001", paoR.PreTrailId)
	s.Equal("测试001", paoR.PreTrailName)
	s.NotNil(paoR.StartTime)
	s.Equal(model.PREAPPROVALING, paoR.PreApprovalStatus)
	// pass
	s.NoError(PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: pao.PreApprovalID,
		PreApprovalStatus: model.PREAPPROVALPASS, OpDesc: "sss",
		IntroductionPlanNum: `{"s":"b"}`, IntroductionFundSide: model.MrOnionFundSide}))

	time.Sleep(500 *time.Millisecond)

	ao := model.GetDefaultApprovalOrder()
	ao.UserIdNum = pao.UserIdNum
	s.NoError(NewApprovalOrder(ao))

	paoR1, err := GetPreApprovalInfo(pao.PreApprovalID)

	fmt.Println(util.StringifyJson(paoR1))

	s.NoError(err)
	s.NotNil(paoR1.PassTime)
	s.Equal(model.PREAPPROVALPASS, paoR1.PreApprovalStatus)
	s.Equal(ao.JinjianId, paoR1.JinjianId)
}
