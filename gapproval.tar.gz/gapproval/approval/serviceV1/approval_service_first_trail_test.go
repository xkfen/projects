package serviceV1

import (
	"gapproval/approval/model"
	"fmt"
	"gcoresys/common/util"
	"time"
	"testing"
	"github.com/stretchr/testify/assert"
	ivModel "gapproval/interview/model"
)

func (s *testingSuite) TestGetFirstTrailApprovalOrderList() {
	ao1 := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao1))
	ao2 := model.GetDefaultApprovalOrder()
	ao2.JinjianId = ao2.JinjianId + "2"
	ao2.ShowId = ao2.ShowId + "2"
	s.NoError(NewApprovalOrder(ao2))
	ao3 := model.GetDefaultApprovalOrder()
	ao3.JinjianId = ao3.JinjianId + "3"
	ao3.ShowId = ao3.ShowId + "3"
	ao3.InterView = `{}`
	s.NoError(NewApprovalOrder(ao3))
	aoList, tp ,_:= GetFirstTrailApprovalOrderList("all", "all",
		"cs001", "初审001", "", "", 1)
	s.Equal(1, tp)
	s.Equal(true, len(aoList) > 0)
	s.Equal(3, len(aoList))
}

func (s *testingSuite) TestGetFirstTrailApprovalOrderList1() {
	ao1 := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao1))
	ao2 := model.GetDefaultApprovalOrder()
	ao2.JinjianId = ao2.JinjianId + "2"
	ao2.ShowId = ao2.ShowId + "2"
	s.NoError(NewApprovalOrder(ao2))
	ao3 := model.GetDefaultApprovalOrder()
	ao3.JinjianId = ao3.JinjianId + "3"
	ao3.ShowId = ao3.ShowId + "3"
	ao3.InterView = `{}`
	s.NoError(NewApprovalOrder(ao3))
	aoList, tp ,_ := GetFirstTrailApprovalOrderList("me", "all",
		"cs001", "初审001", "", "", 1)
	s.Equal(0, tp)
	s.Equal(true, len(aoList) == 0)
	s.Equal(0, len(aoList))
}

func (s *testingSuite) TestGetFirstTrailApprovalOrderList2() {
	ao1 := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao1))
	ao2 := model.GetDefaultApprovalOrder()
	ao2.JinjianId = ao2.JinjianId + "2"
	ao2.ShowId = ao2.ShowId + "2"
	s.NoError(NewApprovalOrder(ao2))
	ao3 := model.GetDefaultApprovalOrder()
	ao3.JinjianId = ao3.JinjianId + "3"
	ao3.ShowId = ao3.ShowId + "3"
	ao3.InterView = `{}`
	s.NoError(NewApprovalOrder(ao3))
	aoList, tp, _ := GetFirstTrailApprovalOrderList("history", "all",
		"cs001", "初审001", "", "", 1)
	s.Equal(0, tp)
	s.Equal(true, len(aoList) == 0)
	s.Equal(0, len(aoList))
}

func (s *testingSuite) TestGetFirstTrailApprovalOrderList3() {
	ao1 := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao1))
	ao2 := model.GetDefaultApprovalOrder()
	ao2.JinjianId = ao2.JinjianId + "2"
	ao2.ShowId = ao2.ShowId + "2"
	s.NoError(NewApprovalOrder(ao2))
	ao3 := model.GetDefaultApprovalOrder()
	ao3.JinjianId = ao3.JinjianId + "3"
	ao3.ShowId = ao3.ShowId + "3"
	ao3.InterView = `{}`
	s.NoError(NewApprovalOrder(ao3))
	aoList, tp, _ := GetFirstTrailApprovalOrderList("all", model.ApprovalStatusWaitUserInput,
		"cs001", "初审001", "", "", 1)
	s.Equal(1, tp)
	s.Equal(true, len(aoList) > 0)
	s.Equal(3, len(aoList))
}

func (s *testingSuite) TestGetFirstTrailApprovalOrderList4() {
	ao1 := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao1))
	ao2 := model.GetDefaultApprovalOrder()
	ao2.JinjianId = ao2.JinjianId + "2"
	ao2.ShowId = ao2.ShowId + "2"
	s.NoError(NewApprovalOrder(ao2))
	aoList, tp, _ := GetFirstTrailApprovalOrderList("all", model.ApprovalStatusWaitUserInput,
		"cs001", "初审001", "", ao2.JinjianUserName, 1)
	s.Equal(1, tp)
	s.Equal(true, len(aoList) > 0)
	s.Equal(2, len(aoList))
}

func (s *testingSuite) TestGetFirstTrailApprovalOrderList5() {
	ao1 := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao1))
	ao1.FirstTrailId = "cs001"
	ao1.FirstTrailName = "初审001"
	aoList, tp, _ := GetFirstTrailApprovalOrderList("all", "all",
		"cs001", "初审001", "", "", 1)
	s.Equal(1, tp)
	s.Equal(true, len(aoList) > 0)
	s.Equal(1, len(aoList))
}

func (s *testingSuite) TestGetFirstTrailApprovalOrderList6() {
	ao1 := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao1))
	ao2 := model.GetDefaultApprovalOrder()
	ao2.JinjianId = ao2.JinjianId + "2"
	ao2.ShowId = ao2.ShowId + "2"
	s.NoError(NewApprovalOrder(ao2))
	ao3 := model.GetDefaultApprovalOrder()
	ao3.JinjianId = ao3.JinjianId + "3"
	ao3.ShowId = ao3.ShowId + "3"
	ao3.InterView = `{}`
	s.NoError(NewApprovalOrder(ao3))
	aoList, tp ,_:= GetFirstTrailApprovalOrderList("all", "all",
		"cs001", "初审001", "created_at desc", "", 1)
	s.Equal(1, tp)
	s.Equal(true, len(aoList) > 0)
	s.Equal(3, len(aoList))
}

func (s *testingSuite) TestGetThreePartyInfo() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	s.NoError(NewApprovalOrder(ao))
	tpi := model.GetDefaultThreePartyInfo()
	tpi.JinjianId = ao.JinjianId
	s.NoError(NewOrUpdateThreePartyInfo(tpi))
	tR := GetThreePartyInfo(ao.JinjianId)
	s.NotNil(tR)
}

func (s *testingSuite) TestFirstTrailPassOrRefuse() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	ao.RiskParam = `{"s":"ds"}`
	ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
	s.NoError(NewApprovalOrder(ao))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "agency_confirm", map[string]interface{}{
	//	"salary_bank" : map[string]interface{}{"salary_bank1" : "sssss"}}))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "user_input", map[string]interface{}{
	//	"salary_bank": map[string]interface{}{"salary_bank1": "sssss"}}))
	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	//s.Equal(model.ApprovalStatusWaitFirstTrail, aR.FirstTrailStatus)
	s.NoError(UploadApprovalFile(&model.ApprovalUploadFile{JinjianId: ao.JinjianId, FileType: model.FT_DIANHE,
		FileUrl: "/sdsd/dsdsd/aaa.x", FileName: "sdfsdfds"}))
	csR := model.GetDefaultApprovalCsResult()
	csR.ApprovalId = aR.ID
	s.NoError(NewApprovalCsResult(csR))
	tpi := model.GetDefaultThreePartyInfo()
	tpi.JinjianId = aR.JinjianId
	s.NoError(NewOrUpdateThreePartyInfo(tpi))
	s.NoError(firstTrailPassOrRefuse(aR, &model.ApprovalOrder{FirstTrailStatus: model.ApprovalStatusFirstTrailRefuse,
		FirstTrailStatusDes: "sssssvvvvvv", RefuseReason: "dfsdfdsfdsfdsfsd"}))
	aR, _, err = GetApprovalOrder(ao.JinjianId)
	s.Equal(model.ApprovalStatusWaitReTrail, aR.ReTrailStatus)
	s.Equal(model.ApprovalStatusFirstTrailRefuse, aR.FirstTrailStatus)
}

func (s *testingSuite) TestFirstTrailPassOrRefuse2() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	ao.RiskParam = `{"s":"ds"}`
	ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
	ao.FundSide = model.CLFundSide
	s.NoError(NewApprovalOrder(ao))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "agency_confirm", map[string]interface{}{
	//	"salary_bank" : map[string]interface{}{"salary_bank1" : "sssss"}}))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "user_input", map[string]interface{}{
	//	"salary_bank": map[string]interface{}{"salary_bank1": "sssss"}}))
	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal(model.ApprovalStatusWaitFirstTrail, aR.FirstTrailStatus)
	s.NoError(UploadApprovalFile(&model.ApprovalUploadFile{JinjianId: ao.JinjianId, FileType: model.FT_DIANHE,
		FileUrl: "/sdsd/dsdsd/aaa.x", FileName: "sdfsdfds"}))
	csR := model.GetDefaultApprovalCsResult()
	csR.ApprovalId = aR.ID
	s.NoError(NewApprovalCsResult(csR))
	s.NotNil(GetApprovalCsResult(csR.ApprovalId))
	tpi := model.GetDefaultThreePartyInfo()
	tpi.JinjianId = aR.JinjianId
	s.NoError(NewOrUpdateThreePartyInfo(tpi))
	salaryAt := time.Now().AddDate(0, 0, 2)
	loanAt := time.Now().AddDate(0, 0, 3)
	s.NoError(firstTrailPassOrRefuse(aR, &model.ApprovalOrder{FirstTrailStatus: model.ApprovalStatusFirstTrailPass,
		FirstTrailStatusDes: "sssssvvvvvv", Card1: "342423432", ApprovedAmount: 20000000, ApprovedRate: 28, SalaryAt: &salaryAt,
		LoanAt: &loanAt, Cellphone: "321312312312312", BankName: "ICBC", UserIdNum: "432423432423423423", LoanBankName: "ICBC",
		LoanCard: "432432423423", CardOnePhone: "432432423423"}))
	aR, _, err = GetApprovalOrder(ao.JinjianId)
	s.Equal(model.ApprovalStatusWaitReTrail, aR.ReTrailStatus)
	s.Equal(model.ApprovalStatusFirstTrailPass, aR.FirstTrailStatus)
}

func (s *testingSuite) TestFirstTrailBack() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
	s.NoError(NewApprovalOrder(ao))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "agency_confirm", map[string]interface{}{
	//	"salary_bank" : map[string]interface{}{"salary_bank1" : "sssss"}}))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "user_input", map[string]interface{}{
	//	"salary_bank": map[string]interface{}{"salary_bank1": "sssss"}}))
	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	//s.Equal(model.ApprovalStatusWaitFirstTrail, aR.FirstTrailStatus)
	s.NoError(firstTrailRepulse(aR, &model.ApprovalOrder{FirstTrailStatus: model.ApprovalStatusFirstTrailRepulse,
		FirstTrailStatusRepulse: `{"sss" : "dfsfsdf"}`, FirstTrailStatusDes: "dfdsfds"}))
	aR, _, err = GetApprovalOrder(ao.JinjianId)
	s.Equal(model.ApprovalStatusFirstTrailRepulse, aR.FirstTrailStatus)
	s.Equal(true, aR.ApprovalRepulseTime != nil)
	fmt.Println(aR.ApprovalRepulseTime)
}

func (s *testingSuite) TestManageAdditionalRecord() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
	s.NoError(NewApprovalOrder(ao))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "agency_confirm", map[string]interface{}{
	//	"salary_bank" : map[string]interface{}{"salary_bank1" : "sssss"}}))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "user_input", map[string]interface{}{
	//	"salary_bank": map[string]interface{}{"salary_bank1": "sssss"}}))
	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	//s.Equal(model.ApprovalStatusWaitFirstTrail, aR.FirstTrailStatus)
	s.NoError(ManageAdditionalRecord(aR.JinjianId, "bank", "open", "jj", map[string]interface{}{"salary_bank1": "sssfdfss"}))
	aR, _, err = GetApprovalOrder(ao.JinjianId)
	s.Equal(true, aR.AdditionalRecord)
	s.NoError(ManageAdditionalRecord(aR.JinjianId, "bank", "close", "jj", map[string]interface{}{"salary_bank1": "sssfdfss"}))
	aR, _, err = GetApprovalOrder(ao.JinjianId)
	s.Equal(false, aR.AdditionalRecord)
}

func (s *testingSuite) TestManageAdditionalRecord2() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
	s.NoError(NewApprovalOrder(ao))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "agency_confirm", map[string]interface{}{
	//	"salary_bank" : map[string]interface{}{"salary_bank1" : "sssss"}}))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "user_input", map[string]interface{}{
	//	"salary_bank": map[string]interface{}{"salary_bank1": "sssss"}}))
	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal(model.ApprovalStatusWaitFirstTrail, aR.FirstTrailStatus)
	s.NoError(ManageAdditionalRecord(aR.JinjianId, "bank", "open", "jj", map[string]interface{}{"salary_bank1": "sssfdfss"}))
	aR, _, err = GetApprovalOrder(ao.JinjianId)
	s.Equal(true, aR.AdditionalRecord)
	s.NoError(ManageAdditionalRecord(aR.JinjianId, "bank", "close", "sss", map[string]interface{}{"salary_bank1": "sssfdfss"}))
	aR, _, err = GetApprovalOrder(ao.JinjianId)
	s.Equal(false, aR.AdditionalRecord)
}

func (s *testingSuite) TestManageAdditionalRecord3() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
	s.NoError(NewApprovalOrder(ao))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "agency_confirm", map[string]interface{}{
	//	"salary_bank" : map[string]interface{}{"salary_bank1" : "sssss"}}))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "user_input", map[string]interface{}{
	//	"salary_bank": map[string]interface{}{"salary_bank1": "sssss"}}))
	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal(model.ApprovalStatusWaitFirstTrail, aR.FirstTrailStatus)
	s.NoError(ManageAdditionalRecord(aR.JinjianId, "call", "open", "jj", map[string]interface{}{"salary_bank1": "sssfdfss"}))
	aR, _, err = GetApprovalOrder(ao.JinjianId)
	s.Equal(true, aR.CallAdditionalRecord)
	s.NoError(ManageAdditionalRecord(aR.JinjianId, "call", "close", "sss", map[string]interface{}{"salary_bank1": "sssfdfss"}))
	aR, _, err = GetApprovalOrder(ao.JinjianId)
	s.Equal(false, aR.CallAdditionalRecord)
}

func (s *testingSuite) TestUpdateJinjianAllInfo() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
	s.NoError(NewApprovalOrder(ao))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "agency_confirm", map[string]interface{}{
	//	"salary_bank" : map[string]interface{}{"salary_bank1" : "sssss"}}))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "user_input", map[string]interface{}{
	//	"salary_bank": map[string]interface{}{"salary_bank1": "sssss"}}))
	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal(model.ApprovalStatusWaitFirstTrail, aR.FirstTrailStatus)
	//s.NoError(UpdateJinjianAllInfo(ao.JinjianId, "workplace", "深圳启元信息服务有限公司"))
	s.NoError(UpdateJinjianAllInfo(ao.JinjianId, "loanTerm", "111111"))
	a, _, err := GetApprovalOrder(ao.JinjianId)
	fmt.Println(a.LoanTerm)
	s.Equal(int(111111), a.LoanTerm)
	//s.Equal("bzzb", a.AllInfo)
}

//func (s *testingSuite) TestAddContact() {
//	ao := model.GetDefaultApprovalOrder()
//	ao.FirstTrailId = "cs001"
//	ao.FirstTrailName = "初审001"
//	s.NoError(NewApprovalOrder(ao))
//	s.NoError(AddContact(ao.JinjianId, "bbbb", "123453543", "f", "ssss"))
//	s.NoError(AddContact(ao.JinjianId, "cccc", "234324234", "f", "sss"))
//	aR, _, err := GetApprovalOrder(ao.JinjianId)
//	s.NoError(err)
//	s.Equal(true, len(aR.ApprovalAddContacts) > 0)
//	fmt.Println(aR.ApprovalAddContacts)
//}

func (s *testingSuite) TestUpdateAddContact() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	s.NoError(NewApprovalOrder(ao))
	s.NoError(AddContact(ao.JinjianId, "bbbb", "123453543", "f", "ss"))
	s.NoError(AddContact(ao.JinjianId, "cccc", "234324234", "f", "sss"))
	aR1, _, err1 := GetApprovalOrder(ao.JinjianId)
	s.NoError(err1)
	s.Equal(true, len(aR1.ApprovalAddContacts) > 0)
	fmt.Println(aR1.ApprovalAddContacts)
	s.NoError(UpdateAddContact(ao.JinjianId, "name", "aaaa", 1))
	aR2, _, err2 := GetApprovalOrder(ao.JinjianId)
	s.NoError(err2)
	s.Equal(true, len(aR2.ApprovalAddContacts) > 0)
	fmt.Println(aR2.ApprovalAddContacts)
}

func (s *testingSuite) TestSaveRiskParam() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	ao.RiskParam = ""
	s.NoError(NewApprovalOrder(ao))
	rp := map[string]interface{}{"fff": "vvv", "ggg": "ttt"}
	s.NoError(SaveRiskParam(ao.JinjianId, rp, 40000, 0, ""))
	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal(true, aR.RiskParam != "")
}

func (s *testingSuite) TestUpdateRiskParam() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	ao.RiskParam = ""
	s.NoError(NewApprovalOrder(ao))
	rp := map[string]interface{}{"fff": "vvv", "ggg": "ttt"}
	s.NoError(SaveRiskParam(ao.JinjianId, rp, 40000, 0, ""))
	aR1, _, err1 := GetApprovalOrder(ao.JinjianId)
	s.NoError(err1)
	s.Equal(true, aR1.RiskParam != "")
	fmt.Println(aR1.RiskParam)
	kl := map[string]string{"fff": "姓名", "ggg": "爱好"}
	nRp := map[string]interface{}{"fff": "xi", "ggg": "ix"}
	s.NoError(UpdateRiskParam(ao.JinjianId, kl, nRp, 2222, 0, ""))
	aR2, _, err2 := GetApprovalOrder(ao.JinjianId)
	s.NoError(err2)
	s.Equal(true, aR2.RiskParam != "")
	fmt.Println(aR2.RiskParam)
}

func (s *testingSuite) TestNewOrUpdateExtensionNumber() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	s.NoError(NewApprovalOrder(ao))
	s.NoError(NewOrUpdateExtensionNumber(ao.JinjianId, "2225435634"))
	s.NoError(NewOrUpdateExtensionNumber(ao.JinjianId, "22222222222"))
	aR1, _, err1 := GetApprovalOrder(ao.JinjianId)
	s.NoError(err1)
	s.Equal(true, aR1.ExtensionNumber == "22222222222")
	fmt.Println(aR1.ExtensionNumber)
}

func (s *testingSuite) TestGetCallRecord() {
	s.NotNil(GetCallRecord("ddddd"))
	s.Equal(0, len(GetCallRecord("fdsfds")))
}

func (s *testingSuite) TestNewCallRecord() {
	s.NoError(NewCallRecord("ddddd", "111111", "3232", "sdf", "ss"))
	s.EqualError(NewCallRecord("ddddd", "111111", "3232", "sdf", "ss"), "此号码电核材料已存在，无法创建")
	s.Equal(1, len(GetCallRecord("ddddd")))
	fmt.Println(util.StringifyJson(GetCallRecord("ddddd")))
}

func (s *testingSuite) TestUpdateCallRecord() {
	s.NoError(NewCallRecord("ddddd", "111111", "3232", "sdf", "sss"))
	s.EqualError(NewCallRecord("ddddd", "111111", "3232", "sdf", "sss"), "此号码电核材料已存在，无法创建")
	acr := GetCallRecord("ddddd")
	s.Equal(1, len(acr))
	fmt.Println(util.StringifyJson(acr))
	s.NoError(UpdateCallRecord(acr[0].ID, "bzzb", "sdf"))
	acr2 := GetCallRecord("ddddd")
	s.Equal(1, len(acr2))
	s.Equal("bzzb", acr2[0].Desc)
}

func (s *testingSuite) TestCreateUserInfoSup() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	uis := model.GetDefaultApprovalUserInfoSup()
	uis.JinjianId = ao.JinjianId
	s.NoError(CreateUserInfoSup(uis, "test001"))
}

func (s *testingSuite) TestUpdateUserInfoSup() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	uis := model.GetDefaultApprovalUserInfoSup()
	uis.JinjianId = ao.JinjianId
	s.NoError(CreateUserInfoSup(uis, "test001"))

	uis2 := model.GetDefaultApprovalUserInfoSup()
	uis2.JinjianId = ao.JinjianId + "sss"
	s.NoError(CreateUserInfoSup(uis2, "test001"))

	uis3 := model.GetDefaultApprovalUserInfoSup()
	uis3.JinjianId = ao.JinjianId
	uis3.CompanySize = "555555"

	s.NoError(UpdateUserInfoSup(uis3, "test001"))

	r := GetUserInfoSup(ao.JinjianId)
	fmt.Println(r)
	r1 := GetUserInfoSup(ao.JinjianId + "sss")
	fmt.Println(r1)

}

func (s *testingSuite) TestMarkIsStandard() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	s.NoError(MarkIsStandard(ao.JinjianId, "1"))
	ar, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal("1", ar.IsStandard)
}

func (s *testingSuite) TestMarkPlanNum() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	s.NoError(MarkPlanNum(ao.JinjianId, "1110"))
	ar, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal("1110", ar.PlanNum)
}

func TestSaveRiskParamNoPlanNum(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailId = "cs001"
		ao.FirstTrailName = "初审001"
		ao.RiskParam = ""
		ao.PlanNum = ""
		assert.NoError(t, NewApprovalOrder(ao))
		rp := map[string]interface{}{"fff": "vvv", "ggg": "ttt"}
		assert.NoError(t, SaveRiskParam(ao.JinjianId, rp, 40000, 0, ""))
		aR, _, err := GetApprovalOrder(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, true, aR.RiskParam != "")
		assert.Equal(t, "", aR.PlanNum)
	})
}

func TestSaveRiskParamPlanNum(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailId = "cs001"
		ao.FirstTrailName = "初审001"
		ao.RiskParam = ""
		ao.PlanNum = ""
		ao.InterView = util.StringifyJson(&ivModel.Interview{})
		assert.NoError(t, NewApprovalOrder(ao))
		rp := map[string]interface{}{"fff": "vvv", "ggg": "ttt"}
		assert.NoError(t, SaveRiskParam(ao.JinjianId, rp, 40000, 0, `{"a":"b"}`))
		aR, _, err := GetApprovalOrder(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, true, aR.RiskParam != "")
		//assert.Equal(t, `{"a":"b"}`, aR.PlanNum)
	})
}

func TestUpdateRiskParamNoPlanNum(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailId = "cs001"
		ao.FirstTrailName = "初审001"
		ao.RiskParam = ""
		ao.PlanNum = ""
		assert.NoError(t, NewApprovalOrder(ao))
		rp := map[string]interface{}{"fff": "vvv", "ggg": "ttt"}
		assert.NoError(t, SaveRiskParam(ao.JinjianId, rp, 40000, 0, ""))
		aR1, _, err1 := GetApprovalOrder(ao.JinjianId)

		assert.NoError(t, err1)
		assert.Equal(t, true, aR1.RiskParam != "")
		assert.Equal(t, true, aR1.RiskParam != "")
		fmt.Println(aR1.RiskParam)
		kl := map[string]string{"fff": "姓名", "ggg": "爱好"}
		nRp := map[string]interface{}{"fff": "xi", "ggg": "ix"}
		assert.NoError(t, UpdateRiskParam(ao.JinjianId, kl, nRp, 2222, 0, ""))
		aR2, _, err2 := GetApprovalOrder(ao.JinjianId)
		assert.NoError(t, err2)
		assert.Equal(t, true, aR2.RiskParam != "")
		fmt.Println(aR2.RiskParam)

		//assert.Equal(t, "", aR2.PlanNum)
	})
}

func TestUpdateRiskParamPlanNum(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailId = "cs001"
		ao.FirstTrailName = "初审001"
		ao.RiskParam = ""
		ao.PlanNum = ""
		ao.InterView = util.StringifyJson(&ivModel.Interview{})
		assert.NoError(t, NewApprovalOrder(ao))
		rp := map[string]interface{}{"fff": "vvv", "ggg": "ttt"}
		assert.NoError(t, SaveRiskParam(ao.JinjianId, rp, 40000, 0, ""))
		aR1, _, err1 := GetApprovalOrder(ao.JinjianId)

		assert.NoError(t, err1)
		assert.Equal(t, true, aR1.RiskParam != "")
		assert.Equal(t, true, aR1.RiskParam != "")

		assert.Equal(t, "", aR1.PlanNum)

		fmt.Println(aR1.RiskParam)
		kl := map[string]string{"fff": "姓名", "ggg": "爱好"}
		nRp := map[string]interface{}{"fff": "xi", "ggg": "ix"}

		assert.NoError(t, UpdateRiskParam(ao.JinjianId, kl, nRp, 2222, 0, `{"a":"b"}`))
		aR2, _, err2 := GetApprovalOrder(ao.JinjianId)
		assert.NoError(t, err2)
		assert.Equal(t, true, aR2.RiskParam != "")
		fmt.Println(aR2.RiskParam)
		//assert.Equal(t, `{"a":"b"}`, aR2.PlanNum)

	})
}


func TestCSOrderStatistic(t *testing.T){
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailId = "cs001"
		ao.FirstTrailName = "初审001"
		ao.RiskParam = ""
		ao.PlanNum = ""
		ao.InterView = util.StringifyJson(&ivModel.Interview{})
		assert.NoError(t, NewApprovalOrder(ao))
		//aR, _, err := GetApprovalOrder(ao.JinjianId)
	})
}