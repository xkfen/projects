package serviceV1

import (
	"errors"
	"gapproval/approval/db/config"
	"gapproval/approval/model"
	"gcoresys/common/logger"
	"gapproval/common/httpReq"
	"gapproval/common/global"
	"gcoresys/common"
)

// 检查身份证与姓名是否匹配
func GetCheckIdCardResult(orderId string, idCard string, name string) (result string, err error) {
	var checkResult = model.IdCardsCheckRecord{
		JinjianId: orderId, IdCard: idCard, Name: name,
	}

	if err = checkResult.IsValidIdCardsCheckRecord(); err != nil {
		return
	}

	sqlBase := config.GetDb().Model(&model.IdCardsCheckRecord{})
	err = sqlBase.Where("id_card=? and name=?", idCard, name).First(&checkResult).Error
	if checkResult.ID > 0 {
		return checkResult.Result, err
	}

	// 如果找不到记录, 则继续往下运行
	err = sqlBase.Where("(id_card=? || name=?) and result='matched'", idCard, name).First(&checkResult).Error
	if checkResult.ID > 0 {
		return "unmatched", err
	}

	// 如果找不到记录, 则继续往下运行
	//result = CheckIdCard(orderId, idCard, name)

	err = CreateCheckRecord(&model.IdCardsCheckRecord{
		JinjianId: orderId, IdCard: idCard, Name: name, Result: result,
	})

	return
}

// 将匹配的结果保存到数据库
func CreateCheckRecord(record *model.IdCardsCheckRecord) (err error) {
	if err = record.IsValidIdCardsCheckRecord("with_result"); err != nil {
		return
	}
	err = config.GetDb().Model(&model.IdCardsCheckRecord{}).Create(record).Error
	if err != nil {
		logger.Error("创建IdCardsCheckRecord失败", "进件id", record.JinjianId, "error", err)
		err = errors.New("创建记录失败, 请立即联系技术人员, 并稍后重试")
	}
	return
}

// 调用风控接口, 检测 身份证\姓名 是否匹配
func CheckIdCardAndName(orderId string, idCard string, name string) (result string) {
	var req = map[string]string{
		"id":   orderId,
		"card": idCard,
		"name": name,
	}

	if common.GetUseDocker() == 0 {
		return "matched"
	}

	resp, err := httpReq.PostJsonProxy(req, global.GetRiskControlServerUrl()+"/api/v1/id_cards/check")
	if err != nil {
		logger.Error("调用风控系统错误", "err", err.Error())
		return "unmatched"
	}

	logger.Debug("result", "resp", resp)
	r, ok := resp["result"].(string)
	if !ok {
		logger.Warn("身份证号与姓名匹配 返回结果解析错误", "err", resp)
	}
	return r
}
