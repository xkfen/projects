package serviceV1

import (
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"errors"
	"strconv"
	csModel "gcoresys/accounting/model"
	"gcoresys/common/logger"
	common2 "gcoresys/common"
	csServer "gcoresys/accounting/grpc/server"
	"gapproval/common/global"
	"gcoresys/common/util"
	"gapproval/common/httpReq"
	"gapproval/approval/service"
)

// 财务退回
func FinBack(accountId uint, username string, desc string) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Model(ao).Where("account_id = ?", accountId).First(&ao).Error; err != nil {
		return err
	}
	if ao.ReTrailStatus != model.ApprovalStatusReTrailPass || ao.CustomServiceStatus != model.ApprovalStatusCustomPass {
		err = errors.New("审批单状态错误，无法进行财务退回")
		return
	}
	// 终审和客服的状态都为财务退回
	ao.ReTrailStatus = model.ApprovalStatusFinanceBack
	ao.CustomServiceStatus = model.ApprovalStatusFinanceBack
	ao.FinBackDesc = desc

	ao.ApprovalStatus = ao.GetAoCurrStatus()

	if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
		return
	}

	service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_CW, model.TP_ZS)

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: username,
		ApprovalStatus: "财务退回给" + ao.ReTrailName,
		ApprovalType: "zs", ApprovalDesc: desc})

	// 业务留痕
	service.AsyncApprovalTrace(ao)
	return
}

// 查询是否放款
func CheckIsLoan() {
	checkArray := []*model.ApprovalOrder{}
	if err := config.GetDb().Model(&checkArray).Where("custom_service_status = ? AND operator_status <> ? AND account_id <> ?",
		model.ApprovalStatusCustomPass, model.ApprovalStatusOperatorSuccess, 0).Find(&checkArray).Error; err != nil {
		logger.Info("=============获取查询是否放款列表err", "err", err.Error())
		return
	}
	if common2.GetUseDocker() != 0 {
		for _, ao := range checkArray {
			respResult, err1 := httpReq.GetProxyNoCheck(global.GetCoreSysUrl() + "/api/v1/account/" + strconv.Itoa(int(ao.AccountID)))
			if err1 != nil {
				logger.Error("==================请求核心系统查询是否放款出错", "Err: ", err1.Error())
			} else {
				var accountResp csServer.GetAccountResp
				if err := util.ParseJson(respResult, &accountResp); err != nil {
					logger.Error("==================解析核心系统查询是否放款响应出错", "Err: ", err.Error())
				} else {

					if accountResp.Account == nil {
						logger.Error("==================accountResp.Account  nil  " + strconv.Itoa(int(ao.AccountID)))
						return
					}
					UpdateApprovalOrderLoanStatus(*ao, *accountResp.Account)
				}
			}
		}
	}
}

func UpdateApprovalOrderLoanStatus(ao model.ApprovalOrder, account csModel.Account) {
	if account.HaveRepayPlans() {
		ao.OperatorStatus = model.ApprovalStatusOperatorSuccess
		ao.AgencyStatus = model.AgencyStatusYFK
		ao.LoanTime = account.RealLoanAt
		ao.OperatorName = account.Operator
		// 更新放款时间和还款时间
		ao.LoanAt = &account.LoanAt
		ao.SalaryAt = &account.FirstRepayAt
		ao.ApprovalStatus = ao.GetAoCurrStatus()
		if err := config.GetDb().Model(ao).Updates(ao).Error; err != nil {
			logger.Error("=========================更新审批出错", "Err: ", err.Error())
		}

		service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_CW)
	}
}
