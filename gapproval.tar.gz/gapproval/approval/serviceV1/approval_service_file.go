package serviceV1

import (
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
	"fmt"
	"errors"
	"gapproval/approval/service"
)

func UploadApprovalFileV1(file *model.ApprovalFile, opName string) (err error) {
	if err = file.IsValidApprovalFile(); err != nil {
		return
	}
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: file.JinjianId, ApprovalName: opName,
		ApprovalStatus: opName + "上传文件" + "，文件名：" + file.FileName,
		ApprovalType: "cs"})
	if err = config.GetDb().Create(file).Error; err != nil {
		return
	}
	return
}

func UpdateApprovalFile(file *model.ApprovalFile, opName string) (error) {
	if err := file.IsValidApprovalFile(); err != nil {
		return err
	}
	if file.ID == 0 {
		return errors.New("更新审批文件必须要id")
	}
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: file.JinjianId, ApprovalName: opName,
		ApprovalStatus: fmt.Sprintf("%v更新审批文件，文件数据id: %v，更新文件名：%v", opName, file.ID, file.FileName),
		ApprovalType: "cs"})
	return config.GetDb().Model(&model.ApprovalFile{}).Where("id = ?", file.ID).
		Update("file_name", file.FileName).Update("file_url", file.FileUrl).Error
}

func GetApprovalFileV1(jinjianId string) []*model.ApprovalFile {
	var approvalFiles []*model.ApprovalFile
	if err := config.GetDb().Where("jinjian_id =? ", jinjianId).Find(&approvalFiles).Error; err != nil {
		logger.Info("==========获取审批材料出错=============")
		logger.Info(err.Error())
		return nil
	}
	return approvalFiles
}
