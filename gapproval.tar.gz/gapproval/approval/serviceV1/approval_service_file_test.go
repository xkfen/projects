package serviceV1

import (
	"gapproval/approval/model"
	"fmt"
	"gcoresys/common/util"
)

func (s *testingSuite) TestUploadApprovalFileV1() {
	af := model.GetDefaultApprovalFile()
	s.NoError(UploadApprovalFileV1(af, "cssss"))
	aflist := GetApprovalFileV1(af.JinjianId)
	s.Equal(1, len(aflist))
}

func (s *testingSuite) TestUpdateApprovalFile() {
	af := model.GetDefaultApprovalFile()
	s.NoError(UploadApprovalFileV1(af, "cssss"))
	aflist := GetApprovalFileV1(af.JinjianId)
	s.Equal(1, len(aflist))
	af1 := aflist[0]
	af1.FileName = "BBB"
	af1.FileUrl = "CCCC"

	s.NoError(UpdateApprovalFile(af1, "BBB"))

	aflist2 := GetApprovalFileV1(af.JinjianId)
	s.Equal(1, len(aflist2))

	fmt.Println(util.StringifyJson(aflist2[0]))

}
