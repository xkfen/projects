package serviceV1

import (
	"gapproval/approval/model"
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
	"gcoresys/common/util"
	"errors"
	"time"
	"gapproval/common/httpReq"
	"gapproval/common/global"
	"gapproval/approval/service"
)

const QVSEARCHLIMIT = 10 // 为了查询效率，结合业务需求，限制查询在库的量化变量

//  获取预审批单详情
func GetPreApprovalInfo(preApprovalId string) (pao model.PreApprovalOrder, err error) {
	if err = config.GetDb().Model(pao).Where("pre_approval_id = ?", preApprovalId).First(&pao).Error; err != nil {
		logger.Error("=============获取预审批单详情出错============: " + err.Error())
		return
	}
	return
}

//  获取列表  (筛选)
type GetPreApprovalListParam struct {
	// 区分是 订单池、我的订单、历史订单  all  me  history
	TypeKey string `json:"type_key"`
	// 进件筛选  已进件 、 未进件、 全部
	JinjianFilter string `json:"jinjian_filter"`
	// 申请方式 筛选  自主、渠道、全部
	PreApprovalTypeFilter string `json:"pre_approval_type_filter"`
	// 预审批单状态筛选
	PreApprovalStatusFilter string `json:"pre_approval_status_filter"`
	Username                string `json:"username"`
	Name                    string `json:"name"`
	// 排序条件
	Sort string `json:"sort"`
	// 搜索条件
	Condition string `json:"condition"`
	// 页数
	Page int `json:"page"`
	// 预审批提交时间
	CommitTime string `json:"commit_time"`
}

func GetPreApprovalList(p GetPreApprovalListParam) (paoList []model.PreApprovalOrder, totalPage int, totalCount int, err error) {
	offset := util.GetOffset(p.Page, perPage)
	// 判定前端页面选择的是 全部、我的或者是历史 isSelectAll
	p.Username, p.Name = isSelectAll(p.Username, p.Name, p.TypeKey)
	sqlBase := config.GetDb().Model(paoList).
		Where("(pre_trail_id = ? AND pre_trail_name = ? AND pre_approval_status in (?))",
		p.Username, p.Name, model.PreApprovalStatusList(p.TypeKey, p.PreApprovalStatusFilter))

	if p.Condition != "" {
		p.Condition = "%" + p.Condition + "%"
		sqlBase = sqlBase.Where("((user_name LIKE ?) OR (user_id_num LIKE ?) OR (pre_show_id LIKE ?) "+
				"OR (agency_employee LIKE ?) OR (agency_name LIKE ?))",
			p.Condition, p.Condition, p.Condition, p.Condition, p.Condition)
	}

	// 判断是否进件
	switch p.JinjianFilter {
	case "未进件":
		sqlBase = sqlBase.Where("jinjian_id = ?", "")
	case "已进件":
		sqlBase = sqlBase.Where("jinjian_id <> ?", "")
	}

	// 判断 申请方式
	if p.PreApprovalTypeFilter != "" {
		sqlBase = sqlBase.Where("pre_approval_type = ?", p.PreApprovalTypeFilter)
	}

	if p.CommitTime == "asc" || p.CommitTime == "desc" {
		sqlBase = sqlBase.Order(p.CommitTime)
	}

	if p.TypeKey == "history" {
		if p.Sort == "" {
			sqlBase = sqlBase.Order("commit_time desc")
		}
	}

	if p.Sort != "" {
		sqlBase = sqlBase.Order(p.Sort)
	}

	// 获取总页数  总条数
	totalPage, totalCount = util.GetTotalPagesAndCount(sqlBase, &paoList, perPage)
	// 获取预审列表 -- 分页后的数据
	if err := sqlBase.Offset(offset).Limit(perPage).Find(&paoList).Error; err != nil {
		logger.Error("获取预审列表出错", "err", err.Error())
	}

	return
}

//  预审操作    通过（推荐进件方案  推荐资金方案）  打回（自主无打回）   不通过    desc
func PreTrailOperation(changePao *model.PreApprovalOrder) (err error) {
	if changePao.PreApprovalID == "" {
		return errors.New("预审id不能为空")
	}
	var pao model.PreApprovalOrder
	if err = config.GetDb().Model(&model.PreApprovalOrder{}).
		Where("pre_approval_id =?", changePao.PreApprovalID).First(&pao).Error; err != nil {
		return err
	}
	if err = pao.IsValidPreTrailOperation(); err != nil {
		return
	}
	switch changePao.PreApprovalStatus {

	case model.PREAPPROVALPASS:
		if err = preTrailPass(pao, changePao); err != nil {
			return
		}
		PostShenMa(ShenMaMap(pao.PreApprovalID, changePao.PreApprovalStatus))
		return

	case model.PREAPPROVALREFUSE:
		if err = preTrailRefuse(pao, changePao); err != nil {
			return
		}
		PostShenMa(ShenMaMap(pao.PreApprovalID, changePao.PreApprovalStatus))
		return

	case model.PREAPPROVALREPULSE:
		return preTrailRepulse(pao, changePao)

	case model.PREAPPROVALCANCEL:
		if err = preTrailCancel(pao, changePao); err != nil {
			return
		}
		PostShenMa(ShenMaMap(pao.PreApprovalID, changePao.PreApprovalStatus))
		return

	default:
		err = errors.New("状态参数错误，请检查预审单Status")
		return
	}
}

func preTrailPass(pao model.PreApprovalOrder, changePao *model.PreApprovalOrder) (error) {
	if pao.PreApprovalType == model.QD_PREAPPROVAL && pao.IsFast != model.FS_PREAPPROVAL {
		if pao.QuantizationMap == "" || pao.QuantizationPoint == 0 || pao.QuantizationCache == "" {
			return errors.New("请先填写量化变量，并且提交，获取结果")
		}
	}

	if pao.PreApprovalType == model.QD_PREAPPROVAL {
		//if changePao.IntroductionPlanNum == "" {
		//	return errors.New("请推荐进件方案")
		//}

		if changePao.IntroductionFundSide == "" {
			return errors.New("请推荐资金方")
		}
	}

	if changePao.OpDesc == "" {
		return errors.New("预审操作备注不能为空，请填写备注")
	}

	nowTime := time.Now()
	pao.IntroductionFundSide = changePao.IntroductionFundSide
	pao.IntroductionPlanNum = changePao.IntroductionPlanNum
	pao.OpDesc = changePao.OpDesc
	pao.PreApprovalStatus = model.PREAPPROVALPASS
	pao.PassTime = &nowTime

	if err := config.GetDb().Model(&model.PreApprovalOrder{}).Updates(pao).Error; err != nil {
		return err
	}

	service.SendPvSms(pao, "pass")

	service.AsyncNewPreApprovalLog(&model.PreApprovalLog{
		PreApprovalId:     pao.PreApprovalID,
		PreApprovalName:   pao.PreTrailName,
		PreApprovalStatus: pao.PreApprovalStatus,
	})

	return nil
}

func preTrailRefuse(pao model.PreApprovalOrder, changePao *model.PreApprovalOrder) (error) {

	//if pao.PreApprovalType == model.QD_PREAPPROVAL && pao.IsFast != model.FS_PREAPPROVAL {
	//	if pao.QuantizationMap == "" || pao.QuantizationPoint == 0 || pao.QuantizationCache == "" {
	//		return errors.New("请先填写量化变量，并且提交，获取结果")
	//	}
	//}

	if changePao.OpDesc == "" {
		return errors.New("预审操作备注不能为空，请填写备注")
	}
	if changePao.RefuseReason == "" {
		return errors.New("预审拒绝原因不能为空")
	}
	if changePao.ExternalReason == "" {
		return errors.New("预审外部原因不能为空")
	}

	nowTime := time.Now()
	pao.OpDesc = changePao.OpDesc
	pao.PreApprovalStatus = model.PREAPPROVALREFUSE
	pao.RefuseTime = &nowTime
	pao.RefuseReason = changePao.RefuseReason // 拒绝原因
	pao.ExternalReason = changePao.ExternalReason // 外部原因

	if err := config.GetDb().Model(&model.PreApprovalOrder{}).Updates(pao).Error; err != nil {
		return err
	}

	service.SendPvSms(pao, "refuse")

	service.AsyncNewPreApprovalLog(&model.PreApprovalLog{
		PreApprovalId:     pao.PreApprovalID,
		PreApprovalName:   pao.PreTrailName,
		PreApprovalStatus: pao.PreApprovalStatus,
	})

	return nil
}

//  打回
func preTrailRepulse(pao model.PreApprovalOrder, changePao *model.PreApprovalOrder) (error) {
	if pao.PreApprovalType == model.ZZ_PREAPPROVAL {
		return errors.New("用户自主申请，无法打回")
	}

	if pao.PreApprovalType == model.QD_PREAPPROVAL {
		if pao.IsFast == model.FS_PREAPPROVAL {
			return errors.New("快速预审批，无法打回")
		}
	}

	if changePao.OpDesc == "" {
		return errors.New("预审操作备注不能为空，请填写备注")
	}

	nowTime := time.Now()
	pao.OpDesc = changePao.OpDesc
	pao.PreApprovalStatus = model.PREAPPROVALREPULSE
	pao.RepulseTime = &nowTime

	if err := config.GetDb().Model(&model.PreApprovalOrder{}).Updates(pao).Error; err != nil {
		return err
	}

	service.SendPvSms(pao, "repulse")

	service.AsyncNewPreApprovalLog(&model.PreApprovalLog{
		PreApprovalId:     pao.PreApprovalID,
		PreApprovalName:   pao.PreTrailName,
		PreApprovalStatus: pao.PreApprovalStatus,
	})

	return nil
}

// 撤销
func preTrailCancel(pao model.PreApprovalOrder, changePao *model.PreApprovalOrder) (error) {

	if pao.PreApprovalType != model.QD_PREAPPROVAL {
		return errors.New("非渠道申请，无法撤销")
	} else {
		if pao.IsFast == model.FS_PREAPPROVAL {
			return errors.New("快速预审批，无法撤销")
		}
	}

	if changePao.OpDesc == "" {
		return errors.New("预审操作备注不能为空，请填写备注")
	}
	nowTime := time.Now()
	pao.OpDesc = changePao.OpDesc
	pao.PreApprovalStatus = model.PREAPPROVALCANCEL //  撤销
	pao.CancelTime = &nowTime

	if err := config.GetDb().Model(&model.PreApprovalOrder{}).Updates(pao).Error; err != nil {
		return err
	}

	service.AsyncNewPreApprovalLog(&model.PreApprovalLog{
		PreApprovalId:     pao.PreApprovalID,
		PreApprovalName:   pao.PreTrailName,
		PreApprovalStatus: pao.PreApprovalStatus,
	})
	return nil
}

// 获取预审批记录
func GetPreApprovalLog(preApprovalId string) []model.PreApprovalLog {
	var logs []model.PreApprovalLog
	config.GetDb().Where("pre_approval_id =?",
		preApprovalId).Order("created_at desc").Find(&logs)
	return logs
}

//  抢单
func GrabPreApproval(username, name string) (err error) {
	if username == "" {
		return errors.New("预审id不能为空")
	}
	if name == "" {
		return errors.New("预审name不能为空")
	}
	// 检查单数
	if err = checkPreApprovalCount(username, name); err != nil {
		logger.Error("检查单数出错", "err", err.Error())
		return
	}
	pao, err := paWorkAllocation()
	if err != nil {
		return
	}

	var checkPao model.PreApprovalOrder
	// 这里开启事物，防止并发抢单
	tx := config.GetDb().Begin()
	defer util.ClearTransaction(tx)
	if err = tx.Model(checkPao).Where("id = ?", pao.ID).First(&checkPao).Error; err != nil {
		logger.Error("抢单出错" + err.Error())
		tx.Rollback()
		return
	}

	if err = checkPao.IsVaildGrab(); err != nil {
		logger.Error("抢单错误, 自动派单后获取的pao不是符合抢单的预审单", "err", err.Error())
		tx.Rollback()
		return
	}

	nowTime := time.Now()
	pao.PreTrailId = username
	pao.PreTrailName = name
	pao.PreApprovalStatus = model.PREAPPROVALING
	pao.StartTime = &nowTime

	if err = tx.Model(&model.PreApprovalOrder{}).Where("id = ?", pao.ID).Updates(pao).Error; err != nil {
		logger.Error("抢单出错" + err.Error())
		tx.Rollback()
		return
	}

	tx.Commit()

	service.AsyncNewPreApprovalLog(&model.PreApprovalLog{
		PreApprovalId:     pao.PreApprovalID,
		PreApprovalName:   name,
		PreApprovalStatus: "预审抢单",
	})

	return
}

// 预审自动派单
func paWorkAllocation() (pao *model.PreApprovalOrder, err error) {
	var res model.PreApprovalOrder
	if err = config.GetDb().Model(&model.PreApprovalOrder{}).Where("pre_trail_id = ? AND pre_trail_name = ? "+
		"AND pre_approval_status = ?", "Null", "Null", model.WAITPREAPPROVAL).First(&res).Error; err != nil {
		logger.Error("获取预审批单抢单列表错误", "err", err.Error())
		return pao, errors.New("目前没有预审批单可抢，请稍候尝试")
	}
	return &res, nil
}

// 检查单数
func checkPreApprovalCount(username string, name string) (err error) {
	var myOrderCount int
	sqlBase := config.GetDb().Model(&model.PreApprovalOrder{}).
		Where("(pre_trail_id = ? AND pre_trail_name = ? AND pre_approval_status in (?))",
		username, name, model.PreApprovalStatusList("me", model.PREAPPROVALING))
	if err = sqlBase.Count(&myOrderCount).Error; err != nil {
		logger.Error("==========检查单数错误", "err", err.Error())
		return
	}
	// 原定是10笔
	if myOrderCount >= 10 {
		err = errors.New("你的预审批单数量已经达到10个，无法再添加预审批单啦")
		return
	}
	return
}

//  需要通过身份证号去查询预审批的 量化变量
type CheckQvInDb struct {
	PaoList []model.PreApprovalOrder `json:"pao_list"`
	AoList  []model.ApprovalOrder    `json:"ao_list"`
}

func getPreApprovalQvByUserIdNum(userIdNum string) (qqv []model.PreApprovalOrder, err error) {
	if err = config.GetDb().Model(&model.PreApprovalOrder{}).Select([]string{
		"pre_approval_id",
		"commit_time",
		"pass_time",
		"refuse_time",
		"cancel_time",
		"pre_approval_type",
		"start_time",
		"pre_trail_name",
		"pre_approval_status",
		"op_desc",
		"quantization_cache",
	}).Where("user_id_num = ? AND quantization_cache <> ? AND pre_approval_status in (?)",
		userIdNum, "", model.PreApprovalStatusList("history", "")).Limit(QVSEARCHLIMIT).
		Find(&qqv).Error; err != nil {
		logger.Error("查询客户存在预审批单量化变量错误", "err", err.Error())
		return
	}
	return
}

//  需要通过身份证号去查询 审批 的 量化变量
func getApprovalQvByUserIdNum(userIdNum string) (qv []model.ApprovalOrder, err error) {
	if err = config.GetDb().Model(&model.ApprovalOrder{}).Select([]string{
		"jinjian_id",
		"created_at",
		"approval_start_time",
		"re_trail_status",
		"refuse_reason",
		"first_trail_name",
		"quantization_cache",
	}).Where("user_id_num = ? AND quantization_cache <> ?", userIdNum, "").Limit(QVSEARCHLIMIT).
		Find(&qv).Error; err != nil {
		logger.Error("查询客户存在审批单量化变量错误", "err", err.Error())
		return
	}
	return
}

// 预审调用gscore
func GetPreApprovalScoreResult(sr ScoreReq, preApprovalID string) (err error) {
	var pao model.PreApprovalOrder
	var preStatus string
	if err = config.GetDb().Model(pao).Where("pre_approval_id =?", preApprovalID).First(&pao).Error; err != nil {
		return err
	}
	if pao.QuantizationPoint == 0 {
		preStatus = "预审第一次上传量化变量"
	} else {
		preStatus = "预审更新量化变量"
	}
	respMap, err := httpReq.PostJsonProxy(sr, global.GetScoreUrl()+"/api/v1/score")
	if err != nil {
		return
	}
	if respMap["score"] == nil || respMap["amount"] == nil || respMap["rate"] == nil || respMap["level"] == nil {
		logger.Info("Gscore 返回==================", "resp", util.StringifyJson(respMap))
		logger.Info("==============score", "isNil", respMap["score"] == nil)
		logger.Info("==============amount", "isNil", respMap["amount"] == nil)
		logger.Info("==============rate", "isNil", respMap["rate"] == nil)
		logger.Info("==============level", "isNil", respMap["level"] == nil)
		var errmsg string
		if es, ok := respMap["errmsg"].(string); ok {
			errmsg = es
		}
		err = errors.New("返回结果为空，请检查日志, err : " + errmsg)
		return
	}
	if score, ok := respMap["score"].(float64); ok {
		pao.QuantizationPoint = int(score)
	}
	if level, ok := respMap["level"].(float64); ok {
		pao.QuantizationLevel = int(level)
	}
	pao.QuantizationMap = util.StringifyJson(sr.OriginMap)
	pao.QuantizationCache = sr.QuantizationCache
	if err = config.GetDb().Model(pao).Updates(pao).Error; err != nil {
		logger.Error("=============Updates Err: " + err.Error())
		return err
	}

	service.AsyncNewPreApprovalLog(&model.PreApprovalLog{
		PreApprovalId:     pao.PreApprovalID,
		PreApprovalName:   pao.PreTrailName,
		PreApprovalStatus: preStatus,
	})

	return
}
