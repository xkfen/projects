package serviceV1

import "gapproval/approval/model"

func (s *testingSuite) TestFinBack() {
	ao := model.GetDefaultApprovalOrder()
	ao.AccountID = 999
	s.NoError(NewApprovalOrder(ao))
	s.EqualError(FinBack(ao.AccountID, "ttt", "退回说明"), "审批单状态错误，无法进行财务退回")
}

func (s *testingSuite) TestFinBack2() {
	ao := model.GetDefaultApprovalOrder()
	ao.AccountID = 999
	ao.ReTrailStatus = model.ApprovalStatusReTrailPass
	ao.CustomServiceStatus = model.ApprovalStatusCustomPass
	s.NoError(NewApprovalOrder(ao))
	s.NoError(FinBack(ao.AccountID, "ttt", "退回说明"))
	result, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal(result.ReTrailStatus, model.ApprovalStatusFinanceBack)
	s.Equal(result.CustomServiceStatus, model.ApprovalStatusFinanceBack)
}
