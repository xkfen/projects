package serviceV1

import (
	"gapproval/approval/model"
	time2 "time"
	"fmt"
	"gcoresys/common/util"
	"gapproval/approval/db/config"
)

func (s *testingSuite) TestGetReTrailApprovalOrderList() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	ao.RiskParam = `{"s": "s"}`
	ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
	//ao.FundSide = model.MrOnionFundSide
	s.NoError(NewApprovalOrder(ao))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "agency_confirm", map[string]interface{}{
	//	"salary_bank" : map[string]interface{}{"salary_bank1" : "sssss"}}))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "user_input", map[string]interface{}{
	//	"salary_bank": map[string]interface{}{"salary_bank1": "sssss"}}))
	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal(model.ApprovalStatusWaitFirstTrail, aR.FirstTrailStatus)

	s.NoError(UploadApprovalFile(&model.ApprovalUploadFile{JinjianId: ao.JinjianId, FileType: model.FT_DIANHE,
		FileUrl: "/sdsd/dsdsd/aaa.x", FileName: "sdfsdfds"}))
	csR := model.GetDefaultApprovalCsResult()
	csR.ApprovalId = aR.ID
	s.NoError(NewApprovalCsResult(csR))

	tpi := model.GetDefaultThreePartyInfo()
	tpi.JinjianId = aR.JinjianId
	s.NoError(NewOrUpdateThreePartyInfo(tpi))
	s.NoError(firstTrailPassOrRefuse(aR, &model.ApprovalOrder{FirstTrailStatus: model.ApprovalStatusFirstTrailRefuse,
		FirstTrailStatusDes: "sssssvvvvvv", RefuseReason: "dfsdfdsfdsfdsfsd"}))
	aR, _, err = GetApprovalOrder(ao.JinjianId)
	s.Equal(model.ApprovalStatusWaitReTrail, aR.ReTrailStatus)
	s.Equal(model.ApprovalStatusFirstTrailRefuse, aR.FirstTrailStatus)

	aoList, tp, _ := GetReTrailApprovalOrderList("all", "all",
		"zs001", "终审001", "", "", 1)
	s.Equal(1, tp)
	s.Equal(true, len(aoList) > 0)
	s.Equal(1, len(aoList))
	s.Equal(model.ApprovalStatusWaitReTrail, aoList[0].ReTrailStatus)

}

func (s *testingSuite) TestUpdateLoanTime() {

	now := time2.Now()

	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	ao.RiskParam = `{"s": "s"}`

	ao.LoanAt = &now

	ao.SalaryAt = &now
	ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail

	s.NoError(NewApprovalOrder(ao))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "agency_confirm", map[string]interface{}{
	//	"salary_bank" : map[string]interface{}{"salary_bank1" : "sssss"}}))
	//s.NoError(AgencyChangeStatus(ao.JinjianId, "user_input", map[string]interface{}{
	//	"salary_bank": map[string]interface{}{"salary_bank1": "sssss"}}))
	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal(model.ApprovalStatusWaitFirstTrail, aR.FirstTrailStatus)

	s.NoError(UploadApprovalFile(&model.ApprovalUploadFile{JinjianId: ao.JinjianId, FileType: model.FT_DIANHE,
		FileUrl: "/sdsd/dsdsd/aaa.x", FileName: "sdfsdfds"}))
	csR := model.GetDefaultApprovalCsResult()
	csR.ApprovalId = aR.ID
	s.NoError(NewApprovalCsResult(csR))

	tpi := model.GetDefaultThreePartyInfo()
	tpi.JinjianId = aR.JinjianId
	s.NoError(NewOrUpdateThreePartyInfo(tpi))
	s.NoError(firstTrailPassOrRefuse(aR, &model.ApprovalOrder{FirstTrailStatus: model.ApprovalStatusFirstTrailRefuse,
		FirstTrailStatusDes: "sssssvvvvvv", RefuseReason: "dfsdfdsfdsfdsfsd"}))
	aR, _, err = GetApprovalOrder(ao.JinjianId)
	s.Equal(model.ApprovalStatusWaitReTrail, aR.ReTrailStatus)
	s.Equal(model.ApprovalStatusFirstTrailRefuse, aR.FirstTrailStatus)

	aoList, tp ,_:= GetReTrailApprovalOrderList("all", "all",
		"zs001", "终审001", "", "", 1)
	s.Equal(1, tp)
	s.Equal(true, len(aoList) > 0)
	s.Equal(1, len(aoList))
	s.Equal(model.ApprovalStatusWaitReTrail, aoList[0].ReTrailStatus)

	fmt.Println(util.StringifyJson(aoList[0]))

	s.NoError(config.GetDb().Model(ao).Updates(ao).Update("salary_at", nil).
		Update("loan_at", nil).Error)


	aR1, _, err := GetApprovalOrder(ao.JinjianId)
	fmt.Println(util.StringifyJson(aR1))
}
