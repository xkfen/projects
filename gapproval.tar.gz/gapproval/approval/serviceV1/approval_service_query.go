package serviceV1

import (
	"errors"
	"gapproval/approval/db/config"
	"gapproval/approval/model"
	"gcoresys/common/util"
	"time"
	"gapproval/approval/service"
)

type QueryParam struct {
	//  所属中介
	AgencyName string `json:"agency_name"`
	// 业务员
	AgencyEmployee string `json:"agency_employee"`
	// 处理人
	Handler string `json:"handler"`
	// 前端显示的进件id
	ShowId string `json:"show_id"`
	// 进件用户名字
	JinjianUserName string `json:"jinjian_user_name"`
	// 进件用户身份证号
	UserIdNum string `json:"user_id_num"`
	// 筛选最大贷款金额
	MaxLoanAmount uint64 `json:"max_loan_amount"`
	// 筛选最小贷款金额
	MinLoanAmount uint64 `json:"min_loan_amount"`
	// 筛选最大贷款金额
	MaxApprovedAmount uint64 `json:"max_approved_amount"`
	// 筛选最小贷款金额
	MinApprovedAmount uint64 `json:"min_approved_amount"`
	// 贷款期数
	LoanTerm int `json:"loan_term"`
	// 渠道经理
	ChannelManager string `json:"channel_manager"`
	// 审批阶段
	ApprovalStage string `json:"approval_stage"`
	// 筛选最大时间
	MaxApprovalTime *time.Time `json:"max_approval_time"`
	// 筛选最小时间
	MinApprovalTime *time.Time `json:"min_approval_time"`
	// 查询类型  全都、在办理、完结
	QueryType string `json:"query_type"`
	// page
	Page int `json:"page"`
	// perPage
	PerPage int `json:"per_page"`

	// 排序
	Sort string `json:"sort"`

	//
	ApprovalType string `json:"approval_type"`
	StartTime    string `json:"start_time"`
	EndTime      string `json:"end_time"`
	DownloadAll  bool   `json:"download_all"`
}

func Query(query QueryParam) (queryResult []*model.ApprovalOrder, count int, totalPage int, err error) {
	sqlBase := config.GetDb().Model(&queryResult)
	if err = checkParam(query); err != nil {
		return
	}

	// 判断审批是否完结
	if query.ApprovalStage == "" {
		sqlBase = sqlBase.
			Where("(inter_view_status in (?)) OR (first_trail_status in (?)) OR (re_trail_status in (?)) OR custom_service_status in (?)",
			ivQueryStatusList("query", query.QueryType), service.FirstTrailStatusList("query", query.QueryType),
			service.ReTrailStatusList("query", query.QueryType),
			service.CustomServiceStatusList("query", query.QueryType))
	}

	if query.Handler != "" {
		sqlBase = sqlBase.Where("first_trail_name = ? OR re_trail_name = ? OR custom_service_name = ?",
			query.Handler, query.Handler, query.Handler)
	}

	if query.AgencyName != "" {
		sqlBase = sqlBase.Where("agency_name = ?", query.AgencyName)
	}

	if query.AgencyEmployee != "" {
		sqlBase = sqlBase.Where("agency_employee = ?", query.AgencyEmployee)
	}

	if query.ShowId != "" {
		sqlBase = sqlBase.Where("show_id = ?", query.ShowId)
	}

	if query.JinjianUserName != "" {
		sqlBase = sqlBase.Where("jinjian_user_name LIKE ?", "%"+query.JinjianUserName+"%")
	}

	if query.UserIdNum != "" {
		sqlBase = sqlBase.Where("user_id_num = ?", query.UserIdNum)
	}

	if query.MinLoanAmount > 0 && query.MaxLoanAmount == 0 {
		sqlBase = sqlBase.Where("loan_amount >= ? ", query.MinLoanAmount)
	}

	if query.MinLoanAmount == 0 && query.MaxLoanAmount > 0 {
		sqlBase = sqlBase.Where("loan_amount <= ? ", query.MaxLoanAmount)
	}

	if query.MinLoanAmount > 0 && query.MaxLoanAmount > 0 {
		sqlBase = sqlBase.Where("loan_amount >= ? AND loan_amount <= ?", query.MinLoanAmount, query.MaxLoanAmount)
	}

	if query.MinApprovedAmount > 0 && query.MaxApprovedAmount == 0 {
		sqlBase = sqlBase.Where("approved_amount >= ? ", query.MinApprovedAmount)
	}

	if query.MinApprovedAmount == 0 && query.MaxApprovedAmount > 0 {
		sqlBase = sqlBase.Where("approved_amount <= ? ", query.MaxApprovedAmount)
	}

	if query.MinApprovedAmount > 0 && query.MaxApprovedAmount > 0 {
		sqlBase = sqlBase.Where("approved_amount >= ? AND approved_amount <= ?", query.MinApprovedAmount, query.MaxApprovedAmount)
	}

	if query.LoanTerm > 0 {
		sqlBase = sqlBase.Where("loan_term = ?", query.LoanTerm)
	}

	if query.ChannelManager != "" {
		sqlBase = sqlBase.Where("id in (SELECT approval_order_id FROM approval_channel_managers WHERE channel_manager = ?)", query.ChannelManager)
	}

	if query.ApprovalStage == "初审" {
		sqlBase = sqlBase.Where("first_trail_status in (?) AND re_trail_status in (?)",
			service.FirstTrailStatusList("query", query.QueryType), []string{"Null", model.ApprovalStatusReTrailBack})
	}

	if query.ApprovalStage == "终审" {
		sqlBase = sqlBase.Where("re_trail_status in (?) AND custom_service_status in (?)",
			service.ReTrailStatusList("query", query.QueryType), []string{"Null", model.ApprovalStatusCustomServiceBack,
				model.ApprovalStatusFinanceBack})
	}

	if query.ApprovalStage == "客服" {
		sqlBase = sqlBase.Where("custom_service_status in (?)", service.CustomServiceStatusList("query", query.QueryType))
	}

	if query.MinApprovalTime != nil && query.MaxApprovalTime == nil {
		sqlBase = sqlBase.Where("created_at >= ?", query.MinApprovalTime)
	}

	if query.MinApprovalTime == nil && query.MaxApprovalTime != nil {
		sqlBase = sqlBase.Where("created_at <= ?", query.MaxApprovalTime)
	}

	if query.MinApprovalTime != nil && query.MaxApprovalTime != nil {
		sqlBase = sqlBase.Where("created_at >= ? AND created_at <= ?", query.MinApprovalTime, query.MaxApprovalTime)
	}

	offset := util.GetOffset(query.Page, query.PerPage)
	totalPage, count = util.GetTotalPagesAndCount(sqlBase, &queryResult, query.PerPage)

	if query.Sort != "" {
		sqlBase = sqlBase.Order(query.Sort)
	} else {
		sqlBase = sqlBase.Order("created_at")
	}

	if query.DownloadAll {
		sqlBase.Find(&queryResult)
	} else {
		sqlBase.Offset(offset).Limit(query.PerPage).Find(&queryResult)
	}

	return
}

func checkParam(param QueryParam) (err error) {
	if param.PerPage <= 0 {
		err = errors.New("PerPage 参数错误")
		return
	}
	switch param.QueryType {
	case "handling":
	case "all":
	case "ending":
	default:
		err = errors.New("QueryType 参数错误")
		return
	}
	//if param.AgencyEmployee == "" && param.AgencyName == "" && param.Handler == "" && param.ShowId == "" && param.JinjianUserName == "" && param.UserIdNum == "" &&
	//	param.MaxLoanAmount == 0 && param.MinLoanAmount == 0 && param.MaxApprovedAmount == 0 &&
	//	param.MinApprovedAmount == 0 && param.LoanTerm == 0 && param.ChannelManager == "" && param.ApprovalStage == "" &&
	//	param.MaxApprovalTime == nil && param.MinApprovalTime == nil {
	//	err = errors.New("筛选参数错误，请至少输入一个筛选条件")
	//	return
	//}
	if param.MinApprovedAmount > 0 && param.MaxApprovedAmount > 0 {
		if param.MaxApprovedAmount < param.MinLoanAmount {
			err = errors.New("核准金额筛选参数错误")
			return
		}
	}
	if param.MinLoanAmount > 0 && param.MaxLoanAmount > 0 {
		if param.MaxLoanAmount < param.MinLoanAmount {
			err = errors.New("贷款金额筛选参数错误")
			return
		}
	}
	if param.MinApprovalTime != nil && param.MaxApprovalTime != nil {
		if param.MinApprovalTime.Sub(*param.MaxApprovalTime) > 0 {
			err = errors.New("审批时间筛选参数错误")
			return
		}
	}
	return
}

func ivQueryStatusList(typeKey string, status string) (statusList []string) {
	switch typeKey {
	case "query":
		switch status {
		case "all":
			statusList = []string{model.ApprovalStatusWaitInterView, model.ApprovalStatusInterViewing,
				model.ApprovalStatusInterViewExchange, model.ApprovalStatusReTrailBackIv,
				model.ApprovalStatusFirstTrailBackIv, model.ApprovalStatusInterViewRepulse,
				model.ApprovalStatusInterViewCancel, model.ApprovalStatusInterViewPass}
			return statusList
		case "handling":
			statusList = []string{model.ApprovalStatusWaitInterView, model.ApprovalStatusInterViewing,
				model.ApprovalStatusInterViewExchange, model.ApprovalStatusReTrailBackIv,
				model.ApprovalStatusFirstTrailBackIv, model.ApprovalStatusInterViewRepulse}
			return statusList
		case "ending":
			statusList = []string{model.ApprovalStatusInterViewCancel, model.ApprovalStatusInterViewPass}
			return statusList
		}

	}
	return
}
