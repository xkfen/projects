package serviceV1

import (
	"gapproval/common/httpReq"
	"gapproval/common/global"
	"gcoresys/common/logger"
	"time"
	"fmt"
)

func ShenMaMap(preApprovalId, preApprovalStatus string) map[string]string {
	return map[string]string{
		"orderNo": preApprovalId,
		"status":  preApprovalStatus,
	}
}

func PostShenMa(params map[string]string) {
	go func(params map[string]string) {
		for i := 0; i < 3; i++ {
			if postShenMa(params) == nil {
				//logger.Info("*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*")
				//logger.Info("||                  调用神马系统接口成功!                     ||")
				break
			}
			logger.Warn(fmt.Sprintf("第%v次调用神马系统接口", i+1))
			time.Sleep(time.Minute * 5)
		}
	}(params)
}

func postShenMa(params map[string]string) error {
	code, resp, err := httpReq.PutParamProxyNoCheck(params, global.GetPreViewServerUrl()+"/api/v1/preview/internal/OrderNotify/updateStatus")
	if err != nil {
		logger.Warn("调用gPreview系统出错", "err", err)
	}

	if code != 200 {
		logger.Warn("调用gPreview系统返回非200", "code", code, "resp", resp)
	}

	return err
}
