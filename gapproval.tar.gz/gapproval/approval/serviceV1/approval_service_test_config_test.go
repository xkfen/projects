package serviceV1

import (
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
	"github.com/stretchr/testify/suite"
	"testing"
	"fmt"
	"time"
	"gapproval/approval/model"
)

func TestRun(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	suite.Run(t, new(testingSuite))
}

type testingSuite struct {
	suite.Suite
}

// 单步测试
func oneStepTest(testMethods ...func()) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)

	for _, testMethods := range testMethods {
		config.ClearAllData()
		testMethods()
		config.ClearAllData()
	}
}

func (s *testingSuite) SetupTest() {
	config.ClearAllData()
}

func (s *testingSuite) TearDownTest() {
	config.ClearAllData()
}

func (s *testingSuite) newApprovalOrders(count int) {
	for i := 0; i < count; i++ {
		ao := model.GetDefaultApprovalOrder()
		ao.JinjianId = fmt.Sprintf("JinjianIdSLZ%v%v", i, time.Now().UnixNano())
		ao.JinjianUserId = fmt.Sprintf("JinjianUserIdSLZ%v%v", i, time.Now().UnixNano())
		ao.JinjianUserName = fmt.Sprintf("进件用户%v%v", i, time.Now().UnixNano())
		ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
		ao.InterView = `{"s":"sss"}`
		time.Sleep(7 * time.Millisecond)
		s.NoError(NewApprovalOrder(ao))
	}

}
