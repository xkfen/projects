package serviceV1

import (
	"gapproval/approval/model"
	"gcoresys/common/util"
	"gapproval/approval/db/config"
	"gapproval/common/httpReq"
	coresysCommon "gcoresys/common"
	"gapproval/common/global"
	"gcoresys/common/logger"
	"errors"
	"fmt"
	"time"
	"gapproval/approval/service"
)

//  初审操作
func FirstTrailOperation(changeAo *model.ApprovalOrder) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Where("jinjian_id =?", changeAo.JinjianId).First(&ao).Error; err != nil {
		return err
	}
	if err = ao.IsValidCsOperation(); err != nil {
		return
	}
	switch changeAo.FirstTrailStatus {
	case model.ApprovalStatusFirstTrailExchange: // 初审流转
		if err = exchange(ao, changeAo, "cs"); err != nil {
			return err
		}
	case model.ApprovalStatusFirstTrailPass: // 初审通过
		if err = firstTrailPassOrRefuse(ao, changeAo); err != nil {
			return err
		}
	case model.ApprovalStatusFirstTrailRefuse: // 初审拒绝
		if err = firstTrailPassOrRefuse(ao, changeAo); err != nil {
			return err
		}
	case model.ApprovalStatusFirstTrailRepulse: // 初审打回
		if err = firstTrailRepulse(ao, changeAo); err != nil {
			return err
		}
	case model.ApprovalStatusCustomCancel: // 客户撤销
		if err = cancel(ao, changeAo, "cs"); err != nil {
			return err
		}
	case model.ApprovalStatusFirstTrailBackIv: // 初审退回面签
		if err = ApprovalBackIv(ao, changeAo, "cs"); err != nil {
			return err
		}
	default:
		err = errors.New("状态参数错误，请检查初审单Status")
		return
	}
	return
}

//  方案号
func MarkPlanNum(jinjianId, planNum string) (err error) {
	if err = config.GetDb().Model(&model.ApprovalOrder{}).Where("jinjian_id = ?", jinjianId).
		Update("plan_num", planNum).Error; err != nil {
		return
	}
	return
}

//  标记是否是非标件
func MarkIsStandard(jinjianId, status string) (err error) {
	if err = config.GetDb().Model(&model.ApprovalOrder{}).Where("jinjian_id = ?", jinjianId).
		Update("is_standard", status).Error; err != nil {
		return
	}
	return
}

//  个人信息补充
func CreateUserInfoSup(info *model.ApprovalUserInfoSup, opName string) (err error) {
	if err = info.IsValidApprovalUserInfoSup(); err != nil {
		return
	}
	if err = config.GetDb().Model(info).Create(info).Error; err != nil {
		return
	}
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: info.JinjianId, ApprovalName: opName,
		ApprovalStatus: "初审补充用户个人信息",
		ApprovalType: "cs"})
	return
}

//  获取个人信息补充
func GetUserInfoSup(jinjianId string) (*model.ApprovalUserInfoSup) {
	var result model.ApprovalUserInfoSup
	config.GetDb().Model(result).Where("jinjian_id = ?", jinjianId).First(&result)
	if result.ID == 0 {
		return nil
	}
	return &result
}

//  获取电核材料
func GetCallRecord(jinjianId string) (result []model.ApprovalCallRecord) {
	config.GetDb().Model(result).Where("jinjian_id = ?", jinjianId).Find(&result)
	return result
}
//  获取催收备注信息材料
func GetCallRecordNoCall(jinjianId string) (result []model.ApprovalCallRecord) {
	config.GetDb().Model(result).Where("jinjian_id = ? and exist_call_record = ?", jinjianId, "no").Find(&result)
	return result
}

//  创建电核材料
func NewCallRecord(jinjianId, number, desc string, opName string, callType string) (err error) {
	var acr model.ApprovalCallRecord
	if config.GetDb().Model(acr).Where("jinjian_id = ? AND number = ? AND call_type = ?",
		jinjianId, number, callType).Find(&acr).RecordNotFound() {
		acr.JinjianId = jinjianId
		acr.Number = number
		acr.Desc = desc
		acr.CallType = callType
		if err = config.GetDb().Model(acr).Create(&acr).Error; err != nil {
			return
		}
		service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: jinjianId, ApprovalName: opName,
			ApprovalStatus: "初审创建电核材料",
			ApprovalType: "cs", ApprovalDesc: "号码: " + number})
		return
	}
	return errors.New("此号码电核材料已存在，无法创建")
}

//  更新电核材料
func UpdateCallRecord(approvalCellRecordId uint, desc string, opName string) (err error) {
	var acr model.ApprovalCallRecord
	if err = config.GetDb().Model(&acr).Where("id = ?", approvalCellRecordId).First(&acr).Error; err != nil {
		return
	}

	logger.Debug(util.StringifyJson(acr))

	oldDesc := acr.Desc
	acr.Desc = desc
	if err = config.GetDb().Model(&acr).Update(&acr).Error; err != nil {
		return
	}
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: acr.JinjianId, ApprovalName: opName,
		ApprovalStatus: "初审修改电核材料，号码：" + acr.Number,
		ApprovalType: "cs", ApprovalDesc: "从" + oldDesc + " 改成 " + desc})
	return
}

//  风险参数  保存
func SaveRiskParam(jinjianId string, riskParam map[string]interface{}, approvalAmount uint64, pmr float64, planNum string) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Model(ao).Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return err
	}
	if ao.RiskParam != "" {
		err = errors.New("风险参数已存在，请调用修改风险参数方法")
		return
	}
	ao.ApprovedAmount = approvalAmount

	ao.PlatformMonthRate = pmr // 平台服务月利率

	ao.RiskParam = util.StringifyJson(riskParam)

	u := map[string]interface{}{
		"approved_amount":     ao.ApprovedAmount,
		"platform_month_rate": ao.PlatformMonthRate,
		"risk_param":          ao.RiskParam,
	}

	if planNum != "" {
		//u["plan_num"] = planNum

		newIv, err1 := updateJinjianPlan(ao.InterView, planNum)

		if err1 != nil {
			logger.Error("======================updateJinjianPlan", "err", err1.Error())
			return err1
		}

		u["inter_view"] = newIv
	}

	if err = config.GetDb().Model(&ao).Update(u).Error; err != nil {
		return
	}
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.FirstTrailName,
		ApprovalStatus: "初审上传风险参数",
		ApprovalType: "cs"})

	// 业务留痕
	service.AsyncApprovalTrace(ao)
	return
}

//  修改风险参数
func UpdateRiskParam(jinjianId string, keyMap map[string]string, newRiskParam map[string]interface{},
	approvalAmount uint64, pmr float64, planNum string) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Model(ao).Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return err
	}
	if ao.RiskParam == "" {
		err = errors.New("风险参数未上传，请调用上传风险参数方法")
		return
	}
	var oldRiskParam map[string]interface{}
	if err = util.ParseJson(ao.RiskParam, &oldRiskParam); err != nil {
		logger.Error("解析旧风险参数错误")
		return
	}
	for key, value := range keyMap {
		oldV, oldOk := oldRiskParam[key]
		newV, newOk := newRiskParam[key]
		if oldOk && newOk {
			cgLog := fmt.Sprintf("从%v改成%v", oldV, newV)
			var approvalName, approvalStatus string
			if ao.FirstTrailStatus == model.ApprovalStatusFirstTrailPass || ao.FirstTrailStatus == model.ApprovalStatusFirstTrailRefuse {
				approvalName = ao.ReTrailName
				approvalStatus = "终审"
			} else {
				approvalName = ao.FirstTrailName
				approvalStatus = "初审"
			}
			service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: approvalName,
				ApprovalStatus: fmt.Sprintf("%v修改风险参数%v", approvalStatus, value),
				ApprovalType: "cs", ApprovalDesc: cgLog})
		} else {
			logger.Error("解析错误", "oldV", oldOk)
			logger.Error("解析错误", "newV", newV)
		}
	}
	ao.ApprovedAmount = approvalAmount

	ao.PlatformMonthRate = pmr // 平台服务月利率

	ao.RiskParam = util.StringifyJson(newRiskParam)

	u := map[string]interface{}{
		"approved_amount":     ao.ApprovedAmount,
		"platform_month_rate": ao.PlatformMonthRate,
		"risk_param":          ao.RiskParam,
	}

	if planNum != "" {
		//u["plan_num"] = planNum

		newIv, err1 := updateJinjianPlan(ao.InterView, planNum)

		if err1 != nil {
			logger.Error("======================updateJinjianPlan", "err", err1.Error())
			return err1
		}

		u["inter_view"] = newIv
	}

	if err = config.GetDb().Model(ao).Update(u).Error; err != nil {
		logger.Error("=============Updates Err: " + err.Error())
		return err
	}
	// 业务留痕
	service.AsyncApprovalTrace(ao)
	return
}

//  获取量化评分以及核准金额利率
type ScoreReq struct {
	OriginMap         map[string]string `json:"Vars"`
	Term              int               `json:"Term"`
	LoanAmount        uint64            `json:"LoanAmount"` // 10000
	QuantizationCache string            `json:"quantization_cache"`
	IsUpdate          bool              `json:"is_update"`
}

func GetScoreResult(sr ScoreReq, jinjianId string) (err error) {
	var ao model.ApprovalOrder
	var approvalStatus string
	if err = config.GetDb().Model(ao).Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return err
	}
	if ao.QuantizationPoint != 0 && !sr.IsUpdate {
		logger.Info("==============量化评分", "QuantizationPoint", ao.QuantizationPoint)
		err = errors.New("非法更新量化变量，请输入审批组密码")
		return
	}
	if ao.QuantizationPoint == 0 {
		approvalStatus = "初审第一次上传量化变量"
	} else {
		approvalStatus = "初审更新量化变量"
	}
	respMap, err := httpReq.PostJsonProxy(sr, global.GetScoreUrl()+"/api/v1/score")
	if err != nil {
		return
	}
	if respMap["score"] == nil || respMap["amount"] == nil || respMap["rate"] == nil || respMap["level"] == nil {
		logger.Info("Gscore 返回==================", "resp", util.StringifyJson(respMap))
		logger.Info("==============score", "isNil", respMap["score"] == nil)
		logger.Info("==============amount", "isNil", respMap["amount"] == nil)
		logger.Info("==============rate", "isNil", respMap["rate"] == nil)
		logger.Info("==============level", "isNil", respMap["level"] == nil)
		var errmsg string
		if es, ok := respMap["errmsg"].(string); ok {
			errmsg = es
		}
		err = errors.New("返回结果为空，请检查日志, err : " + errmsg)
		return
	}
	if score, ok := respMap["score"].(float64); ok {
		ao.QuantizationPoint = int(score)
	}
	//if amount, ok := respMap["amount"].(float64); ok {
	//	ao.ApprovedAmount = uint64(amount * 100)
	//}
	if rate, ok := respMap["rate"].(float64); ok {
		//ao.ApprovedRate = rate    // 现在不需要 量化变量算出的利率
		ao.QuantizationRate = rate
	}
	if level, ok := respMap["level"].(float64); ok {
		ao.QuantizationLevel = int(level)
	}
	ao.QuantizationMap = util.StringifyJson(sr.OriginMap)
	ao.QuantizationCache = sr.QuantizationCache
	if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
		logger.Error("=============Updates Err: " + err.Error())
		return err
	}

	var aqv model.ApprovalQuantizationVar
	if err = util.ParseJson(ao.QuantizationMap, &aqv); err != nil {
		return
	}
	aqv.JinjianId = ao.JinjianId
	if approvalStatus == "初审第一次上传量化变量" {
		if err = config.GetDb().Model(aqv).Create(&aqv).Error; err != nil {
			return
		}
	}

	if approvalStatus == "初审更新量化变量" {
		if err = config.GetDb().Model(aqv).Where("jinjian_id = ?", ao.JinjianId).Update(&aqv).Error; err != nil {
			return
		}
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.FirstTrailName,
		ApprovalStatus: approvalStatus,
		ApprovalType: "cs"})
	// 业务留痕
	service.AsyncApprovalTrace(ao)
	return
}

func GetQuantizationVar(jinjianId string) (*model.ApprovalQuantizationVar) {
	var result model.ApprovalQuantizationVar
	config.GetDb().Model(result).Where("jinjian_id = ?", jinjianId).First(&result)
	if result.ID == 0 {
		return nil
	}
	return &result
}

//  添加和更新分机号
func NewOrUpdateExtensionNumber(jinjianId, extensionNumber string) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return
	}
	var approvalStatus, desc string
	if ao.ExtensionNumber == "" {
		approvalStatus = "添加分机号"
	} else {
		approvalStatus = "更新分机号"
		desc = "从" + ao.ExtensionNumber + "改成" + extensionNumber
	}
	ao.ExtensionNumber = extensionNumber
	if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
		return
	}

	var approvalName, approvalStatus1 string
	if ao.FirstTrailStatus == model.ApprovalStatusFirstTrailPass || ao.FirstTrailStatus == model.ApprovalStatusFirstTrailRefuse {
		approvalName = ao.ReTrailName
		approvalStatus1 = "终审"
	} else {
		approvalName = ao.FirstTrailName
		approvalStatus1 = "初审"
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: approvalName,
		ApprovalStatus: approvalStatus1 + approvalStatus,
		ApprovalType: "cs", ApprovalDesc: desc})
	// 业务留痕
	service.AsyncApprovalTrace(ao)
	return
}

//  添加联系人
func AddContact(jinjianId, name, phoneNum, relationship, address string) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return
	}

	if ao.FundSide == model.MrOnionFundSide && address == "" {
		err = errors.New("详细地址不能为空")
		return
	}

	if ao.ApprovalAddContacts == "" {
		ao.ApprovalAddContacts = "[]"
	}
	var contacts []map[string]string
	if err = util.ParseJson(ao.ApprovalAddContacts, &contacts); err != nil {
		return
	}

	var qc string
	if coresysCommon.GetUseDocker() == 2 && relationship != "公司电话" {
		qc = getPhoneNumQCellCore(phoneNum)
	}

	newContact := map[string]string{"name": name, "phone": phoneNum, "qCellCore": qc, "relationship": relationship,
		"address": address}
	c := append(contacts, newContact)
	ao.ApprovalAddContacts = util.StringifyJson(c)
	if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
		return
	}

	var approvalName, approvalStatus string
	if ao.FirstTrailStatus == model.ApprovalStatusFirstTrailPass || ao.FirstTrailStatus == model.ApprovalStatusFirstTrailRefuse {
		approvalName = ao.ReTrailName
		approvalStatus = "终审"
	} else {
		approvalName = ao.FirstTrailName
		approvalStatus = "初审"
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: approvalName,
		ApprovalStatus: approvalStatus + "新增联系人",
		ApprovalType: "cs", ApprovalDesc: "姓名：" + name + ", 电话：" + phoneNum + ", 关系: " + relationship +
			", 详细地址: " + address})
	// 业务留痕
	service.AsyncApprovalTrace(ao)
	return
}

// 开启补录
func ManageAdditionalRecord(jinjianId, arType, onoff, way string, allInfo map[string]interface{}) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return
	}
	var approvalName, approvalStatus, approvalDesc string
	switch ao.FirstTrailStatus {
	case model.ApprovalStatusWaitFirstTrail:
		break
	case model.ApprovalStatusReTrailBack:
		break
	case model.ApprovalStatusFirstTrailExchange:
		break
	default:
		err = errors.New("当前审批单状态不是" + model.ApprovalStatusWaitFirstTrail + "或" +
			model.ApprovalStatusReTrailBack + "或" + model.ApprovalStatusFirstTrailExchange + "初审无法开启补录")
		return
	}

	switch onoff {
	case "open":
		if arType == "bank" {
			ao.AdditionalRecord = true
			approvalDesc = "开启银行流水补录"
		}

		if arType == "call" {
			ao.CallAdditionalRecord = true
			approvalDesc = "开启运营商补录"
		}

		approvalName = ao.FirstTrailName
		approvalStatus = "初审开启补录"

	case "close":
		if way == "jj" {
			var aoMap map[string]interface{}
			if err = util.ParseJson(ao.AllInfo, &aoMap); err != nil {
				return
			}

			logger.Info("=================", "arType", arType)
			logger.Info("=================", "onoff", onoff)

			if arType == "bank" {
				aoMap["other_bank"] = allInfo["other_bank"]
				aoMap["other_call"] = allInfo["other_call"]
				ao.AdditionalRecord = false
				approvalDesc = "完成银行流水补录"
			}

			if arType == "call" {
				aoMap["other_bank"] = allInfo["other_bank"]
				aoMap["other_call"] = allInfo["other_call"]
				ao.CallAdditionalRecord = false
				approvalDesc = "完成运营商补录"
			}

			ao.AllInfo = util.StringifyJson(aoMap)
			approvalName = ao.JinjianUserName
			approvalStatus = "用户完成补录"

		} else {
			if arType == "bank" {
				ao.AdditionalRecord = false
			}

			if arType == "call" {
				ao.CallAdditionalRecord = false
			}

			approvalName = ao.FirstTrailName
			approvalStatus = "初审关闭补录"
			approvalDesc = "初审手动关闭补录"
		}
	default:
		err = errors.New("审批补录操作类型不能为空")
		return
	}
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: approvalName,
		ApprovalStatus: approvalStatus,
		ApprovalType: "cs", ApprovalDesc: approvalDesc})

	if arType == "bank" {
		if err = config.GetDb().Model(&ao).Where("jinjian_id = ?", ao.JinjianId).
			Update(map[string]interface{}{"additional_record": ao.AdditionalRecord, "all_info": ao.AllInfo}).Error; err != nil {
			return err
		}
	}

	if arType == "call" {
		if err = config.GetDb().Model(&ao).Where("jinjian_id = ?", ao.JinjianId).
			Update(map[string]interface{}{"call_additional_record": ao.CallAdditionalRecord, "all_info": ao.AllInfo}).Error; err != nil {
			return err
		}
	}

	service.AsyncApprovalTrace(ao)
	return
}

//  创建和更新三方信息
func NewOrUpdateThreePartyInfo(info *model.ThreePartyInfo) (err error) {
	if err = info.IsValidThreePartyInfo(); err != nil {
		return
	}
	var threePartyInfo model.ThreePartyInfo
	if err = config.GetDb().Where("jinjian_id =?", info.JinjianId).First(&threePartyInfo).Error; err != nil {
		if err.Error() == "record not found" {
			err = config.GetDb().Create(info).Error
			return
		}
		logger.Error("=========创建三方信息出错======: " + err.Error())
		return
	}
	info.ID = threePartyInfo.ID
	err = config.GetDb().Model(threePartyInfo).Updates(info).Error
	return
}

//  获取三方信息
func GetThreePartyInfo(jinjianId string) *model.ThreePartyInfo {
	var info model.ThreePartyInfo
	if err := config.GetDb().Where("jinjian_id =?", jinjianId).First(&info).Error; err != nil {
		logger.Info("=========查询三方信息出错: " + err.Error())
	}
	if info.ID == 0 {
		return nil
	}
	return &info
}

//  获取初审列表 (包含搜索)
func GetFirstTrailApprovalOrderList(typeKey string, status string, username string, name string,
	sort string, condition string, page int) ([]model.ApprovalOrder, int, int) {
	return transactGetApprovalList("cs", typeKey, status, username, name, sort, condition, page)
}

//  初审打回
func firstTrailRepulse(ao model.ApprovalOrder, changeAo *model.ApprovalOrder) (err error) {

	if ao.FirstTrailStatus != model.ApprovalStatusWaitFirstTrail &&
		ao.FirstTrailStatus != model.ApprovalStatusReTrailBack &&
		ao.FirstTrailStatus != model.ApprovalStatusFirstTrailExchange {
		err = errors.New("审批单状态错误，无法打回")
		return
	}

	if ao.FirstTrailStatus == model.ApprovalStatusFirstTrailRepulse {
		err = errors.New("审批单状态已经是初审打回")
		return
	}
	if changeAo.FirstTrailStatusRepulse == "" {
		err = errors.New("初审打回项不能为空")
		return
	}
	if changeAo.FirstTrailStatusDes == "" {
		err = errors.New("初审打回状态说明不能为空")
		return
	}

	ao = updateAoInfoByChangeAo(ao, changeAo)

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.FirstTrailName,
		ApprovalStatus: "初审打回给用户",
		ApprovalType: "cs", ApprovalDesc: changeAo.FirstTrailStatusDes})
	ao.FirstTrailStatusRepulse = changeAo.FirstTrailStatusRepulse
	ao.FirstTrailStatusDes = changeAo.FirstTrailStatusDes
	ao.RepulseDesc = changeAo.FirstTrailStatusDes
	ao.AgencyStatus = model.AgencyStatusRepulse
	ao.FirstTrailStatus = model.ApprovalStatusFirstTrailRepulse //初审打回

	// 初审打回时间
	nowTime := time.Now()
	ao.ApprovalRepulseTime = &nowTime

	if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
		return err
	}

	service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_CS, model.TP_USERINPUT)

	return
}

