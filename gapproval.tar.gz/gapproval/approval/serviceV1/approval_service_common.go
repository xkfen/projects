package serviceV1

import (
	"errors"
	"fmt"
	"gapproval/approval/db/config"
	"gapproval/approval/model"
	"gapproval/common/global"
	"gapproval/common/httpReq"
	"gcoresys/common/http"
	"gcoresys/common/logger"
	"gcoresys/common/util"
	model2 "griskcontrol/riskcontrol/model"
	"strconv"
	"strings"
	"time"
	"gcoresys/common/util/holidaycheck"
	"gcoresys/common"
	"gapproval/approval/service"
)

/**
@author  wangxi
@desc	重构后版本： 这里都是common函数，处理逻辑业务
@time 2017-09-06 14:57:10
*/

//  分页显示条数
var perPage = 10

const (
	//换行符，加上后面的空格是为了增加缩进
	Newline = "\r\n            "
	// doc页面上的XXX
	EmptyDocInfo = "XXX"
	EmptyInfo    = ""
	// 缴费方式
	Year    = "年缴"
	Month   = "月缴"
	Quarter = "季度"
)

//  是判定前端页面选择的是 全部、我的或者是历史
func isSelectAll(username string, name string, st string) (string, string) {
	if st == "all" {
		username = "Null"
		name = "Null"
	}
	return username, name
}

/**
  @Description: 通用的更新审批单数据，每个阶段审批的数据都要一致
  @Date: 15:20 2017/12/14
*/
func updateAoInfoByChangeAo(ao model.ApprovalOrder, changeAo *model.ApprovalOrder) model.ApprovalOrder {
	// 身份证
	ao.UserIdNum = changeAo.UserIdNum
	// 卡1 银行
	ao.BankName = changeAo.BankName
	// 卡1 电话
	ao.CardOnePhone = changeAo.CardOnePhone
	// 卡1 选择原因
	ao.CardOneChoiceReason = changeAo.CardOneChoiceReason
	// 卡1 卡号
	ao.Card1 = changeAo.Card1
	ao.Card2 = changeAo.Card2
	ao.Card3 = changeAo.Card3
	ao.Card4 = changeAo.Card4
	ao.Card5 = changeAo.Card5
	ao.Card1Json = changeAo.Card1Json
	// 首次还款日期
	ao.SalaryAt = changeAo.SalaryAt
	// 放款日期
	ao.LoanAt = changeAo.LoanAt
	// 放款卡号
	ao.LoanCard = changeAo.LoanCard
	// 放款银行     这里之所以没有放款卡电话 是因为在cellphone字段里
	ao.LoanBankName = changeAo.LoanBankName
	return ao
}

// 退回面签
func ApprovalBackIv(ao model.ApprovalOrder, changeAo *model.ApprovalOrder, approvalType string) (err error) {

	var u map[string]interface{}
	var opName, at, endTimeType, startTimeType string

	switch approvalType {
	case "cs":
		u = map[string]interface{}{
			"first_trail_status":     model.ApprovalStatusFirstTrailBackIv,
			"inter_view_status":      model.ApprovalStatusFirstTrailBackIv,
			"first_trail_status_des": changeAo.FirstTrailStatusDes,
		}
		opName = ao.FirstTrailName
		at = model.ApprovalStatusFirstTrailBackIv
		endTimeType = model.TP_CS
		startTimeType = model.TP_CS_BACK_IV
	case "zs":
		u = map[string]interface{}{
			"re_trail_status":     model.ApprovalStatusReTrailBackIv,
			"inter_view_status":   model.ApprovalStatusReTrailBackIv,
			"re_trail_status_des": changeAo.ReTrailStatusDes,
		}
		opName = ao.ReTrailName
		at = model.ApprovalStatusReTrailBackIv
		endTimeType = model.TP_ZS
		startTimeType = model.TP_ZS_BACK_IV
	default:
		return errors.New("审批类型错误")
	}

	if err = config.GetDb().Model(&ao).Where("jinjian_id = ?", ao.JinjianId).Update(u).Error; err != nil {
		logger.Error("==================审批退回面签操作，UpdateERR：" + err.Error())
		return
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: opName,
		ApprovalStatus: "退回面签", ApprovalType: "cs", ApprovalDesc: at})

	//  时间
	service.AsyncApprovalTimeRecord(ao.JinjianId, endTimeType, startTimeType)

	return
}

// contract_id --> jinjian_id
func GetJjIdByShowId(contractId string) (id uint, jinjianId string) {
	var ao model.ApprovalOrder
	if err := config.GetDb().Model(ao).Where("contract_id =?", contractId).First(&ao).Error; err != nil {
		logger.Error("=================通过contract_id 取 id, jinjian_id 错误 ", "err", err.Error())
		return
	}
	return ao.ID, ao.JinjianId
}

// 审批开关打开面签历史订单修改面签资料
func ManageInterViewUploadFile(jinjianId, ivSwitch string) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Model(ao).Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return err
	}
	logger.Info("============审批操作开关面签历史订单修改面签资料", "onoff", ivSwitch)

	if err = config.GetDb().Model(&model.ApprovalOrder{}).
		Where("id = ?", ao.ID).Update("inter_view_switch", ivSwitch).Error; err != nil {
		logger.Error("=========ManageInterViewUploadFile 更新错误: ", "ivSwitch", ivSwitch, "err", err.Error())
		return
	}

	var approvalName, approvalStatus string
	if ao.FirstTrailStatus == model.ApprovalStatusFirstTrailPass || ao.FirstTrailStatus == model.ApprovalStatusFirstTrailRefuse {
		approvalName = ao.ReTrailName
		approvalStatus = "终审"
	} else {
		approvalName = ao.FirstTrailName
		approvalStatus = "初审"
	}

	if ivSwitch == "on" {
		approvalStatus = approvalStatus + "开启面签单资料上传"
	} else {
		approvalStatus = approvalStatus + "关闭面签单资料上传"
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: approvalName,
		ApprovalStatus: approvalStatus,
		ApprovalType: "cs", ApprovalDesc: ""})

	return
}

// 审批用户获取预审列表
func GetAoUserPaoList(userIdNum string) (qqv []model.PreApprovalOrder, err error) {
	if err = config.GetDb().Model(&model.PreApprovalOrder{}).Where("user_id_num = ? AND pre_approval_status in (?)", userIdNum, model.PreApprovalStatusList("history", "")).Limit(30).
		Find(&qqv).Error; err != nil {
		logger.Error("查询客户存在预审批单量化变量错误", "err", err.Error())
		return
	}
	return
}

// 查询是否存在 多的申请, 同步 量化
func CheckUserQv(userIdNum string) (checkQv CheckQvInDb) {
	//   查询是否存在 多的申请, 同步 量化
	checkQv.AoList, _ = getApprovalQvByUserIdNum(userIdNum)
	checkQv.PaoList, _ = getPreApprovalQvByUserIdNum(userIdNum)
	return
}

//  批量查询审批单
func GetAoListByJinjianArray(jinjianIds []string) (aoList []model.ApprovalOrder, err error) {
	if len(jinjianIds) > 5000 {
		err = errors.New("审批批量查询现在只支持200条内")
		return
	}
	if err = config.GetDb().Model(aoList).
		Select([]string{
		"jinjian_id",
		"first_trail_status",
		"re_trail_status",
		"custom_service_status",
		"operator_status",
		"account_id",
	}).Where("jinjian_id in (?)", jinjianIds).Find(&aoList).Error; err != nil {
		logger.Error("批量查询出错，请检查", "err", err.Error())
		return
	}
	return
}

//  抢单
func GrabApprovalOrder(approveType string, approvalOrder *model.ApprovalOrder, username string, name string) (err error) {
	// 检查审批单数
	if err = checkApprovalOrderCount(approveType, username, name); err != nil {
		return
	}
	// 自动分配订单
	worker, ao, err := workAllocation(approveType)
	if err != nil {
		return err
	}
	switch approveType {
	case "cs":
		err = ao.IsValidCSGrabOrder(approvalOrder)
	case "zs":
		err = ao.IsValidZSGrabOrder(approvalOrder)
	case "kf":
		err = ao.IsValidKFGrabOrder(approvalOrder)
	}
	if err != nil {
		return
	}
	var checkAo model.ApprovalOrder
	// 这里开启事物，防止并发抢单
	tx := config.GetDb().Begin()
	defer util.ClearTransaction(tx)
	if err = tx.Model(checkAo).Where("id = ?", ao.ID).First(&checkAo).Error; err != nil {
		logger.Error("抢单出错" + err.Error())
		tx.Rollback()
		return
	}
	switch approveType {
	case "cs":
		err = checkAo.IsValidCSGrabOrder(approvalOrder)
	case "zs":
		err = checkAo.IsValidZSGrabOrder(approvalOrder)
	case "kf":
		err = checkAo.IsValidKFGrabOrder(approvalOrder)
	}
	if err != nil {
		tx.Rollback()
		return
	}
	if err = tx.Model(ao).Where("id = ?", ao.ID).Updates(approvalOrder).Error; err != nil {
		logger.Error("抢单出错" + err.Error())
		tx.Rollback()
		return
	}
	tx.Commit()
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: name,
		ApprovalStatus: worker + "抢单", ApprovalType: approveType})

	switch approveType {
	case "cs":
		service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_GRAB_CS, model.TP_CS)
	case "zs":
		service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_GRAB_ZS, model.TP_ZS)
	case "kf":
		service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_GRAB_KF, model.TP_KF)
	}

	// 业务留痕
	var aos model.ApprovalOrder
	config.GetDb().Model(aos).Where("id = ?", ao.ID).First(&aos)
	//PostApprovalToRiskControl(aos)
	service.AsyncApprovalTrace(aos)
	return
}

// 自动派单
func workAllocation(approvalType string) (position string, ao *model.ApprovalOrder, err error) {

	var orders model.ApprovalOrder
	switch approvalType {
	case "cs":
		// 初审 只抢待初审已面签的单
		err = config.GetDb().Model(&orders).Where("first_trail_id = ? AND first_trail_name = ? AND first_trail_status = ? AND inter_view <> ?", "Null", "Null", model.ApprovalStatusWaitFirstTrail, "").First(&orders).Error
		position = "初审"
	case "zs":
		err = config.GetDb().Model(&orders).Where("re_trail_id = ? AND re_trail_name = ? AND re_trail_status in (?)", "Null", "Null", service.ReTrailStatusList("all", "")).First(&orders).Error
		position = "终审"
	case "kf":
		err = config.GetDb().Model(&orders).Where("custom_service_id = ? AND custom_service_name = ? AND custom_service_status in (?)", "Null", "Null", service.CustomServiceStatusList("all", "")).First(&orders).Error
		position = "客服"
	default:
		err = errors.New("抢单需要指定身份类型")
		return
	}

	if err != nil {
		logger.Error("自动派单出错", "err", err)
		err = errors.New("未查询到可抢订单")
	}

	return position, &orders, err
}

// 检查我的单数
func checkApprovalOrderCount(approvalType string, username string, name string) (err error) {
	var orders []*model.ApprovalOrder
	sqlBase := config.GetDb().Model(&orders)
	switch approvalType {
	case "cs":
		sqlBase = sqlBase.Where("first_trail_id = ? AND first_trail_name = ? AND first_trail_status in (?)", username, name,
			service.FirstTrailStatusList("me", ""))
	case "zs":
		sqlBase = sqlBase.Where("re_trail_id = ? AND re_trail_name = ? AND re_trail_status in (?)", username, name,
			[]string{model.ApprovalStatusWaitReTrail, model.ApprovalStatusReTrailExchange,
				model.ApprovalStatusCustomServiceBack, model.ApprovalStatusFinanceBack})
	case "kf":
		sqlBase = sqlBase.Where("custom_service_id = ? AND custom_service_name = ? AND custom_service_status in (?)",
			username, name, service.CustomServiceStatusList("me", ""))
	default:
		err = errors.New("approvalType参数读取错误，请检查approvalType")
		return
	}
	var myOrderCount int
	if err = sqlBase.Count(&myOrderCount).Error; err != nil {
		logger.Info("=========获取我的审批单数出错=========", "err", err.Error())
		return
	}

	// 原定是10笔
	if myOrderCount >= 100 {
		err = errors.New("你的审批单数量已经达到10个，无法再添加审批单啦")
		return
	}
	return
}

//  四要素验证通过后添加扣款卡
func AddPayCard(jinjianId string, bankName string, cardNum string, phoneNum string) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Model(ao).Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return err
	}
	var payCardList []map[string]interface{}
	if ao.PayCardList != "" {
		if err = util.ParseJson(ao.PayCardList, &payCardList); err != nil {
			logger.Error("=============ParseJson Err: " + err.Error())
			return
		}
	}

	var card map[string]interface{}
	card = make(map[string]interface{})
	card["bank"] = bankName
	card["cardNo"] = cardNum
	card["cellphone"] = phoneNum
	payCardList = append(payCardList, card)
	ao.PayCardList = util.StringifyJson(payCardList)
	if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
		logger.Error("=============Updates Err: " + err.Error())
		return err
	}

	var approvalName, approvalStatus string
	if ao.FirstTrailStatus == model.ApprovalStatusFirstTrailPass || ao.FirstTrailStatus == model.ApprovalStatusFirstTrailRefuse {
		approvalName = ao.ReTrailName
		approvalStatus = "终审"
	} else {
		approvalName = ao.FirstTrailName
		approvalStatus = "初审"
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: approvalName,
		ApprovalStatus: approvalStatus + "添加扣款卡",
		ApprovalType: "cs", ApprovalDesc: "添加扣款卡"})

	return
}

//  创建或者更新初审结论
func NewApprovalCsResult(result *model.ApprovalCsResult) (err error) {
	if err = result.IsValidApprovalCsResult(); err != nil {
		return
	}
	var r model.ApprovalCsResult
	if err = config.GetDb().Where("approval_id =?", result.ApprovalId).First(&r).Error; err != nil {
		if err.Error() == "record not found" {
			return config.GetDb().Create(result).Error
		}
		logger.Error("=========创建初审结论出错======: " + err.Error())
		return
	}
	result.ID = r.ID
	return config.GetDb().Model(r).Updates(result).Error
}

//  获取初审结论
func GetApprovalCsResult(approvalId uint) *model.ApprovalCsResult {
	var result model.ApprovalCsResult
	if err := config.GetDb().Where("approval_id =?", approvalId).First(&result).Error; err != nil {
		logger.Error("=========获取初审结论出错======: " + err.Error())
		return nil
	}
	return &result
}

//  文件上传
func UploadApprovalFile(file *model.ApprovalUploadFile) (err error) {
	err = file.IsValidApprovalFile()
	if err != nil {
		sqlBase := config.GetDb().Model(file).Where("jinjian_id = ? AND file_type =?", file.JinjianId, file.FileType)
		switch err.Error() {
		//case model.FT_LIANGHUABIANLIANG + "已存在":
		//	if err1 := sqlBase.Updates(*file).Error; err != nil {
		//		return err1
		//	}
		//case model.FT_MIANQINACAILIAO + "已存在":
		//	if err1 := sqlBase.Updates(*file).Error; err != nil {
		//		return err1
		//	}
		//case model.FT_ZHENGXINBAOGAO + "已存在":
		//	if err1 := sqlBase.Updates(*file).Error; err != nil {
		//		return err1
		//	}
		case model.FT_DIANHE + "已存在":
			if err := sqlBase.Updates(*file).Error; err != nil {
				return err
			}
		default:
			return err
		}
	}
	err = config.GetDb().Create(file).Error
	return
}

//  获取资料文件 (下载)
func GetApprovalFile(jinjianId string, fileType string) []*model.ApprovalUploadFile {
	approvalFiles := []*model.ApprovalUploadFile{}
	err := config.GetDb().Where("jinjian_id = ? AND file_type = ?", jinjianId, fileType).Find(&approvalFiles).Error
	if err != nil {
		logger.Error("==========获取审批材料出错=============: " + err.Error())
		return nil
	}
	return approvalFiles
}

//  获取审批详情
func GetApprovalOrder(jinjianId string) (ao model.ApprovalOrder, satisfy bool, err error) {
	if err = config.GetDb().Model(ao).Where("jinjian_id = ?", jinjianId).First(&ao).Error; err != nil {
		logger.Error("进件id: " + jinjianId + "=====GetApprovalOrder========获取审批单详情出错============: " + err.Error())
		return
	}
	// 自动解挂
	if err = offSuspending(&ao); err != nil {
		return
	}
	// 检查三方信息是否相等
	if satisfy, err = checkThreePartyInfo(ao); err != nil {
		return
	}
	// 检查手机归属地
	if common.GetUseDocker() == 2 {
		ao, err = getCellPhoneCore(ao)
	}
	return
}

func checkThreePartyInfo(ao model.ApprovalOrder) (satisfy bool, err error) {
	var allInfo map[string]interface{}
	if err = util.ParseJson(ao.AllInfo, &allInfo); err != nil {
		return
	}
	var threePartyInfo model.ThreePartyInfo
	if threePartyInfo, err = model.GetThreePartyInfoByJinjianId(ao.JinjianId); err != nil {
		if err.Error() == "record not found" {
			return true, nil
		}
		logger.Error("=======获取三方信息出错========: " + err.Error())
		return
	}

	satisfy = true
	// 工作单位
	if company, ok := allInfo["personal_info"].(map[string]interface{})["workplace"].(string); ok {
		if company != threePartyInfo.Company {
			threePartyInfo.GsCompanyResult = 4
			threePartyInfo.BdCompanyResult = 4
			threePartyInfo.RfCompanyResult = 4
			threePartyInfo.SxCompanyResult = 4
			satisfy = false
		}
	}
	// 住宅地址
	if uAddress, ok1 := allInfo["personal_info"].(map[string]interface{})["address"].(string); ok1 {
		if uDetailAddress, ok2 := allInfo["personal_info"].(map[string]interface{})["detailAddress"].(string); ok2 {
			if uAddress+uDetailAddress != threePartyInfo.UserAddress {
				threePartyInfo.BdAddressResult = 4
				satisfy = false
			}
		}
	}
	// 工作地址
	if workAddress, ok1 := allInfo["personal_info"].(map[string]interface{})["workAddress"].(string); ok1 {
		if workDetailAddress, ok2 := allInfo["personal_info"].(map[string]interface{})["workDetailAddress"].(string); ok2 {
			if workAddress+workDetailAddress != threePartyInfo.CompanyAddress {
				threePartyInfo.BdCompanyAddressResult = 4
				satisfy = false
			}
		}
	}
	// 工作电话
	if companyPhone, ok := allInfo["personal_info"].(map[string]interface{})["workplacePhone"].(string); ok {
		if companyPhone != threePartyInfo.CompanyPhone {
			threePartyInfo.BdCompanyPhoneResult = 4
			satisfy = false
		}
	}
	// 主要联系人电话
	if contactCellphone, ok := allInfo["contacts"].(map[string]interface{})["primaryPhone"].(string); ok {
		if contactCellphone != threePartyInfo.ContactCellphone {
			threePartyInfo.BdContactPhoneResult = 4
			satisfy = false
		}
	}
	// 次要联系人电话
	if secContactCellphone, ok := allInfo["contacts"].(map[string]interface{})["secondaryPhone"].(string); ok {
		if secContactCellphone != threePartyInfo.SecContactCellphone {
			threePartyInfo.BdSecContactPhoneResult = 4
			satisfy = false
		}
	}
	if !satisfy {
		err = config.GetDb().Model(threePartyInfo).Updates(threePartyInfo).Error
	}
	return
}

// 手机归属地查询
func getCellPhoneCore(ao model.ApprovalOrder) (ao2 model.ApprovalOrder, err error) {
	var allInfo map[string]interface{}
	if err = util.ParseJson(ao.AllInfo, &allInfo); err != nil {
		logger.Error("=============解析审批单详情AllInfo出错=======: " + err.Error())
		return
	}
	shouldUpdate := false
	if checkAllInfoKeyExist(allInfo, "cellphone") {
		shouldUpdate = true
		allInfo["call_record"].(map[string]interface{})["cellphoneQCellCore"] =
			getPhoneNumQCellCore(allInfo["call_record"].(map[string]interface{})["cellphone"].(string))
	}
	if checkAllInfoKeyExist(allInfo, "primaryPhone") {
		shouldUpdate = true
		allInfo["contacts"].(map[string]interface{})["primaryPhoneQCellCore"] =
			getPhoneNumQCellCore(allInfo["contacts"].(map[string]interface{})["primaryPhone"].(string))
	}
	if checkAllInfoKeyExist(allInfo, "secondaryPhone") {
		shouldUpdate = true
		allInfo["contacts"].(map[string]interface{})["secondaryPhoneQCellCore"] =
			getPhoneNumQCellCore(allInfo["contacts"].(map[string]interface{})["secondaryPhone"].(string))
	}

	if shouldUpdate {
		ao.AllInfo = util.StringifyJson(allInfo)
		if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
			logger.Error("=========更新手机归属地出错: " + err.Error())
			return
		} else {
			// 业务留痕
			service.AsyncApprovalTrace(ao)
		}
	}
	ao2 = ao
	return
}

// 检查是否要查询手机归属地
func checkAllInfoKeyExist(allInfo map[string]interface{}, checkKey string) bool {
	switch checkKey {
	case "cellphone":
		if allInfo["call_record"].(map[string]interface{})["cellphoneQCellCore"] == nil ||
			(allInfo["call_record"].(map[string]interface{})["cellphoneQCellCore"] != nil &&
				allInfo["call_record"].(map[string]interface{})["cellphoneQCellCore"].(string) == "") {
			if allInfo["call_record"].(map[string]interface{})["cellphone"] != nil {
				return true
			}
		}
	case "primaryPhone":
		if allInfo["contacts"].(map[string]interface{})["primaryPhoneQCellCore"] == nil ||
			(allInfo["contacts"].(map[string]interface{})["primaryPhoneQCellCore"] != nil &&
				allInfo["contacts"].(map[string]interface{})["primaryPhoneQCellCore"].(string) == "") {
			if allInfo["contacts"].(map[string]interface{})["primaryPhone"] != nil {
				return true
			}
		}
	case "secondaryPhone":
		if allInfo["contacts"].(map[string]interface{})["secondaryPhoneQCellCore"] == nil ||
			(allInfo["contacts"].(map[string]interface{})["secondaryPhoneQCellCore"] != nil &&
				allInfo["contacts"].(map[string]interface{})["secondaryPhoneQCellCore"].(string) == "") {
			if allInfo["contacts"].(map[string]interface{})["secondaryPhone"] != nil {
				return true
			}
		}
	}
	return false
}

//  从合同管理系统获取url
func GetContractUrl(jinjianId string) (result map[string]interface{}) {
	resultResp, err := httpReq.GetProxy(global.GetContractUrl() + "/api/v1/ec_pdf/" + jinjianId)
	if err != nil {
		logger.Error("========请求合同系统获取url结果出错: " + err.Error())
		return
	}
	if r, ok := resultResp["data"].(map[string]interface{}); ok {
		result = r
	}
	return
}

// 获取手机归属地
func getPhoneNumQCellCore(phoneNum string) (result string) {
	resultResp, err := httpReq.PostJsonProxy(map[string]interface{}{"phone": phoneNum}, global.GetRiskControlServerUrl()+"/api/v1/phones/carrier")
	if err != nil {
		logger.Error("========请求风控返回归属地结果出错: " + err.Error())
		return
	}
	if !resultResp["success"].(bool) {
		logger.Error("========风控返回归属地结果出错: " + util.StringifyJson(resultResp))
		return
	}
	result = resultResp["province"].(string) + resultResp["company"].(string) + " " + resultResp["city"].(string)
	return
}

//  审批挂起
func ApprovalSuspending(jinjianId string, onoff string, desc string, approvalType string) (err error) {
	if desc == "" {
		err = errors.New("挂起原因不能为空")
		return
	}
	var ao model.ApprovalOrder
	if err = config.GetDb().Where("jinjian_id = ?", jinjianId).First(&ao).Error; err != nil {
		return
	}
	var worker, approvalName string
	switch approvalType {
	case "cs":
		worker = "初审"
		approvalName = ao.FirstTrailName
	case "zs":
		worker = "终审"
		approvalName = ao.ReTrailName
	case "kf":
		worker = "客服"
		approvalName = ao.CustomServiceName
	default:
		err = errors.New("挂起操作类型出错，请检查approvalType")
		return
	}
	ao.Suspending = "on" // 现在只有开启挂起，解挂在获取订单详情时解挂
	ao.SuspenseDesc = desc
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: approvalName,
		ApprovalStatus: worker + "挂起", ApprovalType: approvalType, ApprovalDesc: desc})

	if err = config.GetDb().Model(ao).Update("suspense_desc", ao.SuspenseDesc).Updates(ao).Error; err != nil {
		logger.Error("==================审批挂起操作，UpdateERR：" + err.Error())
		return
	}
	// 业务留痕
	service.AsyncApprovalTrace(ao)
	return
}

// 自动解挂 有可能是一个暂时方法，先这样用吧
func offSuspending(ao *model.ApprovalOrder) (err error) {
	if ao.Suspending == "on" {
		ao.Suspending = "off"
		ao.SuspenseDesc = ""
		if err = ao.Update(map[string]interface{}{"suspending": "off", "suspense_desc": ""}); err != nil {
			logger.Error("=========自动解挂错误====: " + err.Error())
			return errors.New("自动解挂失败，请稍后重试")
		}
	}
	return
}

//  获取审批记录
func GetApprovalLog(jinjianId string, approvalType string) []model.ApprovalLog {
	logs := []model.ApprovalLog{}
	config.GetDb().Where("approval_jinjian_id =? AND approval_type in (?)",
		jinjianId, []string{"mq", "cs", "zs", "kf", "yy"}).Order("created_at desc").Find(&logs)
	//switch approvalType {
	//case "cs":
	//	config.GetDb().Where("approval_jinjian_id =? AND approval_type =?", jinjianId, "cs").Find(&logs)
	//case "zs":
	//	config.GetDb().Where("approval_jinjian_id =? AND approval_type in (?)", jinjianId, []string{"cs", "zs"}).Find(&logs)
	//case "kf":
	//	config.GetDb().Where("approval_jinjian_id =? AND approval_type in (?)", jinjianId, []string{"cs", "zs", "kf"}).Find(&logs)
	//case "yy":
	//	config.GetDb().Where("approval_jinjian_id =? AND approval_type in (?)", jinjianId, []string{"cs", "zs", "kf", "yy"}).Find(&logs)
	//}
	return logs
}

//  transact func 获取审批列表和搜索
func transactGetApprovalList(approvalType string, typeKey string, status string, username string, name string,
	sort string, condition string, page int) (aoList []model.ApprovalOrder, totalPage, totalCount int) {
	offset := util.GetOffset(page, perPage)
	// 判定前端页面选择的是 全部、我的或者是历史 isSelectAll
	username, name = isSelectAll(username, name, typeKey)
	sqlBase := config.GetDb().Model(aoList)
	switch approvalType {
	case "cs":
		sqlBase = sqlBase.Where("(first_trail_id = ? AND first_trail_name = ? AND first_trail_status in (?))",
			username, name, service.FirstTrailStatusList(typeKey, status))
	case "zs":
		sqlBase = sqlBase.Where("re_trail_id = ? AND re_trail_name = ? AND re_trail_status in (?)",
			username, name, service.ReTrailStatusList(typeKey, status))
	case "kf":
		sqlBase = sqlBase.Where("custom_service_id = ? AND custom_service_name = ? AND custom_service_status in (?)",
			username, name, service.CustomServiceStatusList(typeKey, status))
	}
	if condition != "" {
		condition = "%" + condition + "%"
		sqlBase = sqlBase.Where(
			"((jinjian_user_name LIKE ?) OR (show_id LIKE ?) OR (agency_name LIKE ?) "+
				"OR (agency_employee LIKE ?) OR (user_id_num LIKE ?))",
			condition, condition, condition, condition, condition)
	}
	if typeKey == "history" {
		if sort == "" {
			sqlBase = sqlBase.Order("created_at desc")
		}
	}
	if sort != "" {
		sqlBase = sqlBase.Order(sort)
	}
	// 获取总页数
	totalPage, totalCount = util.GetTotalPagesAndCount(sqlBase, &aoList, perPage)
	// 获取初审列表 -- 分页后的数据
	sqlBase.Offset(offset).Limit(perPage).Find(&aoList)
	return
}

//  流转
func exchange(ao model.ApprovalOrder, changeAo *model.ApprovalOrder, approvalType string) (err error) {
	switch approvalType {
	case "cs":
		if changeAo.FirstTrailName == "" || changeAo.FirstTrailId == "" || changeAo.FirstTrailName == "Null" ||
			changeAo.FirstTrailId == "Null" {
			err = errors.New("流转参数出错，请检查")
			return
		}
		service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.FirstTrailName,
			ApprovalStatus: "初审流转给" + changeAo.FirstTrailName, ApprovalType: "cs", ApprovalDesc: changeAo.FirstTrailStatusDes})
		ao.FirstTrailId = changeAo.FirstTrailId
		ao.FirstTrailName = changeAo.FirstTrailName
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailExchange
		ao.FirstTrailStatusDes = changeAo.FirstTrailStatusDes
		ao = updateAoInfoByChangeAo(ao, changeAo)
		ao.ApprovalStatus = ao.GetAoCurrStatus()
		if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
			return err
		}
		service.AsyncApprovalTrace(ao)
	case "zs":
		if changeAo.ReTrailName == "" || changeAo.ReTrailId == "" || changeAo.ReTrailName == "Null" ||
			changeAo.ReTrailId == "Null" {
			err = errors.New("流转参数出错，请检查")
			return
		}
		service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.ReTrailName,
			ApprovalStatus: "终审流转给" + changeAo.ReTrailName,
			ApprovalType: "zs", ApprovalDesc: changeAo.ReTrailStatusDes})

		ao = updateAoInfoByChangeAo(ao, changeAo)
		ao.ApprovalStatus = ao.GetAoCurrStatus()
		if changeAo.SalaryAt == nil {
			ao.SalaryAt = nil
		} else {
			ao.SalaryAt = changeAo.SalaryAt
		}

		if changeAo.LoanAt == nil {
			ao.LoanAt = nil
		} else {
			ao.LoanAt = changeAo.LoanAt
		}
		ao.ReTrailName = changeAo.ReTrailName
		ao.ReTrailId = changeAo.ReTrailId
		ao.ReTrailStatus = model.ApprovalStatusReTrailExchange
		ao.ReTrailStatusDes = changeAo.ReTrailStatusDes
		if err = config.GetDb().Model(ao).Updates(ao).Update("salary_at", changeAo.SalaryAt).
			Update("loan_at", changeAo.LoanAt).Error; err != nil {
			return err
		}
		service.AsyncApprovalTrace(ao)
	case "kf":
		if changeAo.CustomServiceName == "" || changeAo.CustomServiceId == "" || changeAo.CustomServiceName == "Null" ||
			changeAo.CustomServiceId == "Null" {
			err = errors.New("流转参数出错，请检查")
			return
		}
		ao.ApprovalStatus = ao.GetAoCurrStatus()
		service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.CustomServiceName,
			ApprovalStatus: "客服流转给" + changeAo.CustomServiceName,
			ApprovalType: "kf", ApprovalDesc: changeAo.CustomServiceStatusDes})
		ao.CustomServiceName = changeAo.CustomServiceName
		ao.CustomServiceId = changeAo.CustomServiceId
		ao.CustomServiceStatus = model.ApprovalStatusCustomServiceExchange
		ao.CustomServiceStatusDes = changeAo.CustomServiceStatusDes
		if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
			return err
		}
		service.AsyncApprovalTrace(ao)
	default:
		err = errors.New("操作流转类型出错，请检查approvalType")
	}
	return
}

//  撤销
func cancel(ao model.ApprovalOrder, changeAo *model.ApprovalOrder, approvalType string) (err error) {
	var approvalStatus, approvalName, approvalDesc string
	switch approvalType {
	case "cs":
		if changeAo.FirstTrailStatus != model.ApprovalStatusCustomCancel {
			err = errors.New("撤销参数出错，请检查")
			return
		}
		ao.FirstTrailStatus = model.ApprovalStatusCustomCancel
		ao.FirstTrailStatusDes = changeAo.FirstTrailStatusDes
		approvalStatus = "初审阶段撤销"
		approvalName = ao.FirstTrailName
		approvalDesc = changeAo.FirstTrailStatusDes
	case "zs":
		if changeAo.ReTrailStatus != model.ApprovalStatusCustomCancel {
			err = errors.New("撤销参数出错，请检查")
			return
		}
		ao.ReTrailStatus = model.ApprovalStatusCustomCancel
		ao.ReTrailStatusDes = changeAo.ReTrailStatusDes
		approvalStatus = "终审阶段撤销"
		approvalName = ao.ReTrailName
		approvalDesc = changeAo.ReTrailStatusDes
	case "kf":
		if changeAo.CustomServiceStatus != model.ApprovalStatusCustomCancel {
			err = errors.New("撤销参数出错，请检查")
			return
		}
		ao.CustomServiceStatus = model.ApprovalStatusCustomCancel
		ao.CustomServiceStatusDes = changeAo.CustomServiceStatusDes
		approvalStatus = "客服阶段撤销"
		approvalName = ao.CustomServiceName
		approvalDesc = changeAo.CustomServiceStatusDes
	default:
		err = errors.New("撤销流转类型出错，请检查approvalType")
	}
	if approvalDesc == "" {
		err = errors.New("撤销说明不能为空, 请检查")
		return
	}
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: approvalName,
		ApprovalStatus: approvalStatus,
		ApprovalType: approvalType, ApprovalDesc: approvalDesc})
	// 中介需要的
	ao.AgencyStatus = "已撤销"
	nowTime := time.Now()
	ao.CancelTime = &nowTime
	ao.ApprovalStatus = ao.GetAoCurrStatus()
	if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
		return err
	}

	// 发短信   撤销
	service.SendSms(ao, "cancel", true)

	switch approvalType {
	case "cs":
		service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_CS)
	case "zs":
		service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_ZS)
	case "kf":
		service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_KF)
	}

	return
}

// 审批更新进件信息
func UpdateJinjianAllInfo(jinjianId string, key string, value string) (err error) {
	var checkIdResult string
	var ao model.ApprovalOrder
	if err = config.GetDb().Model(ao).Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return
	}
	var allInfo map[string]interface{}
	if err = util.ParseJson(ao.AllInfo, &allInfo); err != nil {
		return
	}
	var doSth, cgLog string
	switch key {
	// 2018年01月22日10:32:41 add address
	case "address":
		doSth = "住宅地址"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["address"], value)
		allInfo["personal_info"].(map[string]interface{})["address"] = value

	case "workplace":
		doSth = "工作单位"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["workplace"], value)
		allInfo["personal_info"].(map[string]interface{})["workplace"] = value

	case "detailAddress":
		doSth = "住宅详细地址"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["detailAddress"], value)
		allInfo["personal_info"].(map[string]interface{})["detailAddress"] = value

	case "workDetailAddress":
		doSth = "工作详细地址"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["workDetailAddress"], value)
		allInfo["personal_info"].(map[string]interface{})["workDetailAddress"] = value

	case "workAddress":
		doSth = "工作地址"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["workAddress"], value)
		allInfo["personal_info"].(map[string]interface{})["workAddress"] = value

	case "workplacePhone":
		doSth = "单位电话"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["workplacePhone"], value)
		allInfo["personal_info"].(map[string]interface{})["workplacePhone"] = value

	case "wxNo":
		doSth = "个人微信号"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["wxNo"], value)
		allInfo["personal_info"].(map[string]interface{})["wxNo"] = value

	case "marriage":
		doSth = "婚姻状况"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["marriage"], value)
		allInfo["personal_info"].(map[string]interface{})["marriage"] = value

	case "houseType":
		doSth = "住宅类型"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["houseType"], value)
		allInfo["personal_info"].(map[string]interface{})["houseType"] = value

	case "monthlyCost":
		doSth = "住房月成本"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["monthlyCost"], value)
		allInfo["personal_info"].(map[string]interface{})["monthlyCost"] = value

	case "monthlyIncome":
		doSth = "月收入"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["monthlyIncome"], value)
		allInfo["personal_info"].(map[string]interface{})["monthlyIncome"] = value

	case "hasHouse":
		doSth = "有无房产"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["hasHouse"], value)
		allInfo["personal_info"].(map[string]interface{})["hasHouse"] = value

	case "hasHouseLoan":
		doSth = "有无房贷"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["hasHouseLoan"], value)
		allInfo["personal_info"].(map[string]interface{})["hasHouseLoan"] = value

	case "hasCar":
		doSth = "有无车产"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["hasCar"], value)
		allInfo["personal_info"].(map[string]interface{})["hasCar"] = value

	case "hasCarLoan":
		doSth = "有无车贷"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["hasCarLoan"], value)
		allInfo["personal_info"].(map[string]interface{})["hasCarLoan"] = value

	case "usage":
		doSth = "贷款用途"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["usage"], value)
		allInfo["personal_info"].(map[string]interface{})["usage"] = value

	case "job":
		doSth = "工作职位"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["personal_info"].(map[string]interface{})["job"], value)
		allInfo["personal_info"].(map[string]interface{})["job"] = value

	case "primaryName":
		doSth = "主要联系人姓名"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["contacts"].(map[string]interface{})["primaryName"], value)
		allInfo["contacts"].(map[string]interface{})["primaryName"] = value

	case "primaryPhone":
		doSth = "主要联系人手机号"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["contacts"].(map[string]interface{})["primaryPhone"], value)
		allInfo["contacts"].(map[string]interface{})["primaryPhone"] = value
		allInfo["contacts"].(map[string]interface{})["primaryPhoneQCellCore"] = ""

	case "primaryAddr":
		doSth = "主要要联系人地址"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["contacts"].(map[string]interface{})["primaryAddr"], value)
		allInfo["contacts"].(map[string]interface{})["primaryAddr"] = value

	case "primaryRelation":
		doSth = "与本人关系"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["contacts"].(map[string]interface{})["primaryRelation"], value)
		allInfo["contacts"].(map[string]interface{})["primaryRelation"] = value

	case "secondaryName":
		doSth = "次要联系人姓名"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["contacts"].(map[string]interface{})["secondaryName"], value)
		allInfo["contacts"].(map[string]interface{})["secondaryName"] = value

	case "secondaryPhone":
		doSth = "次要联系人手机号"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["contacts"].(map[string]interface{})["secondaryPhone"], value)
		allInfo["contacts"].(map[string]interface{})["secondaryPhone"] = value
		allInfo["contacts"].(map[string]interface{})["secondaryPhoneQCellCore"] = ""

	case "secondaryAddr":
		doSth = "次要联系人地址"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["contacts"].(map[string]interface{})["secondaryAddr"], value)
		allInfo["contacts"].(map[string]interface{})["secondaryAddr"] = value

	case "secondaryRelation":
		doSth = "与本人关系"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["contacts"].(map[string]interface{})["secondaryRelation"], value)
		allInfo["contacts"].(map[string]interface{})["secondaryRelation"] = value

		//case "loanAmount":
		//	doSth = "贷款金额"
		//	ao.LoanAmount, err = strconv.ParseUint(value,10,64)
		//	cgLog = fmt.Sprintf("从%v改成%v", ao.LoanAmount, value)

	case "loanTerm":
		doSth = "贷款期数"
		ao.LoanTerm, err = strconv.Atoi(value)
		cgLog = fmt.Sprintf("从%v改成%v", ao.LoanTerm, value)

	case "name":
		checkIdResult = CheckIdCardAndName(jinjianId, ao.UserIdNum, value)

		doSth = "姓名"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["idcard_info"].(map[string]interface{})["name"], value)
		allInfo["idcard_info"].(map[string]interface{})["name"] = value
		ao.JinjianUserName = value
	case "number":
		checkIdResult = CheckIdCardAndName(jinjianId, value, ao.JinjianUserName)

		ao.IdCardPlace = GetPlaceInfoByIdNum(value) // 获取身份证归属地
		doSth = "身份证号"
		cgLog = fmt.Sprintf("从%v改成%v", allInfo["idcard_info"].(map[string]interface{})["number"], value)
		allInfo["idcard_info"].(map[string]interface{})["number"] = value
		ao.UserIdNum = value
	default:
		err = errors.New("修改审批信息key匹配错误")
		return
	}

	var approvalName, approvalStatus string
	if ao.FirstTrailStatus == model.ApprovalStatusFirstTrailPass || ao.FirstTrailStatus == model.ApprovalStatusFirstTrailRefuse {
		approvalName = ao.ReTrailName
		approvalStatus = "终审修改"
	} else {
		approvalName = ao.FirstTrailName
		approvalStatus = "初审修改"
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: approvalName,
		ApprovalStatus: approvalStatus + doSth,
		ApprovalType: "cs", ApprovalDesc: cgLog})

	ao.AllInfo = util.StringifyJson(allInfo)
	ao.IdCardCheckResult = checkIdResult // 修改姓名和身份证时,检测结果赋给结构体; 若未修改二者其一,则默认空值,便不会更新该字段
	if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
		return
	}
	// 业务留痕
	service.AsyncApprovalTrace(ao)
	return
}

//  更新个人信息补充
func UpdateUserInfoSup(info *model.ApprovalUserInfoSup, opName string) (err error) {
	if err = info.IsValidApprovalUserInfoSup(); err != nil {
		return
	}
	if err = config.GetDb().Model(info).Where("jinjian_id = ?", info.JinjianId).Update(info).Error; err != nil {
		return
	}
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: info.JinjianId, ApprovalName: opName,
		ApprovalStatus: "更新用户个人信息",
		ApprovalType: "cs"})

	return
}

//  更新添加联系人
func UpdateAddContact(jinjianId, key, value string, index int) (err error) {
	var ao model.ApprovalOrder
	if err = config.GetDb().Where("jinjian_id =?", jinjianId).First(&ao).Error; err != nil {
		return
	}
	if ao.ApprovalAddContacts == "" || ao.ApprovalAddContacts == "[]" {
		err = errors.New("审批添加联系人数组map为空不能修改，请检查")
		return
	}
	var contacts []map[string]string
	if err = util.ParseJson(ao.ApprovalAddContacts, &contacts); err != nil {
		return
	}
	if len(contacts) < index {
		err = errors.New("修改新增联系人数组越界，请检查")
		return
	}
	var doSth, cgLog string
	switch key {
	case "name":
		doSth = "姓名"
		cgLog = fmt.Sprintf("从%v改成%v", contacts[index]["name"], value)
		contacts[index]["name"] = value
	case "phone":
		doSth = "电话"
		cgLog = fmt.Sprintf("从%v改成%v", contacts[index]["phone"], value)
		contacts[index]["phone"] = value
		if common.GetUseDocker() == 2 && contacts[index]["relationship"] != "公司电话" {
			contacts[index]["qCellCore"] = getPhoneNumQCellCore(value)
		}

	case "relationship":
		doSth = "关系"
		cgLog = fmt.Sprintf("从%v改成%v", contacts[index]["relationship"], value)
		contacts[index]["relationship"] = value
	case "address":
		doSth = "详细地址"
		cgLog = fmt.Sprintf("从%v改成%v", contacts[index]["address"], value)
		contacts[index]["address"] = value
	default:
		err = errors.New("修改新增联系人key错误，请检查请求参数")
		return
	}
	ao.ApprovalAddContacts = util.StringifyJson(contacts)
	if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
		return
	}

	var approvalName, approvalStatus string
	if ao.FirstTrailStatus == model.ApprovalStatusFirstTrailPass || ao.FirstTrailStatus == model.ApprovalStatusFirstTrailRefuse {
		approvalName = ao.ReTrailName
		approvalStatus = "终审"
	} else {
		approvalName = ao.FirstTrailName
		approvalStatus = "初审"
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: approvalName,
		ApprovalStatus: fmt.Sprintf("%v修改新增联系人%v ", approvalStatus, index+1) + doSth,
		ApprovalType: "cs", ApprovalDesc: cgLog})
	// 业务留痕
	service.AsyncApprovalTrace(ao)
	return
}

// 多头借贷响应参数
type getMultipointResp struct {
	http.BaseResp
	Multipoints []*model2.Multipoint `json:"multipoints"`
}

// 终审增加简报功能
func GenerateApprovalReport(jinJianId string) (result map[string]string, err error) {
	var ao model.ApprovalOrder
	// 根据前端传入的进件id查询ApprovalOrder
	if err = config.GetDb().Model(&model.ApprovalOrder{}).Where("jinjian_id =?", jinJianId).First(&ao).Error; err != nil {
		logger.Error("err", "根据前端传入的进件id["+jinJianId+"]查询审批订单出错", jinJianId)
		return
	}
	result = map[string]string{}
	// 客户姓名
	getUserNameByOrder(&ao, result)
	// 订单信息
	getOrderInfoByOrder(&ao, result)
	// 用户信息
	getPersonInfo(&ao, result)
	// 风险参数
	var riskParamMap map[string]interface{}
	if err := util.ParseJson(ao.RiskParam, &riskParamMap); err == nil {
		// 风险参数版本
		version := util.GetStrFromJson(riskParamMap, "version")
		getDataByRiskParam(&ao, version, riskParamMap, result)
	} else {
		logger.Error("err", "解析风险参数RiskParam为json出错", err.Error())
	}
	// 根据量化变量得到审批查询次数与房产估值
	getDataByQuantizationMap(&ao, result)
	if !util.IsTestEnv() {
		// 多头借贷
		getMultipointsInfo(&ao, result)
		// 身份证户籍地址
		getPlaceInfoByIdNum(&ao, result)
	} else {
		result["multiHeadsLoan"] = EmptyDocInfo
		result["householdPlace"] = EmptyDocInfo
	}
	return
}

// 得到客户姓名
func getUserNameByOrder(order *model.ApprovalOrder, result map[string]string) {
	var allInfo map[string]interface{}
	if err := util.ParseJson(order.AllInfo, &allInfo); err != nil {
		logger.Error("err", "得到客户姓名----解析allinfo出错", err.Error())
		result["name"] = EmptyDocInfo
	} else {
		cardInfo := allInfo["idcard_info"].(map[string]interface{})
		result["name"] = util.GetStrFromJson(cardInfo, "name")
	}
}

// 得到订单信息
func getOrderInfoByOrder(order *model.ApprovalOrder, result map[string]string) {
	result["showId"] = order.ShowId
	result["funSide"] = order.FundSide
	result["userIdNum"] = order.UserIdNum
	result["agencyName"] = order.AgencyName
	result["quantizationPoint"] = strconv.Itoa(order.QuantizationPoint)
}

// 用户信息
func getPersonInfo(order *model.ApprovalOrder, result map[string]string) {
	var allInfo map[string]interface{}
	if err := util.ParseJson(order.AllInfo, &allInfo); err != nil {
		logger.Error("err", "得到用户信息----解析allinfo出错", err.Error())
		result["workplace"] = EmptyDocInfo
		result["job"] = EmptyDocInfo
		result["usage"] = EmptyDocInfo
		result["monthlyIncome"] = EmptyDocInfo
	} else {
		personalInfo := allInfo["personal_info"].(map[string]interface{})
		result["workplace"] = util.GetStrFromJson(personalInfo, "workplace")
		result["job"] = util.GetStrFromJson(personalInfo, "job")
		result["usage"] = util.GetStrFromJson(personalInfo, "usage")
		income := util.GetStrFromJson(personalInfo, "monthlyIncome")
		result["monthlyIncome"] = float64ToStr(str2Float64DivideTenThousand(income))
	}
}

// 根据量化变量得到数据
func getDataByQuantizationMap(order *model.ApprovalOrder, result map[string]string) {
	var quantizationMap map[string]interface{}
	if err := util.ParseJson(order.QuantizationMap, &quantizationMap); err != nil {
		logger.Error("err", "解析QuantizationMap出错", err.Error())
		result["houseEstate"] = EmptyDocInfo
	} else {
		houseEstate := util.GetStrFromJson(quantizationMap, "CIPB102")
		result["houseEstate"] = float64ToStr(str2Float64DivideTenThousand(houseEstate))
	}

	// 近两个月贷款审批查询次数:
	// 2018.03.08 从QuantizationCache里面的Other里面取k104，以前取的是QuantizationMap里面的:CIPB089
	var quantizationCache map[string]interface{}
	if err := util.ParseJson(order.QuantizationCache, &quantizationCache); err != nil {
		logger.Error("err", "解析QuantizationCache出错", err.Error())
		result["queryCount"] = EmptyDocInfo
	} else {
		other := util.GetJsonFromJson(quantizationCache, "Other")
		if other != nil {
			k104 := util.GetStrFromJson(other, "k104")
			if k104 != "" {
				result["queryCount"] = k104
			} else {
				result["queryCount"] = EmptyDocInfo
			}
		} else {
			result["queryCount"] = EmptyDocInfo
		}
	}
}

// 根据风险参数版本得到数据
func getDataByRiskParam(order *model.ApprovalOrder, version string, riskParamMap map[string]interface{}, result map[string]string) {
	if version == "v1.0" || version == "v2.0" {
		getDataByNewRiskParamV1(order, riskParamMap, result)
	} else {
		getDataByDefaultRiskParamDefault(riskParamMap, result)
	}

}

// 旧版风险参数得到数据
func getDataByDefaultRiskParamDefault(riskParamMap map[string]interface{}, result map[string]string) {
	totalAmount := util.GetStrFromJson(riskParamMap, "k5_01")
	result["totalAmount"] = float64ToStr(str2Float64DivideTenThousand(totalAmount))
	// 已用额度
	used := util.GetStrFromJson(riskParamMap, "k5_02")
	result["usedAmount"] = float64ToStr(str2Float64DivideTenThousand(used))
	// 已知负债月供--所有贷款月供
	r24 := util.GetFloatFromJson(riskParamMap, "k9_04")
	//result["monthly_supply"] = float64ToStr(r24 / 10000)
	//2018.03.08  保留小数点后一位
	result["monthly_supply"] = float64ToStr(util.SiSheWuRu(r24/10000, 1))
	// 申请方案
	result["productPlan"] = util.GetStrFromJson(riskParamMap, "k1_03")
	result["approvalAmount"] = EmptyDocInfo
	result["hireType"] = EmptyDocInfo
	result["debt"] = EmptyDocInfo
	result["approvedAmount"] = EmptyDocInfo
	result["certifiedMonthlyIncome"] = EmptyDocInfo
	result["creditDebtMonthlyRepay"] = EmptyDocInfo
	result["knownDTI"] = EmptyDocInfo
	result["qyDTI"] = EmptyDocInfo
}

func getDataByNewRiskParamV1(order *model.ApprovalOrder, riskParamMap map[string]interface{}, result map[string]string) {
	// 申请方案
	GetProductPlanByRiskParamSimpleReport(order, result)
	r25 := util.GetFloatFromJson(riskParamMap, "r25")
	// 2018.03.08 保留小数点后一位，但是并不四舍五入:先乘以10,再向下取整，最后再除以10
	result["qyDTI"] = float64ToStr(float64(util.FloorFloat64ToUint64(r25*10)) / 10)
	// 信用卡已使用额度
	usedStr := util.GetStrFromJson(riskParamMap, "r10")
	fmt.Println("从风险参数里面取出来的已使用额度---usedStr:" + usedStr)
	// 信用卡使用额度*10%
	used := strToFloat(usedStr) * 0.1
	//fmt.Println(used)
	// 信用贷款总月还:
	// 2018.03.01修改为:信用卡使用额度*10% + 信用贷款总月还
	r18 := util.GetFloatFromJson(riskParamMap, "r18")
	// 2018.03.08 信用卡使用额度*10% 这个地方只需要保留到个位就行，不需要四舍五入，使用向下取整就好
	usedInt := util.FloorFloat64ToUint64(used)
	creditDebtMonthlyRepay := float64(usedInt) + r18
	creditDebtMonthlyRepay = util.SiSheWuRu(creditDebtMonthlyRepay, 1)
	logger.Info("msg", "------result[creditDebtMonthlyRepay]----", creditDebtMonthlyRepay)
	result["creditDebtMonthlyRepay"] = float64ToStr(creditDebtMonthlyRepay)
	//认定月收入
	r3 := util.GetFloatFromJson(riskParamMap, "r3")
	result["creditDebtMonthlyIncome"] = float64ToStr(r3)
	// 已知信用负债DTI:(信用卡使用额度*10% + 信用贷款总月还)/ 认定月收入
	knownDTI := util.SiSheWuRu(creditDebtMonthlyRepay/r3*100, 1) //小数点后保留1位
	result["knownDTI"] = float64ToStr(knownDTI)
	// 拟批核金额
	r4 := util.GetFloatFromJson(riskParamMap, "r4")
	// 2018.03.08 只看千位的值,然后向下取整
	result["approvalAmount"] = float64ToStr(float64(util.FloorFloat64ToUint64(r4/1000)) / 10)
	// 核定金额
	approvedAmount := util.GetFloatFromJson(riskParamMap, "r28")
	approvedAmount = util.SiSheWuRu(approvedAmount/10000, 1)
	result["approvedAmount"] = float64ToStr(approvedAmount)
	// 已知负债月供(所有贷款总月还)
	//--2018.03.01修改： 已知负债月供=所有贷款月供+已用信用卡*10%
	r24 := util.GetFloatFromJson(riskParamMap, "r24")
	monthlySupply := r24 + used
	//2018.03.08 保留小数点1位
	result["monthly_supply"] = float64ToStr(util.SiSheWuRu(monthlySupply/10000, 1))
	// 负债情况
	// 授信总额
	value := util.GetStrFromJson(riskParamMap, "r9")
	result["totalAmount"] = float64ToStr(str2Float64DivideTenThousand(value))
	// 已用额度
	result["usedAmount"] = float64ToStr(str2Float64DivideTenThousand(usedStr))
	// 2018.03需求，调整负债情况：按照抵押类，信用类(包括信用授信信息)列出
	mArray := getMortgageArray(order)
	getMortgageInfo(mArray, result)
	getTotalCreditInfo(order, result["totalAmount"], result["usedAmount"], result)
	// 雇佣类型
	getHireTypeByJinJianId(order, result)
	fmt.Println(result)
}

// 查询多头借贷信息
func getMultipointsInfo(order *model.ApprovalOrder, result map[string]string) {
	var respJson getMultipointResp
	respResult, err := httpReq.PostJsonProxyNoCheck(map[string]interface{}{"id": order.JinjianId}, global.GetRiskControlServerUrl()+"/api/v1"+"/multipoints/query")
	if err != nil {
		logger.Error("风控查询多头借贷信息返回报错", "err", err.Error())
	}
	// 把响应参数转为json格式
	if err := util.ParseJson(respResult, &respJson); err == nil {
		if len(respJson.Multipoints) > 0 {
			result["multiHeadsLoan"] = fmt.Sprintf("%v", respJson.Multipoints[0].RegisterCount)
		} else {
			result["multiHeadsLoan"] = EmptyDocInfo
		}
	} else {
		result["multiHeadsLoan"] = EmptyDocInfo
	}
}

// 根据身份证号码查询身份证户籍地址
func getPlaceInfoByIdNum(order *model.ApprovalOrder, result map[string]string) {
	placeRespResult, err := httpReq.PostJsonProxyNoCheck(map[string]interface{}{"id_card": order.UserIdNum}, global.GetRiskControlServerUrl()+"/api/v1/uniform_interface/GetIDCardPlace")
	if err != nil {
		logger.Error("风控查询身份证户籍地址返回报错", "err", err.Error())
		result["householdPlace"] = EmptyDocInfo
	}
	// 将返回参数解析为结构体
	var idCardPlace map[string]interface{}
	if err := util.ParseJson(placeRespResult, &idCardPlace); err == nil {
		place := util.GetStrFromJson(idCardPlace, "place")
		if place == "" {
			result["householdPlace"] = EmptyDocInfo
		} else {
			result["householdPlace"] = place
		}
	} else {
		result["householdPlace"] = EmptyDocInfo
	}
}

// 根据身份证号码查询身份证户籍地址
func GetPlaceInfoByIdNum(idCard string) (place string) {
	placeRespResult, err := httpReq.PostJsonProxyNoCheck(map[string]interface{}{"id_card": idCard}, global.GetRiskControlServerUrl()+"/api/v1/uniform_interface/GetIDCardPlace")
	if err != nil {
		logger.Error("风控查询身份证户籍地址返回报错", "err", err.Error())
		return
	}
	// 将返回参数解析为结构体
	var idCardPlace map[string]interface{}
	if err := util.ParseJson(placeRespResult, &idCardPlace); err != nil {
		logger.Error("风控返回的数据转换json失败", "err", err)
		return
	}
	return util.GetStrFromJson(idCardPlace, "place")
}

// 得到雇佣类型
func getHireTypeByJinJianId(order *model.ApprovalOrder, result map[string]string) {
	var threePartyInfo model.ThreePartyInfo
	if err := config.GetDb().Model(&model.ThreePartyInfo{}).Select("user_type").Where("jinjian_id =?",
		order.JinjianId).First(&threePartyInfo).Error; err == nil {
		logger.Info("info", "雇佣类型", threePartyInfo.UserType)
		result["hireType"] = threePartyInfo.UserType
	} else {
		logger.Error("err", "查询雇佣类型出错", err.Error())
		result["hireType"] = EmptyDocInfo
	}
}

// 从新版风险参数得到负债信息
func getBebtInfoByRiskParam(order *model.ApprovalOrder) (debtResult string, count int, err error) {
	var riskParamMap map[string]interface{}
	if err = util.ParseJson(order.RiskParam, &riskParamMap); err != nil {
		logger.Error("err", "将风险参数riskP	aram转json出错", err.Error())
		return
	}
	// 将r15存放的是贷款信息转数组
	debtInfoArray := util.GetArrFromJson(riskParamMap, "r15")
	if len(debtInfoArray) <= 0 {
		return debtResult, 1, nil
	}
	// 循环遍历数组
	for i, debtInfo := range debtInfoArray {
		logger.Info("msg", "debtInfo", debtInfo)
		debt := util.JsonToMap(debtInfo)
		debtType := util.GetStrFromJson(debt, "type")
		contentDataMap := util.GetJsonFromJson(debt, "content")
		// 根据type判断是信用贷款还是按揭贷款
		if strings.Contains(debtType, "CREDIT") {
			if contentDataMap["loanAgency"] != nil && contentDataMap["loanDate"] != nil &&
				contentDataMap["loanAmount"] != nil && contentDataMap["monthlyRepayment"] != nil {
				debtResult += fmt.Sprintf("%d.%v：%v发放信用贷款%v万，月供%v元；", i+1, contentDataMap["loanAgency"], contentDataMap["loanDate"], str2Float64DivideTenThousand(contentDataMap["loanAmount"].(string)), contentDataMap["monthlyRepayment"]) + Newline
			}
		} else {
			if contentDataMap["loanAgency"] != nil && contentDataMap["loanDate"] != nil &&
				contentDataMap["loanAmount"] != nil && contentDataMap["monthlyRepayment"] != nil {
				debtResult += fmt.Sprintf("%d.%v：%v发放按揭贷款%v万，月供%v元；", i+1, contentDataMap["loanAgency"], contentDataMap["loanDate"], str2Float64DivideTenThousand(contentDataMap["loanAmount"].(string)), contentDataMap["monthlyRepayment"]) + Newline
			}
		}
	}
	// 索引累加
	return debtResult, len(debtInfoArray) + 1, nil
}

// 得到所有抵押贷款数组信息
func getMortgageArray(order *model.ApprovalOrder) (array []interface{}) {
	var riskParamMap map[string]interface{}
	if err := util.ParseJson(order.RiskParam, &riskParamMap); err != nil {
		logger.Error("err", "将风险参数riskP	aram转json出错", err.Error())
		return
	}
	// 将r15存放的是贷款信息转数组
	debtInfoArray := util.GetArrFromJson(riskParamMap, "r15")
	if len(debtInfoArray) <= 0 {
		return nil
	}

	for _, debtInfo := range debtInfoArray {
		logger.Info("msg", "debtInfo", debtInfo)
		debt := util.JsonToMap(debtInfo)
		debtType := util.GetStrFromJson(debt, "type")
		// 根据type判断是信用贷款还是按揭贷款
		if strings.Contains(debtType, "MORTGAGE") {
			array = append(array, debtInfo)
		}
	}
	return
}

// 得到抵押贷款信息
func getMortgageInfo(mArray []interface{}, result map[string]string) (err error) {
	var mResult string
	if len(mArray) <= 0 {
		result["mortgage"] = EmptyInfo
		return nil
	}
	for i, mInfo := range mArray {
		debt := util.JsonToMap(mInfo)
		contentDataMap := util.GetJsonFromJson(debt, "content")
		if contentDataMap["loanAgency"] != nil && contentDataMap["loanDate"] != nil &&
			contentDataMap["loanAmount"] != nil && contentDataMap["monthlyRepayment"] != nil {
			mResult += fmt.Sprintf("%d.%v：%v发放抵押贷款%v万，月供%v元；", i+1, contentDataMap["loanAgency"], contentDataMap["loanDate"], str2Float64DivideTenThousand(contentDataMap["loanAmount"].(string)), contentDataMap["monthlyRepayment"]) + Newline
		}
	}
	if mResult == "" {
		result["mortgage"] = EmptyInfo
	} else {
		result["mortgage"] = mResult
	}
	logger.Info("msg", "所有抵押贷款信息", result["mortgage"])
	return nil
}

func getTotalCreditInfo(order *model.ApprovalOrder, totalAmount, usedAmount string, result map[string]string) {
	array := getCreditArray(order)
	if _, count, err := getCreditInfo(array, result); err == nil {
		result["total"] = fmt.Sprintf("%d.信用卡：授信总额%v万，已用额度%v万；", count, totalAmount, usedAmount)
	} else {
		result["total"] = EmptyDocInfo
	}
}

// 得到所有信用贷款数组信息
func getCreditArray(order *model.ApprovalOrder) (array []interface{}) {
	var riskParamMap map[string]interface{}
	if err := util.ParseJson(order.RiskParam, &riskParamMap); err != nil {
		logger.Error("err", "将风险参数riskP	aram转json出错", err.Error())
		return
	}
	// 将r15存放的是贷款信息转数组
	debtInfoArray := util.GetArrFromJson(riskParamMap, "r15")
	if len(debtInfoArray) <= 0 {
		return nil
	}

	for _, debtInfo := range debtInfoArray {
		logger.Info("msg", "debtInfo", debtInfo)
		debt := util.JsonToMap(debtInfo)
		debtType := util.GetStrFromJson(debt, "type")
		// 根据type判断是信用贷款还是按揭贷款
		if strings.Contains(debtType, "CREDIT") {
			array = append(array, debtInfo)
		}
	}
	return
}

// 得到信用贷款信息
func getCreditInfo(creditArray []interface{}, result map[string]string) (creditResult string, count int, err error) {
	if len(creditArray) <= 0 {
		result["creditStr"] = EmptyInfo
		return creditResult, 1, nil
	}
	for i, mInfo := range creditArray {
		debt := util.JsonToMap(mInfo)
		contentDataMap := util.GetJsonFromJson(debt, "content")
		if contentDataMap["loanAgency"] != nil && contentDataMap["loanDate"] != nil &&
			contentDataMap["loanAmount"] != nil && contentDataMap["monthlyRepayment"] != nil {
			creditResult += fmt.Sprintf("%d.%v：%v发放信用贷款%v万，月供%v元；", i+1, contentDataMap["loanAgency"], contentDataMap["loanDate"], str2Float64DivideTenThousand(contentDataMap["loanAmount"].(string)), contentDataMap["monthlyRepayment"]) + Newline
		}
	}
	if creditResult == "" {
		result["creditStr"] = EmptyInfo
	} else {
		result["creditStr"] = creditResult
	}
	logger.Info("msg", "所有信用贷款信息", result["creditStr"])

	return creditResult, len(creditArray) + 1, nil
}

// 根据风险参数得到申请方案来生成简报
func GetProductPlanByRiskParamSimpleReport(order *model.ApprovalOrder, result map[string]string) {
	var riskParamMap map[string]interface{}
	//  解析RiskParam为json
	if err := util.ParseJson(order.RiskParam, &riskParamMap); err != nil {
		logger.Error("err", "将风险参数riskP	aram转json出错----简报申请方案----", err.Error())
		return
	}
	// 将riskParamMap转为结构体
	productPlanStruct := util.GetMapToInterface(riskParamMap, "r2")
	// 判断结构体类型
	switch productPlanStruct.(type) {
	case []interface{}:
		// 数组类型---强转为interface数组---循环遍历
		for i, planStruct := range productPlanStruct.([]interface{}) {
			productPlanInfo := util.JsonToMap(planStruct)
			// 得到结构体里面的Name
			name := util.GetStrFromJson(productPlanInfo, "name")
			// 得到json结构体里面的content
			contentJson := util.GetJsonFromJson(productPlanInfo, "content")
			// 将json里面的content转为结构体
			contentMap := util.JsonToMap(contentJson)
			// 2018.03新需求：要区分是房产贷还是月供贷
			// 房产贷，直接得到房产估值
			var supplyAmount string
			if strings.Contains(name, "房产") {
				supplyAmount = float64ToStr(util.GetFloatFromJson(contentMap, "house_valuation"))
				result["productPlan"] += fmt.Sprintf("%d.%v 房产估值%v元;"+Newline, i+1, name, supplyAmount)
			} else {
				// 月供贷:需要得到放款金额与月还金额
				supplyAmount = util.GetStrFromJson(contentMap, "monthly_supply_amount")
				leadingAmount := util.GetStrFromJson(contentMap, "lending_amount")
				result["productPlan"] += fmt.Sprintf("%d.%v 放款金额%v元， 月还%v元;"+Newline, i+1, name, leadingAmount, supplyAmount)
			}
		}
	case interface{}:
		// interface类型---强转为结构体
		productPlanMap := util.JsonToMap(productPlanStruct)
		name := util.GetStrFromJson(productPlanMap, "name")
		// policyList结构体
		policyListStruct := util.GetMapToInterface(productPlanMap, "policyList")
		// 用来汇总年缴保费
		var yearTotalAmount float64
		for _, policyStruct := range policyListStruct.([]interface{}) {
			policyInfo := util.JsonToMap(policyStruct)
			// 2018.03新需求，需要按照缴费方式计算
			// 得到缴费方式
			payType := util.GetStrFromJson(policyInfo, "payment_method")
			// 得到policyList结构体里面的policy_amount
			//2018.03.01不用除以10000
			policyAmount := strToFloat(util.GetStrFromJson(policyInfo, "policy_amount"))
			amount := getPayAmountByType(payType, policyAmount)
			// 每个保单贷年缴费用累加
			yearTotalAmount += amount
		}
		result["productPlan"] = fmt.Sprintf("%v 汇总年缴保费%v元;"+Newline, name, util.SiSheWuRu(yearTotalAmount, 2))

	}
}

/**
2018.03需求，
如果缴费方式是月缴，应该12×policy_amount
季缴：3×policy_amount
年缴：policy_amount
 */
// 根据缴费方式得到年缴金额
func getPayAmountByType(payType string, amount float64) (result float64) {
	switch payType {
	case Year:
		result = amount
	case Quarter:
		result = amount * 4
	case Month:
		result = amount * 12
	}
	return
}

// 获取审批时间记录
func GetTimeRecord(jinjianId, keyType string) []model.ApprovalTimeRecord {
	var atrList []model.ApprovalTimeRecord
	if keyType == "" {
		if err := config.GetDb().Model(&model.ApprovalTimeRecord{}).Where("jinjian_id = ?", jinjianId).
			Order("created_at desc").Debug().Find(&atrList).Error; err != nil {
			logger.Error("查询ApprovalTimeRecord错误", "err", err.Error())
		}
		return atrList
	}

	if err := config.GetDb().Model(&model.ApprovalTimeRecord{}).Where("jinjian_id = ? AND time_record_type = ?",
		jinjianId, keyType).
		Order("created_at desc").Limit(200).Find(&atrList).Error; err != nil {
		logger.Error("查询ApprovalTimeRecord错误", "err", err.Error())
	}
	return atrList
}

//  匹配时间
func AoTimeStatistics(jinjianId string) map[string]interface{} {
	result := map[string]interface{}{}
	result["jinjian"] = timeStatisticsByType(jinjianId, model.TP_JINJIAN)
	result["user_input"] = timeStatisticsByType(jinjianId, model.TP_USERINPUT)
	result["inter_view_grab"] = timeStatisticsByType(jinjianId, model.TP_GRAB_IV)
	result["inter_view"] = timeStatisticsByType(jinjianId, model.TP_INTERVIEW)
	result["cs_grab"] = timeStatisticsByType(jinjianId, model.TP_GRAB_CS)
	result["cs"] = timeStatisticsByType(jinjianId, model.TP_CS)
	result["zs_grab"] = timeStatisticsByType(jinjianId, model.TP_GRAB_ZS)
	result["zs"] = timeStatisticsByType(jinjianId, model.TP_ZS)
	result["zs_upload_contract"] = timeStatisticsByType(jinjianId, model.TP_UPLOADC)
	result["kf_grab"] = timeStatisticsByType(jinjianId, model.TP_GRAB_KF)
	result["kf"] = timeStatisticsByType(jinjianId, model.TP_KF)
	result["cw"] = timeStatisticsByType(jinjianId, model.TP_CW)
	result["cs_back_iv"] = timeStatisticsByType(jinjianId, model.TP_CS_BACK_IV)
	result["zs_back_iv"] = timeStatisticsByType(jinjianId, model.TP_ZS_BACK_IV)

	return result
}

// 按操作类型做各个环节耗时统计
//func timeStatisticsByType(jinjianId string, keyType string) map[string]interface{} {
//	atrList := GetTimeRecord(jinjianId, keyType)
//	var result map[string]interface{}
//
//	if len(atrList) > 0 && len(atrList)%2 == 0 {
//		var startTime time.Time
//		var endTime time.Time
//		var sumTime time.Duration
//		for i, atr := range atrList {
//			i = i + 1
//			if i%2 != 0 {
//				endTime = *atr.TimePoint
//			} else {
//				startTime = *atr.TimePoint
//				// 统计时间
//				sumTime = sumTime + endTime.Sub(startTime)
//			}
//		}
//		r := sumTime.String()
//		result = make(map[string]interface{})
//		result["total_time"] = r
//		result["time_list"] = atrList
//	}
//	return result
//}

// 按操作类型做各个环节工作时间耗时统计 - 非工作时间如午休,下班后,周末,法定节假日不参与统计
func timeStatisticsByType(jinjianId string, keyType string) map[string]interface{} {
	atrList := GetTimeRecord(jinjianId, keyType)
	var result map[string]interface{}

	if len(atrList) > 0 && len(atrList)%2 == 0 {
		var startTime time.Time
		var endTime time.Time
		var sumTime time.Duration
		var sumWorkTime time.Duration
		for i, atr := range atrList {
			i = i + 1
			if i%2 != 0 {
				endTime = *atr.TimePoint
			} else {
				startTime = *atr.TimePoint
				// 统计时间
				sumTime += endTime.Sub(startTime)
				sumWorkTime += SumTimeWithOutWorkTime(startTime, endTime)
			}
		}
		r := sumTime.String()
		rWork := sumWorkTime.String()
		result = make(map[string]interface{})
		result["total_time"] = r
		result["total_work_time"] = rWork
		result["time_list"] = atrList
	}
	return result
}

// 按操作类型做各个环节工作时间耗时统计 - 非工作时间如午休,下班后,周末,法定节假日不参与统计
func workTimeStatisticsByType(jinjianId string, keyType string) map[string]interface{} {
	atrList := GetTimeRecord(jinjianId, keyType)
	var result map[string]interface{}

	if len(atrList) > 0 && len(atrList)%2 == 0 {
		var startTime time.Time
		var endTime time.Time
		var sumTime time.Duration
		var sumWorkTime time.Duration
		for i, atr := range atrList {
			i = i + 1
			if i%2 != 0 {
				endTime = *atr.TimePoint
			} else {
				startTime = *atr.TimePoint
				// 统计时间
				sumTime += endTime.Sub(startTime)
				sumWorkTime += SumTimeWithOutWorkTime(startTime, endTime)
			}
		}
		r := sumTime.String()
		rWork := sumWorkTime.String()
		result = make(map[string]interface{})
		result["total_time"] = r
		result["total_work_time"] = rWork
		result["time_list"] = atrList
	}
	return result
}

// 非工作时间如午休,下班后,周末,法定节假日不参与统计
func SumTimeWithOutWorkTime(startTime time.Time, endTime time.Time) time.Duration {
	var sumDuration time.Duration
	aDay := time.Hour * 24
	am0900 := time.Hour * 9
	pm1200 := time.Hour * 12
	lunchTime := time.Hour*1 + time.Minute*30
	pm0130 := time.Hour*13 + time.Minute*30
	pm0630 := time.Hour*18 + time.Minute*30

	// 预操作:确保开始时间小于结束时间
	if startTime.After(endTime) {
		startTime, endTime = endTime, startTime
	}

	// 预操作:调整开始时间到工作时区之内
	if ok, _ := holidaycheck.IsWorkDay(startTime); ok {
		// 当前开始时间是工作日则将判断是否在工作时内,如果不在向后取到最接近的工作时内
		switch {
		case startTime.Before(TimePoint(startTime, am0900)): // 早上九点前 -> am0900
			startTime = TimePoint(startTime, am0900)
		case !(startTime.Before(TimePoint(startTime, pm1200))) && startTime.Before(TimePoint(startTime, pm0130)): // 午休时间 -> pm0130
			startTime = TimePoint(startTime, pm0130)
		case !(startTime.Before(TimePoint(startTime, pm0630))): // 下午六点半后 -> 次日am0900
			startTime = TimePoint(startTime.Add(aDay), am0900)
		}
	} else {
		for {
			startTime = TimePoint(startTime.Add(aDay), am0900) // 非工作日 -> 次日am0900
			if ok, _ := holidaycheck.IsWorkDay(startTime); ok {
				break
			}
		}
	}

	//预操作:调整结束时间到工作时区之内
	if ok, _ := holidaycheck.IsWorkDay(endTime); ok {
		// 当前结束时间是工作日则将判断是否在工作时内,如果不在向前取到最接近的工作时内
		switch {
		case !(endTime.After(TimePoint(endTime, am0900))): // 早上九点前 -> 前日pm0630
			endTime = TimePoint(endTime.Add(-aDay), pm0630)
		case endTime.After(TimePoint(endTime, pm1200)) && !(endTime.After(TimePoint(endTime, pm0130))): // 午休时间 -> pm1200
			endTime = TimePoint(endTime, pm1200)
		case endTime.After(TimePoint(endTime, pm0630)): // 下午六点半后 -> pm0630
			endTime = TimePoint(endTime, pm0630)
		}
	} else {
		for {
			endTime = TimePoint(endTime.Add(-aDay), pm0630) // 非工作日 -> 前日pm0630
			if ok, _ := holidaycheck.IsWorkDay(endTime); ok {
				break
			}
		}
	}

	// 筛选掉调整后的开始时间小于等于结束时间的情况
	if startTime.After(endTime) || startTime.Equal(endTime) {
		return 0
	}

	// 从开始时间起,累加工作时耗时
	for {
		if startTime.Year() == endTime.Year() && startTime.Month() == endTime.Month() && startTime.Day() == endTime.Day() {
			break // 当开始时间与结束时间在同一天时跳出循环
		}
		if ok, _ := holidaycheck.IsWorkDay(endTime); ok {
			if startTime.Hour() <= 12 { // 开始时间在中午12点前则减去午休时间
				sumDuration -= lunchTime
			}
			sumDuration += TimePoint(startTime, pm0630).Sub(startTime) // 累加当天开始时间到下班时间之间的时长
		}
		startTime = TimePoint(startTime.Add(aDay), am0900)
	}

	//if startTime.Before(TimePoint(startTime, pm1200)) && endTime.After(TimePoint(endTime, pm0130)) { // 存在等于情况,会有bug
	if !(startTime.After(TimePoint(startTime, pm1200))) && !(endTime.Before(TimePoint(endTime, pm0130))) { // (a<=b) && (c>=d) 等价于 !(a>b) && !(c<d)
		sumDuration -= lunchTime
	}
	sumDuration += endTime.Sub(startTime)

	return sumDuration
}

func TimePoint(t time.Time, d time.Duration) time.Time {
	return t.Truncate(time.Hour * 24).Add(d)
}

// 工作单位和联系人结构体
type ContactsResp struct {
	http.BaseResp
	Company     string   `json:"company"`
	LinkerNames []string `json:"linker_names"`
}

// 查询联系人姓名和进件人工作单位，传入进件id返回json格式的联系人姓名，工作单位.
func QueryCompanyAndContactName(jinJianId string) (resp *ContactsResp, err error) {
	var ao model.ApprovalOrder
	// 根据前端传入的进件id查询ApprovalOrder
	if err = config.GetDb().Model(&model.ApprovalOrder{}).Where("jinjian_id=?", jinJianId).First(&ao).Error; err != nil {
		logger.Info("msg", "审批订单查询失败", err.Error())
		return
	}

	var allInfo map[string]interface{}
	if err = util.ParseJson(ao.AllInfo, &allInfo); err != nil {
		logger.Error("没有all_info", "err", err.Error())
		return
	}

	linkerNames := []string{}
	// 主要联系人
	if primaryName, ok := allInfo["contacts"].(map[string]interface{})["primaryName"].(string); ok {
		linkerNames = append(linkerNames, primaryName)
	}
	// 次要联系人
	if secondaryName, ok := allInfo["contacts"].(map[string]interface{})["secondaryName"].(string); ok {
		linkerNames = append(linkerNames, secondaryName)
	}
	logger.Info("msg", "linkerNames", linkerNames)

	resp = &ContactsResp{LinkerNames: linkerNames}
	resp.Success = true

	// 工作单位
	if company, ok := allInfo["personal_info"].(map[string]interface{})["workplace"].(string); ok {
		resp.Company = company
	}
	//resp.Company = allInfo["personal_info"].(map[string]interface{})["workplace"].(string)

	return
}

// 自动生成客户封面
func AutoGenerateCustomerCover(jinJianId string) (result map[string]string, err error) {
	var ao model.ApprovalOrder
	// 根据前端传入的进件id查询ApprovalOrder
	if err = config.GetDb().Model(&model.ApprovalOrder{}).Where("jinjian_id =?", jinJianId).First(&ao).Error; err != nil {
		return
	}
	result = map[string]string{}
	// 基本信息
	getBasicInfoByOrder(&ao, result)
	// 性别 --从量化变量取得
	var quantizationMap map[string]interface{}
	if err := util.ParseJson(ao.QuantizationMap, &quantizationMap); err == nil {
		result["sex"] = util.GetStrFromJson(quantizationMap, "CIPB006")
	}
	// 申请产品
	plan := getPlanByRiskParamForCover(&ao, result)
	result["productPlan"] = strings.TrimRight(plan, "、")
	return
}

// 客户封面基本信息
func getBasicInfoByOrder(order *model.ApprovalOrder, result map[string]string) {
	// 资金方
	result["funSide"] = order.FundSide
	// 客户姓名
	result["userName"] = order.JinjianUserName
	// 编号
	result["TSid"] = order.ShowId
	result["showId"] = order.ShowId
	// 申请日期
	result["applyDate"] = order.CreatedAt.Format("2006-01-02")
	// 手机号
	result["cellphone"] = order.Cellphone
	// 进件渠道
	result["agencyName"] = order.AgencyName
	// 初审
	result["firstTrailName"] = order.FirstTrailName

}

// 审批开关控制面签历史订单上传资料
func UpdateApprovalInterviewSwitch(interviewSwitch, jinJianId string) (err error) {
	if err = config.GetDb().Model(&model.ApprovalOrder{}).Where("jinjian_id = ?", jinJianId).Update("interview_switch", interviewSwitch).Error; err != nil {
		logger.Error("msg", "修改面签补录开关失败", err.Error())
		return
	}
	return
}

// 根据风险参数得到产品方案---客户封面
func getPlanByRiskParamForCover(order *model.ApprovalOrder, result map[string]string) (plan string) {
	var riskParamMap map[string]interface{}
	if err := util.ParseJson(order.RiskParam, &riskParamMap); err != nil {
		logger.Error("msg", "客户封面------将风险参数里面的产品方案转json出错----", err.Error())
		return
	}
	// 将riskParamMap转为结构体
	productPlanStruct := util.GetMapToInterface(riskParamMap, "r2")
	// 判断结构体类型
	switch productPlanStruct.(type) {
	case []interface{}:
		// 数组类型---强转为interface数组---循环遍历
		for _, planStruct := range productPlanStruct.([]interface{}) {
			productPlanInfo := util.JsonToMap(planStruct)
			// 得到结构体里面的Name
			plan = util.GetStrFromJson(productPlanInfo, "name")
			break
			//plan += fmt.Sprintf("%v、", name)
		}
	case interface{}:
		// interface类型---强转为结构体
		productPlanMap := util.JsonToMap(productPlanStruct)
		plan = util.GetStrFromJson(productPlanMap, "name")
		break
		//plan += fmt.Sprintf("%v", name)
	}
	return
}

// 将float64转string
func float64ToStr(value float64) string {
	return strconv.FormatFloat(value, 'f', -1, 64)
}

// 将string转float64,再将float64/10000
func str2Float64DivideTenThousand(key string) (result float64) {
	if key == "" {
		return 0
	} else {
		if value, passErr := strconv.ParseFloat(key, 64); passErr == nil {
			//return value / 10000
			return util.SiSheWuRu(value/10000, 1)
		} else {
			return 0
		}
	}
}

// 将str转float64
func strToFloat(key string) (value float64) {
	if key == "" {
		return 0
	}

	if value, passErr := strconv.ParseFloat(key, 64); passErr == nil {
		return value
	} else {
		return 0
	}

}

//// 订单概括统计
//func StatisticOrderCount(trailType, agencyName string) (info *model.OrderGeneralization) {
//	return queryOrderCount(trailType, agencyName)
//}
//
//// 查询订单数量
//func queryOrderCount(approvalType, agencyName string) (info *model.OrderGeneralization) {
//	baseSql := config.GetDb().Model(&model.PreApprovalOrder{})
//	switch approvalType {
//	case "cs":
//		// 待办订单
//		if allErr := baseSql.Where("first_trail_status = ? ", model.ApprovalStatusWaitFirstTrail).Count(&info.ToBeAssignCount).Error; allErr != nil {
//			logger.Error("err", "查询[初审][所有待办订单出错]", allErr.Error())
//		}
//		// 我的待办订单
//		if myTodoErr := baseSql.Where("first_trail_status = ? AND first_trail_id = ? ", model.ApprovalStatusWaitFirstTrail, agencyName).Error; myTodoErr != nil {
//			logger.Error("err", "查询[初审][我的待办订单出错]", myTodoErr.Error())
//		}
//		// 挂起订单
//		if suspendErr := baseSql.Where("suspending = ? AND first_trail_id = ? ", model.Suspend, agencyName).Count(&info.SuspendCount).Error; suspendErr != nil {
//			logger.Error("err", "查询[初审][挂起订单出错]", suspendErr.Error())
//		}
//		// 回退订单
//		if returnErr := baseSql.Where("first_trail_status = ? AND first_trail_id = ? ", model.ApprovalStatusReTrailBack, agencyName).Count(&info.ReturnCount).Error; returnErr != nil {
//			logger.Error("err", "查询[初审][回退订单出错]", returnErr.Error())
//		}
//	case "zs":
//
//		// 待办订单
//		if allErr := baseSql.Where("retrail_status = ? ", model.ApprovalStatusWaitReTrail).Count(&info.ToBeAssignCount).Error; allErr != nil {
//			logger.Error("err", "查询[终审][所有待办订单出错]", allErr.Error())
//		}
//		// 我的待办订单
//		if myTodoErr := baseSql.Where("retrail_status = ? AND retrail_id = ? ", model.ApprovalStatusWaitReTrail, agencyName).Error; myTodoErr != nil {
//			logger.Error("err", "查询[终审][我的待办订单出错]", myTodoErr.Error())
//		}
//		// 挂起订单
//		if suspendErr := baseSql.Where("suspending = ? AND retrail_id = ? ", model.Suspend, agencyName).Count(&info.SuspendCount).Error; suspendErr != nil {
//			logger.Error("err", "查询[终审][挂起订单出错]", suspendErr.Error())
//		}
//		// 回退订单
//		if returnErr := baseSql.Where("retrail_status = ? AND retrail_id = ? ", model.ApprovalStatusCustomServiceBack, agencyName).Count(&info.ReturnCount).Error; returnErr != nil {
//			logger.Error("err", "查询[终审][回退订单出错]", returnErr.Error())
//		}
//	case "kf":
//		// 待办订单
//		if allErr := baseSql.Where("custom_service_status = ? ", model.ApprovalStatusWaitCustomConfirm).Count(&info.ToBeAssignCount).Error; allErr != nil {
//			logger.Error("err", "查询[客服][所有待办订单出错]", allErr.Error())
//		}
//		// 我的待办订单
//		if myTodoErr := baseSql.Where("custom_service_status = ? AND custom_service_id = ? ", model.ApprovalStatusWaitCustomConfirm, agencyName).Error; myTodoErr != nil {
//			logger.Error("err", "查询[客服][我的待办订单出错]", myTodoErr.Error())
//		}
//		// 挂起订单
//		if suspendErr := baseSql.Where("suspending = ? AND custom_service_id = ? ", model.Suspend, agencyName).Count(&info.SuspendCount).Error; suspendErr != nil {
//			logger.Error("err", "查询[客服][挂起订单出错]", suspendErr.Error())
//		}
//	default:
//		logger.Error("msg", "err", "传入的审批状态有误")
//	}
//	return
//}
