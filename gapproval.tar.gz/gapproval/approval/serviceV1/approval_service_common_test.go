package serviceV1

import (
	"gapproval/approval/model"
	"fmt"
	"gcoresys/common/util"
	"gapproval/approval/db/config"
	"time"
	"testing"
	"github.com/stretchr/testify/assert"
	"gapproval/approval/service"
)

func (s *testingSuite) TestGetApprovalOrder() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	r, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal(true, r.ID != 0)
}

func (s *testingSuite) TestIsSelectAll() {
	username1, name1 := isSelectAll("", "", "all")
	s.Equal("Null", username1)
	s.Equal("Null", name1)
	username2, name2 := isSelectAll("xi", "xx", "me")
	s.Equal("xi", username2)
	s.Equal("xx", name2)
}

func (s *testingSuite) TestGrabApprovalOrder() {
	s.newApprovalOrders(10)
	s.NoError(GrabApprovalOrder("cs", &model.ApprovalOrder{FirstTrailId: "cs001", FirstTrailName: "初审001"},
		"cs001", "初审001"))
	aoList1, tp1, _ := GetFirstTrailApprovalOrderList("me", "",
		"cs001", "初审001", "", "", 1)
	s.Equal(true, tp1 > 0)
	s.Equal(true, len(aoList1) == 1)
	s.NoError(GrabApprovalOrder("cs", &model.ApprovalOrder{FirstTrailId: "cs001", FirstTrailName: "初审001"},
		"cs001", "初审001"))
	s.NoError(GrabApprovalOrder("cs", &model.ApprovalOrder{FirstTrailId: "cs001", FirstTrailName: "初审001"},
		"cs001", "初审001"))
	s.NoError(GrabApprovalOrder("cs", &model.ApprovalOrder{FirstTrailId: "cs001", FirstTrailName: "初审001"},
		"cs001", "初审001"))
	s.NoError(GrabApprovalOrder("cs", &model.ApprovalOrder{FirstTrailId: "cs001", FirstTrailName: "初审001"},
		"cs001", "初审001"))
	s.NoError(GrabApprovalOrder("cs", &model.ApprovalOrder{FirstTrailId: "cs001", FirstTrailName: "初审001"},
		"cs001", "初审001"))
	s.NoError(GrabApprovalOrder("cs", &model.ApprovalOrder{FirstTrailId: "cs001", FirstTrailName: "初审001"},
		"cs001", "初审001"))
	s.NoError(GrabApprovalOrder("cs", &model.ApprovalOrder{FirstTrailId: "cs001", FirstTrailName: "初审001"},
		"cs001", "初审001"))
	s.NoError(GrabApprovalOrder("cs", &model.ApprovalOrder{FirstTrailId: "cs001", FirstTrailName: "初审001"},
		"cs001", "初审001"))
	s.NoError(GrabApprovalOrder("cs", &model.ApprovalOrder{FirstTrailId: "cs001", FirstTrailName: "初审001"},
		"cs001", "初审001"))
	aoList2, tp2, _ := GetFirstTrailApprovalOrderList("me", "",
		"cs001", "初审001", "", "", 1)
	s.Equal(true, tp2 > 0)
	s.Equal(true, len(aoList2) == 10)

	//s.EqualError(GrabApprovalOrder("cs", &model.ApprovalOrder{FirstTrailId: "cs001", FirstTrailName: "初审001"},
	//	"cs001", "初审001"), "你的审批单数量已经达到10个，无法再添加审批单啦")
}

func (s *testingSuite) TestAddPayCard() {
	ao := model.GetDefaultApprovalOrder()

	ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
	ao.InterView = `{"s":"sss"}`

	s.NoError(NewApprovalOrder(ao))
	s.NoError(GrabApprovalOrder("cs", &model.ApprovalOrder{FirstTrailId: "cs001", FirstTrailName: "初审001"},
		"cs001", "初审001"))
	s.NoError(AddPayCard(ao.JinjianId, "中国银行", "123123123123", "1321321312321"))
	s.NoError(AddPayCard(ao.JinjianId, "中国工商银行", "15464123123123", "1321321312321"))
	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal(true, len(aR.PayCardList) > 0)
	fmt.Println(aR.PayCardList)

}

func (s *testingSuite) TestNewApprovalCsResult() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	csResult := model.GetDefaultApprovalCsResult()
	csResult.ApprovalId = ao.ID
	s.NoError(NewApprovalCsResult(csResult))
}

func (s *testingSuite) TestGetApprovalCsResult() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	csResult := model.GetDefaultApprovalCsResult()
	csResult.ApprovalId = ao.ID
	s.NoError(NewApprovalCsResult(csResult))
	csR := GetApprovalCsResult(ao.ID)
	s.NotNil(csR)
}

func (s *testingSuite) TestUploadApprovalFile() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	s.NoError(UploadApprovalFile(&model.ApprovalUploadFile{JinjianId: ao.JinjianId, FileName: "hhaha",
		FileUrl: "dsfsdfs", FileType: model.FT_DIANHE}))
	s.NoError(UploadApprovalFile(&model.ApprovalUploadFile{JinjianId: ao.JinjianId, FileName: "bbbbb",
		FileUrl: "dfdfsfds", FileType: model.FT_DIANHE}))
}

func (s *testingSuite) TestGetApprovalFile() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	s.NoError(UploadApprovalFile(&model.ApprovalUploadFile{JinjianId: ao.JinjianId, FileName: "hhaha",
		FileUrl: "dsfsdfs", FileType: model.FT_DIANHE}))
	s.NoError(UploadApprovalFile(&model.ApprovalUploadFile{JinjianId: ao.JinjianId, FileName: "bbbbb",
		FileUrl: "dfdfsfds", FileType: model.FT_DIANHE}))
	files := GetApprovalFile(ao.JinjianId, model.FT_DIANHE)
	s.Equal(2, len(files))
	s.Equal("bbbbb", files[0].FileName)
}

func (s *testingSuite) TestGetApprovalOrder1() {
	s.newApprovalOrders(10)
	s.NoError(GrabApprovalOrder("cs", &model.ApprovalOrder{FirstTrailId: "cs001", FirstTrailName: "初审001"},
		"cs001", "初审001"))
	aoList1, tp1, _ := GetFirstTrailApprovalOrderList("me", "",
		"cs001", "初审001", "", "", 1)
	s.Equal(true, tp1 > 0)
	s.Equal(true, len(aoList1) == 1)
	aR, _, err := GetApprovalOrder(aoList1[0].JinjianId)
	s.NoError(err)
	s.Equal("cs001", aR.FirstTrailId)
	s.Equal("初审001", aR.FirstTrailName)
}

func (s *testingSuite) TestApprovalSuspending() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	s.NoError(ApprovalSuspending(ao.JinjianId, "", "ddd", "cs"))
}

func (s *testingSuite) TestApprovalSuspending1() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	s.EqualError(ApprovalSuspending(ao.JinjianId, "", "", "cs"), "挂起原因不能为空")
}

func (s *testingSuite) TestApprovalSuspending2() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	s.EqualError(ApprovalSuspending(ao.JinjianId, "", "fdf", ""), "挂起操作类型出错，请检查approvalType")
}

func (s *testingSuite) TestApprovalSuspending3() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	s.NoError(ApprovalSuspending(ao.JinjianId, "", "ddd", "cs"))
	r, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	fmt.Println(r.Suspending)
	s.Equal(true, r.Suspending == "off")
}

func (s *testingSuite) TestGetApprovalLog() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	s.NoError(ApprovalSuspending(ao.JinjianId, "", "ddd", "cs"))
	log := GetApprovalLog(ao.JinjianId, "cs")
	s.Equal(2, len(log))
}

func (s *testingSuite) TestMapC() {
	allInfo := map[string]interface{}{"personal_info": map[string]interface{}{"workplacde": "sdfdsfds"}}
	if w, ok := allInfo["personal_info"].(map[string]interface{})["workplace"].(string); ok {
		fmt.Println(w)
	}
}

func (s *testingSuite) TestExchange() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	s.NoError(NewApprovalOrder(ao))
	aR1, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(exchange(aR1, &model.ApprovalOrder{FirstTrailName: "初审002", FirstTrailId: "cs002"}, "cs"))
	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal("cs002", aR.FirstTrailId)
	s.Equal("初审002", aR.FirstTrailName)
}

func (s *testingSuite) TestCancel() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	s.NoError(NewApprovalOrder(ao))
	aR1, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(cancel(aR1, &model.ApprovalOrder{FirstTrailStatus: model.ApprovalStatusCustomCancel, FirstTrailStatusDes: "fdsf"}, "cs"))
	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal(model.ApprovalStatusCustomCancel, aR.FirstTrailStatus)
}

func (s *testingSuite) TestGetAoListByJinjianArray() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	s.NoError(NewApprovalOrder(ao))
	ao1 := model.GetDefaultApprovalOrder()
	ao1.JinjianId = "S_4443342423"
	s.NoError(NewApprovalOrder(ao1))
	list, err := GetAoListByJinjianArray([]string{ao.JinjianId, ao1.JinjianId})
	s.NoError(err)
	s.Equal(2, len(list))

	fmt.Println(util.StringifyJson(list[0]))

}

func TestGenerateApprovalReport(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		if err := config.GetDb().Create(ao).Error; err != nil {
			panic(err.Error())
		}
		result, err := GenerateApprovalReport(ao.JinjianId)
		assert.NoError(t, err)
		fmt.Println(util.StringifyJson(result))
		assert.Equal(t, "345", result["houseEstate"])
		assert.Equal(t, "3.7", result["monthly_supply"])
	})

}

func (s *testingSuite) TestAutoGenerateCustomerCover() {
	ao := model.GetDefaultApprovalOrder()
	ao.FundSide = model.MrOnionFundSide
	if err := config.GetDb().Create(ao).Error; err != nil {
		panic(err.Error())
	}
	result, err := AutoGenerateCustomerCover(ao.JinjianId)
	s.NoError(err)
	fmt.Println(util.StringifyJson(result))
	s.Equal(model.MrOnionFundSide, result["funSide"])
	s.Equal("S_qy20180313002", result["TSid"])
}

// 测试联系人信息
func (s *testingSuite) TestLinkersInfo() {
	ao := model.GetDefaultApprovalOrder()
	s.NoError(NewApprovalOrder(ao))
	resp, err := QueryCompanyAndContactName(ao.JinjianId)
	fmt.Println(util.StringifyJson(resp))
	s.NoError(err)

}

func (s *testingSuite) TestAsyncApprovalTimeRecord() {
	service.AsyncApprovalTimeRecord("tttt0111", model.TP_JINJIAN, model.TP_JINJIAN, model.TP_INTERVIEW, model.TP_INTERVIEW)
	time.Sleep(3 * time.Second)
	list := GetTimeRecord("tttt0111", "")
	s.Equal(4, len(list))
}

func (s *testingSuite) TestCheckUserQv() {
	pao := model.GetDefaultPreApprovalOrder()
	pao.QuantizationMap = `
{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`

	pao.QuantizationCache = `
{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`

	pao.QuantizationPoint = 400
	pao.QuantizationLevel = 5
	s.NoError(service.CreatePreApproval(pao))
	s.NoError(GrabPreApproval("test001", "测试001"))
	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	s.Equal("test001", paoR.PreTrailId)
	s.Equal("测试001", paoR.PreTrailName)
	s.NotNil(paoR.StartTime)
	s.Equal(model.PREAPPROVALING, paoR.PreApprovalStatus)
	// 拒绝
	s.NoError(PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: pao.PreApprovalID,
		PreApprovalStatus: model.PREAPPROVALREFUSE, OpDesc: "sss",RefuseReason:"123",ExternalReason:"123"}))

	paoR1, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.NotNil(paoR1.RefuseTime)
	s.Equal(model.PREAPPROVALREFUSE, paoR1.PreApprovalStatus)

	result := CheckUserQv(pao.UserIdNum)

	s.Equal(1, len(result.PaoList))

}

func (s *testingSuite) TestTimeStatisticsByType() {
	service.AsyncApprovalTimeRecord("tttt0111", model.TP_GRAB_IV)
	time.Sleep(5 * time.Second)
	service.AsyncApprovalTimeRecord("tttt0111", model.TP_GRAB_IV)
	time.Sleep(3 * time.Second)
	service.AsyncApprovalTimeRecord("tttt0111", model.TP_GRAB_IV)
	time.Sleep(3 * time.Second)
	service.AsyncApprovalTimeRecord("tttt0111", model.TP_GRAB_IV)
	time.Sleep(3 * time.Second)
	r := timeStatisticsByType("tttt0111", model.TP_GRAB_IV)

	fmt.Println(util.StringifyJson(r))

	s.Equal(true, len(r["total_time"].(string)) > 0)
	fmt.Println(r)

}

func (s *testingSuite) TestGetAoUserPaoList() {
	pao := model.GetDefaultPreApprovalOrder()
	pao.QuantizationMap = `
{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`

	pao.QuantizationCache = `
{"CIPB008":"已婚","CIPB003":"身份证","CIPB069":"0","CIPB009":"大专","CIPB049":"0","CIPB034":"9","CIPB043":"25","CIPB071":"0","CIPB072":"0","CIPB011":"居民服务和其他服务业","CIPB089":"5","CIPB098":"61852.20","CIPB001":"2017-10-25","CIPB005":"2030-9-9","CIPB078":"0","CIPB102":"3450000","CIPB023":"0","CIPB028":"2","CIPB039":"无","CIPB050":"0","CIPB013":"2","CIPB045":"0","CIPB091":"6","CIPB060":"2455000","CIPB019":"0","CIPB033":"3216672","CIPB090":"9","CIPB020":"0","CIPB064":"0","CIPB016":"2007.04","CIPB042":"0","CIPB068":"0","CIPB097":"2","CIPB070":"0","CIPB007":"1980-11-6","CIPB040":"无","CIPB083":"203","CIPB052":"0","CIPB006":"女","CIPB075":"0","CIPB036":"100000","CIPB099":"2017-9-22","CIPB096":"3","CIPB031":"4","CIPB077":"0","CIPB079":"11976","CIPB094":"14","CIPB063":"0","CIPB100":"500000","CIPB062":"860000","CIPB086":"无","CIPB022":"0","CIPB032":"3315000","CIPB067":"0","CIPB074":"0","CIPB014":"0","CIPB080":"无","CIPB093":"1","CIPB044":"0","CIPB035":"474000","CIPB057":"13577","CIPB066":"0","CIPB021":"0","CIPB073":"0","CIPB017":"2008.12","CIPB047":"0","CIPB082":"无","CIPB059":"2015-3-11","CIPB055":"0","CIPB053":"0","CIPB076":"0","CIPB010":"商业、服务业人员","CIPB081":"无","CIPB012":"2","CIPB037":"341472","CIPB038":"267113","CIPB030":"0","CIPB018":"2011.06","CIPB088":"无","CIPB046":"0","CIPB092":"1","CIPB087":"无","CIPB027":"17589","CIPB004":"441426198011062448","CIPB084":"5","CIPB024":"0","CIPB056":"1","CIPB048":"0","CIPB054":"0","CIPB026":"无","CIPB025":"无","CIPB061":"2028-3-11","CIPB095":"10","CIPB015":"12","CIPB041":"正常","CIPB029":"0","CIPB065":"0","CIPB002":"陈福兰","CIPB058":"14128","CIPB085":"缴交","CIPB051":"0"}`

	pao.QuantizationPoint = 400
	pao.QuantizationLevel = 5
	s.NoError(service.CreatePreApproval(pao))
	s.NoError(GrabPreApproval("test001", "测试001"))
	paoR, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.Equal(pao.PreApprovalID, paoR.PreApprovalID)
	s.Equal("test001", paoR.PreTrailId)
	s.Equal("测试001", paoR.PreTrailName)
	s.NotNil(paoR.StartTime)
	s.Equal(model.PREAPPROVALING, paoR.PreApprovalStatus)
	// 拒绝
	s.NoError(PreTrailOperation(&model.PreApprovalOrder{PreApprovalID: pao.PreApprovalID,
		PreApprovalStatus: model.PREAPPROVALREFUSE, OpDesc: "sss",RefuseReason:"123",ExternalReason:"123"}))

	paoR1, err := GetPreApprovalInfo(pao.PreApprovalID)
	s.NoError(err)
	s.NotNil(paoR1.RefuseTime)
	s.Equal(model.PREAPPROVALREFUSE, paoR1.PreApprovalStatus)

	l, err := GetAoUserPaoList(pao.UserIdNum)
	s.NoError(err)
	s.Equal(1, len(l))
}

func (s *testingSuite) TestManageInterViewUploadFile() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	s.NoError(NewApprovalOrder(ao))

	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal("off", aR.InterViewSwitch)

	s.NoError(ManageInterViewUploadFile(ao.JinjianId, "on"))

	aR1, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)
	s.Equal("on", aR1.InterViewSwitch)

}

func (s *testingSuite) TestGetJjIdByShowId() {
	ao := model.GetDefaultApprovalOrder()
	ao.FirstTrailId = "cs001"
	ao.FirstTrailName = "初审001"
	s.NoError(NewApprovalOrder(ao))

	aR, _, err := GetApprovalOrder(ao.JinjianId)
	s.NoError(err)

	id, jinjianId := GetJjIdByShowId(aR.ContractId)

	s.NotEqual(0, id)

	s.Equal(aR.ID, id)

	s.Equal(aR.JinjianId, jinjianId)

}

func TestApprovalBackIvCS(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailId = "cs001"
		ao.FirstTrailName = "初审001"
		ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
		assert.NoError(t, NewApprovalOrder(ao))
		assert.NoError(t, ApprovalBackIv(*ao, &model.ApprovalOrder{FirstTrailStatusDes: "ssss"}, "cs"))
		aR, _, err := GetApprovalOrder(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, model.ApprovalStatusFirstTrailBackIv, aR.FirstTrailStatus)
		assert.Equal(t, model.ApprovalStatusFirstTrailBackIv, aR.InterViewStatus)
	})
}

func TestApprovalBackIvZS(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailId = "cs001"
		ao.FirstTrailName = "初审001"
		ao.FirstTrailStatus = model.ApprovalStatusFirstTrailPass
		ao.ReTrailId = "zs001"
		ao.ReTrailName = "终审001"
		ao.ReTrailStatus = model.ApprovalStatusWaitReTrail
		assert.NoError(t, NewApprovalOrder(ao))
		assert.NoError(t, ApprovalBackIv(*ao, &model.ApprovalOrder{ReTrailStatusDes: "ssss"}, "zs"))
		aR, _, err := GetApprovalOrder(ao.JinjianId)
		assert.NoError(t, err)
		assert.Equal(t, model.ApprovalStatusReTrailBackIv, aR.ReTrailStatus)
		assert.Equal(t, model.ApprovalStatusReTrailBackIv, aR.InterViewStatus)
	})
}

func TestApprovalBackIvTyErr(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailId = "cs001"
		ao.FirstTrailName = "初审001"
		ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail

		assert.NoError(t, NewApprovalOrder(ao))

		assert.EqualError(t, ApprovalBackIv(*ao, &model.ApprovalOrder{ReTrailStatusDes: "ssss"}, ""), "审批类型错误")

	})
}

func TestStatisticOrderCount(t *testing.T){
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		ao.FirstTrailId = "cs001"
		ao.FirstTrailName = "初审assert.Equal(t, nil, err)001"
		ao.FirstTrailStatus = model.ApprovalStatusWaitFirstTrail
		assert.NoError(t, NewApprovalOrder(ao))

		assert.EqualError(t, ApprovalBackIv(*ao, &model.ApprovalOrder{ReTrailStatusDes: "ssss"}, ""), "审批类型错误")
	})

}

func TestUpdateJinjianAllInfo(t *testing.T) {
	oneStepTest(func() {
		ao := model.GetDefaultApprovalOrder()
		jjId := ao.JinjianId

		assert.NoError(t, NewApprovalOrder(ao))

		assert.NoError(t, UpdateJinjianAllInfo(jjId, "name", "测试"))

		var resultOrder model.ApprovalOrder
		assert.NoError(t, config.GetDb().Find(&resultOrder, "jinjian_id = ?", jjId).Error)

		var allInfo map[string]interface{}
		assert.NoError(t, util.ParseJson(resultOrder.AllInfo, &allInfo))

		assert.Equal(t, "测试", allInfo["idcard_info"].(map[string]interface{})["name"], "结果不匹配")
	})
}

func TestSumTimeWithOutWorkTime(t *testing.T) {
	oneStepTest(func() {
		var time1 time.Time
		var time2 time.Time
		startTime0 := "2018/03/07 06:00"
		startTime1 := "2018/03/07 11:00"
		startTime2 := "2018/03/07 12:00"
		startTime3 := "2018/03/07 12:30"
		startTime4 := "2018/03/07 13:30"
		startTime5 := "2018/03/07 15:30"
		startTime6 := "2018/03/07 18:30"
		startTime7 := "2018/03/07 19:30"
		endTime0 := "2018/03/07 07:00"
		endTime1 := "2018/03/07 10:00"
		endTime2 := "2018/03/07 12:00"
		endTime3 := "2018/03/07 13:00"
		endTime4 := "2018/03/07 13:30"
		endTime5 := "2018/03/07 16:30"
		endTime6 := "2018/03/07 18:30"
		endTime7 := "2018/03/07 20:30"
		endTime8 := "2018/03/09 07:30"
		endTime9 := "2018/03/09 14:30"
		endTime10 := "2018/03/09 19:30"
		endTime11 := "2018/03/10 12:00" // 周六休息
		endTime12 := "2018/03/10 20:30" // 周六休息
		timeLayout := "2006/01/02 15:04"

		// ***************************************************************************startTime0
		time1, _ = time.Parse(timeLayout, startTime0)
		time2, _ = time.Parse(timeLayout, endTime0)
		assert.Equal(t, time.Duration(0), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime0)
		time2, _ = time.Parse(timeLayout, endTime1)
		assert.Equal(t, time.Duration(time.Hour*1), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime0)
		time2, _ = time.Parse(timeLayout, endTime2)
		assert.Equal(t, time.Duration(time.Hour*3), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime0)
		time2, _ = time.Parse(timeLayout, endTime3)
		assert.Equal(t, time.Duration(time.Hour*3), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime0)
		time2, _ = time.Parse(timeLayout, endTime4)
		assert.Equal(t, time.Duration(time.Hour*3), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime0)
		time2, _ = time.Parse(timeLayout, endTime5)
		assert.Equal(t, time.Duration(time.Hour*6), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime0)
		time2, _ = time.Parse(timeLayout, endTime6)
		assert.Equal(t, time.Duration(time.Hour*8), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime0)
		time2, _ = time.Parse(timeLayout, endTime7)
		assert.Equal(t, time.Duration(time.Hour*8), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime0)
		time2, _ = time.Parse(timeLayout, endTime8)
		assert.Equal(t, time.Duration(time.Hour*16), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime0)
		time2, _ = time.Parse(timeLayout, endTime9)
		assert.Equal(t, time.Duration(time.Hour*20), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime0)
		time2, _ = time.Parse(timeLayout, endTime10)
		assert.Equal(t, time.Duration(time.Hour*24), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime0)
		time2, _ = time.Parse(timeLayout, endTime11)
		assert.Equal(t, time.Duration(time.Hour*24), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime0)
		time2, _ = time.Parse(timeLayout, endTime12)
		assert.Equal(t, time.Duration(time.Hour*24), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		// ***************************************************************************startTime1
		time1, _ = time.Parse(timeLayout, startTime1)
		time2, _ = time.Parse(timeLayout, endTime2)
		assert.Equal(t, time.Duration(time.Hour*1), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime1)
		time2, _ = time.Parse(timeLayout, endTime3)
		assert.Equal(t, time.Duration(time.Hour*1), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime1)
		time2, _ = time.Parse(timeLayout, endTime4)
		assert.Equal(t, time.Duration(time.Hour*1), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime1)
		time2, _ = time.Parse(timeLayout, endTime5)
		assert.Equal(t, time.Duration(time.Hour*4), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime1)
		time2, _ = time.Parse(timeLayout, endTime6)
		assert.Equal(t, time.Duration(time.Hour*6), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime1)
		time2, _ = time.Parse(timeLayout, endTime7)
		assert.Equal(t, time.Duration(time.Hour*6), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime1)
		time2, _ = time.Parse(timeLayout, endTime8)
		assert.Equal(t, time.Duration(time.Hour*14), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime1)
		time2, _ = time.Parse(timeLayout, endTime9)
		assert.Equal(t, time.Duration(time.Hour*18), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime1)
		time2, _ = time.Parse(timeLayout, endTime10)
		assert.Equal(t, time.Duration(time.Hour*22), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime1)
		time2, _ = time.Parse(timeLayout, endTime11)
		assert.Equal(t, time.Duration(time.Hour*22), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime1)
		time2, _ = time.Parse(timeLayout, endTime12)
		assert.Equal(t, time.Duration(time.Hour*22), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		// ***************************************************************************startTime2

		time1, _ = time.Parse(timeLayout, startTime2)
		time2, _ = time.Parse(timeLayout, endTime2)
		assert.Equal(t, time.Duration(0), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime2)
		time2, _ = time.Parse(timeLayout, endTime3)
		assert.Equal(t, time.Duration(0), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime2)
		time2, _ = time.Parse(timeLayout, endTime4)
		assert.Equal(t, time.Duration(0), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime2)
		time2, _ = time.Parse(timeLayout, endTime5)
		assert.Equal(t, time.Duration(time.Hour*3), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime2)
		time2, _ = time.Parse(timeLayout, endTime6)
		assert.Equal(t, time.Duration(time.Hour*5), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime2)
		time2, _ = time.Parse(timeLayout, endTime7)
		assert.Equal(t, time.Duration(time.Hour*5), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime2)
		time2, _ = time.Parse(timeLayout, endTime8)
		assert.Equal(t, time.Duration(time.Hour*13), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime2)
		time2, _ = time.Parse(timeLayout, endTime9)
		assert.Equal(t, time.Duration(time.Hour*17), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime2)
		time2, _ = time.Parse(timeLayout, endTime10)
		assert.Equal(t, time.Duration(time.Hour*21), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		// ***************************************************************************startTime3

		time1, _ = time.Parse(timeLayout, startTime3)
		time2, _ = time.Parse(timeLayout, endTime2)
		assert.Equal(t, time.Duration(0), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime3)
		time2, _ = time.Parse(timeLayout, endTime3)
		assert.Equal(t, time.Duration(0), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime3)
		time2, _ = time.Parse(timeLayout, endTime4)
		assert.Equal(t, time.Duration(0), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime3)
		time2, _ = time.Parse(timeLayout, endTime5)
		assert.Equal(t, time.Duration(time.Hour*3), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime3)
		time2, _ = time.Parse(timeLayout, endTime6)
		assert.Equal(t, time.Duration(time.Hour*5), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime3)
		time2, _ = time.Parse(timeLayout, endTime7)
		assert.Equal(t, time.Duration(time.Hour*5), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime3)
		time2, _ = time.Parse(timeLayout, endTime8)
		assert.Equal(t, time.Duration(time.Hour*13), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime3)
		time2, _ = time.Parse(timeLayout, endTime9)
		assert.Equal(t, time.Duration(time.Hour*17), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime3)
		time2, _ = time.Parse(timeLayout, endTime10)
		assert.Equal(t, time.Duration(time.Hour*21), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		// ***************************************************************************startTime4

		time1, _ = time.Parse(timeLayout, startTime4)
		time2, _ = time.Parse(timeLayout, endTime2)
		assert.Equal(t, time.Duration(0), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime4)
		time2, _ = time.Parse(timeLayout, endTime3)
		assert.Equal(t, time.Duration(0), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime4)
		time2, _ = time.Parse(timeLayout, endTime4)
		assert.Equal(t, time.Duration(0), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime4)
		time2, _ = time.Parse(timeLayout, endTime5)
		assert.Equal(t, time.Duration(time.Hour*3), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime4)
		time2, _ = time.Parse(timeLayout, endTime6)
		assert.Equal(t, time.Duration(time.Hour*5), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime4)
		time2, _ = time.Parse(timeLayout, endTime7)
		assert.Equal(t, time.Duration(time.Hour*5), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime4)
		time2, _ = time.Parse(timeLayout, endTime8)
		assert.Equal(t, time.Duration(time.Hour*13), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime4)
		time2, _ = time.Parse(timeLayout, endTime9)
		assert.Equal(t, time.Duration(time.Hour*17), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime4)
		time2, _ = time.Parse(timeLayout, endTime10)
		assert.Equal(t, time.Duration(time.Hour*21), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		// ***************************************************************************startTime5

		time1, _ = time.Parse(timeLayout, startTime5)
		time2, _ = time.Parse(timeLayout, endTime5)
		assert.Equal(t, time.Duration(time.Hour*1), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime5)
		time2, _ = time.Parse(timeLayout, endTime6)
		assert.Equal(t, time.Duration(time.Hour*3), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime5)
		time2, _ = time.Parse(timeLayout, endTime7)
		assert.Equal(t, time.Duration(time.Hour*3), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime5)
		time2, _ = time.Parse(timeLayout, endTime8)
		assert.Equal(t, time.Duration(time.Hour*11), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime5)
		time2, _ = time.Parse(timeLayout, endTime9)
		assert.Equal(t, time.Duration(time.Hour*15), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime5)
		time2, _ = time.Parse(timeLayout, endTime10)
		assert.Equal(t, time.Duration(time.Hour*19), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		// ***************************************************************************startTime6

		time1, _ = time.Parse(timeLayout, startTime6)
		time2, _ = time.Parse(timeLayout, endTime8)
		assert.Equal(t, time.Duration(time.Hour*8), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime6)
		time2, _ = time.Parse(timeLayout, endTime9)
		assert.Equal(t, time.Duration(time.Hour*12), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime6)
		time2, _ = time.Parse(timeLayout, endTime10)
		assert.Equal(t, time.Duration(time.Hour*16), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		// ***************************************************************************startTime7

		time1, _ = time.Parse(timeLayout, startTime7)
		time2, _ = time.Parse(timeLayout, endTime8)
		assert.Equal(t, time.Duration(time.Hour*8), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime7)
		time2, _ = time.Parse(timeLayout, endTime9)
		assert.Equal(t, time.Duration(time.Hour*12), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")

		time1, _ = time.Parse(timeLayout, startTime7)
		time2, _ = time.Parse(timeLayout, endTime10)
		assert.Equal(t, time.Duration(time.Hour*16), SumTimeWithOutWorkTime(time1, time2), "结果不匹配")
	})
}
