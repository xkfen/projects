package serviceV1

import (
	"gapproval/approval/model"
	"time"
	"errors"
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
	"gapproval/approval/service"
)

//  终审操作
func ReTrailOperation(changeAo *model.ApprovalOrder, sendUser bool) (err error) {
	logger.Info("==========终审操作是否发短信给用户============", "sendUser", sendUser)
	var ao model.ApprovalOrder
	if err = config.GetDb().Where("jinjian_id =?", changeAo.JinjianId).First(&ao).Error; err != nil {
		return err
	}
	if err = ao.IsValidZsOperation(); err != nil {
		return
	}
	switch changeAo.ReTrailStatus {
	case model.ApprovalStatusReTrailExchange: // 终审流转
		if err = exchange(ao, changeAo, "zs"); err != nil {
			return err
		}
	case model.ApprovalStatusReTrailPass: // 终审通过
		if err = reTrailPass(ao, changeAo, sendUser); err != nil {
			return err
		}
	case model.ApprovalStatusReTrailRefuse: // 终审拒绝
		if err = reTrailRefuse(ao, changeAo, sendUser); err != nil {
			return err
		}
	case model.ApprovalStatusReTrailBack: // 终审退回
		if err = reTrailBack(ao, changeAo); err != nil {
			return err
		}
	case model.ApprovalStatusCustomCancel: // 客户撤销
		if err = cancel(ao, changeAo, "zs"); err != nil {
			return err
		}
	case model.ApprovalStatusReTrailBackIv:
		if err = ApprovalBackIv(ao, changeAo, "zs"); err != nil {
			return err
		}
		//case model.ApprovalStatusReTrailFinish: // 上传合同
		//	if err = reTrailContract(ao, changeAo); err != nil {
		//		return err
		//	}
	default:
		err = errors.New("状态参数错误，请检查zsStatus")
		return
	}
	return
}

//  终审上传合同
func reTrailContract(ao model.ApprovalOrder, changeAo *model.ApprovalOrder) (err error) {
	if changeAo.ContractId == "" {
		err = errors.New("合同号不能为空")
		return
	}
	if ao.ReTrailChoice == "" {
		err = errors.New("终审选择状态异常，请联系开发人员")
		return
	}
	if ao.ReTrailChoice != model.ApprovalStatusReTrailRefuse {
		err = errors.New("终审选择状态应该为终审拒绝，请联系开发人员")
		return
	}
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.ReTrailName,
		ApprovalStatus: "终审上传合同",
		ApprovalType: "zs"})

	ao.ContractId = changeAo.ContractId
	ao.ReTrailStatus = ao.ReTrailChoice

	//if ao.ReTrailChoice == model.ApprovalStatusReTrailPass {
	//	ao.CustomServiceStatus = model.ApprovalStatusWaitCustomConfirm
	//}
	ao.ApprovalStatus = ao.GetAoCurrStatus()
	if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
		return err
	}

	service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_UPLOADC)

	//业务留痕
	service.AsyncApprovalTrace(ao)
	return
}

//  终审拒绝
func reTrailRefuse(ao model.ApprovalOrder, changeAo *model.ApprovalOrder, sendUser bool) (err error) {
	ao.ReTrailChoice = model.ApprovalStatusReTrailRefuse
	//ao.ReTrailStatus = model.ApprovalStatusReTrailFinish // 待上传合同状态   2018-01-23 18:50:16

	ao.ReTrailStatus = model.ApprovalStatusReTrailRefuse // 终审拒绝

	if changeAo.ReTrailStatusDes == "" {
		err = errors.New("终审拒绝状态说明不能为空")
		return
	}
	if changeAo.RefuseReason == "" {
		err = errors.New("拒绝原因不能为空")
		return
	}
	if changeAo.ExternalReason == "" {
		err = errors.New("拒绝外部原因不能为空")
		return
	}
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.ReTrailName,
		ApprovalStatus: "终审拒绝",
		ApprovalType: "zs", ApprovalDesc: changeAo.ReTrailStatusDes})

	ao.ExternalReason = changeAo.ExternalReason
	ao.ReTrailStatusDes = changeAo.ReTrailStatusDes
	ao.RefuseReason = changeAo.RefuseReason
	// 设置审核拒绝时间  中介和进件系统需要的字段
	nowTime := time.Now()
	ao.ApprovalRefuseTime = &nowTime
	ao.AgencyStatus = model.AgencyStatusRefuse
	ao.ApprovalStatus = ao.GetAoCurrStatus()
	if err = config.GetDb().Model(ao).Updates(ao).Error; err != nil {
		return err
	}

	service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_ZS)

	//业务留痕
	service.AsyncApprovalTrace(ao)

	// 发短信   拒绝
	service.SendSms(ao, "refuse", sendUser)
	return
}

//  终审通过
func reTrailPass(ao model.ApprovalOrder, changeAo *model.ApprovalOrder, sendUser bool) (err error) {
	if err = rtPassRuleByFundSide(ao, changeAo); err != nil {
		return
	}

	ao.Cellphone = changeAo.Cellphone
	ao.ReTrailStatusDes = changeAo.ReTrailStatusDes
	ao.ApprovedAmount = changeAo.ApprovedAmount
	ao.ApprovedRate = changeAo.ApprovedRate
	ao.PlatformMonthRate = changeAo.PlatformMonthRate

	// 如果不是财务退回需要更改中介端需要的字段
	if ao.ReTrailStatus != model.ApprovalStatusFinanceBack {
		// 设置审核通过时间  中介和进件系统需要的字段
		nowTime := time.Now()
		ao.ApprovalPassTime = &nowTime
		ao.AgencyStatus = model.AgencyStatusPass
	}
	ao = updateAoInfoByChangeAo(ao, changeAo)
	if changeAo.SalaryAt == nil {
		ao.SalaryAt = nil
	} else {
		ao.SalaryAt = changeAo.SalaryAt
	}

	if changeAo.LoanAt == nil {
		ao.LoanAt = nil
	} else {
		ao.LoanAt = changeAo.LoanAt
	}
	ao.ReTrailStatusDes = changeAo.ReTrailStatusDes
	ao.ReTrailStatus = model.ApprovalStatusReTrailPass // 终审通过
	ao.CustomServiceStatus = model.ApprovalStatusWaitCustomConfirm
	ao.ApprovalStatus = ao.GetAoCurrStatus()

	// 资金方为海金社，终审，审核通过时，增加风险等级、风控结论
	if ao.FundSide == model.HAIJINSHEFundSide {
		ao.RiskResult = changeAo.RiskResult
		ao.RiskLevel = changeAo.RiskLevel
	}

	if err = config.GetDb().Model(ao).Updates(ao).Update("salary_at", changeAo.SalaryAt).
		Update("loan_at", changeAo.LoanAt).Error; err != nil {
		return err
	}

	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.ReTrailName,
		ApprovalStatus: "终审通过",
		ApprovalType: "zs", ApprovalDesc: changeAo.ReTrailStatusDes})

	if ao.CustomServiceId != "Null" && ao.CustomServiceName != "Null" {
		service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_ZS, model.TP_KF)
	} else {
		service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_ZS, model.TP_GRAB_KF)
	}

	//业务留痕
	service.AsyncApprovalTrace(ao)
	// 发短信   通过
	service.SendSms(ao, "pass", sendUser)
	return
}

//  终审退回
func reTrailBack(ao model.ApprovalOrder, changeAo *model.ApprovalOrder) (err error) {
	if changeAo.ReTrailStatusDes == "" {
		err = errors.New("终审退回状态说明不能为空")
		return
	}
	ao.ApprovedAmount = changeAo.ApprovedAmount
	ao.ApprovedRate = changeAo.ApprovedRate
	ao = updateAoInfoByChangeAo(ao, changeAo)
	if changeAo.SalaryAt == nil {
		ao.SalaryAt = nil
	} else {
		ao.SalaryAt = changeAo.SalaryAt
	}

	if changeAo.LoanAt == nil {
		ao.LoanAt = nil
	} else {
		ao.LoanAt = changeAo.LoanAt
	}
	service.AsyncNewApprovalLog(&model.ApprovalLog{ApprovalJinjianId: ao.JinjianId, ApprovalName: ao.ReTrailName,
		ApprovalStatus: "终审退回给" + ao.FirstTrailName,
		ApprovalType: "cs", ApprovalDesc: changeAo.ReTrailStatusDes})

	ao.ReTrailStatus = model.ApprovalStatusReTrailBack
	ao.FirstTrailStatus = model.ApprovalStatusReTrailBack
	ao.ReTrailStatusDes = changeAo.ReTrailStatusDes
	ao.ApprovalStatus = ao.GetAoCurrStatus()

	if err = config.GetDb().Model(ao).Updates(ao).Update("salary_at", changeAo.SalaryAt).
		Update("loan_at", changeAo.LoanAt).Error; err != nil {
		return err
	}

	service.AsyncApprovalTimeRecord(ao.JinjianId, model.TP_ZS, model.TP_CS)

	//业务留痕
	service.AsyncApprovalTrace(ao)

	return
}

//  获取终审列表 (包含搜索)
func GetReTrailApprovalOrderList(typeKey string, status string, username string, name string,
	sort string, condition string, page int) ([]model.ApprovalOrder, int, int) {
	return transactGetApprovalList("zs", typeKey, status, username, name, sort, condition, page)
}
