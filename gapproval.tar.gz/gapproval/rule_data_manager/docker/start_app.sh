#!/usr/bin/env bash

rule_data_manager_db --action=create --env=$QY_ENV --docker_env=$QY_DOCKER_ENV;rule_data_manager_db --action=migrate --env=$QY_ENV --docker_env=$QY_DOCKER_ENV;rule_data_manager --env=$QY_ENV --docker_env=$QY_DOCKER_ENV