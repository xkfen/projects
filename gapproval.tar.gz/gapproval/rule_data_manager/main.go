package main

import (
	"gcoresys/common"
	"gcoresys/common/logger"
	"gapproval/rule_data_manager/db/config"
	"gapproval/rule_data_manager/handler"
)

func main() {
	// 获取运行参数
	env := common.DefineRunTimeCommonFlag()
	// 初始化日志
	if common.GetUseDocker() != 0 {
		logger.InitLogger(logger.LvlDebug, "qy_rule_data_manager.log")
	} else {
		logger.InitLogger(logger.LvlDebug, nil)
	}
	logger.Info("程序运行环境：" + env)
	// 初始化数据库配置
	config.GetRuleDataDbConfig(env)
	config.GetDb()

	// 启动http服务器
	handler.StartHttpServer(env)
}
