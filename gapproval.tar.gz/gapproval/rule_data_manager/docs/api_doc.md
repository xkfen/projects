1. 获取参数列表
http://rule-data-app:3000/api/v1/rule_data/rule_args?page=1&per_page=100  
get  
resp  
```
{"success":false,"info":"","errmsg":"","total_pages":0,"total_count":0,"rule_args":[{"id":0,"created_at":"0001-01-01T00:00:00Z","updated_at":"0001-01-01T00:00:00Z","deleted_at":null,"name":"","key":"","v_type":""}]}
```

2. 获取规则执行结果
http://rule-data-app:3000/api/v1/rule_data/rule_result
post
req
```
{
"order_id":"", // 审批单号
"rule_show_id":"", // 可以为空，为空则是默认的启元规则组
"should_refresh":false // 传true就是强行刷新规则执行的结果
}
```
resp
```
{"success":false,"info":"","errmsg":"","result":{
// 规则组名称
"name":"",
// 规则列表
"rules":[{"key":"",
// 规则编号
"num":"",
// 规则名称
"name":"",
// 规则描述
"describe":"",
// 规则执行的结果
"executed_result":"","rule_args":null,"pass_judge":null,"reject_judge":null,"review_judge":null}]}}
```

### 使用规则接口调用步骤（不用这套，直接用上边那个方法2即可）
（1）获取默认的规则（启元规则组）
http://jrule-engine-app:3000/api/v1/rule_engine/rule/{ruleShowId}  
get 
resp 
```
{
  "data": {
            "droolsCode": "package com.qy",
            "id": 0,
            "ruleConf": "string",
            "ruleName": "string",
            "ruleShowId": "string",
            "ruleType": "string"
          },
  "info": "string",
  "success": true
}
```
备注
```
# ruleConf内容：
{
    name: "测试规则组",
    rules: [
        {
            name: "测试评分",
            key: "r1",
            rule_args: [
                {
                    name: "score",
                    key: "rk1",
                    v_type: "int"
                }
            ],
            pass_judge: {
                j_type: "basic",
                operator: ">=",
                arg: {
                    name: "score",
                    key: "rk1",
                    v_type: "int"
                },
                value: 20
            },
            reject_judge: {
                j_type: "basic",
                operator: "<",
                arg: {
                    name: "score",
                    key: "rk1",
                    v_type: "int"
                },
                value: 15
            }
        }
    ]
}
```
（2）获取规则所需的参数的值
http://rule-data-app:3000/api/v1/rule_data/rule_data  
post    
req  
```
 {"order_id":"","rule_args":[{"key":""}]}
```
resp  
```
# rule_data中的key就是req中rule_args每个参数的key的值
{"success":false,"info":"","errmsg":"","rule_data":{}}
```
（3）执行规则
http://jrule-engine-app:3000/api/v1/rule_engine/execute  
post  
req  
```
{"ruleShowId":"","ruleData":{}}
```
resp 
```
{
  "data": {
            "r1_result": "pass"   // reject，review
          },
  "info": "string",
  "success": true
}
```