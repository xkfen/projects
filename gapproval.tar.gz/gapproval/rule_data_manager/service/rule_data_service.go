package service

import (
	"gapproval/rule_data_manager/model"
	"gapproval/common/global"
	"gcoresys/common/logger"
	"errors"
	"griskcontrol/riskcontrol/grpc/server"
	"gcoresys/common/db"
	gapprovalModel "gapproval/approval/model"
	griskcontrolModel "griskcontrol/riskcontrol/model"
	"gcoresys/common/util"
	"time"
	"strings"
	"strconv"
	"gapproval/common/httpReq"
	"github.com/jinzhu/gorm"
	"reflect"
	"gapproval/rule_data_manager/handler/req_model"
	"gapproval/rule_data_manager/db/config"
)

var RuleDataFunc = map[string]func(orderId string) (interface{}, error){
	"have_house": getHaveHouseValue,


	//**********************//zebreay
	//成功绑定的银行卡数
	"bound_cards": getBoundCards,
	//常用移动运营商：总通话次数
	"main_call_times": getMainCallTimes,
	//补录移动运营商：总通话次数
	"second_call_times": getSecondCallTimes,
	//“三非”客户 // 关闭
	//"is_three_false": getThreeFalse,
	//是否有法院信息
	"have_court_info": getCourtInfoAndExecMoney,
	//执行标的================(方法同上) //  关闭
	//"exec_amount": getCourtInfoAndExecMoney,
	//多头借贷数据
	"multi_point_count": getMultiPointCount,
	//富数黑名单 ， 百度黑名单
	"in_fushu_blacklist": getInFushuBlacklist,
	// 内部黑名单未上线，后期要用
	//信用负债/收入比（DTI）
	"DTI": getDTI,
	//近2个月征信上纯贷款审批查询次数
	"M2_loan_app_cnt": getM2LoanAppCnt,

	//**********************//zk
	//用户身份证号
	"user_id_num": getUserIdNum,
	//用户身份证有效时长/月
	"id_expiry_date": getIdExpiryDate,
	//用户年龄
	"user_age": getUserAge,
	//用户身份证信息匹配
	"match_id_info": getIdInfo,
	//贷款当前逾期期数
	"loan_overdue_mth": getLoanOverdueMth,
	//贷记卡当前逾期金额
	"crt_overdue_amt": getCrtOverdueAmt,
	//贷记卡当前逾期期数
	"crt_overdue_mth": getCrtOverdueMth,
	//量化评分
	"quantization_point": getQuantizationPoint,
	//房产抵押日期距今月份（“无”或数字）
	"housing_loan_dt": getHousingLoanDt,
	//获取贷款五级分类
	"loan_status": getLoanStatus,
	//近12月贷款审批查询次数
	"M12_loan_app_cnt": getM12LoanAppCnt,
}

func getHaveHouseValue(orderId string) (interface{}, error) {
	order := gapprovalModel.ApprovalOrder{}
	if err := db.GetApprovalReadDb().Where(&gapprovalModel.ApprovalOrder{JinjianId: orderId}).First(&order).Error; err != nil {
		return nil, err
	}
	interviewJson := map[string]interface{}{}
	if err := util.ParseJson(order.InterView, &interviewJson); err != nil {
		return nil, err
	}
	fcp, _ := interviewJson["fang_chan_plan"].([]interface{})
	ygp, _ := interviewJson["yue_gong_plan"].([]interface{})
	logger.Info("房产和月供", "fang len", len(fcp), "yue gong len", len(ygp))
	if len(fcp) != 0 || len(ygp) != 0 {
		return 1, nil
	}
	return 0, nil
}

// ***********************    Zebreay start    ***********************
// TODO：应该去财务查扣款数？
func getBoundCards(orderId string) (interface{}, error) {
	mainCount, _ := getBoundCards4main(orderId)
	secondCount, _ := getBoundCards4second(orderId)
	return mainCount + secondCount, nil
}

func getBoundCards4main(orderId string) (int, error) {
	orderId = `{"id":"` + orderId + `"}`
	result, err := httpReq.PostJsonProxyNoCheck(orderId, global.GetRiskControlServerUrl()+"/api/v1/banks/query_main")
	if err != nil {
		logger.Warn("调用风控'banks/query_main'接口错误", "info", err.Error())
		return 0, err
	}
	var resp server.GetMainBankResp
	err = util.ParseJson(result, &resp)
	if err != nil {
		logger.Warn("风控'banks/query_main'接口返回参数有误: " + err.Error())
		return 0, errors.New("无法解析风控返回的数据:" + err.Error())
	}

	if resp.Success == false {
		logger.Warn("返回状态非200，info: " + resp.Info)
		return 0, nil
	}
	boundCards := 0
	for _, x := range resp.MainBanks {
		switch x.HasFlow {
		case "1":
			boundCards ++
		case "0":
		default:
			logger.Error("风控端接口逻辑错误.调用接口后,'HasFlow'字段只能为0或1")
		}
	}
	return boundCards, nil
}

func getBoundCards4second(orderId string) (int, error) {
	orderId = `{"id":"` + orderId + `"}`
	result, err := httpReq.PostJsonProxyNoCheck(orderId, global.GetRiskControlServerUrl()+"/api/v1/banks/query_second")
	if err != nil {
		logger.Warn("调用风控'banks/query_second'接口错误", "info", err.Error())
		return 0, nil
	}
	var resp server.GetSecondBankResp
	err = util.ParseJson(result, &resp)
	if err != nil {
		logger.Warn("风控'banks/query_second'接口返回参数有误: " + err.Error())
		return 0, nil
	}
	if resp.Success == false {
		logger.Warn("返回状态非200，info: " + resp.Info)
		return 0, nil
	}
	boundCards := 0
	for _, x := range resp.SecondBanks {
		switch x.HasFlow {
		case "1":
			boundCards ++
		case "0":
		default:
			logger.Error("风控端接口逻辑错误.调用接口后,'HasFlow'字段只能为0或1")
		}
	}
	return boundCards, nil
}

func getMainCallTimes(orderId string) (interface{}, error) {
	var phoneId gorm.Model
	connectedDb := db.GetRiskControlReadDb()
	err := connectedDb.Table("phones").Select("id").Where("jin_jian_id=? AND is_main='1'", orderId).Order("created_at desc").First(&phoneId).Error
	if err != nil {
		return nil, err
	}
	if phoneId.ID == 0 {
		return nil, errors.New("查询不到此单的主电话号码")
	}
	var count int
	err = connectedDb.Table("phone_statements").Where("phone_id=?", phoneId.ID).Count(&count).Error
	if err != nil {
		return nil, err
	}
	return count, nil
}

func getSecondCallTimes(orderId string) (interface{}, error) {
	var phoneId gorm.Model
	connectedDb := db.GetRiskControlReadDb()
	err := connectedDb.Table("phones").Select("id").Where("jin_jian_id=? AND is_main='0'", orderId).Order("created_at desc").First(&phoneId).Error
	if err != nil {
		return nil, err
	}
	if phoneId.ID == 0 {
		return nil, errors.New("查询不到此单的主电话号码")
	}
	var count int
	err = connectedDb.Table("phone_statements").Where("phone_id=?", phoneId.ID).Count(&count).Error
	if err != nil {
		return nil, err
	}
	return count, nil
}

func getThreeFalse(orderId string) (interface{}, error) {
	connectedDb := db.GetApprovalReadDb()
	var three gapprovalModel.ThreePartyInfo
	err := connectedDb.Model(&gapprovalModel.ThreePartyInfo{}).Select("three_false").Where("jinjian_id=?", orderId).First(&three).Error
	if err != nil {
		return nil, err
	}
	if three.ThreeFalse == 1 {
		return 1, nil
	}
	if three.ThreeFalse == 2 {
		return -1, nil
	}
	if three.ThreeFalse == 0 {
		return nil, errors.New("没有该条数据")
	}
	return nil, errors.New("第三方信息数据库错乱,请检查！！！")
}

type RuleNeeded struct {
	Id            uint
	InBlackList   bool
	ExecMoney     float64
	RegisterCount uint
	RiskParam     string `gorm:"type:text" json:"risk_param"`
	UserIdNum     string
}

// 只要检验是否命中法海灰名单即可
func getCourtInfoAndExecMoney(orderId string) (interface{}, error) {
	results := make(map[string]interface{})
	var inBlackList RuleNeeded
	connectedDb := db.GetRiskControlReadDb()
	err := connectedDb.Table("black_lists").Select("id, in_black_list").
		Where("jin_jian_id=? AND source='fahai' AND task_status='1'", orderId).Order("created_at desc").First(&inBlackList).Error
	if err != nil {
		return nil, err
	}
	if inBlackList.InBlackList == false {
		results["have_court_info"] = "否"
		results["exec_amount"] = int(0)
		return results, nil
	}
	if inBlackList.InBlackList == true {
		results["have_court_info"], results["exec_amount"], err = getExecMoney(inBlackList.Id)
		if err != nil {
			return nil, err
		}
		return results, nil
	} else {
		return nil, errors.New("黑名单数据库错乱,请检查!!!")
	}
}

func getExecMoney(blackListId uint) (string, int, error) {
	var money RuleNeeded
	connectedDb := db.GetRiskControlReadDb()
	err := connectedDb.Table("fahai_gray_list_data").Select("exec_money").
		Where("black_list_id=? AND data_type='zxgg'", blackListId).First(&money).Error
	if err != nil && err == gorm.ErrRecordNotFound {
		return "否", 0, nil
	} else if err != nil && err != gorm.ErrRecordNotFound {
		return "", -1, err
	}
	return "是", int(money.ExecMoney), nil
}

func getMultiPointCount(orderId string) (interface{}, error) {
	var count RuleNeeded
	connectedDb := db.GetRiskControlReadDb()
	err := connectedDb.Table("multipoints").Select("register_count").
		Where("jin_jian_id=? AND task_status='1'", orderId).Order("created_at desc").First(&count).Error
	if err != nil {

		if err == gorm.ErrRecordNotFound{
			return 0, nil

		}
		return nil, err
	}
	return int(count.RegisterCount), nil
}

func getInFushuBlacklist(orderId string) (interface{}, error) {
	var result = 0
	var inBlackList []RuleNeeded
	connectedDb := db.GetRiskControlReadDb()
	err := connectedDb.Table("black_lists").Select("id, in_black_list").
		Where("jin_jian_id=? AND source in ('富数', 'baidu') AND task_status='1'", orderId).Order("created_at desc").Find(&inBlackList).Error
	if err != nil {
		if err == gorm.ErrRecordNotFound{
			return 0, nil
		}
		return nil, err
	}
	for _, x := range inBlackList{
		if x.InBlackList == true{
			result ++
		}
	}
	return result, nil
}

// 不用计算直接拿风险参数 ，如下
//   r25: {
//		key: 'debtRatio_DTI',
//		name: 'DTI'
//  },
func getDTI(orderId string) (interface{}, error) {
	var param RuleNeeded
	var paramJSON map[string]interface{}
	connectedDb := db.GetApprovalReadDb()
	err := connectedDb.Table("approval_orders").Select("risk_param").
		Where("jinjian_id=?", orderId).Order("created_at desc").First(&param).Error
	if err != nil {
		return nil, err
	}
	if err = util.ParseJson(param.RiskParam, &paramJSON); err != nil {
		return nil, errors.New("Json格式转换出错;" + err.Error())
	}
	if paramJSON["r25"] == nil {
		return nil, errors.New("数据不完整,请检查ApprovalOrders.RiskParam数据")
	}
	return paramJSON["r25"], nil
}

// 直接取量化变量的 "CIPB089" PbQueryCnt
func getM2LoanAppCnt(orderId string) (interface{}, error) {
	pbQueryCnt, err := getDataFromApprovalQuantizationVar(orderId, "PbQueryCnt")
	if err != nil {
		return nil, err
	}
	count, err := strconv.ParseInt(pbQueryCnt.(string), 10, 0)
	if err != nil {
		return nil, err
	}
	return int(count), err
}

// ***********************    Zebreay finish   ***********************

//获取量化评分
func getQuantizationPoint(orderId string) (interface{}, error) {
	order := gapprovalModel.ApprovalOrder{}
	if err := db.GetApprovalReadDb().Where(&gapprovalModel.ApprovalOrder{JinjianId: orderId}).First(&order).Error; err != nil {
		return nil, err
	} else {
		return order.QuantizationPoint, nil
	}
}

//获取身份证号
// 1. 优化 - 增加扩展性
// 2. 后期将以OCR识别身份证信息为准。目前不用改
func getUserIdNum(orderId string) (interface{}, error) {
	if PbIdNumber, err := getDataFromApprovalQuantizationVar(orderId, "PbIdNumber"); err != nil {
		return nil, err
	} else {
		if PbIdNumber.(string)[0:6] == "352201" ||
			PbIdNumber.(string)[0:6] == "352202" ||
			PbIdNumber.(string)[0:6] == "352224" ||
			PbIdNumber.(string)[0:6] == "352225" ||
			PbIdNumber.(string)[0:6] == "352227" ||
			PbIdNumber.(string)[0:6] == "352228" ||
			PbIdNumber.(string)[0:6] == "352229" ||
			PbIdNumber.(string)[0:6] == "352230" ||
			PbIdNumber.(string)[0:6] == "352231" ||
			PbIdNumber.(string)[0:4] == "3509" {
			return 1, nil
		} else {
			return -1, nil
		}
	}
}

//获取年龄
// 1. 后期将以OCR识别身份证信息为准。目前不用改
func getUserAge(orderId string) (interface{}, error) {
	order := gapprovalModel.ApprovalQuantizationVar{}
	if err := db.GetApprovalReadDb().Select("pb_birthday").Where(&gapprovalModel.ApprovalQuantizationVar{JinjianId: orderId}).First(&order).Error; err != nil {
		return nil, err
	} else {
		if order.PbBirthday != "" {
			birthday := strings.Split(order.PbBirthday, "-")

			if len(birthday) < 3 {
				return nil, errors.New("出生日期格式解析错误")
			}

			birYear, _ := strconv.Atoi(birthday[0])
			birMonth, _ := strconv.Atoi(birthday[1])

			age := time.Now().Year() - birYear

			if int(time.Now().Month()) < birMonth {
				age--
			}

			return age, nil
		} else {
			return nil, errors.New("出生日期为空")
		}
	}
}

//获取身份证有效日期
// 1. 应该拿审批日期比较，精确到天数
// 2. 后期将以OCR识别身份证信息为准。目前不用改
func getIdExpiryDate(orderId string) (interface{}, error) {
	order := gapprovalModel.ApprovalQuantizationVar{}
	if err := db.GetApprovalReadDb().Select("pb_id_expiry_date").Where(&gapprovalModel.ApprovalQuantizationVar{JinjianId: orderId}).First(&order).Error; err != nil {
		return nil, err
	}
	if order.PbIdExpiryDate == "" {
		return nil, errors.New("身份证有效日期为空")
	}
	expiryDate := strings.Split(order.PbIdExpiryDate, "-")

	if len(expiryDate) < 3 {
		return nil, errors.New("身份证有效日期格式解析错误")
	}
	Year, _ := strconv.Atoi(expiryDate[0])
	Month, _ := strconv.Atoi(expiryDate[1])

	countMonth := (Year-time.Now().Year())*12 + (Month - int(time.Now().Month()))

	if countMonth > 1 {
		return 1, nil
	}
	return -1, nil
}

//获取身份证信息匹配结果
func getIdInfo(orderId string) (interface{}, error) {
	idCardInfo := griskcontrolModel.IDCard{}

	if err := db.GetRiskControlReadDb().Where(&griskcontrolModel.IDCard{JinJianID: orderId}).First(&idCardInfo).Error; err != nil {
		return nil, err
	}

	if idCardInfo.Result == "" {
		return nil, errors.New("未找到匹配结果")
	} else {
		switch idCardInfo.Result {
		case "unmatched":
			return -1, nil
		case "matched":
			return 1, nil
		case "unsure":
			return 0, nil
		default:
			return nil, errors.New("不是有效值：" + idCardInfo.Result)
		}
	}
}

//获取贷款当前逾期期数
func getLoanOverdueMth(orderId string) (interface{}, error) {
	if pbLoanOverdueMth, err := getDataFromApprovalQuantizationVar(orderId, "PbLoanOverdueMth"); err != nil {
		return nil, err
	} else {
		return strconv.Atoi(pbLoanOverdueMth.(string))
	}
}

//获取贷记卡当前逾期金额
func getCrtOverdueAmt(orderId string) (interface{}, error) {
	if pbCrtOverdueAmt, err := getDataFromApprovalQuantizationVar(orderId, "PbCrtOverdueAmt"); err != nil {
		return nil, err
	} else {
		return strconv.Atoi(pbCrtOverdueAmt.(string))
	}
}

//获取贷记卡当前逾期期数
func getCrtOverdueMth(orderId string) (interface{}, error) {
	if pbCrtOverdueMth, err := getDataFromApprovalQuantizationVar(orderId, "PbCrtOverdueMth"); err != nil {
		return nil, err
	} else {
		return strconv.Atoi(pbCrtOverdueMth.(string))
	}
}

//获取房产抵押日期距今月份
func getHousingLoanDt(orderId string) (interface{}, error) {
	order := gapprovalModel.ApprovalQuantizationVar{}
	if err := db.GetApprovalReadDb().Where(&gapprovalModel.ApprovalOrder{JinjianId: orderId}).First(&order).Error; err != nil {
		return nil, err

	} else {
		if order.PbHousingLoanDt != "" {
			if order.PbHousingLoanDt == "无" {
				return -1, nil
			}
			housingLoanDate := strings.Split(order.PbHousingLoanDt, "-")

			if len(housingLoanDate) < 3 {
				return nil, errors.New("身份证有效日期格式解析错误")
			}
			Year, _ := strconv.Atoi(housingLoanDate[0])
			Month, _ := strconv.Atoi(housingLoanDate[1])

			countMonth := (Year-time.Now().Year())*12 + (Month - int(time.Now().Month()))

			return countMonth, nil

		} else {
			return nil, errors.New("房贷日期字段为空")
		}
	}
}

//获取贷款五级分类
func getLoanStatus(orderId string) (interface{}, error) {
	if pbLoanStatus, err := getDataFromApprovalQuantizationVar(orderId, "PbLoanStatus"); err != nil {
		return nil, err
	} else {

		switch pbLoanStatus.(string) {
		case "次级", "损失", "可疑", "关注":
			return 1, nil
		default:
			return -1, nil
		}
	}
}

//获取近12月贷款审批查询次数
func getM12LoanAppCnt(orderId string) (interface{}, error) {
	if pbM12LoanAppCnt, err := getDataFromApprovalQuantizationVar(orderId, "PbM12LoanAppCnt"); err != nil {
		return -1, err
	} else {
		return strconv.Atoi(pbM12LoanAppCnt.(string))
	}
}

//封装ApprovalQuantizationVar表数据简单查询操作
func getDataFromApprovalQuantizationVar(orderId string, columeName string) (interface{}, error) {
	order := gapprovalModel.ApprovalQuantizationVar{}
	if err := db.GetApprovalReadDb().Where(&gapprovalModel.ApprovalOrder{JinjianId: orderId}).First(&order).Error; err != nil {
		return nil, err
	} else {
		rv := reflect.ValueOf(order)
		if rv.FieldByName(columeName).Interface() != nil {
			return rv.FieldByName(columeName).Interface(), nil
		} else {
			return nil, errors.New("没有该属性:" + columeName)
		}
	}
}

// 根据审批单id获取规则
func GetRuleData(orderId string, args []*model.RuleArg) (model.RuleData, error) {
	//添加缓存, 避免多次调用同一个方法
	var tmpResults = make(map[string]interface{})
	result := model.RuleData{}
	for _, arg := range args {
		//如果缓存里面有对应key的值, 则直接从缓存里取值
		if b, ok := tmpResults[arg.ArgKey]; ok {
			result[arg.ArgKey] = b
			continue
		}
		if RuleDataFunc[arg.ArgKey] == nil {
			logger.Warn("获取规则参数的值，但是没有实现对应的方法", "key", arg.ArgKey, "arg name", arg.Name)
			continue
		}
		if tmpData, err := RuleDataFunc[arg.ArgKey](orderId); err != nil {
			logger.Error("获取参数值报错", "err", err.Error(), "key", arg.ArgKey)
			return nil, err
		} else {
			// 如果返回的是一个map, 则将其存进缓存. 并将当前的key值赋给result
			if b, ok := tmpData.(map[string]interface{}); ok {
				for key, value := range b {
					tmpResults[key] = value
				}
				result[arg.ArgKey] = tmpResults[arg.ArgKey]
				continue
			}
			result[arg.ArgKey] = tmpData
		}
	}
	return result, nil
}


const (
	// 默认的启元规则组的id
	QyRuleShowId = "Rule_1517454734748"
	RuleEngineHost = "http://jrule-engine-app:3000"
)
// 根据审批单id获取规则执行结果
// 1. 先根据规则id获取规则配置
// 2. 从规则配置中拿到规则所需的参数
// 3. 用参数获取规则执行所需的数据
// 4. 用规则所需的数据去执行规则，获取规则执行结果
func GetRuleResult(req *req_model.GetRuleResultReq) (*req_model.RuleConf, error) {
	ruleShowId := req.RuleShowId
	if ruleShowId == "" {
		ruleShowId = QyRuleShowId
	}

	// 如果不执行刷新，则直接去数据库查，查不到就去远端执行
	if !req.ShouldRefresh {
		var result model.RuleResult
		// 获取最新的一条执行结果，如果查到了，且结果解析正确了，则直接返回，否则需要从远端去执行规则
		if err := config.GetDb().Model(&model.RuleResult{}).Where("sp_order_id=?", req.OrderId).Order("id desc").First(&result).Error; err == nil {
			var rc req_model.RuleConf
			if err = util.ParseJson(result.Result, &rc); err == nil {
				logger.Info("查到以前执行的规则结果", "id", result.ID, "oid", result.SpOrderId)
				return &rc, nil
			}
		}
	}
	// 从远端获取规则结果，如果成功了，就会在里边保存结果，因此外边不用保存了
	if rc, err := ruleResultFromRemote(req.OrderId, ruleShowId); err != nil {
		return nil, err
	} else {
		return rc, nil
	}
}
// 去规则引擎获取规则执行结果（这里获取到结果后会直接保存，因此外边不用再保存了）
func ruleResultFromRemote(spOrderId string, ruleShowId string) (*req_model.RuleConf, error) {
	// 获取规则配置
	rc, err := getRuleConf(ruleShowId)
	if err != nil {
		logger.Info("获取规则配置报错", "err", err.Error())
		return nil, err
	}

	// 获取当前单规则所需参数的值
	args := getRuleArgsFromRuleConf(rc)
	ruleData, err := GetRuleData(spOrderId, args)
	if err != nil {
		logger.Info("获取规则所需数据报错", "err", err.Error())
		return nil, err
	}

	// 保存上一步获取的参数值
	saveRuleData(spOrderId, ruleData)

	// 执行规则
	result, err := executeRule(ruleShowId, ruleData)
	if err != nil {
		logger.Info("执行规则报错", "err", err.Error())
		return nil, err
	}

	// 预处理参数值，供前端显示
	preHandlerRuleData(ruleData)

	// 整理执行结果
	logger.Info("规则执行结果:" + util.StringifyJson(result))
	for _, r := range rc.Rules {
		tmpResult, _ := result[r.Key + "_result"].(string)
		r.ExecutedResult = tmpResult
		for _, d := range r.RuleArgs {
			d.ArgValue = "无结果"
			if _, ok := ruleData[d.ArgKey]; ok {
				d.ArgValue = ruleData[d.ArgKey]
			}
		}
	}
	// 保存执行结果
	if err := config.GetDb().Model(&model.RuleResult{}).Create(&model.RuleResult{
		SpOrderId: spOrderId,
		RuleShowId: ruleShowId,
		Result: util.StringifyJson(rc),
	}).Error; err != nil {
		logger.Error("保存规则执行结果报错", "err", err.Error())
	}
	return rc, nil
}
// 执行规则
func executeRule(rId string, rData model.RuleData) (result map[string]interface{}, err error) {
	logger.Info("调用执行规则，rule data:" + util.StringifyJson(rData), "rule id", rId)
	var resp req_model.ExecuteRuleResp
	if err = util.GeneralJsonPost(RuleEngineHost + "/api/v1/rule_engine/execute", map[string]interface{}{
		"ruleShowId": rId,
		"ruleData": rData,
	}, &resp); err != nil {
		return
	} else if resp.Data == nil {
		return nil, errors.New("规则引擎返回的执行结果为nil")
	}
	return resp.Data, nil
}
// 根据规则配置获取规则所需的所有参数
func getRuleArgsFromRuleConf(rc *req_model.RuleConf) ([]*model.RuleArg) {
	// 用于去重
	tmpArgs := map[string]*model.RuleArg{}
	for _, r := range rc.Rules {
		for _, a := range r.RuleArgs {
			tmpArgs[a.ArgKey] = a
		}
	}
	result := []*model.RuleArg{}
	for _, tmpA := range tmpArgs {
		result = append(result, tmpA)
	}
	return result
}
// 根据规则id获取规则配置
func getRuleConf(rId string) (rc *req_model.RuleConf, err error) {
	logger.Info("获取规则配置", "rule id", rId)
	var result req_model.GetRuleConfResp
	if err = util.GeneralHttpJsonGet(RuleEngineHost + "/api/v1/rule_engine/rule/" + rId, &result); err != nil {
		return
	} else if result.Data == nil {
		return nil, errors.New("规则引擎返回的规则配置不正确")
	}
	ruleConfStr, _ := result.Data["ruleConf"].(string)
	var ruleConf req_model.RuleConf
	if err = util.ParseJson(ruleConfStr, &ruleConf); err != nil {
		logger.Warn("无法解析规则引擎返回的规则配置", "err", err.Error())
		return
	}
	rc = &ruleConf
	return
}

// 保存规则所需参数的值
func saveRuleData(spOrderID string, m model.RuleData) {
	if err := config.GetDb().Create(&model.RuleArgValue{
		SpOrderId: spOrderID,
		ValueJson: util.StringifyJson(m),
	}).Error; err != nil {
		logger.Error("saveRuleData#插入数据库报错", "err", err.Error())
	}
}

// 预审批参数值，供前端显示
func preHandlerRuleData(m model.RuleData) {
	if _, ok := m["have_house"]; ok && m["have_house"] != nil {
		switch m["have_house"] {
		case 0:
			m["have_house"] = "无"
		case 1:
			m["have_house"] = "有"
		}
	}
	if _, ok := m["housing_loan_dt"]; ok && m["housing_loan_dt"] != nil {
		v := m["housing_loan_dt"].(int)
		if v == -1 {
			m["housing_loan_dt"] = "无"
		} else if v < 0 {
			m["housing_loan_dt"] = -v
		}
	}
	if _, ok := m["match_id_info"]; ok && m["match_id_info"] != nil {
		switch m["match_id_info"] {
		case 0:
			m["match_id_info"] = "不确定"
		case 1:
			m["match_id_info"] = "匹配"
		case -1:
			m["match_id_info"] = "不匹配"
		}
	}
	if _, ok := m["user_id_num"]; ok && m["user_id_num"] != nil {
		switch m["user_id_num"] {
		case 1:
			m["user_id_num"] = "是"
		case -1:
			m["user_id_num"] = "否"
		}
	}
	// 最后处理为空的
	for _, k := range []string{"have_house", "bound_cards", "main_call_times", "is_three_false", "have_court_info", "multi_point_count",
		"in_fushu_blacklist", "DTI", "M2_loan_app_cnt", "user_id_num", "id_expiry_date", "user_age", "match_id_info", "loan_overdue_mth",
		"crt_overdue_amt", "crt_overdue_mth", "quantization_point", "housing_loan_dt", "loan_status", "M12_loan_app_cnt"} {
		if _, ok := m[k]; ok {
			if m[k] == nil {
				m[k] = "无结果"
			}
		} else {
			m[k] = "无结果"
		}
	}
}