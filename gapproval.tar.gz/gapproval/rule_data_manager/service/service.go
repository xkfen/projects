package service

import (
	"gapproval/rule_data_manager/model"
	"gapproval/rule_data_manager/db/config"
	"github.com/jinzhu/gorm"
)

// 获取规则参数值 服务
func GetRuleArgValueService(jinjianID string) (m *model.RuleArgValue, err error) {
	m = &model.RuleArgValue{}
	if err := config.GetDb().Where("jinjian_id=?", jinjianID).Order("created_at desc").Find(m).Error; err != nil {
		if err.Error() != gorm.ErrRecordNotFound.Error() {
			return nil, nil
		}
		return nil, err
	}
	return
}
