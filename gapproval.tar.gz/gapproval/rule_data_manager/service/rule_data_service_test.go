package service

import (
	"github.com/stretchr/testify/suite"
	"testing"
	"gcoresys/common/logger"
	"gcoresys/common/util"
	"strconv"
	"griskcontrol/riskcontrol/model"
	"fmt"
	gapprovalModel "gapproval/approval/model"
	griskcontrolModel "griskcontrol/riskcontrol/model"
	"gapproval/approval/db/config"
	griskcontrolConfig "griskcontrol/riskcontrol/db/config"
	"time"
	"strings"
)

type testingSuite struct {
	suite.Suite
}

func (suite *testingSuite) SetupTest() {

}

func (suite *testingSuite) TearDownTest() {
	config.ClearAllData()
	ClearAllRiskControlTestData()
	griskcontrolConfig.ClearAllData()
}

func (suite *testingSuite) TestParseInterview() {
	interviewStr := `{"houseDeeds":null,"bao_dan_plan":[{"id":277,"created_at":"2018-01-31T16:26:11+08:00","updated_at":"2018-01-31T16:27:16+08:00","deleted_at":null,"plan_num":"","order_id":"order_1517383064569","plan_type":"BaoDan","plan_name":"保单贷(满5年)","plan_content":"[{\"policy_name\":\"平安\",\"policy_number\":\"4632\",\"policy_effective_date\":\"2011-04-06\",\"policy_amount\":6798,\"payment_method\":\"年缴\",\"payment_times\":7,\"is_valid\":1,\"policy_total\":1,\"policy_valid_total\":1,\"policy_amount_total\":6798}]","files_url":[{"id":16195,"created_at":"2018-01-31T16:25:22+08:00","updated_at":"2018-01-31T16:25:22+08:00","deleted_at":null,"orderId":"order_1517383064569","fileType":"policy","fileTypeName":"","file":"/assets/uploads/order_1517383064569/file_1517387121588884486.pdf","planNum":"","username":"mqliaolishan"},{"id":16321,"created_at":"2018-01-31T18:50:40+08:00","updated_at":"2018-01-31T18:50:40+08:00","deleted_at":null,"orderId":"order_1517383064569","fileType":"policy","fileTypeName":"","file":"/assets/uploads/order_1517383064569/file_1517395840195422276.png","planNum":"","username":"mqliaolishan"}],"files_url_a":[],"IsUpdate":false}],"fang_chan_plan":[],"score":"4.5分","policy":null,"other":[],"credit_report":[{"id":16203,"created_at":"2018-01-31T16:27:08+08:00","updated_at":"2018-01-31T16:27:08+08:00","deleted_at":null,"orderId":"order_1517383064569","fileType":"credit_report","fileTypeName":"","file":"/assets/uploads/order_1517383064569/credit_report/file_1517387227878093997.pdf","planNum":"","username":"mqliaolishan"}],"creditReport":null,"contracts":[],"video_path":"","loanBank":[{"id":897,"created_at":"2018-01-31T16:29:34+08:00","updated_at":"2018-01-31T16:29:34+08:00","deleted_at":null,"order_id":"order_1517383064569","bank_name":"中国民生银行","bank_num":"6226220680828323","cellphone":"13430498788","bank_address":"广东省_深圳市","bank_url":"/assets/uploads/order_1517383064569/file_1517387071024525205.png","files_url":[{"id":16193,"created_at":"2018-01-31T16:24:31+08:00","updated_at":"2018-01-31T16:24:31+08:00","deleted_at":null,"orderId":"order_1517383064569","fileType":"loan_bank_card","fileTypeName":"","file":"/assets/uploads/order_1517383064569/file_1517387071024525205.png","planNum":"","username":"mqliaolishan"}]}],"remark":"1.面签通过，2.客户简版征信：zzh2230,密码：a123456,无验证码。3、公司员工4个，客户名下在深圳有小产权房，用途装修，张志霞是客户妹妹。","sound":null,"insurance_policy":null,"interview_video":null,"idCards":[{"id":16197,"created_at":"2018-01-31T16:26:51+08:00","updated_at":"2018-01-31T16:26:51+08:00","deleted_at":null,"orderId":"order_1517383064569","fileType":"id_card_a","fileTypeName":"","file":"/assets/uploads/order_1517383064569/file_1517387211449238314.png","planNum":"","username":"mqliaolishan"},{"id":16199,"created_at":"2018-01-31T16:26:57+08:00","updated_at":"2018-01-31T16:26:57+08:00","deleted_at":null,"orderId":"order_1517383064569","fileType":"id_card_b","fileTypeName":"","file":"/assets/uploads/order_1517383064569/file_1517387216906351908.png","planNum":"","username":"mqliaolishan"},{"id":16201,"created_at":"2018-01-31T16:27:01+08:00","updated_at":"2018-01-31T16:27:01+08:00","deleted_at":null,"orderId":"order_1517383064569","fileType":"id_card_c","fileTypeName":"","file":"/assets/uploads/order_1517383064569/file_1517387221048798722.png","planNum":"","username":"mqliaolishan"}],"yue_gong_plan":[],"comment":"客户张志宏，平安新一贷0进件，批款0万。"}`

	interviewJson := map[string]interface{}{}
	err := util.ParseJson(interviewStr, &interviewJson)
	suite.Equal(nil, err)

	suite.Equal(0, len(interviewJson["fang_chan_plan"].([]interface{})))
	//plan := []model.JinjianPlan{}
	//err := util.ParseJson(interviewJson[""], &interviewJson)

}

func (suite *testingSuite) TestGetQuantizationPoint() {
	order := gapprovalModel.GetDefaultApprovalOrder()

	config.GetDb().Create(&order)

		config.GetDb().Create(&order)

		data ,err := getQuantizationPoint(order.JinjianId)

		if suite.NoError(err) {
			suite.Equal(order.QuantizationPoint, data)
		}
}

func (suite *testingSuite) TestGetUserIdNum() {
	orderJson := `{"CIPB001":"1991-1-1","CIPB002":"六","CIPB003":"身份证","CIPB004":"330825197110067548","CIPB005":"2020-1-1","CIPB006":"女","CIPB007":"1971-10-06","CIPB008":"未婚","CIPB009":"高中","CIPB010":"123","CIPB011":"1234","CIPB012":"0","CIPB013":"0","CIPB014":"0","CIPB015":"0","CIPB016":"1991.01","CIPB017":"1991.01","CIPB018":"1991.01","CIPB019":"0","CIPB020":"0","CIPB021":"0","CIPB022":"0","CIPB023":"0","CIPB024":"0","CIPB025":"10","CIPB026":"10","CIPB027":"1","CIPB028":"1","CIPB029":"1","CIPB030":"1","CIPB031":"1","CIPB032":"1","CIPB033":"1","CIPB034":"1","CIPB035":"1","CIPB036":"1","CIPB037":"1","CIPB038":"1","CIPB039":"无","CIPB040":"无","CIPB041":"正常","CIPB042":"0","CIPB043":"0","CIPB044":"0","CIPB045":"0","CIPB046":"0","CIPB047":"0","CIPB048":"0","CIPB049":"0","CIPB050":"0","CIPB051":"0","CIPB052":"0","CIPB053":"0","CIPB054":"0","CIPB055":"0","CIPB056":"0","CIPB057":"0","CIPB058":"0","CIPB059":"1991-1-1","CIPB060":"0","CIPB061":"1991-1-1","CIPB062":"0","CIPB063":"0","CIPB064":"0","CIPB065":"0","CIPB066":"0","CIPB067":"0","CIPB068":"0","CIPB069":"0","CIPB070":"0","CIPB071":"0","CIPB072":"0","CIPB073":"0","CIPB074":"0","CIPB075":"0","CIPB076":"0","CIPB077":"0","CIPB078":"0","CIPB079":"0","CIPB080":"无","CIPB081":"无","CIPB082":"无","CIPB083":"0","CIPB084":"0","CIPB085":"无","CIPB086":"有","CIPB087":"有","CIPB088":"有","CIPB089":"0","CIPB090":"0","CIPB091":"0","CIPB092":"0","CIPB093":"0","CIPB094":"0","CIPB095":"0","CIPB096":"0","CIPB097":"0","CIPB098":"0.10","CIPB099":"1991-1-1","CIPB100":"0","CIPB101":"","CIPB102":"0","created_at":"2018-01-15T17:06:58+08:00","deleted_at":null,"id":1,"jinjian_id":"order_1514516168239","updated_at":"2018-02-05T15:49:39+08:00"}`
	order := gapprovalModel.ApprovalQuantizationVar{}
	if err := util.ParseJson(orderJson, &order); err != nil {
		fmt.Println(err.Error())
	} else {

		config.GetDb().Create(&order)

		idNum,err := getUserIdNum("order_1514516168239")

		if suite.NoError(err) {
			suite.Equal(-1, idNum)
		}
	}
}

func (suite *testingSuite) TestGetUserAge() {
	orderJson := `{"CIPB001":"1991-1-1","CIPB002":"六","CIPB003":"身份证","CIPB004":"330825197110067548","CIPB005":"2020-1-1","CIPB006":"女","CIPB007":"1971-10-06","CIPB008":"未婚","CIPB009":"高中","CIPB010":"123","CIPB011":"1234","CIPB012":"0","CIPB013":"0","CIPB014":"0","CIPB015":"0","CIPB016":"1991.01","CIPB017":"1991.01","CIPB018":"1991.01","CIPB019":"0","CIPB020":"0","CIPB021":"0","CIPB022":"0","CIPB023":"0","CIPB024":"0","CIPB025":"10","CIPB026":"10","CIPB027":"1","CIPB028":"1","CIPB029":"1","CIPB030":"1","CIPB031":"1","CIPB032":"1","CIPB033":"1","CIPB034":"1","CIPB035":"1","CIPB036":"1","CIPB037":"1","CIPB038":"1","CIPB039":"无","CIPB040":"无","CIPB041":"正常","CIPB042":"0","CIPB043":"0","CIPB044":"0","CIPB045":"0","CIPB046":"0","CIPB047":"0","CIPB048":"0","CIPB049":"0","CIPB050":"0","CIPB051":"0","CIPB052":"0","CIPB053":"0","CIPB054":"0","CIPB055":"0","CIPB056":"0","CIPB057":"0","CIPB058":"0","CIPB059":"1991-1-1","CIPB060":"0","CIPB061":"1991-1-1","CIPB062":"0","CIPB063":"0","CIPB064":"0","CIPB065":"0","CIPB066":"0","CIPB067":"0","CIPB068":"0","CIPB069":"0","CIPB070":"0","CIPB071":"0","CIPB072":"0","CIPB073":"0","CIPB074":"0","CIPB075":"0","CIPB076":"0","CIPB077":"0","CIPB078":"0","CIPB079":"0","CIPB080":"无","CIPB081":"无","CIPB082":"无","CIPB083":"0","CIPB084":"0","CIPB085":"无","CIPB086":"有","CIPB087":"有","CIPB088":"有","CIPB089":"0","CIPB090":"0","CIPB091":"0","CIPB092":"0","CIPB093":"0","CIPB094":"0","CIPB095":"0","CIPB096":"0","CIPB097":"0","CIPB098":"0.10","CIPB099":"1991-1-1","CIPB100":"0","CIPB101":"","CIPB102":"0","created_at":"2018-01-15T17:06:58+08:00","deleted_at":null,"id":1,"jinjian_id":"order_1514516168239","updated_at":"2018-02-05T15:49:39+08:00"}`
	order := gapprovalModel.ApprovalQuantizationVar{}
	if err := util.ParseJson(orderJson, &order); err != nil {
		fmt.Println(err.Error())
	} else {

		config.GetDb().Create(&order)

		testAge,err := getUserAge("order_1514516168239")

		config.GetDb().Where(&gapprovalModel.ApprovalQuantizationVar{JinjianId: "order_1514516168239"}).First(&order)
		birthday := strings.Split(order.PbBirthday,"-")

		birYear,_ := strconv.Atoi(birthday[0])
		birMonth,_ := strconv.Atoi(birthday[1])

		age := time.Now().Year() - birYear

		if int(time.Now().Month()) < birMonth {
			age--
		}

		if suite.NoError(err) {
			suite.Equal(age,testAge)
		}
	}
}

func (suite *testingSuite) TestGetIdExpiryDate() {
	orderJson := `{"CIPB001":"1991-1-1","CIPB002":"六","CIPB003":"身份证","CIPB004":"330825197110067548","CIPB005":"2020-1-1","CIPB006":"女","CIPB007":"1971-10-06","CIPB008":"未婚","CIPB009":"高中","CIPB010":"123","CIPB011":"1234","CIPB012":"0","CIPB013":"0","CIPB014":"0","CIPB015":"0","CIPB016":"1991.01","CIPB017":"1991.01","CIPB018":"1991.01","CIPB019":"0","CIPB020":"0","CIPB021":"0","CIPB022":"0","CIPB023":"0","CIPB024":"0","CIPB025":"10","CIPB026":"10","CIPB027":"1","CIPB028":"1","CIPB029":"1","CIPB030":"1","CIPB031":"1","CIPB032":"1","CIPB033":"1","CIPB034":"1","CIPB035":"1","CIPB036":"1","CIPB037":"1","CIPB038":"1","CIPB039":"无","CIPB040":"无","CIPB041":"正常","CIPB042":"0","CIPB043":"0","CIPB044":"0","CIPB045":"0","CIPB046":"0","CIPB047":"0","CIPB048":"0","CIPB049":"0","CIPB050":"0","CIPB051":"0","CIPB052":"0","CIPB053":"0","CIPB054":"0","CIPB055":"0","CIPB056":"0","CIPB057":"0","CIPB058":"0","CIPB059":"1991-1-1","CIPB060":"0","CIPB061":"1991-1-1","CIPB062":"0","CIPB063":"0","CIPB064":"0","CIPB065":"0","CIPB066":"0","CIPB067":"0","CIPB068":"0","CIPB069":"0","CIPB070":"0","CIPB071":"0","CIPB072":"0","CIPB073":"0","CIPB074":"0","CIPB075":"0","CIPB076":"0","CIPB077":"0","CIPB078":"0","CIPB079":"0","CIPB080":"无","CIPB081":"无","CIPB082":"无","CIPB083":"0","CIPB084":"0","CIPB085":"无","CIPB086":"有","CIPB087":"有","CIPB088":"有","CIPB089":"0","CIPB090":"0","CIPB091":"0","CIPB092":"0","CIPB093":"0","CIPB094":"0","CIPB095":"0","CIPB096":"0","CIPB097":"0","CIPB098":"0.10","CIPB099":"1991-1-1","CIPB100":"0","CIPB101":"","CIPB102":"0","created_at":"2018-01-15T17:06:58+08:00","deleted_at":null,"id":1,"jinjian_id":"order_1514516168239","updated_at":"2018-02-05T15:49:39+08:00"}`
	order := gapprovalModel.ApprovalQuantizationVar{}
	if err := util.ParseJson(orderJson, &order); err != nil {
		fmt.Println(err.Error())
	} else {

		config.GetDb().Create(&order)

		rasult, err := getIdExpiryDate("order_1514516168239")

		if suite.NoError(err) {
			countMonth := (2020 - time.Now().Year())*12 + (1 - int(time.Now().Month()))
			if countMonth > 1 {
				suite.Equal(1, rasult)
			} else {
				suite.Equal(-1, rasult)
			}
		}
	}
}

func (suite *testingSuite) TestGetIdInfo() {
	idCardInfoJson := `{"area":"广西壮族自治区桂林市临桂县","birthday":"1993年06月30日","card":"450322199306300014","created_at":"2018-01-16T11:44:25+08:00","deleted_at":null,"error_msg":"","error_msg2":"","id":1,"jin_jian_id":"order_1516073879255","name":"郑柏屹","result":"matched","task_status":"1","updated_at":"2018-01-16T11:44:25+08:00"}`
	idCardInfo := griskcontrolModel.IDCard{}
	if err := util.ParseJson(idCardInfoJson, &idCardInfo); err != nil {
		fmt.Println(err.Error())
	} else {

		griskcontrolConfig.GetDb().Create(&idCardInfo)

		result,err := getIdInfo("order_1516073879255")

		if suite.NoError(err) {
			suite.Equal(1, result)
		}
	}
}

func (suite *testingSuite) TestGetLoanOverdueMth() {
	orderJson := `{"CIPB001":"1991-1-1","CIPB002":"六","CIPB003":"身份证","CIPB004":"330825197110067548","CIPB005":"2020-1-1","CIPB006":"女","CIPB007":"1971-10-06","CIPB008":"未婚","CIPB009":"高中","CIPB010":"123","CIPB011":"1234","CIPB012":"0","CIPB013":"0","CIPB014":"0","CIPB015":"0","CIPB016":"1991.01","CIPB017":"1991.01","CIPB018":"1991.01","CIPB019":"0","CIPB020":"0","CIPB021":"0","CIPB022":"0","CIPB023":"0","CIPB024":"0","CIPB025":"10","CIPB026":"10","CIPB027":"1","CIPB028":"1","CIPB029":"1","CIPB030":"1","CIPB031":"1","CIPB032":"1","CIPB033":"1","CIPB034":"1","CIPB035":"1","CIPB036":"1","CIPB037":"1","CIPB038":"1","CIPB039":"无","CIPB040":"无","CIPB041":"正常","CIPB042":"0","CIPB043":"0","CIPB044":"0","CIPB045":"0","CIPB046":"0","CIPB047":"0","CIPB048":"0","CIPB049":"0","CIPB050":"0","CIPB051":"0","CIPB052":"0","CIPB053":"0","CIPB054":"0","CIPB055":"0","CIPB056":"0","CIPB057":"0","CIPB058":"0","CIPB059":"1991-1-1","CIPB060":"0","CIPB061":"1991-1-1","CIPB062":"0","CIPB063":"0","CIPB064":"0","CIPB065":"0","CIPB066":"0","CIPB067":"0","CIPB068":"0","CIPB069":"0","CIPB070":"0","CIPB071":"0","CIPB072":"0","CIPB073":"0","CIPB074":"0","CIPB075":"0","CIPB076":"0","CIPB077":"0","CIPB078":"0","CIPB079":"0","CIPB080":"无","CIPB081":"无","CIPB082":"无","CIPB083":"0","CIPB084":"0","CIPB085":"无","CIPB086":"有","CIPB087":"有","CIPB088":"有","CIPB089":"0","CIPB090":"0","CIPB091":"0","CIPB092":"0","CIPB093":"0","CIPB094":"0","CIPB095":"0","CIPB096":"0","CIPB097":"0","CIPB098":"0.10","CIPB099":"1991-1-1","CIPB100":"0","CIPB101":"","CIPB102":"0","created_at":"2018-01-15T17:06:58+08:00","deleted_at":null,"id":1,"jinjian_id":"order_1514516168239","updated_at":"2018-02-05T15:49:39+08:00"}`
	order := gapprovalModel.ApprovalQuantizationVar{}
	if err := util.ParseJson(orderJson, &order); err != nil {
		fmt.Println(err.Error())
	} else {

		config.GetDb().Create(&order)

		rasult ,err := getLoanOverdueMth("order_1514516168239")

		if suite.NoError(err) {
			suite.Equal(0, rasult)
		}
	}
}

func (suite *testingSuite) TestGetCrtOverdueAmt() {
	orderJson := `{"CIPB001":"1991-1-1","CIPB002":"六","CIPB003":"身份证","CIPB004":"330825197110067548","CIPB005":"2020-1-1","CIPB006":"女","CIPB007":"1971-10-06","CIPB008":"未婚","CIPB009":"高中","CIPB010":"123","CIPB011":"1234","CIPB012":"0","CIPB013":"0","CIPB014":"0","CIPB015":"0","CIPB016":"1991.01","CIPB017":"1991.01","CIPB018":"1991.01","CIPB019":"0","CIPB020":"0","CIPB021":"0","CIPB022":"0","CIPB023":"0","CIPB024":"0","CIPB025":"10","CIPB026":"10","CIPB027":"1","CIPB028":"1","CIPB029":"1","CIPB030":"1","CIPB031":"1","CIPB032":"1","CIPB033":"1","CIPB034":"1","CIPB035":"1","CIPB036":"1","CIPB037":"1","CIPB038":"1","CIPB039":"无","CIPB040":"无","CIPB041":"正常","CIPB042":"0","CIPB043":"0","CIPB044":"0","CIPB045":"0","CIPB046":"0","CIPB047":"0","CIPB048":"0","CIPB049":"0","CIPB050":"0","CIPB051":"0","CIPB052":"0","CIPB053":"0","CIPB054":"0","CIPB055":"0","CIPB056":"0","CIPB057":"0","CIPB058":"0","CIPB059":"1991-1-1","CIPB060":"0","CIPB061":"1991-1-1","CIPB062":"0","CIPB063":"0","CIPB064":"0","CIPB065":"0","CIPB066":"0","CIPB067":"0","CIPB068":"0","CIPB069":"0","CIPB070":"0","CIPB071":"0","CIPB072":"0","CIPB073":"0","CIPB074":"0","CIPB075":"0","CIPB076":"0","CIPB077":"0","CIPB078":"0","CIPB079":"0","CIPB080":"无","CIPB081":"无","CIPB082":"无","CIPB083":"0","CIPB084":"0","CIPB085":"无","CIPB086":"有","CIPB087":"有","CIPB088":"有","CIPB089":"0","CIPB090":"0","CIPB091":"0","CIPB092":"0","CIPB093":"0","CIPB094":"0","CIPB095":"0","CIPB096":"0","CIPB097":"0","CIPB098":"0.10","CIPB099":"1991-1-1","CIPB100":"0","CIPB101":"","CIPB102":"0","created_at":"2018-01-15T17:06:58+08:00","deleted_at":null,"id":1,"jinjian_id":"order_1514516168239","updated_at":"2018-02-05T15:49:39+08:00"}`
	order := gapprovalModel.ApprovalQuantizationVar{}
	if err := util.ParseJson(orderJson, &order); err != nil {
		fmt.Println(err.Error())
	} else {

		config.GetDb().Create(&order)

		rasult ,err := getCrtOverdueAmt("order_1514516168239")

		if suite.NoError(err) {
			suite.Equal(0, rasult)
		}
	}
}

func (suite *testingSuite) TestGetCrtOverdueMth() {
	orderJson := `{"CIPB001":"1991-1-1","CIPB002":"六","CIPB003":"身份证","CIPB004":"330825197110067548","CIPB005":"2020-1-1","CIPB006":"女","CIPB007":"1971-10-06","CIPB008":"未婚","CIPB009":"高中","CIPB010":"123","CIPB011":"1234","CIPB012":"0","CIPB013":"0","CIPB014":"0","CIPB015":"0","CIPB016":"1991.01","CIPB017":"1991.01","CIPB018":"1991.01","CIPB019":"0","CIPB020":"0","CIPB021":"0","CIPB022":"0","CIPB023":"0","CIPB024":"0","CIPB025":"10","CIPB026":"10","CIPB027":"1","CIPB028":"1","CIPB029":"1","CIPB030":"1","CIPB031":"1","CIPB032":"1","CIPB033":"1","CIPB034":"1","CIPB035":"1","CIPB036":"1","CIPB037":"1","CIPB038":"1","CIPB039":"无","CIPB040":"无","CIPB041":"正常","CIPB042":"0","CIPB043":"0","CIPB044":"0","CIPB045":"0","CIPB046":"0","CIPB047":"0","CIPB048":"0","CIPB049":"0","CIPB050":"0","CIPB051":"0","CIPB052":"0","CIPB053":"0","CIPB054":"0","CIPB055":"0","CIPB056":"0","CIPB057":"0","CIPB058":"0","CIPB059":"2018-1-1","CIPB060":"0","CIPB061":"1991-1-1","CIPB062":"0","CIPB063":"0","CIPB064":"0","CIPB065":"0","CIPB066":"0","CIPB067":"0","CIPB068":"0","CIPB069":"0","CIPB070":"0","CIPB071":"0","CIPB072":"0","CIPB073":"0","CIPB074":"0","CIPB075":"0","CIPB076":"0","CIPB077":"0","CIPB078":"0","CIPB079":"0","CIPB080":"无","CIPB081":"无","CIPB082":"无","CIPB083":"0","CIPB084":"0","CIPB085":"无","CIPB086":"有","CIPB087":"有","CIPB088":"有","CIPB089":"0","CIPB090":"0","CIPB091":"0","CIPB092":"0","CIPB093":"0","CIPB094":"0","CIPB095":"0","CIPB096":"0","CIPB097":"0","CIPB098":"0.10","CIPB099":"1991-1-1","CIPB100":"0","CIPB101":"","CIPB102":"0","created_at":"2018-01-15T17:06:58+08:00","deleted_at":null,"id":1,"jinjian_id":"order_1514516168239","updated_at":"2018-02-05T15:49:39+08:00"}`
	order := gapprovalModel.ApprovalQuantizationVar{}
	if err := util.ParseJson(orderJson, &order); err != nil {
		fmt.Println(err.Error())
	} else {

		config.GetDb().Create(&order)

		rasult ,err := getCrtOverdueMth("order_1514516168239")

		if suite.NoError(err) {
			suite.Equal(0, rasult)
		}
	}
}

func (suite *testingSuite) TestGetHousingLoanDt() {
	orderJson := `{"CIPB001":"1991-1-1","CIPB002":"六","CIPB003":"身份证","CIPB004":"330825197110067548","CIPB005":"2020-1-1","CIPB006":"女","CIPB007":"1971-10-06","CIPB008":"未婚","CIPB009":"高中","CIPB010":"123","CIPB011":"1234","CIPB012":"0","CIPB013":"0","CIPB014":"0","CIPB015":"0","CIPB016":"1991.01","CIPB017":"1991.01","CIPB018":"1991.01","CIPB019":"0","CIPB020":"0","CIPB021":"0","CIPB022":"0","CIPB023":"0","CIPB024":"0","CIPB025":"10","CIPB026":"10","CIPB027":"1","CIPB028":"1","CIPB029":"1","CIPB030":"1","CIPB031":"1","CIPB032":"1","CIPB033":"1","CIPB034":"1","CIPB035":"1","CIPB036":"1","CIPB037":"1","CIPB038":"1","CIPB039":"无","CIPB040":"无","CIPB041":"正常","CIPB042":"0","CIPB043":"0","CIPB044":"0","CIPB045":"0","CIPB046":"0","CIPB047":"0","CIPB048":"0","CIPB049":"0","CIPB050":"0","CIPB051":"0","CIPB052":"0","CIPB053":"0","CIPB054":"0","CIPB055":"0","CIPB056":"0","CIPB057":"0","CIPB058":"0","CIPB059":"2019-1-1","CIPB060":"0","CIPB061":"1991-1-1","CIPB062":"0","CIPB063":"0","CIPB064":"0","CIPB065":"0","CIPB066":"0","CIPB067":"0","CIPB068":"0","CIPB069":"0","CIPB070":"0","CIPB071":"0","CIPB072":"0","CIPB073":"0","CIPB074":"0","CIPB075":"0","CIPB076":"0","CIPB077":"0","CIPB078":"0","CIPB079":"0","CIPB080":"无","CIPB081":"无","CIPB082":"无","CIPB083":"0","CIPB084":"0","CIPB085":"无","CIPB086":"有","CIPB087":"有","CIPB088":"有","CIPB089":"0","CIPB090":"0","CIPB091":"0","CIPB092":"0","CIPB093":"0","CIPB094":"0","CIPB095":"0","CIPB096":"0","CIPB097":"0","CIPB098":"0.10","CIPB099":"1991-1-1","CIPB100":"0","CIPB101":"","CIPB102":"0","created_at":"2018-01-15T17:06:58+08:00","deleted_at":null,"id":1,"jinjian_id":"order_1514516168239","updated_at":"2018-02-05T15:49:39+08:00"}`
	order := gapprovalModel.ApprovalQuantizationVar{}
	if err := util.ParseJson(orderJson, &order); err != nil {
		fmt.Println(err.Error())
	} else {

		config.GetDb().Create(&order)

		rasult ,err := getHousingLoanDt("order_1514516168239")

		config.GetDb().Where(&gapprovalModel.ApprovalOrder{JinjianId: "order_1514516168239"}).First(&order)
		housingLoanDate := strings.Split(order.PbHousingLoanDt,"-")
		Year,_ := strconv.Atoi(housingLoanDate[0])
		Month,_ := strconv.Atoi(housingLoanDate[1])

		countMonth := (Year - time.Now().Year())*12 + (Month - int(time.Now().Month()))

		if suite.NoError(err) {
			suite.Equal(countMonth, rasult)
		}
	}
}

func (suite *testingSuite) TestGetLoanStatus() {
	orderJson := `{"CIPB001":"1991-1-1","CIPB002":"六","CIPB003":"身份证","CIPB004":"330825197110067548","CIPB005":"2020-1-1","CIPB006":"女","CIPB007":"1971-10-06","CIPB008":"未婚","CIPB009":"高中","CIPB010":"123","CIPB011":"1234","CIPB012":"0","CIPB013":"0","CIPB014":"0","CIPB015":"0","CIPB016":"1991.01","CIPB017":"1991.01","CIPB018":"1991.01","CIPB019":"0","CIPB020":"0","CIPB021":"0","CIPB022":"0","CIPB023":"0","CIPB024":"0","CIPB025":"10","CIPB026":"10","CIPB027":"1","CIPB028":"1","CIPB029":"1","CIPB030":"1","CIPB031":"1","CIPB032":"1","CIPB033":"1","CIPB034":"1","CIPB035":"1","CIPB036":"1","CIPB037":"1","CIPB038":"1","CIPB039":"无","CIPB040":"无","CIPB041":"正常","CIPB042":"0","CIPB043":"0","CIPB044":"0","CIPB045":"0","CIPB046":"0","CIPB047":"0","CIPB048":"0","CIPB049":"0","CIPB050":"0","CIPB051":"0","CIPB052":"0","CIPB053":"0","CIPB054":"0","CIPB055":"0","CIPB056":"0","CIPB057":"0","CIPB058":"0","CIPB059":"1991-1-1","CIPB060":"0","CIPB061":"1991-1-1","CIPB062":"0","CIPB063":"0","CIPB064":"0","CIPB065":"0","CIPB066":"0","CIPB067":"0","CIPB068":"0","CIPB069":"0","CIPB070":"0","CIPB071":"0","CIPB072":"0","CIPB073":"0","CIPB074":"0","CIPB075":"0","CIPB076":"0","CIPB077":"0","CIPB078":"0","CIPB079":"0","CIPB080":"无","CIPB081":"无","CIPB082":"无","CIPB083":"0","CIPB084":"0","CIPB085":"无","CIPB086":"有","CIPB087":"有","CIPB088":"有","CIPB089":"0","CIPB090":"0","CIPB091":"0","CIPB092":"0","CIPB093":"0","CIPB094":"0","CIPB095":"0","CIPB096":"0","CIPB097":"0","CIPB098":"0.10","CIPB099":"1991-1-1","CIPB100":"0","CIPB101":"","CIPB102":"0","created_at":"2018-01-15T17:06:58+08:00","deleted_at":null,"id":1,"jinjian_id":"order_1514516168239","updated_at":"2018-02-05T15:49:39+08:00"}`
	order := gapprovalModel.ApprovalQuantizationVar{}
	if err := util.ParseJson(orderJson, &order); err != nil {
		fmt.Println(err.Error())
	} else {

		config.GetDb().Create(&order)

		rasult ,err := getLoanStatus("order_1514516168239")

		if suite.NoError(err) {
			suite.Equal(-1, rasult)
		}
	}
}

func (suite *testingSuite) TestGetM12LoanAppCnt() {
	orderJson := `{"CIPB001":"1991-1-1","CIPB002":"六","CIPB003":"身份证","CIPB004":"330825197110067548","CIPB005":"2020-1-1","CIPB006":"女","CIPB007":"1971-10-06","CIPB008":"未婚","CIPB009":"高中","CIPB010":"123","CIPB011":"1234","CIPB012":"0","CIPB013":"0","CIPB014":"0","CIPB015":"0","CIPB016":"1991.01","CIPB017":"1991.01","CIPB018":"1991.01","CIPB019":"0","CIPB020":"0","CIPB021":"0","CIPB022":"0","CIPB023":"0","CIPB024":"0","CIPB025":"10","CIPB026":"10","CIPB027":"1","CIPB028":"1","CIPB029":"1","CIPB030":"1","CIPB031":"1","CIPB032":"1","CIPB033":"1","CIPB034":"1","CIPB035":"1","CIPB036":"1","CIPB037":"1","CIPB038":"1","CIPB039":"无","CIPB040":"无","CIPB041":"正常","CIPB042":"0","CIPB043":"0","CIPB044":"0","CIPB045":"0","CIPB046":"0","CIPB047":"0","CIPB048":"0","CIPB049":"0","CIPB050":"0","CIPB051":"0","CIPB052":"0","CIPB053":"0","CIPB054":"0","CIPB055":"0","CIPB056":"0","CIPB057":"0","CIPB058":"0","CIPB059":"2018-1-1","CIPB060":"0","CIPB061":"1991-1-1","CIPB062":"0","CIPB063":"0","CIPB064":"0","CIPB065":"0","CIPB066":"0","CIPB067":"0","CIPB068":"0","CIPB069":"0","CIPB070":"0","CIPB071":"0","CIPB072":"0","CIPB073":"0","CIPB074":"0","CIPB075":"0","CIPB076":"0","CIPB077":"0","CIPB078":"0","CIPB079":"0","CIPB080":"无","CIPB081":"无","CIPB082":"无","CIPB083":"0","CIPB084":"0","CIPB085":"无","CIPB086":"有","CIPB087":"有","CIPB088":"有","CIPB089":"0","CIPB090":"0","CIPB091":"0","CIPB092":"0","CIPB093":"0","CIPB094":"22","CIPB095":"0","CIPB096":"0","CIPB097":"0","CIPB098":"0.10","CIPB099":"1991-1-1","CIPB100":"0","CIPB101":"","CIPB102":"0","created_at":"2018-01-15T17:06:58+08:00","deleted_at":null,"id":1,"jinjian_id":"order_1514516168239","updated_at":"2018-02-05T15:49:39+08:00"}`
	order := gapprovalModel.ApprovalQuantizationVar{}
	if err := util.ParseJson(orderJson, &order); err != nil {
		fmt.Println(err.Error())
	} else {

		config.GetDb().Create(&order)

		rasult ,err := getM12LoanAppCnt("order_1514516168239")

		if suite.NoError(err) {
			suite.Equal(22,rasult) //CIPB094
		}
	}
}

// ***********************    Zebreay start    ***********************
func (s *testingSuite) TestGetCallTimes() {
	var tmpPhone model.Phone
	//var phoneStatement model.PhoneStatement
	connectedDb := griskcontrolConfig.GetDb()
	connectedDb.AutoMigrate(&model.Phone{})
	connectedDb.AutoMigrate(&model.PhoneStatement{})
	connectedDb.Create(&model.Phone{ JinJianID:"100", Name:"zeb", Phone:"13145828984", Provider:"none", Province:"hn", City:"gl", Analysis:"nalysis", IsMain:"1"})
	connectedDb.Create(&model.Phone{ JinJianID:"100", Name:"zeb", Phone:"13145820000", Provider:"none", Province:"hn", City:"gl", Analysis:"nalysis", IsMain:"0"})

	connectedDb.Model(&tmpPhone).Where("is_main='0' AND jin_jian_id='100'").First(&tmpPhone)
	for i := 1; i < 11 ; i++{
		connectedDb.Create(&model.PhoneStatement{PhoneID:tmpPhone.ID,CallUsedTime:strconv.Itoa(i)})
	}
	count, err := getMainCallTimes("100")
	s.Equal(nil, err)
	s.Equal(0, count)
	count, err = getSecondCallTimes("100")
	s.Equal(nil, err)
	s.Equal(10, count)
}

func (s *testingSuite) TestGetThreeFalse() {
	var result [3]interface{}
	var err [3]error
	data := [3]gapprovalModel.ThreePartyInfo{
		{JinjianId: "1", ThreeFalse: 1},
		{JinjianId: "2", ThreeFalse: 2},
		{JinjianId: "3", ThreeFalse: 0},}
	cdb := config.GetDb()
	for i, x := range data {
		cdb.Create(&x)
		result[i], err[i] = getThreeFalse(x.JinjianId)
	}
	s.Equal(1, result[0])
	s.Equal(-1, result[1])
	s.Equal("没有该条数据", err[2].Error())
}

func (s *testingSuite) TestGetCourtInfoAndExecMoney()  {
	var testList model.BlackList
	connectedDb := griskcontrolConfig.GetDb()
	connectedDb.AutoMigrate(&model.BlackList{})
	connectedDb.AutoMigrate(&model.FahaiGrayListData{})
	connectedDb.Create(&model.BlackList{JinJianID:"123", Source:"fahai", InBlackList:true, TaskStatus:"1"})
	connectedDb.Create(&model.BlackList{JinJianID:"124", Source:"fahai", InBlackList:false, TaskStatus:"1"})
	connectedDb.Model(&model.BlackList{}).Where("jin_jian_id='123'").Order("created_at desc").First(&testList)
	connectedDb.Create(&model.FahaiGrayListData{BlackListID:testList.ID, DataType:"zxgg", ExecMoney:float64(9999)})

	results, err := getCourtInfoAndExecMoney("123")
	s.Equal(nil, err)
	s.Equal("是", results.(map[string]interface{})["have_court_info"].(string))
	s.Equal(int(9999), results.(map[string]interface{})["exec_amount"].(int))

	results, err = getCourtInfoAndExecMoney("124")
	s.Equal(nil, err)
	s.Equal("否", results.(map[string]interface{})["have_court_info"].(string))
	s.Equal(int(0), results.(map[string]interface{})["exec_amount"].(int))
}

func ClearAllRiskControlTestData() {
		tmpDb := griskcontrolConfig.GetDb()
		if tmpDb == nil {
			fmt.Println("尚未初始化数据库")
			return
		}
		if rs, err := tmpDb.Raw("show tables;").Rows(); err == nil {
			var tName string
			for rs.Next() {
				rs.Scan(&tName)
				// data_sources carrier_ids 两个有初始数据，不需要清除
				if tName != "" && tName != "data_sources" && tName != "carrier_ids"{
					tmpDb.Exec(fmt.Sprintf("delete from %s", tName))
				}
			}
		}
}

func (s *testingSuite) TestGetMultiPointCount()  {
	connectedDb := griskcontrolConfig.GetDb()
	connectedDb.AutoMigrate(&model.Multipoint{})
	connectedDb.Create(&model.Multipoint{JinJianID:"123456789", RegisterCount:2, TaskStatus:"1"})
	connectedDb.Create(&model.Multipoint{JinJianID:"1234567890", RegisterCount:1, TaskStatus:"-1"})

	count, err := getMultiPointCount("123456789")
	s.Equal(nil, err)
	s.Equal(2, count)
	count, err = getMultiPointCount("1234567890")
	s.Equal(nil, err)
	s.Equal(0, count)
}

func (s *testingSuite) TestGetInFushuBlacklist() {
	connectedDb := griskcontrolConfig.GetDb()
	connectedDb.AutoMigrate(&model.BlackList{})
	connectedDb.Create(&model.BlackList{JinJianID:"100", Source:"富数", InBlackList:true, TaskStatus:"1"})
	connectedDb.Create(&model.BlackList{JinJianID:"101", Source:"富数", InBlackList:true, TaskStatus:"-1"})
	connectedDb.Create(&model.BlackList{JinJianID:"102", Source:"富数", InBlackList:false, TaskStatus:"1"})
	connectedDb.Create(&model.BlackList{JinJianID:"103", Source:"富数", InBlackList:true, TaskStatus:"1"})
	connectedDb.Create(&model.BlackList{JinJianID:"103", Source:"富数", InBlackList:true, TaskStatus:"1"})

	inBlacklist, err := getInFushuBlacklist("100")
	s.Equal(nil, err)
	s.Equal(1, inBlacklist)
	inBlacklist, err = getInFushuBlacklist("101")
	s.Equal(nil, err)
	s.Equal(0, inBlacklist)
	inBlacklist, err = getInFushuBlacklist("102")
	s.Equal(nil, err)
	s.Equal(0, inBlacklist)
	inBlacklist, err = getInFushuBlacklist("103")
	s.Equal(nil, err)
	s.Equal(2, inBlacklist)
}

//func (s *testingSuite) TestGetDTI() {
//	connectedDb := config.GetDb()
//	connectedDb.Create(&gapprovalModel.ApprovalOrder{JinjianId:"123", RiskParam:"{\"r8\":\"28000\",\"r14\":\"0\",\"r1\":\"POLICY_LOAN\",\"r12\":\"98035\",\"r15\":[{\"type\":\"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK\",\"content\":{\"loanAmount\":\"100000\",\"monthlyRepayment\":\"3633\",\"loanBalance\":\"75010\",\"remainingPeriod\":\"25\",\"loanAgency\":\"平安银行\",\"loanDate\":\"2017-2-14\"}},{\"type\":\"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK\",\"content\":{\"loanDate\":\"2017-12-15\",\"loanAmount\":\"48000\",\"monthlyRepayment\":\"1680\",\"loanBalance\":\"48000\",\"remainingPeriod\":\"20\",\"loanAgency\":\"微众银行\"}}],\"r3\":42768,\"r27\":46.61,\"r13\":\"51.87\",\"r4\":142560,\"r5\":[{\"name\":\"0\",\"amount\":\"0\"}],\"r6\":\"6514.09\",\"r29\":24,\"r9\":\"189000\",\"r2\":{\"policyList\":[{\"policy_amount\":594,\"policy_effective_date\":\"2015-01-17\",\"policy_valid_total\":1,\"payment_method\":\"月缴\",\"policy_total\":1,\"policy_amount_total\":7128,\"policy_name\":\"平安保险\",\"policy_number\":\"P050000013518978\",\"is_valid\":1,\"payment_times\":37}],\"name\":\"保单贷（满3年）\"},\"r21\":0,\"r10\":\"76995\",\"r22\":148000,\"r7\":348658.09,\"r26\":83.18,\"r19\":0,\"r24\":5313,\"version\":\"v1.0\",\"r23\":123010,\"r18\":5313,\"r30\":0.6,\"r20\":0,\"r25\":48.52,\"r28\":50000,\"r11\":\"40.74\",\"r16\":148000,\"r17\":123010}"})
//	connectedDb.Create(&gapprovalModel.ApprovalOrder{JinjianId:"999", RiskParam:"{\"r8\":\"28000\",\"r14\":\"0\",\"r1\":\"POLICY_LOAN\",\"r12\":\"98035\",\"r15\":[{\"type\":\"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK\",\"content\":{\"loanAmount\":\"100000\",\"monthlyRepayment\":\"3633\",\"loanBalance\":\"75010\",\"remainingPeriod\":\"25\",\"loanAgency\":\"平安银行\",\"loanDate\":\"2017-2-14\"}},{\"type\":\"DEBT_TYPE_CREDIT_LOANS_PEOPLE_BANK\",\"content\":{\"loanDate\":\"2017-12-15\",\"loanAmount\":\"48000\",\"monthlyRepayment\":\"1680\",\"loanBalance\":\"48000\",\"remainingPeriod\":\"20\",\"loanAgency\":\"微众银行\"}}],\"r3\":null,\"r27\":46.61,\"r13\":\"51.87\",\"r4\":142560,\"r5\":[{\"name\":\"0\",\"amount\":\"0\"}],\"r6\":\"6514.09\",\"r29\":24,\"r9\":\"189000\",\"r2\":{\"policyList\":[{\"policy_amount\":594,\"policy_effective_date\":\"2015-01-17\",\"policy_valid_total\":1,\"payment_method\":\"月缴\",\"policy_total\":1,\"policy_amount_total\":7128,\"policy_name\":\"平安保险\",\"policy_number\":\"P050000013518978\",\"is_valid\":1,\"payment_times\":37}],\"name\":\"保单贷（满3年）\"},\"r21\":0,\"r10\":\"76995\",\"r22\":148000,\"r7\":348658.09,\"r26\":83.18,\"r19\":0,\"r24\":5313,\"version\":\"v1.0\",\"r23\":123010,\"r18\":5313,\"r30\":0.6,\"r20\":0,\"r25\":48.52,\"r28\":50000,\"r11\":\"40.74\",\"r16\":148000,\"r17\":123010}"})
//
//	dti, err := getDTI("123")
//	s.Equal(nil, err)
//	//s.Equal(0.12422839506172839, dti)
//	dti, err = getDTI("999")
//	s.Equal("数据不完整,请检查ApprovalOrders.RiskParam数据;", err.Error())
//	s.Equal(nil, dti)
//}
//
//func (s *testingSuite) TestGetM2LoanAppCnt()  {
//	gapprovalDb := config.GetDb()
//	gapprovalDb.Create(&gapprovalModel.ApprovalOrder{JinjianId:"100", UserIdNum:"516504610"})
//	griskcontrolDb := griskcontrolConfig.GetDb()
//	griskcontrolDb.Create(&model.SimpleCreditReport{InputIDCardNum:"516504610"})
//	var testdata model.SimpleCreditReport
//	griskcontrolDb.First(&testdata)
//	griskcontrolDb.Create(&model.SCRQueryRecord{SCRBase:model.SCRBase{SimpleCreditReportID:testdata.ID}, QueryReason:"贷款审批", QueryTime:"2018年1月1日"})
//
//	now := time.Now()
//	year, month, day := now.Date()
//	queryTime := fmt.Sprintf("%d年%d月%d日", year, month, day)
//
//	griskcontrolDb.Create(&model.SCRQueryRecord{SCRBase:model.SCRBase{SimpleCreditReportID:testdata.ID}, QueryReason: "贷款审批", QueryTime: queryTime})
//
//	count, err := getM2LoanAppCnt("100")
//	s.Equal(nil, err)
//	s.Equal(1, count)
//}
// ***********************    Zebreay finish   ***********************

func TestRun(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)

	griskcontrolConfig.GetRiskcontrolDbConfig("test")
	griskcontrolConfig.GetDb().LogMode(false)
	//common.ENV = "test"
	//go StartHttpServer("test")
	suite.Run(t, new(testingSuite))
}