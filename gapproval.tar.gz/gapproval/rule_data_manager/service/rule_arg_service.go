package service

import (
	"gapproval/rule_data_manager/model"
	"gapproval/rule_data_manager/db/config"
	"gcoresys/common/util"
)

// 分页获取规则参数列表
func GetRuleArgs(page int, perPage int) ([]*model.RuleArg, int, int) {
	var result []*model.RuleArg
	totalPages, totalCount := util.GetDataByPageAndPerPage(config.GetDb().Model(&model.RuleArg{}), page, perPage, &model.RuleArg{}, &result)
	return result, totalPages, totalCount
}

