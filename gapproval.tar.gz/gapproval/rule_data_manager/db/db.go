package main

import (
	"fmt"
	"gapproval/rule_data_manager/db/config"
	"gapproval/rule_data_manager/model"
	"gcoresys/common/mysql"
	"flag"
	"gcoresys/common"
)

func main() {
	common.DefineDbMigrateCommonFlag()
	env := common.DefineRunTimeCommonFlag()
	action := flag.Lookup("action").Value.String()
	switch action {
	case "create":
		doCreate(env)
	case "drop":
		doDrop(env)
	case "migrate":
		doMigrate(env)
	}
}

func doCreate(env string) {
	fmt.Println("do create")
	dbConfig := config.GetRuleDataDbConfig(env)
	mysql.CreateDB(dbConfig)
}

func doDrop(env string) {
	fmt.Println("do drop")
	dbConfig := config.GetRuleDataDbConfig(env)
	mysql.DropDB(dbConfig)
}

func doMigrate(env string) {
	fmt.Println("do migrate and gen data")
	config.GetRuleDataDbConfig(env)
	db := config.GetDb()
	db.AutoMigrate(&model.RuleArg{}, &model.RuleResult{})
	// 生成参数
	genRuleArgs()
}

// 生成参数
func genRuleArgs() {
	fmt.Println("生成参数")
	for _, arg := range ruleArgs {
		if arg.ArgKey == "" {
			fmt.Println("参数的key为空:" + arg.Name)
			continue
		}
		tmpArg := model.RuleArg{}
		// 如果有了这条参数，则不用创建了
		config.GetDb().Model(&model.RuleArg{}).Where("arg_key=?", arg.ArgKey).First(&tmpArg)
		if tmpArg.ID != 0 {
			continue
		}
		if err := config.GetDb().Model(&model.RuleArg{}).Create(arg).Error; err != nil {
			panic("创建参数报错:" + err.Error())
		}
	}
}

var ruleArgs = []*model.RuleArg{
	{
		Name:   "是否有房",
		ArgKey: "have_house",
		VType:  "int",
	},
	//**********************//by
	{
		Name:   "绑定银行卡少于两张（两银行卡必须同名、同身份证号）",
		ArgKey: "bound_cards",
		VType:  "int",
	},
	{
		Name:   "常用移动运营商：总通话次数",
		ArgKey: "main_call_times",
		VType:  "int",
	},
	{
		Name:   "补录移动运营商：总通话次数",
		ArgKey: "second_call_times",
		VType:  "int",
	},
	//{
	//	Name:   `“三非”客户`,
	//	ArgKey: "is_three_false",
	//	VType:  "int",
	//},
	{
		Name:   "是否有法院信息",
		ArgKey: "have_court_info",
		VType:  "string",
	},
	//{
	//	Name:   "申请人姓名+身份证 出现在法院黑名单",
	//	ArgKey: "exec_amount",
	//	VType:  "int",
	//},
	{
		Name:   "多头借贷数据",
		ArgKey: "multi_point_count",
		VType:  "int",
	},
	{
		Name:   "富数黑名单",
		ArgKey: "in_fushu_blacklist",
		VType:  "int",
	},
	{
		Name:   "信用负债/收入比（DTI）",
		ArgKey: "DTI",
		VType:  "float",
	},
	{
		Name:   "近2个月征信上纯贷款审批查询次数",
		ArgKey: "M2_loan_app_cnt",
		VType:  "int",
	},
	//**********************//zk
	{
		Name:"客户身份证号码以352201、352202、352224、352225、352227、352228、352229、352230、352231或3509开头",
		ArgKey:"user_id_num",
		VType:"int",
	},{
		Name:"身份证有效期截止日距审批日小于1个月",
		ArgKey:"id_expiry_date",
		VType:"int",
	},{
		Name:"年龄小于22周岁，或大于55周岁",
		ArgKey:"user_age",
		VType:"int",
	},{
		Name:"身份证公安部信息不匹配",
		ArgKey:"match_id_info",
		VType:"int",
	},{
		Name:"贷款当前逾期：当前逾期期数 ",
		ArgKey:"loan_overdue_mth",
		VType:"int",
	},{
		Name:"贷记卡当前逾期：当前逾期金额",
		ArgKey:"crt_overdue_amt",
		VType:"int",
	},{
		Name:"贷记卡当前逾期：当前逾期期数",
		ArgKey:"crt_overdue_mth",
		VType:"int",
	},{
		Name:"启元评分",
		ArgKey:"quantization_point",
		VType:"int",
	},{
		Name:"房产抵押日期距今",
		ArgKey:"housing_loan_dt",
		VType:"int",
	},{
		Name:"人行征信 - 信用卡、贷款出现负面 ",
		ArgKey:"loan_status",
		VType:"int",
	},{
		Name:"近12个月征信上纯贷款审批查询次数",
		ArgKey:"M12_loan_app_cnt",
		VType:"int",
	},
}
