package config

import (
	"gcoresys/common/mysql"
	"gcoresys/common/mysql/connection"
	"github.com/jinzhu/gorm"
)

// 记录当前运行时的数据库配置
var curDbConfig *mysql.DbConfig

// 获取mysql数据库配置，此处还可以加到配置文件去获取配置的逻辑
func GetRuleDataDbConfig(env string) *mysql.DbConfig {
	curDbConfig = mysql.NewDbConfig()
	switch env {
	case "prod":
		curDbConfig.DbName = "qy_rule_data_prod"
	case "test":
		curDbConfig.DbName = "qy_rule_data_test"
	default:
		curDbConfig.DbName = "qy_rule_data_dev"
	}
	return curDbConfig
}

// 获取当前服务的数据库连接
func GetDb() *gorm.DB {
	if curDbConfig == nil {
		panic("请先初始化数据库配置，调用：GetRuleDataDbConfig方法")
	}
	return connection.GetDb(curDbConfig)
}

// 清空当前数据库的所有数据
func ClearAllData() {
	connection.ClearAllData(curDbConfig)
}
