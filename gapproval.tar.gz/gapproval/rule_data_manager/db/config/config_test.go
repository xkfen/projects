package config

import "testing"

func TestClearAllData(t *testing.T) {
	GetRuleDataDbConfig("test")
	GetDb()
	ClearAllData()
}
