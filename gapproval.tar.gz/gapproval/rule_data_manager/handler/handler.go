package handler

import (
	"gopkg.in/gin-gonic/gin.v1"
	"gapproval/rule_data_manager/handler/req_model"
	"gcoresys/apigw/gw_common"
	"gapproval/rule_data_manager/service"
	"gcoresys/common/util"
	util2 "gsso/common/util"
	"gcoresys/common/logger"
)

// 获取参数列表
func GetRuleArgs(c *gin.Context) {
	logger.Info("获取参数", "page", c.Query("page"), "per_page", c.Query("per_page"))
	perPage := util2.StringToInt(c.Query("per_page"))
	page := util2.StringToInt(c.Query("page"))
	if perPage == 0 || page == 0 {
		gw_common.RenderError(c, "当前页和每页多少条不能为空")
		return
	}
	args, totalPages, totalCount := service.GetRuleArgs(page, perPage)
	c.JSON(200, req_model.GetRuleArgsResp{BaseResp: *util.GetBaseResp(nil, "获取成功"), TotalPages: totalPages, TotalCount: totalCount, RuleArgs: args})
}

// 获取规则所需的数据
func GetRuleData(c *gin.Context) {
	var req req_model.GetRuleDataReq
	if err := c.BindJSON(&req); err != nil {
		gw_common.RenderError(c, "无法解析该请求:" + err.Error())
		return
	} else if err = req.IsValid(); err != nil {
		gw_common.RenderError(c, err.Error())
		return
	}
	if result, err := service.GetRuleData(req.OrderId, req.RuleArgs); err != nil {
		gw_common.RenderError(c, err.Error())
	} else {
		c.JSON(200, req_model.GetRuleDataResp{BaseResp: *util.GetBaseResp(nil, "获取成功"), RuleData: result})
	}
}

// 直接获取规则执行的结果
func GetRuleResult(c *gin.Context) {
	var req req_model.GetRuleResultReq
	if err := c.BindJSON(&req); err != nil {
		gw_common.RenderError(c, "无法解析该请求:" + err.Error())
		return
	} else if err = req.IsValid(); err != nil {
		gw_common.RenderError(c, err.Error())
		return
	}
	// 获取某个审批单的规则执行结果
	if rc, err := service.GetRuleResult(&req); err != nil {
		gw_common.RenderError(c, err.Error())
		return
	} else {
		util.GinRenderJsonObjSuccess(c, &req_model.GetRuleResultResp{BaseResp: *util.GetSuccessBaseResp("获取成功"), Result: rc})
	}
}

// 获取规则参数的值
func GetRuleArgValueHandler(c *gin.Context) {
	var req req_model.GetRuleArgValueReq
	if err := c.BindJSON(&req); err != nil {
		gw_common.RenderError(c, "无法解析该请求:" + err.Error())
		return
	}
	if err := req.IsValid(); err != nil {
		gw_common.RenderError(c, err.Error())
		return
	}
	m, err := service.GetRuleArgValueService(req.OrderID)
	if err != nil {
		gw_common.RenderError(c, err.Error())
		return
	}
	util.GinRenderJsonObjSuccess(c, &req_model.GetRuleArgValueResp{
		BaseResp: *util.GetSuccessBaseResp("请求成功"),
		RuleArgValue: m,
	})
}
