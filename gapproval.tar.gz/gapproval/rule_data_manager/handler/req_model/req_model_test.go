package req_model

import (
	"testing"
	"fmt"
	"gapproval/rule_data_manager/model"
	"gcoresys/common/util"
	"gcoresys/common/logger"
)

func TestPrintModel(t *testing.T) {
	fmt.Println(util.StringifyJson(GetRuleArgsResp{RuleArgs: []*model.RuleArg{{}}}))

	fmt.Println(util.StringifyJson(GetRuleResultReq{}))
	fmt.Println(util.StringifyJson(GetRuleResultResp{Result: &RuleConf{Rules: []*Rule{{}}}}))
}

func TestParseRuleConf(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	confStr := `{"name": "启元规则组", "rules": [{"id": 1518402784530, "key": "1518402784530", "num": "1", "name": "1", "describe": "1", "rule_args": [{"id": 2, "key": "bound_cards", "name": "成功绑定银行卡数量", "v_type": "int", "created_at": "2018-02-10T15:04:36+08:00", "deleted_at": null, "updated_at": "2018-02-10T15:04:36+08:00"}, {"id": 1, "key": "have_house", "name": "是否有房", "v_type": "int", "created_at": "2018-02-10T15:04:36+08:00", "deleted_at": null, "updated_at": "2018-02-10T15:04:36+08:00"}], "pass_judge": {"id": 1518402795467, "arg": {"id": 2, "key": "bound_cards", "name": "成功绑定银行卡数量", "v_type": "int", "created_at": "2018-02-10T15:04:36+08:00", "deleted_at": null, "updated_at": "2018-02-10T15:04:36+08:00"}, "value": "2", "j_type": "basic", "operator": "=="}, "perform_rule": "        Integer boundCards = $data.getInteger(\"bound_cards\");\n        Integer haveHouse = $data.getInteger(\"have_house\");\n        if(boundCards == 2) {\n            $data.put(\"1518402784530_result\", \"pass\");\n        } else if(haveHouse == 0) {\n            $data.put(\"1518402784530_result\", \"reject\");\n        }", "reject_judge": {"id": 1518402805353, "arg": {"id": 1, "key": "have_house", "name": "是否有房", "v_type": "int", "created_at": "2018-02-10T15:04:36+08:00", "deleted_at": null, "updated_at": "2018-02-10T15:04:36+08:00"}, "value": "0", "j_type": "basic", "operator": "=="}, "review_judge": null, "check_requires": "JSONObject( (!Util.isNullJsonValue(\"bound_cards\", $data) && !Util.isNullJsonValue(\"have_house\", $data)) && (getInteger(\"bound_cards\") != 0 && getInteger(\"have_house\") != 0) )"}]}`
	var ruleConf RuleConf
	if err := util.ParseJson(confStr, &ruleConf); err != nil {
		logger.Error(err.Error())
	}
	fmt.Println(util.StringifyJson(ruleConf))
}
