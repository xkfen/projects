package req_model

import (
	"gcoresys/common/http"
	"gapproval/rule_data_manager/model"
	"errors"
)

type GetRuleDataReq struct {
	// 审批订单的id
	OrderId string							`json:"order_id"`
	// 规则的参数列表
	RuleArgs []*model.RuleArg				`json:"rule_args"`
}

func (getRuleDataReq *GetRuleDataReq) IsValid() error {
	switch {
	case getRuleDataReq.OrderId == "":
		return errors.New("审批订单号不能为空")
	case len(getRuleDataReq.RuleArgs) == 0:
		return errors.New("规则所需的参数个数不能为空")
	}
	return nil
}

type GetRuleDataResp struct {
	http.BaseResp
	// 规则的数据
	RuleData model.RuleData					`json:"rule_data"`
}

type GetRuleArgsResp struct {
	http.BaseResp
	// 一共多少页
	TotalPages int 							`json:"total_pages"`
	// 一共多少条
	TotalCount int 							`json:"total_count"`
	// 参数列表
	RuleArgs []*model.RuleArg				`json:"rule_args"`
}

// 获取规则结果
type GetRuleResultReq struct {
	// 审批订单的id
	OrderId string							`json:"order_id"`
	// 要执行的规则编号（可以为空，如果为空则取默认的启元规则组）
	RuleShowId string						`json:"rule_show_id"`
	// 标志是否需要重新执行一次规则
	ShouldRefresh bool						`json:"should_refresh"`
}

func (req *GetRuleResultReq)IsValid() error {
	switch {
	case req.OrderId == "":
		return errors.New("审批订单id不能为空")
	}
	return nil
}

type GetRuleResultResp struct {
	http.BaseResp
	// 结果
	Result *RuleConf				`json:"result"`
}




// ------------------- 请求规则引擎的model

type ExecuteRuleResp struct {
	http.BaseResp
	Data map[string]interface{} 			`json:"data"`
}
type GetRuleConfResp struct {
	http.BaseResp
	Data map[string]interface{}			`json:"data"`
}
type RuleConf struct {
	Name string 			`json:"name"`
	Rules []*Rule			`json:"rules"`
}
type Rule struct {
	Key string				`json:"key"`
	// 规则编号
	Num string				`json:"num"`
	// 规则名称
	Name string				`json:"name"`
	// 规则描述
	Describe string 		`json:"describe"`
	// 规则执行的结果（pass，reject，review）
	ExecutedResult string	`json:"executed_result"`
	// 规则的参数
	RuleArgs []*model.RuleArg		`json:"rule_args"`
	// 通过条件
	PassJudge map[string]interface{} 	`json:"pass_judge"`
	// 拒绝条件
	RejectJudge map[string]interface{}	`json:"reject_judge"`
	// 审慎条件
	ReviewJudge map[string]interface{}	`json:"review_judge"`
}

// ------------------- 请求规则引擎的model

// 获取规则参数的值
type GetRuleArgValueReq struct {
	OrderID string `json:"order_id"`
}
func (req *GetRuleArgValueReq) IsValid() error {
	if req.OrderID == "" {
		return errors.New("审批ID不能为空")
	}
	return nil
}

type GetRuleArgValueResp struct {
	http.BaseResp
	// 参数值数据
	RuleArgValue *model.RuleArgValue `json:"rule_arg_value"`
}