package handler

import (
	"gopkg.in/gin-gonic/gin.v1"
	"gcoresys/common/logger"
	gcGlobal "gcoresys/common"
)

func StartHttpServer(env string) {
	if env == gcGlobal.EnvProd {
		gin.SetMode(gin.ReleaseMode)
	}
	// 注册用户
	r := gin.Default() //获得路由实例
	v1 := r.Group("api/v1/rule_data")
	{
		// 分页获取参数列表
		v1.GET("/rule_args", GetRuleArgs)
		v1.POST("/rule_result", GetRuleResult)
		v1.POST("/rule_value", GetRuleArgValueHandler)
	}

	port := gcGlobal.GetHttpServerPort(gcGlobal.GPREVIEW_SERVER_PORT)
	logger.Info("服务启动完成", "port", port)
	//r.Static(model.PreChannelApprovalFileUrlPre, model.PreChannelApprovalFileSavePath)
	r.Run(":" + port)
}
