package model

import "gcoresys/common/mysql"

// 规则执行结果
type RuleResult struct {
	mysql.BaseModel
	// 审批的订单id
	SpOrderId string			`gorm:"index" json:"sp_order_id"`
	// 规则执行的结果（里边包含了各个判断条件），实际保存的是RuleConf
	Result string				`gorm:"type:longtext" json:"result"`
	// 执行的规则的id
	RuleShowId string			`json:"rule_show_id"`
}