package model

import "gcoresys/common/mysql"

type RuleArg struct {
	mysql.BaseModel
	// 参数的名称
	Name string					`json:"name"`
	// 参数的key
	ArgKey string				`gorm:"unique_index" json:"key"`
	// 参数值的类型
	VType string				`json:"v_type"`
	// 参数值，数据库不创建此字段
	ArgValue interface{} 		`sql:"-" json:"arg_value"`
}

type RuleData map[string]interface{}

type RuleArgValue struct {
	mysql.BaseModel
	// 审批的订单id
	SpOrderId string	`gorm:"index" json:"sp_order_id"`
	// 参数值，json格式
	ValueJson string 	`json:"value_json"`
}

