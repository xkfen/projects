#!/usr/bin/env bash

env=$1
if [ ! $env ];then
    env=dev
fi

go run db/db.go --action=drop --env=$1
go run db/db.go --action=create --env=$1
go run db/db.go --action=migrate --env=$1

cd ../../griskcontrol && ./init_env.sh test