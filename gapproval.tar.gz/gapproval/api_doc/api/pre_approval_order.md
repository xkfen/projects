##### 预审批订单列表
    call: /api/v2/approval/uniform_interface/QueryPreOrderList
    method: post
    header:
    {
        SsoToken:""
        ApprovalType:""
        
    }
    Request:
    with params
    {
        // all代表全部，"1":渠道(快速预审批),渠道(资料上传)可随意传
        "apply_type":"all", 
        // 搜索框，姓名，身份证，申请ID
        "condition": "",
        // 预审提交时间排序
        "commit_time":"desc", "asc"
        // 页数
        "page":1,
    }

    Response:
    {
        "success":true,
        "info":"成功",
        "data":{},
        "total_page":"", 总页数
        "total_count":"" 总共多少条
    }

#### 订单简要信息，显示进件方案，产品方案，预审编号，客户姓名，身份证号，订单状态；
    call: /api/v2/approval/uniform_interface/GetBriefPreOrderInfo
    method: post
    header:
    {
        SsoToken:""
        ApprovalType:""
    }
    Request:
    with params
    {
        "pre_approval_id":"",
    }

    Response:
        {
            "success":true,
            "info":"成功",
            "data":{},
            "total_page":"", 总页数
            "total_count":"" 总共多少条
        }



        进件方案：jinjian_plan
        
        产品方案：introduction_plan_num
        
        预审编号:pre_show_id
        
        客户姓名:user_name
        
        身份证号:user_id_num
        
        订单状态:pre_approval_status
        

#### 进件方案、姓名、身份证号、电话为可编辑项，点击编辑对这四个内容进行编辑
    call: /api/v2/approval/uniform_interface/UpdatePreOrderInfo
    method: post
    header:
    {
        SsoToken:""
        ApprovalType:""
        
    }
    Request:
    with params
    {
        "pre_approval_id":"",
        "jinjian_plan":"",
        "user_name":"",
        "user_id_num":"",
        "phone_number":""
    }
    response:
        {
            "success":true,
            "info":"修改成功",
        }

#### 预审详情
      call: /api/v2/approval/uniform_interface/QueryPreOrderInfo
         method: post
         header:
         {
             SsoToken:""
             ApprovalType:""
             
         }
         Request:
         with params
         {
             "pre_approval_id":"",
         }   
         以下是新版的返回参数: 
         Response:
          {
             "success":true,
             "info":"获取成功",
             // 进件方案
             "jinjian_plan":"",
             // 姓名
             "user_name":"",
             // 身份证号码
             "user_id_num":"",
             // 电话
             "phone_number":"",
             // 学历
             "education":"",
             // 预审编号
             "pre_show_id":"",
             // 预审类型:如果次数为1,说明是首次申请，否则为非首次
             
             // 提交预审时间
             "commit_time":""
             // 所属渠道
             "agency_name":"",
             // 渠道公司负责人
             "legal_person":"",
             // 业务员
             "agency_employee":"",
             // 业务员电话
             "employee_phone_number":"",
             // 客户经理
             "customer_managers":"",
             // 客户经理编号
             "customer_manager_nums":""
          }         

##### 预审批历史订单列表
    call: /api/v2/approval/uniform_interface/QueryHistoryPreOrderList
    method: post
    header:
    {
        SsoToken:""
        ApprovalType:""
        
    }
    Request:
    with params
    {
        "apply_type":"",
        "enter":"",
        "condition":"",
        "commit_time":"",
        "end_time":"",
        "jinjian_time":"",
        "page":0
    }
     
    Response:
    {
        "success":true,
        "info":"成功",
        "data":{},
        "total_page":"", 总页数
        "total_count":"" 总共多少条
    }
    
        

#### 预审详情
     使用旧版接口即可，以下是新版返回参数
         Response:
          {
             "success":true,
             "info":"获取成功",
             // 进件方案
             "jinjian_plan":"",
             // 姓名
             "user_name":"",
             // 身份证号码
             "user_id_num":"",
             // 电话
             "phone_number":"",
             // 学历
             "education":"",
             // 预审编号
             "pre_show_id":"",
             // 预审类型:如果次数为1,说明是首次申请，否则为非首次
             // 
             // 提交预审时间
             "commit_time":""
             // 所属渠道
             "agency_name":"",
             // 渠道公司负责人
             "legal_person":"",
             // 业务员
             "agency_employee":"",
             // 业务员电话
             "employee_phone_number":"",
             // 客户经理
             "customer_managers":"",
             // 客户经理编号
             "customer_manager_nums":""
          } 



#### 获取预审批列表
    call: /api/v2/approval/uniform_interface/QueryPreApprovalListByKey
        method: post
        header:
        {
            SsoToken:""
            ApprovalType:""
        }
    request:
       {    
       // key必传，"me"我的订单,"history":历史订单,"query":查询
       　　"key":"",
       //************ 我的订单**********
       // "all":全部，"1",快速预审批
       　　"apply_type":"",
       // 搜索条件条件
       　　"condition":"",
       　　"page":1,
       
       //*********历史订单**********
       // "all":全部，"1",快速预审批
      　　"apply_type":"",
      // 搜索条件条件
      　　"condition":"",
      　　"page":1,
       // 已进件/未进件
       　　"enter":"",
       // 预审批结束时间:asc/desc
       　　"end_time":"",
       // 进件时间：asc/desc
       　　"jinjian_time":"",
       
       //*****************查询************
       // 预审批人员姓名
       　　"pre_trail_name":"",
       // 预审id
       　　"pre_show_id":"",
       // 进件用户姓名
       　　"jin_jian_user_name":"",
       // 进件用户身份证号码
       　　"user_id_num":"",
       // 预审批筛选状态,"all"为查询所有状态
       　　"pre_status":"",
       // 所属渠道
       　　"agency_name":"",
       // 业务员
       　　"agency_employee":"",
       // 客户经理
           "customer_manager":""; 
       // 筛选的预审批申请开始时间
       　　"apply_start_time":null,
       // 筛选的预审批申请结束时间
       　　"apply_end_time":null,
       // 筛选的预审批结束开始时间
       　　"finish_start_time":null,
       // 筛选的预审批结束结束时间
       　　"finish_end_time":null,
       // 筛选的进件开始时间
       　　"jin_jian_start_time":null,
       // 筛选的进件结束时间
       　　"jin_jian_end_time":null,
       // 筛选"all":全部业务，"handling":在办业务，"ending":已完业务
       ""order_status:
       // 预审批提交时间，"asc":升序,"desc"降序
         　　"commit_time":"",
       // 预审批结束时间:asc/desc
        　　"end_time":"",
        // 进件时间：asc/desc
        　　"jinjian_time":"",
       // 下载所有
       　　"download_all":false
       
     //************排序*********
       sort什么都不传默认按照提交时间降序，sort,取值commit_time asc或者commit_time desc ; updated_at desc 或者updated_at asc ；jinjian_time asc 或者jinjian_time desc
         "sort":""
       }
       
       Response:
       {
            "data":{},
            "totalPages":
            "totalCount":
       }
       
       
#### 获取所有预审批文件
    call: /api/v2/approval/uniform_interface/GetPreApprovalFiles
    method: post
    header:
    {
        SsoToken:""
        ApprovalType:""
    }
    Request:
    with params
    {
        "pre_approval_id": 预审批ID
    }
    
    Response:
    {
        "data":{}, 
    }
    
#### 预审批文件操作
    call: /api/v2/pre_file_operations
    method: post
    header:
    {
        SsoToken:""
        ApprovalType:""
    }
    PostForm:
    {
        pre_approval_id: "xxx"
        file_type : ""
        id : 1
        action: "upload"   (upload上传, update更新, delete删除)[更新和删除要上传id]
        desc: "文件描述"
        stage: "ysp"      ("ysp"=预审批, "sp"=审批)
        upload: 文件
    }   

#### 预审批操作
    
    {
        旧接口~~
    }
    
#### 预审批查询--下载excel
    call: /api/v2/approval/uniform_interface/PreQueryDownloadExcelFile
        method: post
        header:
        {
            SsoToken:""
            ApprovalType:""
        }
        Request:
        {
           
        }   
        
        Response:
        {
            "data":url,
        }


#### 预审批查询--下载excel（以传入选择的订单的pre_approval_id下载）        
    call: /api/v2/approval/uniform_interface/DownloadPreOrderExcelFile
            method: post
            header:
            {
                SsoToken:""
                ApprovalType:""
            }
            Request:
            {
               "pre_approval_ids":{}
            }   
            
            Response:
            {
                "data":url,
            }
            
            
#### 预审批订单excel下载   
    call:/api/v1/pre_approval_query/download
    method:POST
    Request         