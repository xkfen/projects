##### 订单概括
    call: /api/v2/approval/uniform_interface/StatisticOrderCount
    method: post
    header:
    {
        SsoToken:""
        ApprovalType:""
    }


     Response:
        {
            "success":true,
            "info":"获取成功",
            "to_be_assign_count":待分配订单
            "my_to_do_order_count":, 我的待办订单
            "suspend_count": 挂起订单
            "return_count":回退订单
            "pre_repulse_count":预审打回订单
        }


##### 历史订单
    call: /api/v2/approval/uniform_interface/StatisticHistoryOrderCount
    method: post
    header:
    {
        SsoToken:""
        ApprovalType:""
    }

    Response:
            {
                "success":true,
                "info":"获取成功",
                "today_finished_order_count":今日完成订单
                "all_finished_order_count": 所有完成订单
            }