#!/usr/bin/env bash

root=`pwd`
password='luyun123'
readonly password

auto_ssh_c () {
    expect -c " set timeout -1;
                spawn ./shell_util/ssh_dev_or_preprod.sh $1 $2 $3;
                expect {
                    *assword:* {send -- $password\r;
                                 expect {
                                    *denied* {exit 2;}
                                    eof
                                 }
                    }
                    eof         {exit 1;}
                }
                "
    return $?
}

push_dev_opd () {
     echo '推送 docker 到 开发环境 ..... '
     ./shell_util/create_new_image.sh $1 $2

     read -p "请问你要更新 devk8s 审批pod吗？ 请回答 y/n   " is
         case ${is} in
           [Yy]* )
                auto_ssh_c devk8s devk8s shell_util/reset_approvl_dev.sh
                sleep 2s
                echo '更新请输入devk8s 开发环境 k8s pod ，请耐心等待36s'
                exit;;
           [Nn]* )
           echo 'docker 镜像推送成功，请手动去 k8s 更新pod'
           exit;;
         esac
     return $?
}

push_uat_opd () {
     if [ ! $1 ];then
        echo 'env不能为空 test | preprod'
        exit 2
     fi

     if [ $1 == "test" ];then
        echo '推送 docker 到 测试环境 ..... '
     fi

     if [ $1 == "preprod" ];then
        echo '推送 docker 到 预生产环境 ..... '
     fi

     ./shell_util/create_new_image.sh $1 $2

     echo $1'环境 k8s更新pod需要测试同学拉取镜像，请通知测试相关人员'
     return $?
}

push_prod_opd () {
    echo '这是要推生产环境的docker，你确定要推吗？测试写了吗？测试跑了吗？测试验收了吗？'
    read -p "三思啊麻瓜，真的要推生产吗？？？   请回答 y/n   " is
        case ${is} in
            [Yy]* )
                echo '推送 docker 到 生产环境 ..... '
                ./shell_util/create_new_image.sh $1 $2
                echo '生产环境 k8s更新pod需要网管同学拉取镜像，请通知网管'
                return $?
                break;;
            [Nn]* )
                exit;;
        esac
    return $?
}

#############################################################
#
#
#                      shell is funny
#
#
#############################################################

### $1
if [ ! $1 ] # 第一个参数为空的情况
then
    while true; do
        read -p "请问你要推docker吗, 请回答 y/n   " is
            case ${is} in
                [Yy]* )
                    read -p "请问你要推什么环境    " env
                        case ${env} in
                            dev )
                                push_dev_opd ${env}
                                break;;
                            test )
                                push_uat_opd ${env}
                                break;;
                            preprod )
                                push_uat_opd ${env}
                                break;;
                            prod )
                                push_prod_opd ${env}
                                break;;
                            * )
                                echo "你是麻瓜吗？？？ 推什么环境都不知道，回答 dev、test、preprod、prod";;
                        esac;
                    break;;
                [Nn]* )
                    exit;;
                * )
                    echo "Please answer yes or no.";;
            esac;
    done
   exit 0
else # 第一个参数不为空的情况
    case $1 in
        dev )
            push_dev_opd $1 $2
            ;;
        test )
            push_uat_opd $1 $2
            ;;
        preprod )
            push_uat_opd $1 $2
            ;;
        prod )
            push_prod_opd $1 $2
            ;;
        * )
            echo "第一个参数为要推的环境,请输入：dev、test、preprod、prod";;
    esac;
fi