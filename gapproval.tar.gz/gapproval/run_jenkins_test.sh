#!/usr/bin/env bash
root=`pwd`

if [ -d ~/go/src/gapproval/ ];then
    cd ~/go/src/gapproval/
    git pull origin master
fi

cd $root
make ctest
