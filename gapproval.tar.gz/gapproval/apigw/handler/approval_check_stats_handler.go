package handler

import (
	"gapproval/approval/grpc/client"
	"gapproval/approval/grpc/pb"
	"gapproval/tuningbox"
	"gapproval/common/gw"
	"gopkg.in/gin-gonic/gin.v1"
)

func CheckQyApprovalStats(c *gin.Context) {
	if respMsg, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		Method:     "check_stats",
	}); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respMsg.RpcReply)
	}
}

func CheckApigwStats(c *gin.Context) {
	c.JSON(200, gin.H{
		"success" : true,
		"stats": tuningbox.GetStats(),
	})
}
