package handler

import (
	"gapproval/common/gw"
	"gcoresys/common/util"
	"gopkg.in/gin-gonic/gin.v1"
	"gapproval/approval/grpc/client"
	"gapproval/approval/grpc/pb"
	"github.com/tidwall/gjson"
	"gapproval/common/tool"
	"gcoresys/common/logger"
	"strconv"
	"gapproval/approval/grpc/server"
	"gapproval/approval/model"
)

// 审批文件上传
func UploadApprovalFileHandler(c *gin.Context) {
	// 接受参数
	jinjianId := c.PostForm("jinjian_id")
	fileType := c.PostForm("file_type")
	action := c.PostForm("action")
	desc := c.PostForm("desc")
	var id int
	var err error
	if tmpId := c.PostForm("id"); tmpId != "" {
		id, err = strconv.Atoi(tmpId)
		if err != nil {
			gw.RenderError(c, "参数id出错, 请检查")
			return
		}
	}

	// 保存文件
	var fileUrl, fileName string
	if action == "update" || action == "upload" {
		fileUrl, fileName, err = tool.GetFileUrl(jinjianId, "upload", c)
		if err != nil {
			logger.Error("文件上传失败", "err", err)
			gw.RenderError(c, err.Error())
			return
		}
	}

	var params = map[string]interface{}{
		"jinjian_id": jinjianId,
		"file_type":  fileType,
		"file_name":  fileName,
		"file_url":   fileUrl,
		"action":     action,
		"desc":       desc,
		"id":         id,
	}

	// 调用grpc保存数据
	if respMsg, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		Method:       "ApprovalFile",
		RpcRequest:   util.StringifyJson(params),
		ApprovalType: c.Request.Header.Get("ApprovalType"),
		Username:     c.MustGet("username").(string),
		Name:         c.MustGet("name").(string),
		IsAuth:       true,
	}); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respMsg.RpcReply)
	}

}

// 打包下载审批资料
func DownloadApprovalFileHandler(c *gin.Context) {
	resp, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		RpcRequest:   string(getStringBodyFromGin(c, true)),
		Method:       "GetPackCompressedFiles",
		ApprovalType: c.Request.Header.Get("ApprovalType"),
		Username:     c.MustGet("username").(string),
		Name:         c.MustGet("name").(string),
		IsAuth:       true,
	})
	if err != nil {
		gw.RenderError(c, err.Error())
		return
	}

	data := gjson.Parse(resp.RpcReply)
	if !data.IsArray() {
		gw.RenderError(c, gjson.Get(resp.RpcReply, "info").Str)
		return
	}
	var fileUrls []string
	var jinjianId string
	for _, d := range data.Array() {
		fileUrls = append(fileUrls, d.Get("file_url").Str)
		if jinjianId == "" {
			jinjianId = d.Get("jinjian_id").Str
		}
	}

	if filePath, err := tool.ArchiveFileZIP(fileUrls, jinjianId); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, map[string]interface{}{"file_path": filePath, "success": true, "info": "打包成功"})
	}
}

// --------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------

func UploadApprovalFileV1(c *gin.Context) {
	jinjianId := c.PostForm("jinjian_id")
	fileType := c.PostForm("file_type")
	action := c.PostForm("action")
	desc := c.PostForm("desc")
	id := c.PostForm("id")
	name := c.MustGet("name").(string)

	var req server.ApprovalFileReq
	if action == "get" {
		req = server.ApprovalFileReq{Action: action, JinjianId: jinjianId}
	} else {
		fileUrl, fileName, err := tool.GetFileUrl(jinjianId, "upload", c)
		if err != nil {
			gw.RenderError(c, err.Error())
			return
		}
		req = server.ApprovalFileReq{
			ApprovalFile: &model.ApprovalFile{
				JinjianId: jinjianId,
				FileName:  fileName,
				FileType:  fileType,
				FileUrl:   fileUrl,
				Desc:      desc,
			},
			Action: action,
			OpName: name,
		}
		if action == "update" {
			u, _ := strconv.ParseUint(id, 0, 64)
			if id == "" || u == 0 {
				gw.RenderError(c, "id为空")
				return
			}

			req.ApprovalFile.BaseModel.ID = uint(u)
		}
	}

	if respMsg, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		Method:       "OldApprovalFile",
		RpcRequest:   util.StringifyJson(req),
		ApprovalType: c.Request.Header.Get("ApprovalType"),
		Username:     c.MustGet("username").(string),
		Name:         c.MustGet("name").(string),
		IsAuth:       true,
	}); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respMsg.RpcReply)
	}
}

func UploadFile(c *gin.Context) {
	jinjianId := c.PostForm("jinjianId")
	fileType := getFileType(c.PostForm("fileType"))
	if jinjianId == "" || fileType == "nil" {
		gw.RenderError(c, "jinjianId 或 fileType 错误")
		return
	}

	fileUrl, fileName, err := tool.GetFileUrl(jinjianId, "upload", c)
	if err != nil {
		gw.RenderError(c, err.Error())
		return
	}
	req := server.UploadApprovalFileReq{ApprovalUploadFile: &model.ApprovalUploadFile{
		JinjianId: jinjianId,
		FileName:  fileName,
		FileType:  fileType,
		FileUrl:   fileUrl,
	}}
	if respMsg, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		Method:       "UploadApprovalFile",
		RpcRequest:   util.StringifyJson(req),
		ApprovalType: c.Request.Header.Get("ApprovalType"),
		Username:     c.MustGet("username").(string),
		Name:         c.MustGet("name").(string),
		IsAuth:       true,
	}); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respMsg.RpcReply)
	}
}

func getFileType(fileType string) string {
	switch fileType {
	case "lh":
		return model.FT_LIANGHUABIANLIANG
	case "mq":
		return model.FT_MIANQINACAILIAO
	case "dh":
		return model.FT_DIANHE
	case "zx":
		return model.FT_ZHENGXINBAOGAO
	case "fc":
		return model.FT_FANGCHAN
	default:
		return "nil"
	}
}
