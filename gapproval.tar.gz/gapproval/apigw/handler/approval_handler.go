package handler

import (
	"gcoresys/common/logger"
	"gapproval/approval/grpc/client"
	"gapproval/approval/grpc/pb"
	"io/ioutil"
	"gapproval/common/gw"
	"gopkg.in/gin-gonic/gin.v1"
	"bytes"
)

// 审批统一接口处理 v2
func ApprovalNewHandler(c *gin.Context) {
	approvalType := c.Request.Header.Get("ApprovalType")
	logger.Info("==============审批账号类型", "approvalType", approvalType)

	method := c.Param("method")
	logger.Info("==============统一接口调用方法", "method", method)

	// 转发请求
	if respMsg, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		Method:       method,
		RpcRequest:   string(getStringBodyFromGin(c, false)),
		ApprovalType: approvalType,
		Username:     c.MustGet("username").(string),
		Name:         c.MustGet("name").(string),
		IsAuth:       true,
	}); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respMsg.RpcReply)
	}
}

// 审批统一接口处理 v1
func ApprovalHandler(c *gin.Context) {
	token := c.Request.Header.Get("SsoToken")
	approvalType := c.Request.Header.Get("ApprovalType")
	logger.Info("××××××××××××××审批账号类型", "approvalType", approvalType)

	method := c.Param("method")
	logger.Info("××××××××××××××统一接口调用方法", "method", method)

	authType := c.Param("auth_type")
	logger.Info("××××××××××××××统一接口授权类型", "authType", authType)

	reqMsg := &pb.ApprovalRpcReqMsg{
		Method:       method,
		RpcRequest:   string(getStringBodyFromGin(c, false)),
		ApprovalType: approvalType,
		IsAuth:       false,
	}
	// internal(内部) 接口验证token
	if authType == "internal" {
		username, name, err := ApprovalTokenAuth(token, approvalType)
		if err != nil {
			gw.RenderErrorNoAuth(c, err.Error())
			return
		}
		reqMsg.IsAuth = true
		reqMsg.Username = username
		reqMsg.Name = name
	}
	// 转发请求
	if respMsg, err := client.GetApprovalClient().ApprovalRpcHandler(c, reqMsg); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respMsg.RpcReply)
	}
}

func OldApiHandlerNoAuth(c *gin.Context, method string) {
	// 转发请求
	if respMsg, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		Method:     method,
		RpcRequest: string(getStringBodyFromGin(c, false)),
		IsAuth:     false,
	}); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respMsg.RpcReply)
	}
}

func OldApiHandlerAuth(c *gin.Context, method string) {
	// 转发请求
	if respMsg, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		Method:       method,
		RpcRequest:   string(getStringBodyFromGin(c, false)),
		ApprovalType: c.Request.Header.Get("ApprovalType"),
		Username:     c.MustGet("username").(string),
		Name:         c.MustGet("name").(string),
		IsAuth:       true,
	}); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respMsg.RpcReply)
	}
}

// 得到请求体
func getStringBodyFromGin(c *gin.Context, keepBody bool) (b []byte) {
	if c.ContentType() == "multipart/form-data" {
		return
	}
	reqMap, err := ioutil.ReadAll(c.Request.Body)
	if err != nil {
		logger.Error("############################## 统一接口出现错误", "err", err)
		return
	}
	c.Request.Body.Close()
	if keepBody {
		c.Request.Body = ioutil.NopCloser(bytes.NewBuffer(reqMap))
	}
	return reqMap
}
