package handler

import (
	"gopkg.in/gin-gonic/gin.v1"
	"gapproval/common/httpReq"
)

import (
	"gapproval/common/gw"
	"gapproval/common/global"
)

func GetYbCard(c *gin.Context) {
	jinjianId := c.Params.ByName("jinjianId")
	if jinjianId == "" {
		gw.RenderError(c, "jinjian_id 不能为空")
		return
	}
	res, err := httpReq.PostJsonProxyNoCheck(map[string]interface{}{"orderId": jinjianId}, global.GetNqyServerUrl()+"/api/v1/approval/repayBank")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, res)
	}
}