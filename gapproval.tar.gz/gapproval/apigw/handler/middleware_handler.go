package handler

import (
	gsso "gsso/config"
	gssoJwt "gsso/common/jwt"
	"gopkg.in/gin-gonic/gin.v1"
	"gcoresys/common/logger"
	"gcoresys/common"
	"gapproval/common/gw"
	"gapproval/common/httpReq"
	"gapproval/common/global"
	"errors"
)

func AuthValidateTokenHandler(c *gin.Context) {
	logger.Info("========================================================================================")
	token := c.Request.Header.Get("SsoToken")
	approvalType := c.Request.Header.Get("ApprovalType")
	username, name, err := ApprovalTokenAuth(token, approvalType)
	if err != nil {
		c.Abort()
		logger.Info("============ 403 ============", "err", err.Error())
		gw.RenderErrorNoAuth(c, err.Error())
		return
	}

	// test 环境手动赋值
	if common.GetUseDocker() == 0 {
		c.Set("username", "test")
		c.Set("name", "测试")
	} else {
		c.Set("username", username)
		c.Set("name", name)
	}

	logger.Info("操作日志=====", "username", username, "name", name, "ip", c.ClientIP(), "url", c.Request.URL)
	return
}

// token的验证
func ApprovalTokenAuth(token string, approvalType string) (username string, name string, err error) {
	if common.GetUseDocker() == 0 {
		username = "test"
		name = "测试"
		return
	}

	if approvalType == "" || token == "" {
		err = errors.New("token 或 approval_type 不能为空")
		return
	}

	if err = checkTokenReq(token, getApprovalType(approvalType)); err != nil {
		return
	}

	return gssoJwt.DecodeJwtToken(token)
}

// 匹配对应的权限
func getApprovalType(ApprovalType string) string {
	switch ApprovalType {
	case "cs":
		return gsso.APPROVAL_CS
	case "zs":
		return gsso.APPROVAL_ZS
	case "kf":
		return gsso.APPROVAL_KF
	case "mq":
		return gsso.INTERVIEW_MQ
	case "yy":
		return gsso.APPROVAL_YY
	case "ys":
		return gsso.APPROVAL_YS
	default:
		return "nil"
	}
}

// 验证Token是否有访问权限
func checkTokenReq(jwtToken string, route string) (err error) {

	params := map[string]interface{}{
		"jwt_token": jwtToken,
		"req_route": route,
		"only_one":  "1",
	}

	_, err = httpReq.PostJsonProxy(params, global.GetGssoServerUrl()+"/api/v1/valid_req")
	if err != nil {
		logger.Error("gsso valid token return err", "info", err.Error())
		return err
	}
	return nil
}
