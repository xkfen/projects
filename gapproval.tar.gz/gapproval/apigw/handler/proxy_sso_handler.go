package handler

import (
	"gapproval/common/gw"
	"gcoresys/common/logger"
	"gopkg.in/gin-gonic/gin.v1"
	"gapproval/common/httpReq"
	"gapproval/common/global"
	"fmt"
)

func SsoLogin(c *gin.Context) {
	var user map[string]string
	if c.BindJSON(&user) != nil {
		gw.RenderError(c, "login parse json err")
		return
	}
	if user["username"] == "" || user["password"] == "" {
		gw.RenderError(c, "用户名或密码不能为空")
		return
	}
	params := map[string]string{
		"username":      user["username"],
		"password":      user["password"],
		"client_id":     "approve",
		"response_type": "token",
		"scope":         "everything",
	}
	_, result, err := httpReq.PostFormDataProxyNoCheck(params, global.GetGssoServerUrl()+"/api/v1/authorize")
	if err != nil {
		gw.RenderError(c, "登录失败:"+err.Error())
	} else {
		gw.RenderSuccess(c, result)
	}
}

// 用户列表
func SsoGetUserList(c *gin.Context) {
	//approvalType := c.Request.Header.Get("ApprovalType")
	//respResult, err := httpReq.GetProxy(global.GetGssoServerUrl() + "/api/v1/group_user?permissions=" + getApprovalType(approvalType))
	//if err != nil {
	//	gw.RenderError(c, err.Error())
	//} else {
	//	gw.RenderSuccess(c, respResult)
	//}
	var reqMap map[string]interface{}
	if c.BindJSON(&reqMap) != nil {
		gw.RenderError(c, "json parse err")
		return
	}
	url := fmt.Sprintf("/api/v1/user?page=%v&group_id=%v", reqMap["page"], reqMap["grpup_id"])
	respResult, err := httpReq.GetProxy(global.GetGssoServerUrl() + url)
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respResult)
	}
}

type ssoUpdateUserPasswordReq struct {
	UserId      string `json:"user_id"`
	OldPassword string `json:"old_password"`
	NewPassword string `json:"new_password"`
}

// 更改密码
func SsoUpdateUserPassword(c *gin.Context) {
	var req ssoUpdateUserPasswordReq
	if c.BindJSON(&req) == nil && req.NewPassword != "" && req.OldPassword != "" {
		putFormDataMap := make(map[string]string)
		putFormDataMap["password"] = req.OldPassword
		putFormDataMap["new_password"] = req.NewPassword
		respResult, err := httpReq.PutFormDataProxy(putFormDataMap, global.GetGssoServerUrl()+"/api/v1/user/"+req.UserId)
		if err != nil {
			gw.RenderError(c, err.Error())
		} else {
			gw.RenderSuccess(c, respResult)
		}
	} else {
		gw.RenderError(c, "参数解析错误,请检查")
	}
}

type ssoAuthGroupPwdReq struct {
	GroupId  string `json:"group_id"`
	Password string `json:"password"`
}

// 验证组密码
func AuthGroupPwd(c *gin.Context) {
	var req ssoAuthGroupPwdReq
	if c.BindJSON(&req) == nil && req.GroupId != "" && req.Password != "" {
		if validGroupPassword(req.GroupId, req.Password) {
			c.JSON(200,map[string]interface{}{"success":true,"info":"密码验证成功"})
		} else {
			gw.RenderError(c, "密码验证失败")
		}
	} else {
		gw.RenderError(c, "参数解析错误,请检查")
	}
}

// 验证组密码
func validGroupPassword(groupId, password string) bool {

	//logger.Info("请求验证组密码", "group id", groupId, "password", password)
	url := "/api/v1/valid_password?id=" + groupId + "&password=" + password
	result, err := httpReq.GetProxy(global.GetGssoServerUrl() + url)
	if err != nil {
		logger.Error("请求验证组密码错误：" + err.Error())
		return false
	}

	data, ok := result["success"].(bool)
	return ok && data
}
