package handler

import (
	"strconv"
	"gopkg.in/gin-gonic/gin.v1"
	"gapproval/common/gw"
	"gapproval/common/tool"
	"gcoresys/common/logger"
	"gapproval/approval/grpc/client"
	"gapproval/approval/grpc/pb"
	"gcoresys/common/util"
	"github.com/tidwall/gjson"
)

// 预审批文件上传
func UploadPreApprovalFileHandler(c *gin.Context) {
	preApprovalId := c.PostForm("pre_approval_id")
	fileType := c.PostForm("file_type")
	action := c.PostForm("action")
	stage := c.PostForm("stage")
	desc := c.PostForm("desc")
	var id int
	var err error
	if tmpId := c.PostForm("id"); tmpId != "" {
		id, err = strconv.Atoi(tmpId)
		if err != nil {
			gw.RenderError(c, "参数id出错, 请检查")
			return
		}
	}

	var fileUrl, fileName string
	if action == "update" || action == "upload" {
		fileUrl, fileName, err = tool.GetFileUrl(preApprovalId, "upload", c)
		if err != nil {
			logger.Error("文件上传失败", "err", err)
			gw.RenderError(c, err.Error())
			return
		}
	}

	var params = map[string]interface{}{
		"pre_approval_id": preApprovalId,
		"file_type":       fileType,
		"file_name":       fileName,
		"file_url":        fileUrl,
		"action":          action,
		"stage":           stage,
		"desc":            desc,
		"id":              id,
	}

	if respMsg, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		Method:       "PreApprovalFile",
		RpcRequest:   util.StringifyJson(params),
		ApprovalType: c.Request.Header.Get("ApprovalType"),
		Username:     c.MustGet("username").(string),
		Name:         c.MustGet("name").(string),
		IsAuth:       true,
	}); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respMsg.RpcReply)
	}
}

func DownloadPreApprovalFileHandler(c *gin.Context) {
	resp, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		RpcRequest:   string(getStringBodyFromGin(c, true)),
		Method:       "GetPackCompressedPreApprovalFiles",
		ApprovalType: c.Request.Header.Get("ApprovalType"),
		Username:     c.MustGet("username").(string),
		Name:         c.MustGet("name").(string),
		IsAuth:       true,
	})
	if err != nil {
		gw.RenderError(c, err.Error())
		return
	}

	data := gjson.Parse(resp.RpcReply)
	if !data.IsArray() {
		gw.RenderError(c, resp.RpcReply)
		return
	}
	var fileUrls []string
	var preApprovalId string
	for _, d := range data.Array() {
		fileUrls = append(fileUrls, d.Get("file_url").Str)
		if preApprovalId == "" {
			preApprovalId = d.Get("pre_approval_id").Str
		}
	}

	if filePath, err := tool.ArchiveFileZIP(fileUrls, preApprovalId); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, map[string]interface{}{"file_path": filePath, "success": true, "info": "打包成功"})
	}
}
