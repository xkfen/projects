package handler

import (
	"gapproval/common/gw"
	"gopkg.in/gin-gonic/gin.v1"
	"gapproval/common/httpReq"
	"gapproval/common/global"
	"github.com/tidwall/gjson"
	"gcoresys/common/logger"
)

// 获取临时还款计划
func GetPreviewRepayPlans(c *gin.Context) {
	resBt, err := httpReq.ProxyReq(c.Request, global.GetCoreSysUrl()+"/api/v1/repayPlan/previewRepayPlans")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", resBt)
	}
}

func GetRepayPlansHandler(c *gin.Context) {
	accountId := gjson.Get(string(getStringBodyFromGin(c, false)), "account_id").Int()
	logger.Info("================== GetRepayPlansHandler", "account_id", accountId)
	resp, err := httpReq.PostJsonProxyNoCheck(map[string]uint{"account_id": uint(accountId)}, global.GetCoreSysUrl()+"/sp/v1/repay_plans")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, resp)
	}
}

func GetRepayRecordProxyHandler(c *gin.Context) {
	resBt, err := httpReq.ProxyReq(c.Request, global.GetCoreSysUrl()+"/cw/v1/repay_records")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", resBt)
	}
}
