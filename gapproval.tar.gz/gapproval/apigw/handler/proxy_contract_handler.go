package handler

import (
	"gapproval/common/gw"
	"gopkg.in/gin-gonic/gin.v1"
	"gapproval/common/global"
	"gcoresys/common/util"
	"gapproval/common/httpReq"
)

// 上传合同
func UploadContract(c *gin.Context) {
	respBt, err := httpReq.ProxyReq(c.Request, global.GetContractUrl()+"/api/v1/contract")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", respBt)
	}
}

// 下载合同
func GetContract(c *gin.Context) {
	jinjianId := c.Params.ByName("jinjianId")
	resp, err := httpReq.GetProxy(global.GetContractUrl() + "/api/v1/contract/" + jinjianId)
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, resp)
	}
}

// 浏览CA合同
func PreviewCaContract(c *gin.Context) {
	if respBt, err := httpReq.ProxyReq(c.Request, global.GetProdmngUrl()+"/api/v1/contract_preview"); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", respBt)
	}
}

// 提交CA合同
func CommitCaContract(c *gin.Context) {
	if respBt, err := util.ProxyReq(c.Request, global.GetContractUrl()+"/api/v1/ec_info"); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", respBt)
	}
}
