package handler

import (
	"gapproval/common/gw"
	"gapproval/apigw/service"
	"gapproval/approval/grpc/server"
	"gcoresys/common/util"
	"gopkg.in/gin-gonic/gin.v1"
	"time"
	"gapproval/approval/model"
	"gapproval/approval/grpc/client"
	"gapproval/approval/grpc/pb"
)

//创建审批单
func NewApprovalOrderHandler(c *gin.Context) {
	OldApiHandlerNoAuth(c, "NewApprovalOrder")
}

//获取审批单详情
func GetApprovalOrderHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "GetApprovalOrderInfo")
}

//中介段获取列表
func GetApprovalOrderListHandler(c *gin.Context) {
	OldApiHandlerNoAuth(c, "GetApprovalOrderList")
}

//创建初审结论
func NewApprovalCsResultHandler(c *gin.Context) {
	OldApiHandlerNoAuth(c, "NewApprovalCsResult")
}

// 中介端更改审批状态
func AgencyChangeStatusHandler(c *gin.Context) {
	OldApiHandlerNoAuth(c, "AgencyChangeStatus")
}

//抢单
func GrabApprovalHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "GrabApproval")
}

//获取初审结论
func GetApprovalCsResultHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "GetApprovalCsResult")
}

// 审批单挂起
func ApprovalSuspendHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "ApprovalSuspend")
}

// 获取三方信息
func GetThreePartyInfoHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "GetThreePartyInfo")
}

// 修改是否标准件
func MarkIsStandardHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "MarkIsStandard")
}

// 用户个人信息补充
func ApprovalUserInfoSupHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "ApprovalUserInfoSup")
}

func ApprovalCallRecordHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "ApprovalCallRecord")
}

func NewOrUpdateThreePartyInfoHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "NewOrUpdateThreePartyInfo")
}

func AddOrUpdateAddContactHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "AddOrUpdateAddContact")
}

func NewOrUpdateRiskParamHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "NewOrUpdateRiskParam")
}

func NewOrUpdateExtensionNumberHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "NewOrUpdateExtensionNumber")
}

func UpdateJinjianAllInfoHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "UpdateJinjianAllInfo")
}

func AddPayCardHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "AddPayCard")
}

//获取审批记录
func GetApprovalLogHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "GetApprovalLog")
}

// 电子渠道获取审批订单详情
func GetApprovalInfoHandler(c *gin.Context) {
	OldApiHandlerNoAuth(c, "QyGetApprovalOrder")
}

//获取审批列表
func GetApprovalListHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "GetApprovalList")
}

func QueryHandler(c *gin.Context) {
	OldApiHandlerAuth(c, "Query")
}

// =================================================================================
// =================================================================================

func GetAndSetScoreHandler(c *gin.Context) {
	var req server.SetQuantizationPointReq
	if c.BindJSON(&req) != nil || req.JinjianId == "" || req.Sr == nil {
		gw.RenderError(c, "参数错误,请检查参数是否正确")
		return
	}
	// 验证密码
	if req.Password != "" && req.GroupId != "" {
		if !validGroupPassword(req.GroupId, req.Password) {
			gw.RenderError(c, "密码验证失败，请检查")
			return
		}
		req.Sr.IsUpdate = true
	}

	if respMsg, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		Method:       "SetQuantizationPoint",
		RpcRequest:   util.StringifyJson(req),
		ApprovalType: c.Request.Header.Get("ApprovalType"),
		Username:     c.MustGet("username").(string),
		Name:         c.MustGet("name").(string),
		IsAuth:       true,
	}); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respMsg.RpcReply)
	}
}

// --------------------------------------------------------

type ApprovalOperationReq struct {
	ApprovalOrder     *model.ApprovalOrder `json:"approval_order"`
	ApprovalType      string               `json:"approval_type"`
	SalaryAt          string               `json:"salary_at"`
	LoanAt            string               `json:"loan_at"` // 放款日期
	SendUserMsgSwitch bool                 `json:"send_user_msg_switch"`
}

//审批操作
func ApprovalOperationHandler(c *gin.Context) {
	var operationReq ApprovalOperationReq
	if c.BindJSON(&operationReq) == nil && operationReq.ApprovalOrder != nil &&
		operationReq.ApprovalOrder.JinjianId != "" && operationReq.ApprovalType != "" {

		if operationReq.LoanAt != "" && operationReq.SalaryAt != "" {
			loanAt, _ := time.Parse("2006-01-02", operationReq.LoanAt)
			firstRepayAt, _ := time.Parse("2006-01-02", operationReq.SalaryAt)
			operationReq.ApprovalOrder.SalaryAt = &firstRepayAt
			operationReq.ApprovalOrder.LoanAt = &loanAt
		}
		req := server.ApprovalOperationReq{ApprovalOrder: operationReq.ApprovalOrder, OperationType: operationReq.ApprovalType}
		if req.OperationType == "zs" {
			req.SendUserMsgSwitch = operationReq.SendUserMsgSwitch
		}
		result, err := service.ApprovalOperation(util.StringifyJson(req))
		if err != nil {
			gw.RenderError(c, err.Error())
		} else {
			gw.RenderSuccess(c, result)
		}
	} else {
		gw.RenderError(c, "参数错误,请检查参数是否正确")
	}
}


type JinjianReq struct {
	JjID       string                 `json:"jinjian_id"`
	BuluType   string                 `json:"bulu_type"`
	BuluStatus bool                   `json:"bulu_status"`
	AllInfo    map[string]interface{} `json:"all_info"`
}

func RealTimeUpdateOtherBank(c *gin.Context) {
	var jinjianReq JinjianReq
	if c.BindJSON(&jinjianReq) == nil && jinjianReq.JjID != "" && jinjianReq.AllInfo != nil && jinjianReq.BuluType != "" {
		req := server.ApprovalOperationReq{ApprovalOrder: &model.ApprovalOrder{JinjianId: jinjianReq.JjID},
			OperationType: "rt", AllInfo: jinjianReq.AllInfo, ArType: jinjianReq.BuluType}
		result, err := service.ApprovalOperation(util.StringifyJson(req))
		if err != nil {
			gw.RenderError(c, err.Error())
		} else {
			gw.RenderSuccess(c, result)
		}
	} else {
		gw.RenderError(c, "参数错误,请检查必要的参数")
	}
}

func UpdateJinJianBuLuByQy(c *gin.Context) {
	var jinjianReq JinjianReq
	if c.BindJSON(&jinjianReq) == nil && jinjianReq.JjID != "" && jinjianReq.AllInfo != nil && jinjianReq.BuluType != "" {
		//  补录开关标识
		var arSwitch string
		if jinjianReq.BuluStatus {
			arSwitch = "open"
		} else {
			arSwitch = "close"
		}
		req := server.ApprovalOperationReq{ApprovalOrder: &model.ApprovalOrder{JinjianId: jinjianReq.JjID},
			OperationType: "cs", ArSwitch: arSwitch, Way: "jj", AllInfo: jinjianReq.AllInfo, ArType: jinjianReq.BuluType}
		result, err := service.ApprovalOperation(util.StringifyJson(req))
		if err != nil {
			gw.RenderError(c, err.Error())
		} else {
			gw.RenderSuccess(c, result)
		}
	} else {
		gw.RenderError(c, "参数错误,请检查必要的参数")
	}
}

func UpdateJinJianBuLu(c *gin.Context) {
	var jinjianReq JinjianReq
	if c.BindJSON(&jinjianReq) == nil && jinjianReq.JjID != "" && jinjianReq.BuluType != "" {
		//  补录开关标识
		var arSwitch string
		if jinjianReq.BuluStatus {
			arSwitch = "open"
		} else {
			arSwitch = "close"
		}

		req := server.ApprovalOperationReq{ApprovalOrder: &model.ApprovalOrder{JinjianId: jinjianReq.JjID},
			OperationType: "cs", ArSwitch: arSwitch, ArType: jinjianReq.BuluType}
		result, err := service.ApprovalOperation(util.StringifyJson(req))
		if err != nil {
			gw.RenderError(c, err.Error())
		} else {
			gw.RenderSuccess(c, result)
		}
	} else {
		gw.RenderError(c, "参数错误,请检查 token 以及必要的参数")
	}
}

// --------------------------------------------------------

//审批操作  cw
func CwOperationHandler(c *gin.Context) {
	var req server.ApprovalOperationReq
	if c.BindJSON(&req) == nil && req.ApprovalOrder != nil && req.FinBackUsername != "" {
		req.OperationType = "cw"
		result, err := service.ApprovalOperation(util.StringifyJson(req))
		if err != nil {
			gw.RenderError(c, err.Error())
		} else {
			gw.RenderSuccess(c, result)
		}
	} else {
		gw.RenderError(c, "参数错误,请检查参数是否正确")
	}
}
