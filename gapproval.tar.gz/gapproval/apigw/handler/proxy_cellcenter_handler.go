package handler

import (
	"gapproval/common/gw"
	"gopkg.in/gin-gonic/gin.v1"
	"gcoresys/common/util"
	"gapproval/common/global"
	ccUtil "gcallcenter/util"
	ccModel "gcallcenter/model"
	"gapproval/approval/model"
	"gapproval/approval/grpc/server"
	"gapproval/common/httpReq"
	"gapproval/approval/grpc/client"
	"gapproval/approval/grpc/pb"
)

// 绑定主被叫号码
func BindPhoneHandler(c *gin.Context) {
	resBt, err := httpReq.ProxyReq(c.Request, global.GetCallCenterUrl()+"/api/v1/bind_phone")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", resBt)
	}
}

// 取消绑定
func CancelBindPhoneHandler(c *gin.Context) {
	resBt, err := httpReq.ProxyReq(c.Request, global.GetCallCenterUrl()+"/api/v1/unbind_phone")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", resBt)
	}

}

// 获取单个通话记录 （通话结束时条用）
func GetCallRecordHandler(c *gin.Context) {
	resBt, err := httpReq.ProxyReq(c.Request, global.GetCallCenterUrl()+"/api/v1/records/query")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", resBt)
	}
}

// 新增主叫号码
func AddCallNumberHandler(c *gin.Context) {
	resBt, err := httpReq.ProxyReq(c.Request, global.GetCallCenterUrl()+"/api/v1/from_phones/create")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", resBt)
	}
}

// 获取所有主叫号码
func GetAllCallNumberHandler(c *gin.Context) {
	resBt, err := httpReq.ProxyReq(c.Request, global.GetCallCenterUrl()+"/api/v1/from_phones/query_all")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", resBt)
	}
}

// 查询本人手机号码是否有通话记录
func GetHasRecordsHandler(c *gin.Context) {
	resBt, err := httpReq.ProxyReq(c.Request, global.GetCallCenterUrl()+"/api/v1/records/has_oneself")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", resBt)
	}
}

// 呼叫/打电话 - 固话
func CallPhoneHandler(c *gin.Context) {
	resBt, err := httpReq.ProxyReq(c.Request, global.GetCallCenterUrl()+"/api/v1/call_phone")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", resBt)
	}
}

// 取消通话 - 固话
func CancelCallPhoneHandler(c *gin.Context) {
	resBt, err := httpReq.ProxyReq(c.Request, global.GetCallCenterUrl()+"/api/v1/cancel_phone")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", resBt)
	}
}

// 查询单个主叫号码的通话状态
func GetCallStatusHandler(c *gin.Context) {
	resBt, err := httpReq.ProxyReq(c.Request, global.GetCallCenterUrl()+"/api/v1/call_status/query")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", resBt)
	}
}

// 为单条通话记录添加备注信息
func UpdateRecordRemarkHandler(c *gin.Context) {
	resBt, err := httpReq.ProxyReq(c.Request, global.GetCallCenterUrl()+"/api/v1/update_record_remark")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", resBt)
	}
}

type recordQueryAllResp struct {
	ccUtil.RenderResp
	Records []*ccModel.Record `json:"records"`
}

// 获取所有通话记录
func GetCallAllRecordsHandler(c *gin.Context) {
	var reqMap map[string]string
	if err := c.BindJSON(&reqMap); err != nil {
		gw.RenderError(c, err.Error())
		return
	}
	resp, err := httpReq.PostJsonProxyNoCheck(reqMap, global.GetCallCenterUrl()+"/api/v1/records/query_all")
	if err != nil {
		gw.RenderError(c, err.Error())
		return
	}
	if reqMap["user_type"] != "2" {
		gw.RenderSuccess(c, resp)
		return
	}

	// user_type == "2" 继续
	// 解析返回的结果
	var ccResp recordQueryAllResp
	if err := util.ParseJson(resp, &ccResp); err != nil {
		gw.RenderError(c, "解析电核记录失败"+err.Error())
		return
	}
	// 如果出错，返回错误
	if !ccResp.Success {
		c.Data(400, "application/json", []byte(resp))
		return
	}

	if respMsg, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		Method:       "ApprovalCallRecord",
		RpcRequest:   util.StringifyJson(server.ApprovalCallRecordReq{JinjianId: reqMap["jin_jian_id"], Action: "get_desc"}),
		ApprovalType: c.Request.Header.Get("ApprovalType"),
		Username:     c.MustGet("username").(string),
		Name:         c.MustGet("name").(string),
		IsAuth:       true,
	}); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		// 将审批系统保持的备注查询出来，并组装到电核系统返回的数据中
		var recordsNoCall []model.ApprovalCallRecord
		if err := util.ParseJson(respMsg.RpcReply, &recordsNoCall); err != nil {
			gw.RenderError(c, "解析本地催收备注失败")
			return
		}

		for _, v := range recordsNoCall {
			newRecord := ccModel.Record{}
			newRecord.JinJianID = v.JinjianId
			newRecord.Remark = v.Desc
			newRecord.UserType = "2"
			newRecord.To = v.Number
			ccResp.Records = append(ccResp.Records, &newRecord)
		}
		gw.RenderSuccess(c, util.StringifyJson(ccResp))
	}
}
