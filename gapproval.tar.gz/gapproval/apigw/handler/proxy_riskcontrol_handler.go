package handler

import (
	"gapproval/common/gw"
	"gapproval/apigw/service"
	"gopkg.in/gin-gonic/gin.v1"
	"gapproval/approval/grpc/server"
	"gcoresys/common/util"
	"gapproval/common/httpReq"
	"gapproval/common/global"
	"strings"
)

// 代理风控数据 （新的）
func ProxyRiskControlHandler(c *gin.Context) {
	if respBt, err := httpReq.ProxyReq(c.Request, global.GetRiskControlServerUrl()+strings.Replace(c.Request.URL.Path, "v2", "v1", 1)); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", respBt)
	}
}

// --------------------------------- RiskCtrlProxyHandler ---------------------------------

type RiskCtrlProxy struct {
	ReqParam interface{} `json:"req_param"`
	Method   string      `json:"method"`
}

// 预审需要的代理接口
func RiskCtrlProxyHandler(c *gin.Context) {
	var req RiskCtrlProxy
	if c.BindJSON(&req) != nil || req.ReqParam == nil || req.Method == "" {
		gw.RenderError(c, "参数解析错误，请检查")
		return
	}

	respResult, err := httpReq.PostJsonProxy(req.ReqParam, global.GetRiskControlServerUrl()+"/api/v1"+req.Method)
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respResult)
	}
}

func FlowTagHandler(c *gin.Context) {
	var req server.ApprovalOperationReq
	if c.BindJSON(&req) != nil || req.FlowTagMethod == "" {
		gw.RenderError(c, "参数解析错误，请检查")
		return
	}

	req.OperationName = c.MustGet("name").(string)
	req.OperationType = "flow"
	respResult, err := service.ApprovalOperation(util.StringifyJson(req))
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respResult)
	}
}

// --------------------------------- SimpleCreditReportHandler ---------------------------------
type SCRReqProxyParam struct {
	ReqParam     interface{} `json:"req_param"`
	ApprovalType string      `json:"approval_type"`
	Method       string      `json:"method"`
}

// 简版征信代理接口
func SimpleCreditReportHandler(c *gin.Context) {
	var req SCRReqProxyParam
	if c.BindJSON(&req) != nil || req.Method == "" || req.ReqParam == nil {
		gw.RenderError(c, "参数解析错误，请检查")
		return
	}
	respResult, err := httpReq.PostJsonProxy(req.ReqParam, global.GetRiskControlServerUrl()+"/api/v1/uniform_interface/"+req.Method)
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respResult)
	}
}

// -------------------------------------------------------------------------
// --------------------------------- FkReq ---------------------------------
type FkReq struct {
	PhoneId      uint   `json:"phone_id"`
	JinjianId    string `json:"jinjian_id"`
	Page         int    `json:"page"`
	Id           string `json:"id"`
	Mark         string `json:"mark"`
	CardType     string `json:"card_type"`
	BankId       string `json:"bank_id"`
	ApprovalType string `json:"approval_type"`
	PageSize     int    `json:"page_size"`
	OrderBy      string `json:"order_by"`
	FlowTag      string `json:"flow_tag"`
	DataSource   string `json:"data_source"`
	PageNum      int    `json:"page_num"`
	IsNew        bool   `json:"is_new"`
}

func GetBlankLists(c *gin.Context) {
	var req FkReq
	if c.BindJSON(&req) != nil || req.JinjianId == "" {
		gw.RenderError(c, "参数解析错误,请检查")
		return
	}
	req.Id = req.JinjianId
	//req.DataSource = req.DataSource
	respResult, err := httpReq.PostJsonProxy(req, global.GetRiskControlServerUrl()+"/api/v1/black_lists/query")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respResult)
	}
}

func GetMultipoints(c *gin.Context) {
	var req FkReq
	if c.BindJSON(&req) != nil || req.JinjianId == "" {
		gw.RenderError(c, "参数解析错误,请检查")
		return
	}
	req.Id = req.JinjianId
	respResult, err := httpReq.PostJsonProxy(req, global.GetRiskControlServerUrl()+"/api/v1/multipoints/query")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respResult)
	}
}

// 获取运营商数据基本信息
func GetPhoneInfo(c *gin.Context) {
	var req FkReq
	if c.BindJSON(&req) != nil || req.JinjianId == "" {
		gw.RenderError(c, "参数解析错误,请检查")
		return
	}
	req.Id = req.JinjianId
	respResult, err := httpReq.PostJsonProxy(req, global.GetRiskControlServerUrl()+"/api/v1/phones/query")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respResult)
	}
}

// 获取运营商数据通话记录
func GetPhoneStatements(c *gin.Context) {
	var req FkReq
	if c.BindJSON(&req) != nil || req.JinjianId == "" {
		gw.RenderError(c, "参数解析错误,请检查")
		return
	}
	req.Id = req.JinjianId
	req.PageNum = req.Page
	respResult, err := httpReq.PostJsonProxy(req, global.GetRiskControlServerUrl()+"/api/v1/phone_statements/query")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respResult)
	}
}

// 获取主要银行卡基本信息
func GetMainBankInfo(c *gin.Context) {
	var req FkReq
	if c.BindJSON(&req) != nil || req.JinjianId == "" {
		gw.RenderError(c, "参数解析错误,请检查")
		return
	}
	req.Id = req.JinjianId
	respResult, err := httpReq.PostJsonProxy(req, global.GetRiskControlServerUrl()+"/api/v1/banks/query_main")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respResult)
	}
}

// 获取主要银行卡交易流水
func GetMainBankStatements(c *gin.Context) {
	var req ReqProxyParam
	if c.BindJSON(&req) != nil || req.JinjianId == "" {
		gw.RenderError(c, "参数解析错误,请检查")
		return
	}
	req.ID = req.JinjianId
	req.PageNum = req.Page
	respResult, err := httpReq.PostJsonProxy(req, global.GetRiskControlServerUrl()+"/api/v1/bank_statements/query_main")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respResult)
	}
}

// 获取补录银行卡基本信息
func GetSecBankInfo(c *gin.Context) {
	var req FkReq
	if c.BindJSON(&req) != nil || req.JinjianId == "" {
		gw.RenderError(c, "参数解析错误,请检查")
		return
	}
	req.Id = req.JinjianId
	respResult, err := httpReq.PostJsonProxy(req, global.GetRiskControlServerUrl()+"/api/v1/banks/query_second")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respResult)
	}
}

// 获取补录银行卡交易流水
func GetSecBankStatements(c *gin.Context) {
	var req ReqProxyParam
	if c.BindJSON(&req) != nil || req.JinjianId == "" {
		gw.RenderError(c, "参数解析错误,请检查")
		return
	}
	req.ID = req.JinjianId
	req.PageNum = req.Page
	respResult, err := httpReq.PostJsonProxy(req, global.GetRiskControlServerUrl()+"/api/v1/bank_statements/query_second")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respResult)
	}
}

// 获取身份证相关信息
func GetIdCardInfo(c *gin.Context) {
	var req FkReq
	if c.BindJSON(&req) != nil || req.JinjianId == "" {
		gw.RenderError(c, "参数解析错误,请检查")
		return
	}
	req.Id = req.JinjianId
	respResult, err := httpReq.PostJsonProxy(req, global.GetRiskControlServerUrl()+"/api/v1/id_cards/query")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, respResult)
	}
}

// 标识银行卡交易流水
func UpdateBankStatements(c *gin.Context) {
	respBt, err := httpReq.ProxyReq(c.Request, global.GetRiskControlServerUrl()+"/api/v1/bank_statements/update")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", respBt)
	}
}

// 四要素验证
func ValidateBank(c *gin.Context) {
	respBt, err := httpReq.ProxyReq(c.Request, global.GetRiskControlServerUrl()+"/api/v1/banks/check_four_point")
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.Data(200, "application/json", respBt)
	}
}

type ReqProxyParam struct {
	ID                string `json:"id"`
	PageNum           int    `json:"page_num"`
	BankID            string `json:"bank_id"`
	PageSize          int    `json:"page_size"`
	OrderBy           string `json:"order_by"`
	Mark              string `json:"mark"`
	FlowTag           string `json:"flow_tag"`
	StartTime         string `json:"start_time"`
	EndTime           string `json:"end_time"`
	StartIncomeAmount string `json:"start_income_amount"`
	EndIncomeAmount   string `json:"end_income_amount"`
	StartPayAmount    string `json:"start_pay_amount"`
	EndPayAmount      string `json:"end_pay_amount"`
	StartBalance      string `json:"start_balance"`
	EndBalance        string `json:"end_balance"`
	ApprovalType      string `json:"approval_type"`
	JinjianId         string `json:"jinjian_id"`
	Page              int    `json:"page"`
}
