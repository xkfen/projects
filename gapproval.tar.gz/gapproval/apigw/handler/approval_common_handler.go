package handler

import (
	"gopkg.in/gin-gonic/gin.v1"
	"gapproval/approval/grpc/client"
	"gapproval/approval/grpc/pb"
	"gapproval/common/gw"
	"gapproval/apigw/service"
	"gcoresys/common/util"
)

// 终审增加简报功能 返回文件流
func SimpleReportHandler(c *gin.Context) {
	resp, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		RpcRequest: string(getStringBodyFromGin(c, false)),
		Method:     "GenerateApprovalReport",
		IsAuth:     true,})
	if err != nil {
		gw.RenderError(c, err.Error())
		return
	}

	if fileUrl, err := service.MakeDocFile("简报", "query_docx", "simple_report.docx", resp.RpcReply); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		// 把文件返回出去
		c.File(fileUrl)
	}
}

// 自动生成客户封面 返回文件流
func AutoGenerateCustomerCoverHandler(c *gin.Context) {
	// 通过grpc调用查询
	resp, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		RpcRequest: string(getStringBodyFromGin(c, false)),
		Method:     "AutoGenerateCustomerCover",
		IsAuth:     true,})
	if err != nil {
		gw.RenderError(c, err.Error())
		return
	}

	if fileUrl, err := service.MakeDocFile("封面", "cover_docx", "cover.docx", resp.RpcReply); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		// 把文件返回出去
		c.File(fileUrl)
	}
}

// 下载审批报表 返回文件路径
func DownloadReportFormHandler(c *gin.Context) {
	body := map[string]string{
		"start_time": c.Query("start_time"),
		"end_time":   c.Query("end_time"),
	}

	// 转发请求
	if respMsg, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		Method:     "ApprovalReportForm",
		RpcRequest: util.StringifyJson(body),
		IsAuth:     false,
	}); err != nil {
		gw.RenderError(c, err.Error())
	} else {
		if url, err := service.MakeApprovalReportForm(respMsg.RpcReply); err != nil {
			gw.RenderError(c, err.Error())
		} else {
			c.JSON(200, gin.H{"success": true, "info": "报表获取成功", "file_path": url})
		}
	}
}

// 下载查询excel 返回文件路径
func DownloadQueryHandler(c *gin.Context) {
	var OriginReq map[string]interface{}
	if c.BindJSON(&OriginReq) != nil || OriginReq == nil {
		gw.RenderError(c, "参数错误,请检查参数是否正确")
		return
	}

	url, err := service.CreateApprovalQueryExcelFile(OriginReq)
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.JSON(200, gin.H{"success": true, "info": "获取成功", "url": url})
	}
}

// 查询进件人工作单位和联系人姓名
func QueryCompanyAndContactNameHandler(c *gin.Context) {
	// 通过grpc调用查询
	resp, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		RpcRequest: string(getStringBodyFromGin(c, false)),
		Method:     "QueryCompanyAndContactName",
		IsAuth:     false,})

	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, resp.RpcReply)
	}
}

// 审批开关打开面签历史订单修改面签资料
func InterviewUpdateHistoryHandler(c *gin.Context) {
	// 通过grpc调用查询
	resp, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		RpcRequest: string(getStringBodyFromGin(c, false)),
		Method:     "InterviewUpdateHistory",
		IsAuth:     true,})
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		gw.RenderSuccess(c, resp.RpcReply)
	}
}

// 更新面签开关
func UpdateApprovalInterviewSwitchHandler(c *gin.Context) {
	resp, err := client.GetApprovalClient().ApprovalRpcHandler(c, &pb.ApprovalRpcReqMsg{
		RpcRequest: string(getStringBodyFromGin(c, false)),
		Method:     "UpdateApprovalInterviewSwitch",
		IsAuth:     false,})
	if err != nil {
		gw.RenderError(c, err.Error())
		return
	} else {
		gw.RenderSuccess(c, resp.RpcReply)
	}
}


// 预审批下载查询excel 返回文件路径
func DownloadPreOrderQueryHandler(c *gin.Context) {
	var OriginReq map[string]interface{}
	if c.BindJSON(&OriginReq) != nil || OriginReq == nil {
		gw.RenderError(c, "参数错误,请检查参数是否正确")
		return
	}

	url, err := service.PreQueryDownloadExcelFile(OriginReq)
	if err != nil {
		gw.RenderError(c, err.Error())
	} else {
		c.JSON(200, gin.H{"success": true, "info": "获取成功", "url": url})
	}
}