package service

import (
	"context"
	"gapproval/approval/grpc/client"
	"gapproval/approval/grpc/pb"
	"gcoresys/common/logger"
	"gcoresys/common/util"
	"gapproval/common/tool"
	"gcoresys/common/util/docx"
	"path"
	"time"
	"os"
)

func ApprovalOperation(params string) (resultJson interface{}, err error) {
	r, err := client.GetApprovalClient().ApprovalOperation(context.Background(), &pb.ApprovalRequestMsg{RpcRequest: params})
	if r == nil {
		return `{"success: false, "info": "GRPC接口返回为空"}`, err
	}
	return r.RpcReply, err
}

// 生成 word 文档
func MakeDocFile(wordName, wordType, tempPath, data string) (fileUrl string, err error) {

	logger.Info("==================================","wordName",wordName,"wordType",wordType)
	logger.Info("==================================","tempPath",tempPath,"data",data)

	var result map[string]string
	if err = util.ParseJson(data, &result); err != nil {
		return
	}

	dirPath := path.Join(".", "assert", wordType, time.Now().Format("2006-01-02"), result["showId"])
	fileName := wordName + "-" + util.GetCurNanoStr() + ".docx"
	if !tool.PathExists(dirPath) {
		os.MkdirAll(dirPath, os.ModePerm)
	}

	tempPath = "./" + tempPath
	if util.IsTestEnv() {
		tempPath = "../docker/" + tempPath
	}
	// 调用接口生成简报:参数依次是：模板文件路径，生成文件的路径，需要替换的模板文件的字段
	if err = docx.GenDocxFromTemp(tempPath, path.Join(dirPath, fileName), result); err != nil {
		return
	}

	return path.Join(dirPath, fileName), nil
}
