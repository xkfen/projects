package service

import (
	"fmt"
	"gcoresys/common/util"
	"testing"
	"time"
	"os"
	"gapproval/common/tool"
	"github.com/stretchr/testify/assert"
	//"gapproval/approval/model"
	//"gapproval/approval/db/config"
	"github.com/tidwall/gjson"
)

func TestCreateApprovalQuery(t *testing.T) {
	dirPath := "./assert/" + time.Now().Format("2006-01-02") + "/"
	if !tool.PathExists(dirPath) {
		os.MkdirAll(dirPath, os.ModePerm)
	}
	xlsx := SetExcelTitle()
	err := xlsx.SaveAs(dirPath + util.GetCurNanoStr() + ".xlsx")
	assert.Equal(t, nil, err)
	os.RemoveAll("./assert")
}

func TestCheckMapValue(t *testing.T) {
	testJson := `{"data":[{"test1":"test"},{"test2":"test"}]}`

	var OriginMap map[string]interface{}
	err := util.ParseJson(testJson, &OriginMap)
	assert.NoError(t, err)

	data, err := CheckMapValue("data", OriginMap)
	assert.NoError(t, err)
	fmt.Println("data list", data)
}

func TestSetExcelValue(t *testing.T) {
	testJson := `{"data":[{"test1":"test"},{"test2":"test"}]}`

	var OriginMap map[string]interface{}
	err := util.ParseJson(testJson, &OriginMap)
	assert.NoError(t, err)
}

func TestMakeApprovalReportForm(t *testing.T) {
	//var orderList []*model.ApprovalOrder
	//err := config.GetDataMigrateDb("prod").Model(&model.ApprovalOrder{}).Where("inter_view_finish_time BETWEEN ? AND ?", "2018-01-01 01:01:01", "2018-04-04 04:04:04").Limit(1000).Find(&orderList).Error
	//assert.Equal(t, nil, err)
	//
	//url, err := MakeApprovalReportForm(util.StringifyJson(orderList))
	//assert.Equal(t, nil, err)
	//fmt.Println(url)
}

func TestMakeApprovalReportForm001(t *testing.T) {
	//var orderList []*model.ApprovalOrder
	//err := config.GetDataMigrateDb("prod").Model(&model.ApprovalOrder{}).Where("jinjian_id = ? ", "123").Find(&orderList).Error
	//assert.Equal(t, nil, err)
	//
	//url, err := MakeApprovalReportForm(util.StringifyJson(orderList))
	//assert.Equal(t, nil, err)
	//fmt.Println(url)
}

func TestMakeApprovalReportForm002(t *testing.T) {

	url, err := MakeApprovalReportForm("[]")
	assert.Equal(t, nil, err)
	fmt.Println(url)
	os.RemoveAll("./assert")
}

func TestGjsonGetBoolValue(t *testing.T) {

	data := "{}"
	success := gjson.Get(data, "success")
	assert.Equal(t, false, success.Exists() && success.Bool() == false)

	data = `{"success":false}`
	success = gjson.Get(data, "success")
	assert.Equal(t, true, success.Exists() && success.Bool() == false)
}
