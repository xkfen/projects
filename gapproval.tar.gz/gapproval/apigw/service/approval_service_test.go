package service

import (
	"testing"
	"github.com/stretchr/testify/assert"
	"fmt"
	"gcoresys/common/logger"
	"os"
)

func TestMakeDocFile(t *testing.T) {

	logger.InitLogger(logger.LvlDebug, nil)

	data := "{\"funSide\":\"onion\",\"cellphone\":\"15302678545\",\"agencyName\":\"深圳前海神马金融服务有限公司\",\"sex\":\"女\",\"productPlan\":\"月供贷（24期或以上，按揭）\",\"userName\":\"进进件\",\"showId\":\"S_qy20180313002\",\"applyDate\":\"2018-04-13\",\"firstTrailName\":\"赵宣\"}"

	fileUrl, err := MakeDocFile("封面", "cover_docx", "cover.docx", data)
	assert.Equal(t, nil, err)
	fmt.Println("fileUrl == ", fileUrl)
	os.RemoveAll("./assert")
}
