package service

import (
	"context"
	"goplogger/grpc/client"
	"goplogger/grpc/pb"
)

// 这里调的是日志微服务
func NewOperationLog(params string) (resultJson interface{}, err error) {
	r, err := client.GetOperationLogClient().NewOperationLog(context.Background(), &pb.OperationLogRequestMsg{RpcRequest: params})
	if r == nil {
		return `{"success: false, "info": "GRPC接口返回为空"}`, err
	}
	return r.RpcReply, err
}
