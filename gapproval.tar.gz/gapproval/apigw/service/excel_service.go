package service

import (
	"errors"
	"gcoresys/common/logger"
	"gcoresys/common/util"
	"github.com/xuri/excelize"
	"os"
	"strconv"
	"time"
	"gapproval/common/tool"
	"gapproval/approval/model"
	"github.com/tidwall/gjson"
)

//  生成查询excel
func CreateApprovalQueryExcelFile(originReq map[string]interface{}) (url string, err error) {
	dataList, err := CheckMapValue("data", originReq)
	if err != nil {
		return
	}

	xlsx := SetExcelTitle()

	for index, originData := range dataList {
		data := originData.(map[string]interface{})
		if err = SetExcelValue("show_id", data, xlsx, "A"+strconv.Itoa(index+2)); err != nil {
			return
		}
		if err = SetExcelValue("jinjian_user_name", data, xlsx, "B"+strconv.Itoa(index+2)); err != nil {
			return
		}
		if err = SetExcelValue("agency_employee", data, xlsx, "C"+strconv.Itoa(index+2)); err != nil {
			return
		}
		if err = SetExcelValue("agency_name", data, xlsx, "D"+strconv.Itoa(index+2)); err != nil {
			return
		}
		if err = SetExcelValue("commit_time", data, xlsx, "E"+strconv.Itoa(index+2)); err != nil {
			return
		}
		if err = SetExcelValue("handler", data, xlsx, "F"+strconv.Itoa(index+2)); err != nil {
			return
		}
		if err = SetExcelValue("loan_amount", data, xlsx, "G"+strconv.Itoa(index+2)); err != nil {
			return
		}
		if err = SetExcelValue("approved_amount", data, xlsx, "H"+strconv.Itoa(index+2)); err != nil {
			return
		}
		if err = SetExcelValue("loan_term", data, xlsx, "I"+strconv.Itoa(index+2)); err != nil {
			return
		}
		if err = SetExcelValue("status", data, xlsx, "J"+strconv.Itoa(index+2)); err != nil {
			return
		}
	}

	dirPath := "./assert/query_excel/" + time.Now().Format("2006-01-02") + "/"
	fileName := util.GetCurNanoStr() + ".xlsx"
	if !tool.PathExists(dirPath) {
		os.MkdirAll(dirPath, os.ModePerm)
	}

	if err = xlsx.SaveAs(dirPath + fileName); err != nil {
		logger.Info("===========xlsx.SaveAs err", "err", err.Error())
		return
	}

	url = dirPath + fileName

	return
}

func SetExcelTitle() *excelize.File {
	xlsx := excelize.NewFile()
	xlsx.SetCellValue("Sheet1", "A1", "进件ID")
	xlsx.SetCellValue("Sheet1", "B1", "用户姓名")
	xlsx.SetCellValue("Sheet1", "C1", "业务员")
	xlsx.SetCellValue("Sheet1", "D1", "所属中介")
	xlsx.SetCellValue("Sheet1", "E1", "提交时间")
	xlsx.SetCellValue("Sheet1", "F1", "审核人")
	xlsx.SetCellValue("Sheet1", "G1", "贷款金额")
	xlsx.SetCellValue("Sheet1", "H1", "核准金额")
	xlsx.SetCellValue("Sheet1", "I1", "贷款期数")
	xlsx.SetCellValue("Sheet1", "J1", "当前审批状态")
	return xlsx
}

func SetExcelValue(key string, data map[string]interface{}, xlsx *excelize.File, axis string) (err error) {
	if data[key] == nil {
		err = errors.New("map中" + key + "数据为空请检查")
		return
	}
	xlsx.SetCellValue("Sheet1", axis, data[key])
	return
}

func CheckMapValue(keyName string, originReq map[string]interface{}) (dataList []interface{}, err error) {
	if originReq[keyName] == nil {
		err = errors.New("指定key :" + keyName + " ，对应value 为空，请检查map")
		return
	}
	dataList = originReq[keyName].([]interface{})
	if len(dataList) == 0 {
		err = errors.New("数组长度有错")
		return
	}
	return
}

/***************************************************************************************/

// 审批报表
func MakeApprovalReportForm(dataStr string) (url string, err error) {

	success := gjson.Get(dataStr, "success")
	if success.Exists() && success.Bool() == false {
		return url, errors.New(gjson.Get(dataStr, "info").Str)
	}

	var orderList []model.ApprovalOrder
	if err = util.ParseJson(dataStr, &orderList); err != nil {
		return url, errors.New("订单数据解析错误，请稍后再试")
	}

	xlsx := excelize.NewFile()

	xlsx.SetSheetRow("sheet1", "A1", &[]string{"面签日期", "面签时间", "进件ID", "姓名", "渠道", "评分", "征信信用贷款总额", "状态", "终审时间", "用途", "方案", "是否标准件", "放款额", "拒绝原因"})

	for i, order := range orderList {

		if order.IsStandard == "0" {
			order.IsStandard = "否"
		} else {
			order.IsStandard = "是"
		}

		var plan string
		if gjson.Get(order.RiskParam, "version").Exists() {
			plan = gjson.Get(order.RiskParam, "r2.0.name").Str
			if plan == "" {
				plan = gjson.Get(order.RiskParam, "r2.name").Str
			}
		} else {
			plan = gjson.Get(order.RiskParam, "k1_03").Str
		}

		used, _ := strconv.Atoi(gjson.Get(order.QuantizationMap, "CIPB037").Str)
		loan, _ := strconv.Atoi(gjson.Get(order.QuantizationMap, "CIPB062").Str)

		var zsTime time.Time
		if order.ReTrailStatus == "终审通过" {
			zsTime = *order.ApprovalPassTime
		}
		if order.ReTrailStatus == "终审拒绝" {
			zsTime = *order.ApprovalRefuseTime
		}
		if order.ReTrailStatus == "已撤销" {
			zsTime = *order.CancelTime
		}
		slice := []interface{}{
			order.InterViewFinishTime.Format("2006-01-02"),
			order.InterViewFinishTime.Format("15:04:05"),
			order.ShowId,
			order.JinjianUserName,
			order.AgencyName,
			order.QuantizationPoint,
			used + loan,
			order.ApprovalStatus,
			zsTime.Format("2006-01-02 15:04:05"),
			gjson.Get(order.AllInfo, "personal_info.usage").Str,
			util.Substr(plan, 0, 3),
			order.IsStandard,
			order.ApprovedAmount,
			gjson.Get(order.RefuseReason, "0.label"),
		}

		xlsx.SetSheetRow("sheet1", "A"+strconv.Itoa(i+2), &slice)
	}

	// Save xlsx file by the given path.
	dirPath := "./assert/report_form/" + time.Now().Format("2006-01-02") + "/"
	fileName := "report-" + util.GetCurNanoStr() + ".xlsx"
	if !tool.PathExists(dirPath) {
		os.MkdirAll(dirPath, os.ModePerm)
	}

	if err = xlsx.SaveAs(dirPath + fileName); err != nil {
		logger.Info("===========MakeApprovalReportForm save err", "err", err.Error())
		return
	}

	url = dirPath + fileName
	return
}



// 预审批查询模块下载excel
func PreQueryDownloadExcelFile(originReq map[string]interface{}) (url string, err error){
	dataList, err := CheckMapValue("data", originReq)
	if err != nil {
		return
	}

	xlsx := setPreApprovalOrderExcelTitle()

	for index, originData := range dataList {
		data := originData.(map[string]interface{})
		// 申请次数
		if err = SetExcelValue("pre_approval_count", data, xlsx, "A"+strconv.Itoa(index+2)); err != nil {
			return
		}
		// 预审ID
		if err = SetExcelValue("pre_show_id", data, xlsx, "B"+strconv.Itoa(index+2)); err != nil {
			return
		}
		// 用户姓名
		if err = SetExcelValue("user_name", data, xlsx, "C"+strconv.Itoa(index+2)); err != nil {
			return
		}
		// 身份证号码
		if err = SetExcelValue("user_id_num", data, xlsx, "D"+strconv.Itoa(index+2)); err != nil {
			return
		}
		// 客户经理
		if err = SetExcelValue("customer_managers", data, xlsx, "E"+strconv.Itoa(index+2)); err != nil {
			return
		}
		// 所属渠道
		if err = SetExcelValue("agency_name", data, xlsx, "F"+strconv.Itoa(index+2)); err != nil {
			return
		}
		// 业务员
		if err = SetExcelValue("agency_employee", data, xlsx, "G"+strconv.Itoa(index+2)); err != nil {
			return
		}
		//提交预审批时间
		if err = SetExcelValue("commit_time", data, xlsx, "H"+strconv.Itoa(index+2)); err != nil {
			return
		}
		// 预审批结束时间
		if err = SetExcelValue("updated_at", data, xlsx, "I"+strconv.Itoa(index+2)); err != nil {
			return
		}
		// 客户进件时间
		if err = SetExcelValue("jinjian_time", data, xlsx, "J"+strconv.Itoa(index+2)); err != nil {
			return
		}
		// 状态
		if err = SetExcelValue("status", data, xlsx, "K"+strconv.Itoa(index+2)); err != nil {
			return
		}
	}
	dirPath := "./assert/query_excel/ys/" + time.Now().Format("2006-01-02") + "/"
	fileName := util.GetCurNanoStr() + ".xlsx"
	if !tool.PathExists(dirPath) {
		os.MkdirAll(dirPath, os.ModePerm)
	}

	if err = xlsx.SaveAs(dirPath + fileName); err != nil {
		logger.Info("===========xlsx.SaveAs err", "err", err.Error())
		return
	}

	url = dirPath + fileName


	return
}

// 给下载的excle文件设置标题
func setPreApprovalOrderExcelTitle() *excelize.File{
	xlsx := excelize.NewFile()
	xlsx.SetCellValue("Sheet1", "A1", "申请次数")
	xlsx.SetCellValue("Sheet1", "B1", "预审ID")
	xlsx.SetCellValue("Sheet1", "C1", "用户姓名")
	xlsx.SetCellValue("Sheet1", "D1", "身份证号码")
	xlsx.SetCellValue("Sheet1", "E1", "客户经理")
	xlsx.SetCellValue("Sheet1", "F1", "所属渠道")
	xlsx.SetCellValue("Sheet1", "G1", "业务员")
	xlsx.SetCellValue("Sheet1", "H1", "提交预审批时间")
	xlsx.SetCellValue("Sheet1", "I1", "预审批结束时间")
	xlsx.SetCellValue("Sheet1", "J1", "客户进件时间")
	xlsx.SetCellValue("Sheet1", "K1", "状态")
	return xlsx
}

// 预审批查询下载选择的预审批订单excel文件(以传入预审批id的方式下载)
//func DownloadPreOrderExcel(preApprovalIds []string)(url string , err error){
//	// 根据传入的preApprovalId查询预审批订单
//	var preOrders []model.PreApprovalOrder
//	if err = config.GetDb().Model(&model.PreApprovalOrder{}).Where("pre_approval_id in (?)", preApprovalIds).Find(&preOrders).Error; err != nil && err != gorm.ErrRecordNotFound{
//		logger.Error("err", "根据选择的预审批id查询预审批订单列表出错", err.Error())
//	}
//	xlsx := setPreApprovalOrderExcelTitle()
//
//	for i, preOrder := range preOrders{
//		// 申请次数
//		xlsx.SetCellValue("Sheet1", "A"+strconv.Itoa(i+2), preOrder.PreApprovalCount)
//		// 预审id
//		xlsx.SetCellValue("Sheet1", "B"+strconv.Itoa(i+2), preOrder.PreShowId)
//		// 用户姓名
//		xlsx.SetCellValue("Sheet1", "C"+strconv.Itoa(i+2), preOrder.UserName)
//		// 身份证号码
//		xlsx.SetCellValue("Sheet1", "D"+strconv.Itoa(i+2), preOrder.UserIdNum)
//		// 客户经理
//		xlsx.SetCellValue("Sheet1", "E"+strconv.Itoa(i+2), preOrder.CustomerManagers)
//		// 所属渠道
//		xlsx.SetCellValue("Sheet1", "F"+strconv.Itoa(i+2), preOrder.AgencyName)
//		// 业务员
//		xlsx.SetCellValue("Sheet1", "G"+strconv.Itoa(i+2), preOrder.AgencyEmployee)
//		// 提交预审批时间
//		xlsx.SetCellValue("Sheet1", "H"+strconv.Itoa(i+2), preOrder.CommitTime)
//		// 预审批结束时间
//		xlsx.SetCellValue("Sheet1", "I"+strconv.Itoa(i+2), preOrder.UpdatedAt)
//		// 客户进件时间
//		xlsx.SetCellValue("Sheet1", "J"+strconv.Itoa(i+2), preOrder.JinjianTime)
//		// 状态
//		xlsx.SetCellValue("Sheet1", "K"+strconv.Itoa(i+2), preOrder.PreApprovalStatus)
//	}
//
//	dirPath := "./assert/query_excel/ys/" + time.Now().Format("2006-01-02") + "/"
//	fileName := util.GetCurNanoStr() + ".xlsx"
//	if !tool.PathExists(dirPath) {
//		os.MkdirAll(dirPath, os.ModePerm)
//	}
//
//	if err = xlsx.SaveAs(dirPath + fileName); err != nil {
//		logger.Info("===========xlsx.SaveAs err", "err", err.Error())
//		return
//	}
//
//	url = dirPath + fileName
//	return
//}
