#!/usr/bin/env bash

approval_apigw --env=$QY_ENV --docker_env=$QY_DOCKER_ENV