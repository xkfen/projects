package main

import (
	"gapproval/apigw/router"
	"gcoresys/common"
	"gcoresys/common/logger"
	"gopkg.in/gin-gonic/gin.v1"
	"gcoresys/common/util"
	"time"
)

func main() {

	env := common.DefineRunTimeCommonFlag()
	logger.Info("=========== 运行环境", "env", env)

	port := ":7005"
	if common.GetUseDocker() != 0 {
		port = ":" + common.GetAppConfig().HttpServerPort
		logger.InitLogger(logger.LvlInfo, "qy_approval_apigw.log")
	} else {
		logger.InitLogger(logger.LvlDebug, nil)
	}

	if env == "prod" {
		gin.SetMode(gin.ReleaseMode)
	} else {
		gin.SetMode(gin.DebugMode)
		logger.InitLogger(logger.LvlDebug, nil)
	}

	logger.Info("=========== 系统更新时间： " + time.Now().String())
	logger.Info("=========== api gateway 启动 端口 " + port)
	util.WishNoBug()

	r := router.GetHttpRouter() //获得路由实例
	r.Run(port)
}
