package router

import (
	"github.com/stretchr/testify/suite"
	"testing"
	"gcoresys/common/logger"
	"gapproval/approval/db/config"
	"time"
	"gapproval/approval/grpc"
	"github.com/gavv/httpexpect"
	"gapproval/approval/model"
	"fmt"
	"gapproval/approval/serviceV1"
	"gcoresys/common/util"
	"reflect"
	"strconv"
	"strings"
	"os"
	model2 "gapproval/interview/model"
	"github.com/tidwall/gjson"
)

const (
	baseURL = "http://localhost:7005/api/v1"
	baseURL2 = "http://localhost:7005/api/v2"
)

type testingSuite struct {
	suite.Suite
}

func (s *testingSuite) SetupTest() {
	config.ClearAllData()
}

func (s *testingSuite) TearDownTest() {
	config.ClearAllData()
	os.RemoveAll("./assert")
}

func TestRun(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	// 初始化审批数据库
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	// 初始化apigw服务
	apigw := GetHttpRouter()
	go apigw.Run(":7005")
	// 初始化approval grpc服务
	go grpc.StartApprovalRpcServer()
	time.Sleep(100 * time.Millisecond)
	suite.Run(t, new(testingSuite))
}

// 测试导出终审简报
func (s *testingSuite) TestExportSimpleReport() {
	fmt.Println("123")
	time.Sleep(100 * time.Millisecond)
	order := model.GetDefaultApprovalOrder()
	// 创建测试数据
	if err := config.GetDb().Model(&model.ApprovalOrder{}).Create(order).Error; err != nil {
		panic(err.Error())
	}

	resp := httpexpect.New(s.T(), baseURL).
		POST("/approval/simple_report").
		WithJSON(&model.ApprovalOrder{
		JinjianId: order.JinjianId,
	}).Expect()

	resp.Status(200)
	// 此处返回的是文件而不是json格式的数据，断言文件不为空即可
	resp.Body().NotEmpty()
}

// 查询进件人工作单位和联系人姓名
func (s *testingSuite) TestQueryCompanyContactName() {
	order := model.GetDefaultApprovalOrder()
	// 创建测试数据
	if err := config.GetDb().Model(&model.ApprovalOrder{}).Create(order).Error; err != nil {
		panic(err.Error())
	}

	resp := httpexpect.New(s.T(), baseURL).
		POST("/approval/linkers_for_risk").
		WithJSON(&model.ApprovalOrder{
		JinjianId: order.JinjianId,
	}).Expect()

	respStr := resp.Body().Raw()
	var respJson serviceV1.ContactsResp
	if err := util.ParseJson(respStr, &respJson); err != nil {
		panic(err.Error())
	}
	logger.Info(respStr)

	s.Equal(true, respJson.Success)

	nowTime := time.Now().Unix()
	fmt.Println(nowTime)
}

// 测试根据风险参数得到产品方案
func (s *testingSuite) TestGetProductPlanByRiskParam() {
	order := model.GetDefaultApprovalOrder()
	var productPlanInfo []string
	var err error
	if productPlanInfo, err = GetProductPlanByRiskParam(order); err != nil {
		logger.Info("解析出错", "err", err.Error())
	} else {
		if len(productPlanInfo) > 0 {
			logger.Info("msg", "result", productPlanInfo[0])
		}
	}
}

func GetProductPlanByRiskParam(order *model.ApprovalOrder) (productPlanInfo []string, err error) {
	var result []string
	var riskParamMap map[string]interface{}
	if err := util.ParseJson(order.RiskParam, &riskParamMap); err == nil {
		if data, ok := riskParamMap["r2"]; ok {
			switch data.(type) {
			case []interface{}:
				logger.Info("数组类型")
				debtArray := data.([]interface{})
				logger.Info("msg", "数组长度", len(debtArray))
				for _, debtInfo := range debtArray {
					logger.Info("msg", "debtInfo", debtInfo)
					if debt, ok := debtInfo.(map[string]interface{}); ok {
						logger.Info("msg", "debt:", debt)
						logger.Info("msg", "debt[name]", debt["name"])
						logger.Info("msg", "方案名称", debt["name"].(string))
						logger.Info("msg", "方案内容", debt["content"].(map[string]interface{}))
						if contentDataMap, ok := debt["content"].(map[string]interface{}); ok {
							logger.Info("msg", "contentDataMap:", contentDataMap)
							logger.Info("msg", "content---monthlyRepayment:", contentDataMap["monthlyRepayment"])
						}
						result = append(result, debt["name"].(string))
					}
				}
			case interface{}:
				logger.Info("结构体/map类型")
				if dataMap, ok := data.(map[string]interface{}); ok {
					logger.Info("msg", "方案名称", dataMap["name"].(string))
					productPlanInfo = append(productPlanInfo, dataMap["name"].(string))
					logger.Info("r2类型", "policyList", reflect.TypeOf(dataMap["policyList"]))
					if policyData, ok := dataMap["policyList"]; ok {
						switch policyData.(type) {
						case []interface{}:
							logger.Info("数组类型")
							if dataMap, ok := (policyData.([]interface{})[0]).(map[string]interface{}); ok {
								fmt.Println(dataMap["policy_name"])
								logger.Info("msg", "名称", dataMap["policy_name"].(string))
							} else {
								logger.Error("err", "数组类型的dataMap解析出错", err.Error())
							}
						}
					}
				} else {
					logger.Error("err", "结构体/map类型的dataMap解析出错", err.Error())
				}

			}
		}
		logger.Info("r2类型", "info", reflect.TypeOf(riskParamMap["r2"]))
	} else {
		logger.Error("申请方案解析出错", "err", err.Error())
	}
	logger.Info("msg", "result", result)
	return productPlanInfo, nil
}

// 测试自动生成客户封面
func (s *testingSuite) TestAutoGenerateCustomerCover() {
	order := model.GetDefaultApprovalOrder()
	order.Cellphone = "15302678545"
	order.FirstTrailName = "赵宣"

	// 创建测试数据
	if err := config.GetDb().Model(&model.ApprovalOrder{}).Create(order).Error; err != nil {
		panic(err.Error())
	}
	resp := httpexpect.New(s.T(), baseURL).
		POST("/approval/auto_generate_customer_cover").
		WithJSON(&model.ApprovalOrder{
		JinjianId: order.JinjianId,
	}).Expect()
	resp.Status(200)
	// 此处返回的是文件而不是json格式的数据，断言文件不为空即可
	resp.Body().NotEmpty()
}

// 测试根据风险参数得到负债信息
func (s *testingSuite) TestGetDebtByRiskParam() {
	order := model.GetDefaultApprovalOrder()
	if debtInfo, count, err := getBebtInfoByRiskParam(order); err != nil {
		logger.Info("解析出错", "err", err.Error())
	} else {
		logger.Info("msg", "debtInfo", debtInfo)
		logger.Info("msg", "count", count)
	}
}

func getBebtInfoByRiskParam(order *model.ApprovalOrder) (debtResult string, count int, err error) {
	var riskParamMap map[string]interface{}
	if err = util.ParseJson(order.RiskParam, &riskParamMap); err != nil {
		logger.Error("err", "将风险参数riskP	aram转json出错", err.Error())
		return
	}
	debtInfoArray := util.GetArrFromJson(riskParamMap, "r15")
	logger.Info("msg", "数组长度", len(debtInfoArray))
	if len(debtInfoArray) <= 0 {
		return debtResult, 1, nil
	}
	for i, debtInfo := range debtInfoArray {
		logger.Info("msg", "debtInfo", debtInfo)
		debt := util.JsonToMap(debtInfo)
		debtType := util.GetStrFromJson(debt, "type")
		contentDataMap := util.GetJsonFromJson(debt, "content")

		if strings.Contains(debtType, "CREDIT") {
			debtResult += fmt.Sprintf("%d.%v银行：%v发放信用贷款%v万，月供%v元；", i+1, contentDataMap["loanAgency"], contentDataMap["loanDate"], changeString2Float64(contentDataMap["loanAmount"].(string)), contentDataMap["monthlyRepayment"]) + "\n\r"
		} else {
			debtResult += fmt.Sprintf("%d.%v银行：%v发放按揭贷款%v万，月供%v元；", i+1, contentDataMap["loanAgency"], contentDataMap["loanDate"], changeString2Float64(contentDataMap["loanAmount"].(string)), contentDataMap["monthlyRepayment"]) + "\n\r"
		}
	}
	return debtResult, len(debtInfoArray) + 1, nil
}

// 将string转float64
func changeString2Float64(key string) (result float64) {
	if value, passErr := strconv.ParseFloat(key, 64); passErr == nil {
		result = value / 10000
	} else {
		logger.Warn("string to float64 err", "key", key)
	}
	return
}

// 测试根据风险参数得到申请方案信息---简报
func (s *testingSuite) TestSimpleReport() {
	order := model.GetDefaultApprovalOrder()
	if productPlan, err := GetProductPlanByRiskParamSimpleReport(order); err != nil {
		logger.Info("err", "解析出错", err.Error())
	} else {
		logger.Info("申请方案:" + productPlan)
	}

}
func GetProductPlanByRiskParamSimpleReport(order *model.ApprovalOrder) (productPlan string, err error) {
	var riskParamMap map[string]interface{}
	//  解析RiskParam为json
	if err = util.ParseJson(order.RiskParam, &riskParamMap); err != nil {
		logger.Error("err", "将风险参数riskP	aram转json出错----简版申请方案----", err.Error())
		return
	}
	// 将riskParamMap转为结构体
	productPlanStruct := util.GetMapToInterface(riskParamMap, "r2")
	// 判断结构体类型
	switch  productPlanStruct.(type) {
	case []interface{}:
		// 数组类型---强转为interface数组---循环遍历
		for i, planStruct := range productPlanStruct.([]interface{}) {
			productPlanInfo := util.JsonToMap(planStruct)
			// 得到结构体里面的Name
			name := util.GetStrFromJson(productPlanInfo, "name")
			// 得到json结构体里面的content
			contentJson := util.GetJsonFromJson(productPlanInfo, "content")
			// 将json里面的content转为结构体
			contentMap := util.JsonToMap(contentJson)
			// 取出content机构体里面的monthly_supply_amount
			monthlySupply := util.GetStrFromJson(contentMap, "monthly_supply_amount")
			// monthly_supply_amount/10000
			result := strconv.FormatFloat(changeString2Float64(monthlySupply), 'f', -1, 64)
			productPlan += fmt.Sprintf("%d.%v %v万", i+1, name, result)
		}
	case interface{}:
		// interface类型---强转为结构体
		productPlanMap := util.JsonToMap(productPlanStruct)
		name := util.GetStrFromJson(productPlanMap, "name")
		// policyList结构体
		policyListStruct := util.GetMapToInterface(productPlanMap, "policyList")
		logger.Info("policyListStruct:" + util.StringifyJson(policyListStruct))
		for i, policyStruct := range policyListStruct.([] interface{}) {
			policyInfo := util.JsonToMap(policyStruct)
			// 得到policyList结构体里面的policy_amount
			policyAmount := util.GetFloatFromJson(policyInfo, "policy_amount")
			logger.Info("policyAmount", "policyAmount", policyAmount)
			// 将policy_amount/10000
			result := strconv.FormatFloat(policyAmount/10000, 'f', -1, 64)
			productPlan += fmt.Sprintf("%d.%v %v万", i+1, name, result)
		}
	}
	return
}

// todo
func (s *testingSuite) TestFileDownload() {
	ao := model.GetDefaultApprovalOrder()
	ao.InterView = model2.GetTestInterviewCompleteString()
	s.NoError(ao.Create())

	file := model.GetDefaultApprovalFile()
	file.JinjianId = ao.JinjianId
	s.NoError(file.Create())
	resp := httpexpect.New(s.T(), baseURL2).
		POST("/file_download").
		WithJSON(map[string]string{"jinjian_id":ao.JinjianId}).Expect()
	resp.Status(400)
	fmt.Println(resp.Body().Raw())
	s.Equal("未找到文件，压缩失败", gjson.Get(resp.Body().Raw(), "info").Str)
}