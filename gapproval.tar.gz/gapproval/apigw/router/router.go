package router

import (
	"gapproval/apigw/handler"
	"gopkg.in/gin-gonic/gin.v1"
	"gapproval/common/ginlog"
)

func GetHttpRouter() *gin.Engine {
	r := gin.Default() //获得路由实例

	// 审批前段改版
	v2 := r.Group("/api/v2")
	v2.Use(ginlog.PrintReq())
	v2.Use(ginlog.PrintResp())
	v2.Use(handler.AuthValidateTokenHandler)
	{

		v2.POST("/approval/uniform_interface/:method", handler.ApprovalNewHandler)

		// 文件上传操作
		v2.POST("/file_operations", handler.UploadApprovalFileHandler)
		// 文件打包下载
		v2.POST("/file_download", handler.DownloadApprovalFileHandler)

		// 预审文件操作
		v2.POST("/pre_file_operations", handler.UploadPreApprovalFileHandler)
		// 预审文件打包下载
		v2.POST("/pre_file_download", handler.DownloadPreApprovalFileHandler)

		// **********************新风控接口**********************
		// 新建(匹配)内部危险名单
		v2.POST("/uniform_interface/NewQyDangerList", handler.ProxyRiskControlHandler)
		// 查询内部危险名单
		v2.POST("/uniform_interface/GetQyDangerList", handler.ProxyRiskControlHandler)
	}

	a := r.Group("/api/v1")
	a.Use(ginlog.PrintReq())
	a.Use(ginlog.PrintResp())
	{
		// 查询审批系统状态
		a.GET("/check_stats/approval", handler.CheckQyApprovalStats)
		a.GET("/check_stats/apigw", handler.CheckApigwStats)

		// 统一通用接口 | internal | external
		a.POST("/approval/uniform_interface/:auth_type/:method", handler.ApprovalHandler)

		// sso 登录
		a.POST("/login", handler.SsoLogin)
		// 进件 创建审批单
		a.POST("/approvalOrder", handler.NewApprovalOrderHandler)
		// 中介 获取审批列表
		a.POST("/approvalOrderList", handler.GetApprovalOrderListHandler)
		// 中介 更改审批单状态
		a.POST("/approvalOrder/changeStatus", handler.AgencyChangeStatusHandler)
		// 渠道 获取审批详情
		a.POST("/approvalOrder/info", handler.GetApprovalInfoHandler)
		// 进件 实时更新
		a.POST("/approvalOrder/real_time_update", handler.RealTimeUpdateOtherBank)
		// 进件 补录
		a.POST("/approval_order/bulu", handler.UpdateJinJianBuLu)
		// 进件 关闭补录
		a.POST("/approval_order/bulu_qy", handler.UpdateJinJianBuLuByQy)
		// 财务 审批操作
		a.POST("/approval_order/approval_operation/cw", handler.CwOperationHandler)
		// 查询联系人姓名和进件人姓名
		a.POST("/approval/linkers_for_risk", handler.QueryCompanyAndContactNameHandler)
		// 获取审批报表
		a.GET("/approval/report_form", handler.DownloadReportFormHandler)
	}

	v1 := r.Group("/api/v1")
	v1.Use(ginlog.PrintReq())
	v1.Use(ginlog.PrintResp())
	v1.Use(handler.AuthValidateTokenHandler)
	{
		// 用户个人信息补充
		v1.POST("/approval_order/user_info_sup", handler.ApprovalUserInfoSupHandler)
		// 非标件
		v1.POST("/approval_order/standard", handler.MarkIsStandardHandler)
		// 审批筛选
		v1.POST("/approval_query", handler.QueryHandler)
		// 获取三方信息
		v1.POST("/approval_order/get_three_party_info", handler.GetThreePartyInfoHandler)
		// 创建或更新三方信息
		v1.POST("/approval_order/three_party_info", handler.NewOrUpdateThreePartyInfoHandler)
		// 更新审批信息
		v1.PUT("/approval_order/all_info", handler.UpdateJinjianAllInfoHandler)
		// 添加扣款卡
		v1.POST("/approval_order/add_pay_card", handler.AddPayCardHandler)
		// 新增或修改联系人
		v1.POST("/approval/contact", handler.AddOrUpdateAddContactHandler)
		// 风险参数
		v1.POST("/approval/risk_param", handler.NewOrUpdateRiskParamHandler)
		// 分机号
		v1.POST("/approval/extension_number", handler.NewOrUpdateExtensionNumberHandler)
		// 电核材料
		v1.POST("/approval/call_record", handler.ApprovalCallRecordHandler)
		// 审批  获取审批列表 通过身份
		v1.POST("/approval_order", handler.GetApprovalListHandler)
		// 审批  获取审批详情 通过身份
		v1.POST("/approval_order/info", handler.GetApprovalOrderHandler)
		// 审批  抢单 通过身份
		v1.POST("/grab_approval", handler.GrabApprovalHandler)
		// 审批  获取审批记录
		v1.POST("/approval_order/log", handler.GetApprovalLogHandler)
		// 审批  创建初审结论
		v1.POST("/approval_order/cs_result", handler.NewApprovalCsResultHandler)
		// 审批  获取初审结论
		v1.POST("/approval_order/get_cs_result", handler.GetApprovalCsResultHandler)
		// 审批  获取评分
		v1.POST("/approval_order/get_score", handler.GetAndSetScoreHandler)
		// 审批  审批操作
		v1.POST("/approval_order/approval_operation", handler.ApprovalOperationHandler)
		// 审批  审批挂起
		v1.POST("/approval_order/approval_operation/sus", handler.ApprovalSuspendHandler)
		// 审批打开面签历史订单修改面签资料的开关
		v1.POST("/approval_order/interview_update_history", handler.InterviewUpdateHistoryHandler)
		// 导出终审简报文档
		v1.POST("/approval/simple_report", handler.SimpleReportHandler)
		// 自动生成客户封面
		v1.POST("/approval/auto_generate_customer_cover", handler.AutoGenerateCustomerCoverHandler)
		// 审批开关控制面签历史订单补件
		v1.POST("/approval/interview_switch", handler.UpdateApprovalInterviewSwitchHandler)
		// 下载审批筛选excel
		v1.POST("/approval_query/download", handler.DownloadQueryHandler)
		// 文件上传 以及历史文件上传需要组密码
		v1.POST("/approval_order/file", handler.UploadApprovalFileV1)
		// 文件上传下载
		v1.POST("/upload", handler.UploadFile)

		// 浏览CA合同
		v1.POST("/contract/ca/preview_ca_contract", handler.PreviewCaContract)
		// 提交CA合同
		v1.POST("/contract/ca/commit_ca_contract", handler.CommitCaContract)
		// 下载合同
		v1.GET("/contract/:jinjianId", handler.GetContract)
		// 上传合同
		v1.POST("/contract", handler.UploadContract)

		// sso ---------------------------
		v1.POST("/users", handler.SsoGetUserList)
		v1.PUT("/user", handler.SsoUpdateUserPassword)
		v1.POST("/approval_order/auth_group_pwd", handler.AuthGroupPwd)

		// 风控接口 ---------------------------
		v1.POST("/risk_control/blanklists", handler.GetBlankLists)
		v1.POST("/risk_control/multipoints", handler.GetMultipoints)
		v1.POST("/risk_control/phoneinfo", handler.GetPhoneInfo)
		v1.POST("/risk_control/phonestatements", handler.GetPhoneStatements)
		v1.POST("/risk_control/mainbankinfo", handler.GetMainBankInfo)
		v1.POST("/risk_control/mainbankstatements", handler.GetMainBankStatements)
		v1.POST("/risk_control/secbankinfo", handler.GetSecBankInfo)
		v1.POST("/risk_control/secbankstatements", handler.GetSecBankStatements)
		v1.POST("/risk_control/idCardInfo", handler.GetIdCardInfo)
		v1.POST("/risk_control/updateBankStatements", handler.UpdateBankStatements)
		v1.POST("/risk_control/validateBank", handler.ValidateBank)
		v1.POST("/approval_order/simple_credit_report", handler.SimpleCreditReportHandler)
		v1.POST("/pre_approval_order/get_risk_ctrl_info", handler.RiskCtrlProxyHandler)

		// 电核接口 ---------------------------
		v1.POST("/call/bind_phone", handler.BindPhoneHandler)
		v1.POST("/call/cancel_bind", handler.CancelBindPhoneHandler)
		v1.POST("/call/get_record", handler.GetCallRecordHandler)
		v1.POST("/call/get_records", handler.GetCallAllRecordsHandler)
		v1.POST("/call/add_from_phone", handler.AddCallNumberHandler)
		v1.POST("/call/get_has_records", handler.GetHasRecordsHandler)
		v1.GET("/call/from_phones/:approvalType", handler.GetAllCallNumberHandler)
		v1.POST("/call/call", handler.CallPhoneHandler)
		v1.POST("/call/cancel_call", handler.CancelCallPhoneHandler)
		v1.POST("/call/get_call_status", handler.GetCallStatusHandler)
		v1.POST("/call/update_record_remark", handler.UpdateRecordRemarkHandler)

		// 核心系统 ---------------------------
		v1.POST("/approval_order/previewRepayPlans", handler.GetPreviewRepayPlans)
		v1.POST("/approval_query/repay_plans", handler.GetRepayPlansHandler)
		v1.POST("/approval_query/repay_record", handler.GetRepayRecordProxyHandler)

		// 流水标签 ---------------------------
		v1.POST("/approval_order/flow_tag", handler.FlowTagHandler)

		// 获取易宝卡 ---------------------------
		v1.GET("/qy/yb_card/:jinjianId", handler.GetYbCard)

		// 预审批查询下载excel
		v1.POST("pre_approval_query/download", handler.DownloadPreOrderQueryHandler)

	}
	// 静态文件
	r.Static("/assert", "./assert")
	return r
}
