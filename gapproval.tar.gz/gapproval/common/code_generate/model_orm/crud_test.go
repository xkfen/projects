package model_orm

import (
	"testing"
	"fmt"
	"github.com/stretchr/testify/assert"
)

/**
 @FileDescription: 
 @author: WangXi
 @create: 11:44 2018/2/27
*/

func TestGetCode(t *testing.T) {
	bt := GetCurdCode("Ass")
	assert.Empty(t, bt)
	fmt.Println(string(bt))
}
