package model_orm

import (
	"text/template"
	"log"
	"bytes"
	"go/format"
	"gapproval/common/code_generate/util"
)

/**
 @FileDescription: 
 @author: WangXi
 @create: 11:10 2018/2/27
*/

const strTmp = `

func ({{.name}} *{{.typ}}) Create() error {
	if err := config.GetDb().Model({{.name}}).Create({{.name}}).Error; err != nil {
		logger.Error("================ model {{.typ}} Create", "err", err.Error())
		return err
	}
	return nil
}

func Get{{.typ}}ByJinjianId(jinjianId string) ({{.name}} {{.typ}}, err error) {
	if err = config.GetDb().Model(&{{.name}}).Where("jinjian_id = ?", jinjianId).First(&{{.name}}).Error; err != nil {
		logger.Error("============= model {{.typ}} Get{{.typ}}ByJinjianId", "err", err.Error())
		return
	}
	return
}

func ({{.name}} *{{.typ}}) Update(update ...interface{}) error {
	if len(update) == 0 {
		if err := config.GetDb().Model({{.name}}).Where("id = ?", {{.name}}.ID).Updates({{.name}}).Error; err != nil {
			logger.Error("=================== model {{.typ}} Update Updates", "err", err.Error())
			return err
		}
		return nil
	}

	// 类型判断
	switch u := update[0];u.(type) {
	case map[string]interface{}:
		if err := config.GetDb().Model({{.name}}).Where("id = ?", {{.name}}.ID).Update(u).Error; err != nil {
			logger.Error("=================== model {{.typ}} Update Map[string]interface", "err", err.Error())
			return err
		}
	default:
		return errors.New("更新 {{.name}} 参数类型未设置, 请检查")
	}

	return nil
}

`

func GetCurdCode(typeName string) []byte {
	data := map[string]interface{}{
		"typ":  typeName,
		"name": util.GetNameByTypeName(typeName),
	}

	//利用模板库，生成代码文件
	t, err := template.New("").Parse(strTmp)
	if err != nil {
		log.Fatal(err)
	}
	buff := bytes.NewBufferString("")
	err = t.Execute(buff, data)
	if err != nil {
		log.Fatal(err)
	}
	//格式化
	src, err := format.Source(buff.Bytes())
	if err != nil {
		log.Fatal(err)
	}

	return src
}
