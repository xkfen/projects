package model_valid

import (
	"fmt"
	"reflect"
	"strings"
)

func MakeModelIsValid(model interface{}) {
	t := reflect.TypeOf(model)
	if t.Kind() == reflect.Ptr {
		fmt.Println("传入的model不能为指针, 请检查")
		return
	}
	if t.NumField() == 0 {
		fmt.Println("结构体:" + t.Name() + " 没有声明字段, 请检查")
		return
	}

	n := strings.ToLower(t.Name()[0:1])

	fmt.Println(fmt.Sprintf("func (%v *%v) IsValid() error {", n, t.Name()))
	for i := 0; i < t.NumField(); i++ {
		sf := t.Field(i)
		res := typeToInitValue(sf.Type)
		if res == nil {
			continue
		}
		fmt.Println(fmt.Sprintf("\tif %v.%v == %v {\n\t\treturn errors.New(\"%v不能为空\")\n\t}", n,sf.Name, res, getFieldJsonTag(sf)))
	}
	fmt.Println("\treturn nil\n}")
}

func typeToInitValue(t reflect.Type) interface{} {
	switch t.Kind() {
	case reflect.String:
		return "\"\""
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64, reflect.Uint, reflect.Uint8,
		reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Float32, reflect.Float64:
		return 0
	default:
		// 未知类型则跳过
		return nil
	}
}

func getFieldJsonTag(sf reflect.StructField) (tag string) {
	tag = sf.Tag.Get("json")
	if tag == "" {
		return sf.Name
	}
	return
}
