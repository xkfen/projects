package model_valid

import (
	"testing"
	"gapproval/approval/model"
)

func TestMakeModelIsValid(t *testing.T) {

	MakeModelIsValid(model.ApprovalOrder{})

}