package util

import (
	"testing"
)

/**
 @FileDescription: 
 @author: WangXi
 @create: 10:14 2018/2/27
*/

func TestName(t *testing.T) {
	GetNameByTypeName("AA")
}