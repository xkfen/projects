package util

import (
	"log"
	"strings"
)

/**
 @FileDescription: 
 @author: WangXi
 @create: 10:06 2018/2/27
*/

func GetNameByTypeName(typeName string) (name string) {
	typeNameIsValid(typeName)
	name = strings.ToLower(string(typeName[0])) + typeName[1:]
	return
}

// 检查 typeName 是否是合法的
func typeNameIsValid(typeName string) {
	// 判断是否是空的
	if typeName == "" {
		log.Fatal("-type 必填")
	}

	// 判断第一位是否是大写
	if string(typeName[0]) != strings.ToUpper(string(typeName[0])) {
		log.Fatal("type name 格式错误，第一位需大写")
	}
}
