package util

import (
	"testing"
)

func TestGetQuantifiedExcel(t *testing.T) {
	//r, err := GetQuantifiedExcel("风险变量.xlsx", 0, 5)
	//assert.NoError(t, err, "应该是没有错误的")
	//assert.NotNil(t, r, "返回结果不为空")
	//fmt.Println(r["E15"])
	//fmt.Println(r["E16"])
	//fmt.Println(r["E17"])

}

func TestCheckIndexIsOutOfRange(t *testing.T) {
	//assert.Equal(t, CheckIndexIsOutOfRange(2, 1), true, "数组越界")
	//assert.Equal(t, CheckIndexIsOutOfRange(1, 3), false, "数组没越界")
}

func TestGetColAllValue(t *testing.T) {
	//xlFile, err := xlsx.OpenFile("风险变量.xlsx")
	//assert.NoError(t, err, "应该是没有错误的")
	//sheet := xlFile.Sheets[0]
	//assert.Equal(t, sheet.MaxRow, 93)
	//fmt.Println(sheet.MaxCol)
	//resultMap, err := GetColAllValue(sheet, 5)
	//assert.NoError(t, err)
	//fmt.Println(resultMap["E74"])
	//for _,v := range resultMap {
	//	//fmt.Println(v)
	//}
}

func TestGetColAllValue2(t *testing.T) {
	//xlFile, err := xlsx.OpenFile("风险变量.xlsx")
	//assert.NoError(t, err, "应该是没有错误的")
	//sheet := xlFile.Sheets[0]
	//_, err = GetColAllValue(sheet, 5)
	//assert.NoError(t, err, "应该没有错误")

	//for _,v := range resultMap {
	//	fmt.Println(v)
	//}

}

func TestGetColAllKeyAndValue(t *testing.T) {
	//xlFile, err := xlsx.OpenFile("风险变量.xlsx")
	//assert.NoError(t, err, "应该是没有错误的")
	//sheet := xlFile.Sheets[0]
	//_, err = GetColAllKeyAndValue(sheet, 3, 5)
	//assert.NoError(t, err, "应该没有错误")

	//for k,v := range resultMap {
	//	fmt.Println(k+" :  "+v)
	//}

}
