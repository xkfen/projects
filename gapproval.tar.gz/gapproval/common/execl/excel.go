package util

import (
	"errors"
	"github.com/tealeg/xlsx"
	"strconv"
	"gcoresys/common/logger"
	"gapproval/common/tool"
)

// 读取Excel指定sheet
func GetQuantifiedExcel(excelPath string, sheetIndex int, colIndex int) (resultMap map[string]string, err error) {
	if !tool.PathExists(excelPath) {
		err = errors.New("未找到Excel文件，请检查路径")
	}
	// 读取Excel
	xlFile, err := xlsx.OpenFile(excelPath)
	if err != nil {
		return
	}
	// 这里会获取到Excel Sheet数组，长度一定大于等于1
	if CheckIndexIsOutOfRange(sheetIndex, len(xlFile.Sheets)) {
		err = errors.New("sheets数组越界，请检查sheetIndex")
		return
	}
	// 获取有用列的所有值
	resultMap, err = GetColAllValue(xlFile.Sheets[sheetIndex], colIndex)

	if err != nil {
		logger.Info("获取Excel量化列出错", "err", err.Error())
		return nil, err
	}

	if resultMap == nil {
		err = errors.New("读取结果为空，请检查")
		return nil, err
	}

	return
}

// 获取指定列所有的值
func GetColAllValue(sheet *xlsx.Sheet, colIndex int) (resultMap map[string]string, err error) {
	if CheckIndexIsOutOfRange(colIndex, sheet.MaxCol) {
		err = errors.New("value cols数组越界，请检查colIndex")
		return
	}
	resultMap = make(map[string]string)
	for i, row := range sheet.Rows {
		// 第一行说明，不需要
		if i == 0 {
			continue
		}

		if colIndex == 5 {
			// 格式化日期   这几项日期需要格式化成yyyy-mm-dd
			if i == 1 || i == 6 || i == 91 {
				row.Cells[colIndex].NumFmt = "yyyy-mm-dd"
				if err = tool.CheckDateString(row.Cells[colIndex].String(), "yyyy/mm/dd"); err != nil {
					err = errors.New("第" + strconv.Itoa(i) + "项" + err.Error())
					return
				}
			}

			// 格式化数值，防止最为一位小数位0，被处理没了
			if i >= 15 && i <= 17 {
				row.Cells[colIndex].NumFmt = "#,##0.00;(#,##0.00)"
				if err = tool.CheckDateString(row.Cells[colIndex].String(), "yyyy.mm"); err != nil {
					return
				}
			}
		}

		resultMap["E"+strconv.Itoa(i)] = row.Cells[colIndex].String()
		//fmt.Println(resultMap["E"+strconv.Itoa(i)])
	}
	return
}

// 判断index是否越界, 越界TRUE
func CheckIndexIsOutOfRange(index int, arrayLength int) bool {
	return index > arrayLength
}

// 获取量化变量说明 key  这个方法可能是一个临时方法，以后没有这个需求
func GetQuantifiedKeyAndValue(excelPath string, sheetIndex int, keyColIndex int, valueColIndex int) (resultMap map[string]string, err error) {
	if !tool.PathExists(excelPath) {
		err = errors.New("未找到Excel文件，请检查路径")
	}
	// 读取Excel
	xlFile, err := xlsx.OpenFile(excelPath)
	if err != nil {
		return
	}
	// 这里会获取到Excel Sheet数组，长度一定大于等于1
	if CheckIndexIsOutOfRange(sheetIndex, len(xlFile.Sheets)) {
		err = errors.New("sheets数组越界，请检查sheetIndex")
		return
	}

	// 获取量化变量值
	resultMap, err = GetColAllKeyAndValue(xlFile.Sheets[sheetIndex], keyColIndex, valueColIndex)

	return
}

// 获取量化变量key and value 前端显示   临时方法
func GetColAllKeyAndValue(sheet *xlsx.Sheet, keyColIndex int, valueColIndex int) (resultMap map[string]string, err error) {
	if CheckIndexIsOutOfRange(keyColIndex, sheet.MaxCol) {
		err = errors.New("key cols数组越界，请检查colIndex")
		return
	}

	if CheckIndexIsOutOfRange(valueColIndex, sheet.MaxCol) {
		err = errors.New("value cols数组越界，请检查colIndex")
		return
	}

	if CheckIndexIsOutOfRange(1, sheet.MaxCol) {
		err = errors.New("二级分类 cols数组越界，请检查colIndex")
		return
	}

	if CheckIndexIsOutOfRange(2, sheet.MaxCol) {
		err = errors.New("二级分类 cols数组越界，请检查colIndex")
		return
	}

	resultMap = make(map[string]string)
	for i, row := range sheet.Rows {
		// 第一行说明，不需要
		if i == 0 {
			continue
		}

		// 格式化日期   这几项日期需要格式化成yyyy-mm-dd     现在没什么灵活的方法去实现
		if i == 1 || i == 6 || i == 91 {
			row.Cells[valueColIndex].NumFmt = "yyyy-mm-dd"
		}

		key := row.Cells[keyColIndex].String()

		// 为了显示量化变量的说明，必须对map中的key进行拼接, 心好累  =_=!!!
		if i <= 23 && i >= 18 {
			key = row.Cells[2].String() + "-" + key
		}

		if i <= 25 && i >= 24 {
			key = "贷款逾期-" + key
		}

		if i <= 27 && i >= 26 {
			key = "贷记卡逾期-" + key
		}

		if i <= 30 && i >= 28 {
			key = "未结清贷款信息汇总-" + key
		}

		if i <= 35 && i >= 31 {
			key = "未销户贷记卡信息汇总-" + key
		}

		if i <= 37 && i >= 36 {
			key = row.Cells[1].String() + "-" + key
		}

		if i <= 50 && i >= 38 {
			key = "贷款-还款记录-" + key
		}

		if i <= 53 && i >= 51 {
			key = "贷款-" + row.Cells[1].String() + "-" + key
		}

		if i == 54 {
			key = "贷记卡-" + "逾期金额-" + key
		}

		if i <= 67 && i >= 55 {
			key = "贷记卡-" + "还款记录-" + key
		}

		if i <= 69 && i >= 68 {
			key = "贷记卡-" + row.Cells[2].String() + "-" + key
		}

		if i <= 71 && i >= 70 {
			key = "担保信息-" + row.Cells[2].String() + "-" + key
		}

		if i == 72 {
			key = "强制执行记录-" + key
		}

		if i <= 75 && i >= 73 {
			key = "住房公积金参缴记录-" + key
		}

		if i == 76 {
			key = "老保险缴存记录-" + key
		}

		if i == 77 {
			key = "本人声明-" + key
		}

		if i == 78 {
			key = "异议标注-" + key
		}

		if i == 79 {
			key = "信贷查询记录明细-查询时间为近三个月-" + key
		}

		if i <= 83 && i >= 80 {
			key = "信贷查询记录明细-查询时间为近六个月-" + key
		}

		if i <= 87 && i >= 84 {
			key = "信贷查询记录明细-查询时间为近一年-" + key
		}

		if i <= 90 && i >= 89 {
			key = "央行征信报告评分-" + key
		}

		if i <= 92 && i >= 91 {
			key = "新一贷放款情况-" + key
		}

		resultMap[key] = row.Cells[valueColIndex].String()
		//fmt.Println(resultMap["E"+strconv.Itoa(i)])
	}
	return

}
