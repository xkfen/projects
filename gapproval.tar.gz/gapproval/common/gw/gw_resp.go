package gw

import (
	"gcoresys/common/util"
	"gopkg.in/gin-gonic/gin.v1"
)

type RenderErrorResp struct {
	Success  bool   `json:"success"`
	ErrorMsg string `json:"errmsg"`
	Info     string `json:"info"`
}

func RenderError(c *gin.Context, info string) {
	c.JSON(400, RenderErrorResp{Success: false, ErrorMsg: info, Info: info})
}

func RenderErrorNoAuth(c *gin.Context, info string) {
	c.JSON(403, RenderErrorResp{Success: false, ErrorMsg: info, Info: info})
}

func RenderSuccess(c *gin.Context, resultJson interface{}) {

	result, err := interfaceToMapInterface(resultJson)

	if d, ok := result["success"].(bool); ok && d {
		c.JSON(200, result)
	} else {
		// success为false或未获取到 则手动赋值为false
		result["success"] = false

		// 当 json 字符串解析错误是时 将字符串直接返回出去
		if err != nil {
			result["info"] = resultJson
		}

		c.JSON(400, result)
	}
}

func interfaceToMapInterface(resultJson interface{}) (result map[string]interface{}, err error) {
	switch resultJson.(type) {

	case string:
		err = util.ParseJson(resultJson.(string), &result)

	case map[string]interface{}:
		result = resultJson.(map[string]interface{})

	}
	return
}
