package gw

import (
	"testing"
	"github.com/stretchr/testify/assert"
)

func TestRenderError(t *testing.T) {

	_, err := interfaceToMapInterface("jinjian id 不能为空")
	assert.NotEqual(t, nil, err)
}
