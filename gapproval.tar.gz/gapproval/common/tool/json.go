package tool

import (
	"strconv"
	"strings"
	"regexp"
	"errors"
	"gcoresys/common/util"
	"reflect"
	"gapproval/approval/model"
	"gcoresys/common/logger"
	"fmt"
)

func isInteger(key string) bool {
	result, _ := regexp.MatchString(`[0-9]+`, key)
	return result
}

// 修改json字符串中的某个字段, pattern表示字段路径, 规则举例如下:
// "xx.yy.0.zz#", 其中#表示将 "json格式字符串 或 数组格式字符串" 以字符串的形式存入; 如果不带#,则转换为对象后再存入
// 上面的表达式相当于: {xx:{yy:[{zz:"value"}]}}

func UpdateIntoJson(original string, pattern string, value interface{}) (jsonStr string, err error) {
	var base []interface{}
	var IsValueStr bool

	if strings.Contains(pattern, "#") {
		pattern = strings.Trim(pattern, "#")
		IsValueStr = true
	}

	keys := strings.Split(pattern, ".")
	if len(keys) == 0 || keys[0] == "" {
		return "", errors.New("不能传空pattern")
	}

	var resultMap map[string]interface{}
	if err = util.ParseJson(original, &resultMap); err != nil {
		logger.Error("UpdateIntoJson err!", "original", original)
		logger.Error("UpdateIntoJson err!", "pattern", pattern)
		return "", errors.New("UpdateIntoJson 转换json出错; error: " + err.Error())
	}

	base = append(base, resultMap[keys[0]])

	for i, key := range keys[1:] {
		if key == "" {
			return "", errors.New("key不能为空, 请检查参数")
		}
		if isInteger(key) {
			if transfer, ok := base[i].([]interface{}); ok {
				index2, _ := strconv.Atoi(key)
				//if len(transfer) == index2 {
				//	return addingSlice(base, keys[i:], value) // todo, 向数组中添加元素
				//}
				if len(transfer) < index2 {
					return "", errors.New("数组越界")
				}
				base = append(base, transfer[index2])
			}
		} else {
			if transfer, ok := base[i].(map[string]interface{}); ok {
				if _, ok := transfer[key]; !ok {
					return "", errors.New("找不到此key: " + key)
				}
				base = append(base, transfer[key])
			}
		}
	}

	if v, ok := value.(string); ok && !IsValueStr {

		if []byte(v)[0] == []byte(`{`)[0] {
			var vMap map[string]interface{}
			if err = util.ParseJson(v, &vMap); err != nil {
				logger.Error("UpdateIntoJson err!", "pattern", pattern)
				return "", errors.New("UpdateIntoJson 转换json 2 出错; error: " + err.Error())
			}
			base[len(base)-1] = vMap
		}
		if []byte(v)[0] == []byte(`[`)[0] {
			var vSlice []interface{}
			if err = util.ParseJson(v, &vSlice); err != nil {
				logger.Error("UpdateIntoJson err!", "pattern", pattern)
				return "", errors.New("UpdateIntoJson 转换json 3 出错; error: " + err.Error())
			}
			base[len(base)-1] = vSlice
		}else{
			base[len(base)-1] = value
		}

	} else {
		base[len(base)-1] = value
	}

	for i := len(base) - 2; i >= 0; i-- {
		if isInteger(keys[i+1]) {
			index3, _ := strconv.Atoi(keys[i+1])
			base[i].([]interface{})[index3] = base[i+1]
			fmt.Println(base, base[i], base[i+1])
		} else {
			base[i].(map[string]interface{})[keys[i+1]] = base[i+1]
		}
	}

	resultMap[keys[0]] = base[0]

	return util.StringifyJson(resultMap), nil
}

//func addingSlice(base []interface{}, keys []string, value interface{}) (jsonStr string, err error) {
//	if keys
//}

// 带 pattern 更新进 approval order
func UpdateAOWithJsonSingly(jinjianId string, patternValue map[string]interface{}) (ao model.ApprovalOrder, err error) {
	defer func() (err error) {
		if rec := recover(); rec != nil {
			logger.Error("panic", "panicErr", rec)
			err = errors.New(fmt.Sprintf("PanicErr: %v", rec))
			return
		}
		return
	}()
	ao, err = model.GetApprovalOrderByJinjianId(jinjianId)
	if err != nil {
		return
	}
	rv := reflect.ValueOf(&ao).Elem()

	for pattern, value := range patternValue {
		path := strings.Split(pattern, ":")
		if path[0] == "" {
			err = errors.New("不能传空pattern")
			return
		}

		if len(path) == 1 || (len(path) > 1 && path[1] == "") {
			v := reflect.ValueOf(value)
			rv.FieldByName(util.StrToTF1(path[0])).Set(v)
		}

		if len(path) > 1 && path[1] != "" {
			v := rv.FieldByName(path[0]).String()
			jsonResult, err := UpdateIntoJson(v, path[1], value)
			if err != nil {
				return ao, err
			}
			rv.FieldByName(util.StrToTF1(path[0])).SetString(jsonResult)
		}
	}

	return
}
