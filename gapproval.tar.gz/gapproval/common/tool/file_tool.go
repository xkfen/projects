package tool

import (
	"io/ioutil"
	"archive/zip"
	"os"
	"path"
	"fmt"
	"strings"
	"time"
	"errors"
	"io"
	"gopkg.in/gin-gonic/gin.v1"
	"gcoresys/common"
)

const assetsStatic = "/assert"

// 归档文件
func ArchiveFileZIP(fileUrls []string, jinjianId string) (filePath string, err error) {
	filePath = path.Join(assetsStatic, "archive", jinjianId)
	if common.GetUseDocker() == 0 {
		filePath = path.Join(".", "assert", "archive", jinjianId)
	}
	if !PathExists(filePath) {
		os.MkdirAll(filePath, os.ModePerm)
	}

	filePath = path.Join(filePath, fmt.Sprintf("%s-归档文件.zip", time.Now().Format("2006-01-02")))
	fileZip, err := os.Create(filePath)
	if err != nil {
		return "", err
	}
	w := zip.NewWriter(fileZip)
	defer w.Close()
	var sum int

	for _, url := range fileUrls {

		fi, err := os.Stat(url)
		if err != nil {
			fmt.Println("读取文件错误", "err:", err.Error())
			continue
		}

		fw, err := w.Create(fi.Name())
		if err != nil {
			return "", err
		}

		fileContent, err := ioutil.ReadFile(url)
		if err != nil {
			return "", err
		}

		n, err := fw.Write(fileContent)
		if err != nil {
			return "", err
		}
		sum += n
	}

	if sum == 0 {
		os.Remove(filePath)
		return "", errors.New("未找到任何文件，压缩失败，请检查")
	}
	fmt.Println("压缩文件大小：", sum)
	return
}

// 生成一个新的文件名
func GetNewFileName(fileName string) string {
	// 解析文件名后缀
	_, name := path.Split(fileName)
	hz := strings.Split(name, ".")
	if len(hz) > 1 {
		return fmt.Sprintf("%v_%v.%v", hz[0], time.Now().UnixNano(), hz[len(hz)-1])
	} else {
		return fmt.Sprintf("%v_%v", fileName, time.Now().UnixNano())
	}
}

// 保存上传文件 返回文件名和文件路径
func GetFileUrl(jinjianId string, uploadKey string, c *gin.Context) (fileUrl string, fileName string, err error) {
	file, header, err := c.Request.FormFile(uploadKey)
	if err != nil {
		return "", "", errors.New("没有读取到文件, err: " + err.Error())
	}
	if file == nil {
		return "", "", errors.New("file 为空，请检查")
	}

	fileName = GetNewFileName(header.Filename)               //文件名
	filePath := path.Join(assetsStatic, "upload", jinjianId) //存放路径
	if common.GetUseDocker() == 0 {
		filePath = path.Join(".", assetsStatic, "upload", jinjianId) //测试存放路径
	}
	fileUrl = path.Join(filePath, fileName) //存放路径
	if !PathExists(filePath) {
		os.MkdirAll(filePath, os.ModePerm)
	}
	out, err := os.Create(fileUrl)
	if err != nil {
		return "", "", err
	}
	defer out.Close()
	_, err = io.Copy(out, file)
	if err != nil {
		return "", "", err
	}
	return fileUrl, fileName, err
}

// 判断文件或路径是否存在 存在true
func PathExists(path string) bool {
	_, err := os.Stat(path)
	if err == nil {
		return true
	}
	return false
}
