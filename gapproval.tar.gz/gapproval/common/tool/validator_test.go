package tool

import (
	"fmt"
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestCheckDateString(t *testing.T) {
	s := "yyyy/m/d"
	s2 := "yyyy/mm/d" // "yyyy/m/dd"
	s3 := "yyyy/mm/dd"
	var ss string
	fmt.Println(len(ss))
	fmt.Println(len(s))
	fmt.Println(len(s2))
	fmt.Println(len(s3))
}

func TestCheckDateString2(t *testing.T) {
	assert.NoError(t, CheckDateString("2017/1/1", "yyyy/mm/dd"))
	assert.NoError(t, CheckDateString("2017/11/21", "yyyy/mm/dd"))
	assert.NoError(t, CheckDateString("2017.01", "yyyy.mm"))

}
