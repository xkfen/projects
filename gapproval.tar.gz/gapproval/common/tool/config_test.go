package tool

import (
	"github.com/stretchr/testify/suite"
	"testing"
	"gcoresys/common/logger"
	"gapproval/approval/db/config"
)

type testingSuite struct {
	suite.Suite
}

func (s *testingSuite) SetupTest() {
	config.ClearAllData()
}

func (s *testingSuite) TearDownTest() {
	config.ClearAllData()
}

func TestRun(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	suite.Run(t, new(testingSuite))
}

// 单步测试
func oneStepTest(testMethods ...func()) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	//defer config.ClearAllData()

	for _, testMethods := range testMethods {
		config.ClearAllData()
		testMethods()
		//config.ClearAllData()
	}
}
