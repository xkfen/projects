package tool

import (
	"errors"
	"fmt"
)

/*
	日期格式1  => string => 2017/7/21
	日期格式2  => string => 2017.07

	数值无小数点 => int => 0
	数值有小数点 => float => 0

	数值百分比 => string => 6%

	有无  => string =>  有/无
	性别  => string =>  男/女/未知
	婚姻状况  => string =>  未婚/已婚/离异/丧偶/未知
	学历  => string =>  本科及以上/大专/高中及以下/未知
	住房公积金参缴记录--缴费状态  => string =>  缴交/断缴/无

*/

func CheckDateString(data string, format string) (err error) {
	switch format {
	case "yyyy/mm/dd":
		if data == "无" {
			return
		}
		switch len(data) {
		case 8:
			return
		case 9:
			return
		case 10:
			return
		default:
			fmt.Println("=====check data ===" + data)
			err = errors.New("数据未通过检验，请检查数据")
			return
		}
	case "yyyy.mm":
		if data == "-" {
			return
		}
		if len(data) < len("yyyy.mm") {
			fmt.Println("=====check data ===" + data)
			err = errors.New("数据未通过检验，请检查数据")
			return
		}
	default:
		fmt.Println("=====check data ===" + data)
		err = errors.New("数据检查格式设定为匹配，请检查format")
		return
	}
	return
}
