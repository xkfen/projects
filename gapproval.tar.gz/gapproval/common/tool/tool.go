package tool

import (
	"reflect"
	"time"
	//"testing"
	//"github.com/stretchr/testify/assert"
	"crypto/md5"
	"encoding/base64"
	"strings"
	//"github.com/stretchr/testify/assert"
)

// 判断一个变量是否为空
func IsEmpty(object interface{}) bool {

	if object == nil {
		return true
	} else if object == "" {
		return true
	} else if object == false {
		return true
	}

	for _, v := range numericZeros {
		if object == v {
			return true
		}
	}

	objValue := reflect.ValueOf(object)

	switch objValue.Kind() {
	case reflect.Map:
		fallthrough
	case reflect.Slice, reflect.Chan:
		{
			return objValue.Len() == 0
		}
	case reflect.Struct:
		switch object.(type) {
		case time.Time:
			return object.(time.Time).IsZero()
		}
	case reflect.Ptr:
		{
			if objValue.IsNil() {
				return true
			}
			switch object.(type) {
			case *time.Time:
				return object.(*time.Time).IsZero()
			default:
				return false
			}
		}
	}
	return false
}

var numericZeros = []interface{}{
	int(0),
	int8(0),
	int16(0),
	int32(0),
	int64(0),
	uint(0),
	uint8(0),
	uint16(0),
	uint32(0),
	uint64(0),
	float32(0),
	float64(0),
}

// md5加密
func Md5Encode(str string) string {
	md5B := md5.Sum([]byte(str))
	return base64.StdEncoding.EncodeToString(md5B[:])
}

//把年月日格式转换为go的时间格式  ---by Zebreay
func ChineseStr2Time(timestr string) (result time.Time, err error) {
	timestr = strings.TrimSpace(timestr)
	timestr = strings.Trim(timestr, "日")
	timestr = strings.Replace(timestr, "月", "-", 1)
	timestr = strings.Replace(timestr, "年", "-", 1)
	timestr += " 00:00:00"
	result, err = time.Parse("2006-1-2 15:04:05", timestr)
	return
}

// interface 转换为 array-interface
func ToSlice(array interface{}) []interface{} {
	v := reflect.ValueOf(array)
	if v.Kind() != reflect.Slice {
		panic("ToSlice array not slice")
	}
	l := v.Len()
	ret := make([]interface{}, l)
	for i := 0; i < l; i++ {
		ret[i] = v.Index(i).Interface()
	}
	return ret
}

// 判断 item 是否在 数组 array 里
func InArray(item interface{}, array interface{}) (bool) {
	arr := ToSlice(array)
	for _, x := range arr {
		if item == x {
			return true
		}
	}
	return false
}

// 判断 item 是否在 数组 array 里, 并且返回首个匹配值的index
func InArrayWithIndex(item interface{}, array interface{}) (bool, int) {
	arr := ToSlice(array)
	for i, x := range arr {
		if item == x {
			return true, i
		}
	}
	return false, -1
}
