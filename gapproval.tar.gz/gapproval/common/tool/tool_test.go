package tool

import (
	"testing"
	"fmt"
	"github.com/stretchr/testify/assert"
)

func TestGetNewFileName(t *testing.T) {

	fmt.Println(GetNewFileName("征信.png"))
	fmt.Println(GetNewFileName("征信"))
}

// 测试时多对比较  ---by Zebreay
func MultiEqual(t *testing.T, a ...interface{}) {
	if len(a) % 2 == 0 {
		for i := range a{
			if i % 2 == 0 {
				assert.Equal(t, a[i], a[i+1])
			}
		}
	}else{
		assert.Fail(t, "比较元素不对等~")
	}
}