package tool

import (
	"testing"
	"github.com/stretchr/testify/assert"
	"github.com/tidwall/gjson"
	"fmt"
)

func TestUpdateIntoJson(t *testing.T) {
	original := `{"salary_bank":[{"isCrawled":true,"bank":"工商银行","isJump":false,"updatedAt":"2018-01-15 20:21:11","bankCity":null,"bankProv":null,"orgId":"010003_20","createdAt":"2018-01-15 20:20:52","userId":56,"cardNo":"65566655","orderId":"52","password":null,"id":94,"status":"1","account":null,"cellphone":"15012880331"}],"credit_files":null,"idcard_info":{"bankNo":null,"cellphone":null,"id":48,"createdAt":"2018-01-15 20:17:25","backPhoto":"/assets/uploads/images//idCard/B8eQ0HXaBsoXGwOCKL_FU0helOF3OOX-bine5bp3toPgg4Bjk3yaRfy_NMGImT7K.jpg","updatedAt":"2018-01-15 20:17:25","number":"450322199306300014","userId":56,"facePhoto":"/assets/uploads/images//idCard/SlyCGjdUIl57ye4pxYpMLDNCo9c-cZU3D884Ub4ivi_S_45TIg7ubuvRxpL4HFqS.jpg","name":"郑柏屹","orderId":"52","status":"1"},"personal_info":{"id":43,"companyType":null,"houseType":"租房","hasHouse":"有","addressCity":null,"monthlyIncome":"6","workplacePhone":"15012880331","hasCarLoan":"有","userId":56,"education":null,"wxNo":"6","workDetailAddress":"6","address":"广东省 深圳市 市辖区","hasChildren":null,"status":"1","job":"6","department":null,"hasHouseLoan":"有","workAddress":"广东省 深圳市 市辖区","createdAt":"2018-01-15 20:17:54","detailAddress":"6","jobAt":null,"marriage":"已婚","workplace":"6","monthlyCost":"6","orderId":"52","updatedAt":"2018-01-15 21:06:59","usage":"投资","hasCar":"有","companySize":null},"other_bank":[{"id":51,"bankCity":null,"isCrawled":true,"createdAt":"2018-01-15 20:21:28","orderId":"52","userId":56,"bank":"","orgId":"","status":"1","bankProv":null,"updatedAt":"2018-01-15 20:21:28","cellphone":"","isJump":true,"password":null,"cardNo":"","account":null}],"call_record":{"password":null,"isJump":true,"updatedAt":"2018-01-15 20:17:59","status":"1","userId":56,"isCrawled":true,"id":44,"cellphone":"","createdAt":"2018-01-15 20:17:59","orderId":"52"},"contacts":{"primaryRelation":"配偶","primaryName":"六","updatedAt":"2018-01-15 20:18:23","createdAt":"2018-01-15 20:18:23","primaryAddr":"6","id":43,"secondaryPhone":"15012880332","status":"1","secondaryName":"六","secondaryAddr":"6","secondaryRelation":"配偶","userId":56,"primaryPhone":"15012880331","orderId":"52"}}`
	oneStepTest(func() {
		json, err := UpdateIntoJson(original, "salary_bank.0.bank", "没有银行")
		assert.NoError(t, err)
		assert.Equal(t, "没有银行", gjson.Get(json, "salary_bank.0.bank").Str)
		json, err = UpdateIntoJson(original, "personal_info.address", "没有地址")
		assert.NoError(t, err)
		assert.Equal(t, "没有地址", gjson.Get(json, "personal_info.address").Str)
	})
}

func TestUpdateIntoJson2(t *testing.T) {
	original := `{"commitTime":"4/10/2018, 11:24:33 AM","customerRejectTime":null,"creditReportPath":null,"isSpCallBuLu":false,"adjustRepayAmount":null,"backInfo":null,"pendingTime":null,"applyResult":null,"isBuLu":false,"idNo":"510129199507170762","isCallBuLu":false,"isInterviewPass":false,"createdAt":"2018-04-09 16:52:26","bankName":null,"orderId":"order_1523263946063","showOrderId":"S_qy20180410001","brokerPhone":"13160678016","loanType":null,"cancelTime":null,"statusUpdatedAt":"2018-04-10T03:24:34.154Z","rate":null,"loanTime":null,"loanCard":null,"rstUserId":null,"userPhone":"17688761114","brokerId":797,"finishBulu":false,"userName":"吴怜珊","accountId":null,"rejectTime":null,"realAmount":null,"terms":24,"userId":844,"passTime":null,"approvalAmount":null,"realLoanAmount":null,"brokerCompany":"渠道公司2000","brokerName":"李旭","status":8,"isSpBuLu":false,"loanBank":null,"finishCallBulu":false,"isOpenSignature":false,"signAt":null,"updatedAt":"2018-04-10 11:24:04","repayDate":null,"chanelManagers":["中介2000","李三宝","601"],"approvalStatus":null,"amount":20000000,"id":211,"loanAmount":null,"brokerCompanyId":91,"backItem":null,"refuseReason":null,"managers":null}`
	oneStepTest(func() {
		_, err := UpdateIntoJson(original, "amount", 200000)
		assert.NoError(t, err)
		s, err := UpdateIntoJson(original, "terms", 24)
		assert.NoError(t, err)
		fmt.Println(s)
	})
}

//func TestUpdateAOWithJsonSingly(t *testing.T) {
//	oneStepTest(func() {
//		ao := model.GetDefaultApprovalOrder()
//		assert.NoError(t, ao.Create())
//		upAo, err := UpdateAOWithJsonSingly(ao.JinjianId, map[string]interface{}{"product_id": "what?"})
//		assert.NoError(t, err)
//		assert.Equal(t, "what?", upAo.ProductId)
//
//		upAo, err = UpdateAOWithJsonSingly(ao.JinjianId, map[string]interface{}{"product_id": "hehe", "JinjianUserInfo:salaryBanks":`[{"bank":"哈哈"}]`, "JinjianUserInfo:baseInfo.education":"文盲"})
//		assert.NoError(t, err)
//		MultiEqual(t, "hehe", upAo.ProductId, "哈哈", gjson.Get(upAo.JinjianUserInfo, "salaryBanks.0.bank").Str, "文盲", gjson.Get(upAo.JinjianUserInfo, "baseInfo.education").Str)
//
//		upAo, err = UpdateAOWithJsonSingly(ao.JinjianId, map[string]interface{}{"JinjianUserInfo:salaryBanks#":`[{"bank":"哈哈"}]`, "JinjianUserInfo:baseInfo.education#":123})
//		assert.NoError(t, err)
//		MultiEqual(t, `[{"bank":"哈哈"}]`, gjson.Get(upAo.JinjianUserInfo, "salaryBanks").Str, 123, int(gjson.Get(upAo.JinjianUserInfo, "baseInfo.education").Int()))
//
//		assert.NotEqual(t, 1, 0)
//	})
//}
