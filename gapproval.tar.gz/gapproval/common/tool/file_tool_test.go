package tool

import (
	"testing"
	"fmt"
	"github.com/stretchr/testify/assert"
	"os"
)

func TestArchiveFileZIP(t *testing.T) {

	fileUrls := []string{
		"../code_generate/make_model_valid_func.go",
		"../global/global.go.go",
	}

	filePath, err := ArchiveFileZIP(fileUrls, "S_qy20180327")
	fmt.Println("filePath:", filePath)

	assert.NoError(t, err)
	assert.NotEmpty(t, filePath)
	assert.Equal(t, true, PathExists(filePath))

	os.Remove(filePath)
	os.RemoveAll("./assert")
}

func TestArchiveFileZIP001(t *testing.T) {

	fileUrls := []string{}

	filePath, err := ArchiveFileZIP(fileUrls, "")

	assert.Error(t, err)
	assert.Empty(t, filePath)

	os.RemoveAll("./assert")
}
