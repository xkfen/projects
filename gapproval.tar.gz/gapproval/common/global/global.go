package global

import (
	"fmt"
	"gcoresys/common"
)

// 预审批
func GetPreViewServerUrl() string {
	// 使用docker
	if common.GetUseDocker() != 0 {
		return fmt.Sprintf("http://%s:%v", common.GpreviewMicroDns, common.GetAppConfig().HttpServerPort)
	} else {
		return "http://localhost:7006"
	}
}

// gsso
func GetGssoServerUrl() string {
	// 使用docker
	if common.GetUseDocker() != 0 {
		return fmt.Sprintf("http://%s:%v", common.GssoMicroDns, common.GetAppConfig().HttpServerPort)
	} else {
		return "http://localhost:14000"
	}
}

// 进件
func GetNqyServerUrl() string {
	// 使用docker
	if common.GetUseDocker() != 0 {
		return fmt.Sprintf("http://%s:%v", common.NqiyuanMicroDns, common.GetAppConfig().HttpServerPort)
	} else {
		return "http://localhost:14000"
	}
}

// 风控
func GetRiskControlServerUrl() string {
	// 使用docker
	if common.GetUseDocker() != 0 {
		return fmt.Sprintf("http://%s:%v", common.GriskcontrolApigwMicroDns, common.GetAppConfig().HttpServerPort)
	} else {
		return "http://localhost:8062"
	}
}

// 核心系统
func GetCoreSysUrl() string {
	// 使用docker
	if common.GetUseDocker() != 0 {
		return fmt.Sprintf("http://%s:%v", common.CoreSysApigwMicroDns, common.GetAppConfig().HttpServerPort)
	} else {
		return "http://localhost:8092"
	}
}

// 合同管理系统
func GetContractUrl() string {
	// 使用docker
	if common.GetUseDocker() != 0 {
		return fmt.Sprintf("http://%s:%v", common.GcontractMicroDns, common.GetAppConfig().HttpServerPort)
	} else {
		return "http://localhost:15000"
	}
}

// 话务系统
func GetCallCenterUrl() string {
	// 使用docker
	if common.GetUseDocker() != 0 {
		return fmt.Sprintf("http://%s:%v", common.GgcallcenterMicroDns, common.GetAppConfig().HttpServerPort)
	} else {
		return "http://localhost:8015"
	}
}

// 评分系统
func GetScoreUrl() string {
	// 使用docker
	if common.GetUseDocker() != 0 {
		return fmt.Sprintf("http://%s:%v", common.GscoreMicroDns, common.GetAppConfig().HttpServerPort)
	} else {
		return "http://localhost:7006"
	}
}

// 财务系统
func GetFinUrl() string {
	// 使用docker
	if common.GetUseDocker() != 0 {
		return fmt.Sprintf("http://%s:%v", "gfin-app", common.GetAppConfig().HttpServerPort)
	} else {
		return "http://localhost:7006"
	}
}

// 产品系统
func GetProdmngUrl() string {
	// 使用docker
	if common.GetUseDocker() != 0 {
		return fmt.Sprintf("http://%s:%v", common.GprodmngMicroDns, common.GetAppConfig().HttpServerPort)
	} else {
		return "http://localhost:7006"
	}
}
