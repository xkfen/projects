package ginlog

import (
	"gopkg.in/gin-gonic/gin.v1"
	"gcoresys/common/logger"
	"io/ioutil"
	"bytes"
)

func PrintReq() gin.HandlerFunc {
	return func(c *gin.Context) {
		// 不打印有文件的请求
		if c.ContentType() == "multipart/form-data" {
			return
		}
		params, _ := ioutil.ReadAll(c.Request.Body)
		c.Request.Body.Close()
		// 这里有意思，呵呵
		c.Request.Body = ioutil.NopCloser(bytes.NewBuffer(params))
		paramsStr := string(params)
		//logger.Info("=====Gin请求", "clientIP", c.ClientIP(), "method", c.Request.Method, "path", c.Request.URL.Path)
		logger.Info("收到请求", "req_url", c.Request.RequestURI, "params", paramsStr)
	}
}

type bodyLogWriter struct {
	gin.ResponseWriter
	body *bytes.Buffer
}

func (w bodyLogWriter) Write(b []byte) (int, error) {
	w.body.Write(b)
	return w.ResponseWriter.Write(b)
}

func PrintResp() gin.HandlerFunc {
	return func(c *gin.Context) {
		blw := &bodyLogWriter{body: bytes.NewBufferString(""), ResponseWriter: c.Writer}
		c.Writer = blw
		c.Next()
		respStr := blw.body.String()
		if len(respStr) > 1000 {
			logger.Info("返回结果过长，未打印全部", "resp", respStr[0:1000])
		} else {
			logger.Info("返回结果", "resp", respStr)
		}
	}
}
