package httpReq

import (
	"github.com/json-iterator/go"
	"gopkg.in/resty.v0"
	"errors"
	"gcoresys/common/logger"
)

/**
	这里封装了所有http请求的方法
 */

func PostJsonProxy(params interface{}, serverURL string) (respMap map[string]interface{}, err error) {
	resp, err := resty.R().
		SetHeader("Content-Type", "application/json").
		SetBody(params).
		Post(serverURL)
	if err != nil {
		return
	}
	return checkResp(resp.Body(), serverURL)
}

func GetProxy(serverURL string) (respMap map[string]interface{}, err error) {
	resp, err := resty.R().Get(serverURL)
	if err != nil {
		return
	}
	return checkResp(resp.Body(), serverURL)
}

func PutJsonProxy(params interface{}, serverURL string) (respMap map[string]interface{}, err error) {
	resp, err := resty.R().
		SetHeader("Content-Type", "application/json").
		SetBody(params).
		Put(serverURL)
	if err != nil {
		return
	}
	return checkResp(resp.Body(), serverURL)
}

func PutParamProxy(params map[string]string, serverURL string) (respMap map[string]interface{}, err error) {
	resp, err := resty.R().
		SetHeader("Content-Type", "application/json").
		SetQueryParams(params).
		Put(serverURL)
	if err != nil {
		return
	}
	return checkResp(resp.Body(), serverURL)
}

func PutParamProxyNoCheck(params map[string]string, serverURL string) (statusCode int, respResult string, err error) {
	resp, err := resty.R().
		//SetHeader("Content-Type", "application/json").
		SetQueryParams(params).
		Put(serverURL)
	if err != nil {
		return
	}
	respResult = resp.String()
	statusCode = resp.StatusCode()
	return statusCode, respResult, err
}

func PutFormDataProxy(params interface{}, serverURL string) (respMap map[string]interface{}, err error) {
	resp, err := resty.R().
		SetHeader("Content-Type", "application/x-www-form-urlencoded").
		SetFormData(params.(map[string]string)).
		Put(serverURL)
	if err != nil {
		return
	}
	return checkResp(resp.Body(), serverURL)
}

func PostFormDataProxy(params interface{}, serverURL string) (respMap map[string]interface{}, err error) {
	resp, err := resty.R().
		SetHeader("Content-Type", "application/x-www-form-urlencoded").
		SetFormData(params.(map[string]string)).
		Post(serverURL)
	if err != nil {
		return
	}
	return checkResp(resp.Body(), serverURL)
}

func checkResp(resp []byte, serverURL string) (respMap map[string]interface{}, err error) {
	if err = jsoniter.Unmarshal(resp, &respMap); err != nil {
		return respMap, errors.New("请求:" + serverURL + " parse json err " + err.Error())
	}
	if res, ok := respMap["success"].(bool); !ok || !res {
		logger.Error("请求其他系统错误", "resp", string(resp))
		errInfo, _ := respMap["info"].(string)
		return respMap, errors.New(errInfo)
	}
	return
}

func PostJsonProxyNoCheck(params interface{}, serverURL string) (respResult string, err error) {
	resp, err := resty.R().
		SetHeader("Content-Type", "application/json").
		SetBody(params).
		Post(serverURL)
	if err != nil {
		return
	}
	respResult = resp.String()
	return respResult, err
}

func PostFormDataProxyNoCheck(params interface{}, serverURL string) (statusCode int, respResult string, err error) {
	resp, err := resty.R().
		SetHeader("Content-Type", "application/x-www-form-urlencoded").
		SetFormData(params.(map[string]string)).
		Post(serverURL)
	if err != nil {
		logger.Error("请求:"+serverURL+"响应错误", "err", err.Error())
	}
	return resp.StatusCode(), resp.String(), err
}

func GetProxyNoCheck(serverURL string) (respResult string, err error) {
	resp, err := resty.R().Get(serverURL)
	if err != nil {
		return
	}
	return resp.String(), nil
}
