package httpReq

import (
	"strings"
	"gcoresys/common/logger"
	"io/ioutil"
	"net/http"
)

// proxy to other server
func ProxyReq(originReq *http.Request, targetUrl string) (respBt []byte, err error) {
	splitResult := strings.Split(originReq.RequestURI, "?")
	if len(splitResult) > 1 {
		targetUrl += "?" + splitResult[1]
	}

	logger.Info("代理请求到：" + targetUrl)
	req, err := http.NewRequest(originReq.Method, targetUrl, originReq.Body)
	if err != nil {
		return
	}
	req.Header = originReq.Header

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return
	}
	defer resp.Body.Close()
	respBt, err = ioutil.ReadAll(resp.Body)
	if err != nil {
		return
	}
	return respBt, nil
}

