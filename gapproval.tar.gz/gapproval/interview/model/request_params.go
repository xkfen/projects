package model

import (
	"errors"
	"time"
)

// 面签列表请求参数
type InterviewListReqParams struct {
	// 查询列表类型
	TypeKey string `json:"type_key"`
	// 渠道(中介)公司
	Agency string `json:"agency"`
	// 查询面签状态
	Status string `json:"status"`
	// 搜索内容
	Condition string `json:"condition"`
	// 时间排序
	Sort string `json:"sort"`
	// 页码
	Page int `json:"page"`
	// 每页数量
	PerPage int `json:"per_page"`
	// 面签挂起
	InterViewSuspending string `json:"inter_view_suspending"`
	// 开始时间
	StartTime time.Time `json:"start_time"`
	// 结束时间
	EndTime time.Time `json:"end_time"`
	// 操作人账号
	Username string `json:"-"`
	// 操作人姓名
	Name string `json:"-"`
}

func (req *InterviewListReqParams) IsValidInterviewListReqParams() error {
	switch {
	case req.Page <= 0:
		return errors.New("请提交页码")
	case req.PerPage <= 0:
		return errors.New("每页查多少")
	case req.Sort != "" && req.Sort != "commit_time desc" && req.Sort != "commit_time asc":
		return errors.New("sort 参数错误, 请检查")
	case !req.StartTime.IsZero() && !req.EndTime.IsZero() && req.StartTime.After(req.EndTime):
		return errors.New("开始时间要在结束时间之前")
	case req.TypeKey == "":
		return errors.New("请选择查询类别")
	case req.TypeKey != "all" && req.TypeKey != "me" && req.TypeKey != "history" && req.TypeKey != "query":
		return errors.New("type_key 错误， 请检查")
	case req.InterViewSuspending != "" && req.InterViewSuspending != "off" && req.InterViewSuspending != "on":
		return errors.New("inter_view_suspending 错误, 请检查")
	case req.Username == "" || req.Name == "":
		return errors.New("操作人信息不能为空")
	}

	return nil
}

// 修改进件信息请求参数
type OrderInfoReqParams struct {
	OrderId string `json:"order_id"`
	// 修改字段 all_info | order_info
	Info string `json:"info"`
	// all_info 外层key
	TopKey string `json:"top_key"`
	// key
	Key string `json:"key"`
	// key 对应的 value
	Value interface{} `json:"value"`
}

// 添加联系人
type ContactsReqParams struct {
	// 姓名
	Name string `json:"name"`
	// 电话号码
	Phone string `json:"phone"`
	// 归属地
	QCellCore string `json:"q_cell_core"`
	// 与本人关系
	Relationship string `json:"relationship"`
	// 地址
	Address string `json:"address"`
}
