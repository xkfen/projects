package model

import (
	"testing"
	"fmt"
	"gcoresys/common/util"
	"github.com/stretchr/testify/assert"
)

// 打印请求参数 JSON格式
func TestPrintReqParams(t *testing.T) {
	fmt.Println("=====================================")
	fmt.Println("面签列表请求参数", util.StringifyJson(InterviewListReqParams{}))

	fmt.Println("=====================================")
	fmt.Println("保存放款银行卡信息参数", util.StringifyJson(LoanBank{}))

	fmt.Println("=====================================")
	fmt.Println("保存面签状态记录请求参数", util.StringifyJson(StatusRecord{}))

	fmt.Println("=====================================")
	fmt.Println("保存面签信息请求参数", util.StringifyJson(Interview{}))

	var mapJson map[string]interface{}
	assert.Equal(t, 0, len(mapJson))
}

func TestRunFile001(t *testing.T) {
	file := GetTestInterviewFile()
	err := file.IsValidInterviewFile()
	assert.Equal(t, nil, err)
}

func TestRunLoanBankModel(t *testing.T) {
	lb := GetTestLoanBank()
	err := lb.IsValidLoanBank()
	assert.Equal(t, nil, err)
}

func TestRunInterviewListReqParams(t *testing.T) {
	reqStr := `{"agency":"", "condition":"", "end_time":"2018-01-31T03:00:00Z", "page":1, "per_page":10, "sort":"commit_time desc", "status":"", "type_key":"history"}`
	params := InterviewListReqParams{}

	err := util.ParseJson(reqStr, &params)
	assert.Equal(t, nil, err)
	assert.Equal(t, "2018-01-31 03:00:00", params.EndTime.Format("2006-01-02 15:04:05"))
}

func TestRunJsonMap(t *testing.T) {
	mm := map[string]interface{}{
		"success": "qwe",
	}
	data, ok := mm["success"].(bool)
	assert.Equal(t, false, data)
	assert.Equal(t, false, ok)


	var f float64
	f = 1.99
	fmt.Println(fmt.Sprintf("%.f", f-0.5))
	fmt.Println(util.FloorFloat64ToUint64(f))

	var i uint
	i = 10
	fmt.Println(float64(i) + f)


	var num3 float64

	num4 := num3 /1000
	util.FloorFloat64ToUint64(num4)

	fmt.Println(num4)
	f2, _ := fmt.Printf("%.2f", num4)
	fmt.Println(f2)
}

func TestRunJsonToStatusRecord(t *testing.T) {
	str := `{}`

	inter := Interview{}
	err := util.ParseJson(str, &inter)

	assert.Equal(t, nil, err)

	s := []string{"a", "b", "v"}
	for i := range s {
		s[i] = "cc"
	}
	fmt.Println(s)
}
