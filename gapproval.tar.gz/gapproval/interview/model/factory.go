package model

import (
	"gcoresys/common/util"
	"time"
	"gapproval/approval/model"
)

func GetTestInterviewFile() InterviewFile {
	return InterviewFile{
		OrderId:           "123",
		FilePath:          "123",
		FileType:          LoanBankCard,
		InterviewUsername: "test",
		InterviewName:     "测试",
	}
}

func GetTestStatusRecord() StatusRecord {
	return StatusRecord{
		OrderId: "123",
		Status:  model.ApprovalStatusInterViewPass,
		Remark:  "123",
		InterviewUsername: "test",
		InterviewName:     "测试",
	}
}

func GetTestInterviewComplete() Interview {
	contract := GetTestFile(Contract)
	idCards := GetTestIdCards()
	credit := GetTestFile(CreditReport)
	otherFile := GetTestOtherFile()
	loanbank := GetTestLoanBankWithFile()
	return Interview{
		JinjianId:         "123",
		SchemeId:          "1234",
		JinjianPlan:       `[{"content":{"lending_data":"2018-05-05","lending_amount":"10000000","monthly_supply_amount":"2"},"name":"月供贷（12-23期，按揭）"}]`,
		JinjianPlanTime:   time.Now().Unix(),
		JinjianPlanFiles:  []*InterviewFile{{}},
		InterviewUsername: "test",
		InterviewName:     "测试",
		FundSide:          "个人",
		IsStandard:        "1",
		InterviewMode:     "现场面签",
		InterviewAddress:  "nowhere on earth",
		Comment:           "满分好评!",
		Score:             "100",
		Remark:            "perfect, very good",
		ContractFile:      []*InterviewFile{&contract},
		IdCardFile:        idCards,
		CreditReportFile:  []*InterviewFile{&credit},
		OtherFile:         []*InterviewFile{&otherFile},
		LoanBank:          loanbank,
	}
}

func GetTestInterview() Interview {
	return Interview{
		InterviewUsername: "test",
		InterviewName:     "测试",
	}
}

func GetTestInterviewIncompleteString() string {
	interview := GetTestInterviewIncomplete()
	return util.StringifyJson(interview)
}

func GetTestInterviewCompleteString() string {
	interview := GetTestInterviewComplete()
	return util.StringifyJson(interview)
}

func GetTestOtherFile() InterviewFile {
	return InterviewFile{
		OrderId:           "123",
		FilePath:          "/assets/123",
		FileTypeName:      OtherType,
		FileType:          OtherType,
		InterviewUsername: "test",
		InterviewName:     "测试",
	}
}

func GetTestFile(s string) InterviewFile {
	return InterviewFile{
		OrderId:           "123",
		FilePath:          "/assets/123",
		FileType:          s,
		InterviewUsername: "test",
		InterviewName:     "测试",
	}
}

func GetTestIdCards() []*InterviewFile {
	idCarda := GetTestFile(IdCardA)
	idCardb := GetTestFile(IdCardB)
	idCardc := GetTestFile(IdCardC)
	return []*InterviewFile{
		&idCarda, &idCardb, &idCardc,
	}
}

func GetTestLoanBank() LoanBank {
	return LoanBank{
		OrderId:           "123",
		BankName:          "中国银行",
		BankNum:           "4565124546123",
		Cellphone:         "13145781245",
		BankAddress:       "sdf54",
		BankUrl:           "www.www.www",
		InterviewUsername: "test",
		InterviewName:     "测试",
	}
}

func GetTestLoanBankWithFile() []LoanBank {
	file := GetTestFile(LoanBankCard)
	lb := LoanBank{
		OrderId:           "123",
		BankName:          "中国银行",
		BankNum:           "4565124546123",
		Cellphone:         "13145781245",
		BankAddress:       "sdf54",
		BankUrl:           "www.www.www",
		InterviewUsername: "test",
		InterviewName:     "测试",
		FilesUrl:          []*InterviewFile{&file},
	}
	return []LoanBank{lb}
}

func GetTestLoanBankWithoutFile() []LoanBank {
	lb := LoanBank{
		OrderId:           "123",
		BankName:          "中国银行",
		BankNum:           "4565124546123",
		Cellphone:         "13145781245",
		BankAddress:       "sdf54",
		BankUrl:           "www.www.www",
		InterviewUsername: "test",
		InterviewName:     "测试",
	}
	return []LoanBank{lb}
}

func GetTestInterviewIncomplete() Interview {
	return Interview{
		JinjianId:         "123",
		SchemeId:          "1234",
		InterviewName:     "test",
		InterviewUsername: "测试",
	}
}

func GetInterviewListReq() InterviewListReqParams {
	return InterviewListReqParams{
		Page:     1,
		PerPage:  10,
		Username: "test",
		Name:     "测试",
	}
}

func GetOrderInfoReqParams() OrderInfoReqParams {
	return OrderInfoReqParams{
		Info:   "all_info",
		TopKey: "idcard_info",
		Key:    "name",
		Value:  "嘻嘻哈哈哇哇",
	}
}

func GetContactsReqParams() []ContactsReqParams {
	return []ContactsReqParams{
		{
			Name:         "123123",
			Phone:        "123123",
			Relationship: "123123",
			Address:      "123123",
		},
	}
}

func GetTestBuluAdditionReq() BuluAdditionReq {
	return BuluAdditionReq{
		JinjianId: "123",
		ArType: "call",
		ArChannel: "ar channel",
		Onoff: "open",
	}
}