package model

import (
	"gcoresys/common/mysql"
	"errors"
)

const (
	// 纸质合同
	Contract = "contract"

	// 用于匹配身份证照片类型文件
	IDCARD = "id_card"
	// 手持身份证照片
	IdCardA = "id_card_a"
	IdCardB = "id_card_b"
	IdCardC = "id_card_c"

	// 进件方案
	PLAN = "plan"
	// 进件方案相关文件
	JinjianPlan = "jinjian_plan"
	// 进件方案电核录音
	SoundPlan = "sound_plan"

	// 上传征信报告
	CreditReport = "credit_report"

	// 放款银行卡
	LoanBankCard = "loan_bank_card"

	// 其他文件类型
	OtherType = "other"
)

var fileTypeAry = []string{IdCardA, IdCardB, IdCardC, JinjianPlan, SoundPlan,
	Contract, LoanBankCard, CreditReport, OtherType}

// 面签文件信息
type InterviewFile struct {
	mysql.BaseModel
	// 订单id
	OrderId string `json:"orderId"`
	// 文件类型
	FileType string `json:"fileType"`
	// 文件类型名称
	FileTypeName string `json:"fileTypeName"`
	// 文件url
	FilePath string `json:"file"`
	// 面签人姓名
	InterviewName string `json:"interview_name"`
	// 面签人账号
	InterviewUsername string `json:"interview_username"`
	//是否为空  (用于同步时判断)
	IsEmpty bool `sql:"-" json:"-"` //默认为false
}

func (f *InterviewFile) IsValidInterviewFile() error {
	switch {
	case f.OrderId == "":
		return errors.New("订单id不能为空")
	case f.FileType == "":
		return errors.New("文件类型不能为空")
	case f.FilePath == "":
		return errors.New("文件路径不能为空")
	case f.InterviewUsername == "" || f.InterviewName == "":
		return errors.New("操作人信息不能为空")
	}

	// 文件为其他类型的,必须要填文件名称
	if f.FileType == OtherType && f.FileTypeName == "" {
		return errors.New("缺少其他文件类型的名称")
	}

	//　检查文件类型是否合法
	for i := range fileTypeAry {
		if fileTypeAry[i] == f.FileType {
			return nil
		}
	}
	return errors.New("文件类型错误")
}

/****************************/
// 房贷相关文件
//HouseFD = "house_fd"
// 月供带相关件
//HouseYGD = "house_ygd"
// 房产证复印件 弃用
//HouseDeed = "house_deed"
// 征信压缩 弃用
//CreditReportZip = "credit_report_zip"
// 视频 弃用
//Video = "video"
// 保单
//Policy = "policy"
