package model

import (
	"gcoresys/common/mysql"
	"errors"
)

// 放款银行卡信息
type LoanBank struct {
	mysql.BaseModel
	// 进件订单id
	OrderId string `json:"order_id"`
	// 开户银行
	BankName string `json:"bank_name"`
	// 放款银行卡
	BankNum string `json:"bank_num"`
	// 预留手机号
	Cellphone string `json:"cellphone"`
	// 开户地
	BankAddress string `json:"bank_address"`
	// 银行卡url
	BankUrl string `json:"bank_url"`
	// 面签人姓名
	InterviewName string `json:"interview_name"`
	// 面签人账号
	InterviewUsername string `json:"interview_username"`
	// 银行卡url
	FilesUrl []*InterviewFile `sql:"-" json:"files_url"`
}

func (l *LoanBank) IsValidLoanBank() error {
	switch {
	case l.OrderId == "":
		return errors.New("订单id不能为空")
	case l.BankName == "":
		return errors.New("银行不能为空")
	case l.BankNum == "":
		return errors.New("银行账号不能为空")
	case l.Cellphone == "":
		return errors.New("手机号不能为空")
	case l.BankAddress == "":
		return errors.New("银行地址不能为空")
	case l.InterviewUsername == "" || l.InterviewName == "":
		return errors.New("操作人信息不能为空")
	}
	return nil
}
