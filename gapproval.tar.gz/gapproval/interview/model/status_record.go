package model

import (
	"gcoresys/common/mysql"
	"errors"
	"gapproval/approval/model"
)

const InterviewHangUp = "面签挂起"

// 用于保存面签状态记录
type StatusRecord struct {
	mysql.BaseModel
	// 进件订单id
	OrderId string `json:"order_id"`
	// 面签状态
	Status string `json:"status"`
	// 流转账号
	ExchangeUser string `json:"exchange_user"`
	// 流转姓名
	ExchangeName string `json:"exchange_name"`
	// 面签打回数据
	RepulseData string `json:"repulse_data"`
	// 状态备注
	Remark string `gorm:"type:text" json:"remark"`
	// 是否提交 "1" | "0"
	IsSubmit string `json:"is_submit"`
	// 操作人账号
	InterviewUsername string `json:"interview_username"`
	// 操作人姓名
	InterviewName string `json:"interview_name"`
	// 流转密码
	Password string `sql:"-" json:"password"`
	// 所属用户组
	GroupId string `sql:"-" json:"group_id"`
}

// 提交面签资料时验证
func (s *StatusRecord) IsValidStatusRecord() error {
	switch {
	case s.OrderId == "":
		return errors.New("请告诉我order_id好么")
	case s.Status == "":
		return errors.New("请选择要执行的面签操作")
	case s.Remark == "":
		return errors.New("备注不能为空")
	case s.InterviewUsername == "" || s.InterviewName == "":
		return errors.New("操作人信息不能为空")
	}

	switch s.Status {
	case model.ApprovalStatusInterViewPass:
		switch {
		case s.ExchangeUser != "":
			return errors.New("面签通过,不需要传流转账号！！！")
		case s.ExchangeName != "":
			return errors.New("面签通过,不需要传流转姓名！！！")
		case s.RepulseData != "":
			return errors.New("面签通过,不需要传打回内容！！！")
		}

	case model.ApprovalStatusInterViewRepulse:
		switch {
		case len(s.RepulseData) < 3:
			return errors.New("请选择打回内容")
		case s.ExchangeUser != "":
			return errors.New("面签打回,不需要传流转账号！！！")
		case s.ExchangeName != "":
			return errors.New("面签打回,不需要传流转姓名！！！")
		}

	case model.ApprovalStatusInterViewExchange:
		switch {
		case s.ExchangeUser == "":
			return errors.New("请选择流转账号")
		case s.ExchangeName == "":
			return errors.New("请选择流转账号姓名")
		case s.RepulseData != "":
			return errors.New("面签流转,不需要传打回内容！！！")
		case s.ExchangeUser == s.InterviewUsername || s.ExchangeName == s.InterviewName:
			return errors.New("不可以流转给自己")
		}

	case InterviewHangUp:
		switch {
		case s.ExchangeUser != "":
			return errors.New("面签挂起,不需要传流转账号！！！")
		case s.ExchangeName != "":
			return errors.New("面签挂起,不需要传流转姓名！！！")
		case s.RepulseData != "":
			return errors.New("面签挂起,不需要传打回内容！！！")
		}

	case model.ApprovalStatusInterViewCancel:
		switch {
		case s.ExchangeUser != "":
			return errors.New("面签撤销,不需要传流转账号！！！")
		case s.ExchangeName != "":
			return errors.New("面签撤销,不需要传流转姓名！！！")
		case s.RepulseData != "":
			return errors.New("面签撤销,不需要传打回内容！！！")
		}

	default:
		return errors.New("你确定这个面签状态是存在的？？？")
	}
	return nil
}
