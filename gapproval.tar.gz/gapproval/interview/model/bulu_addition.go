package model

type BuluAdditionReq struct {
	JinjianId string                 `json:"jinjian_id"`
	ArType    string                 `json:"ar_type"`
	ArChannel string                 `json:"ar_channel"`
	Onoff     string                 `json:"onoff"`
	//AllInfo   map[string]interface{} `json:"all_info"`
}
