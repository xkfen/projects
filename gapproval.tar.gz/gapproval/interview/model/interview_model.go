package model

import (
	"errors"
	"gcoresys/common/util"
	"gapproval/common/httpReq"
	"gcoresys/common"
	"gcoresys/common/logger"
	"time"
)

// 面签信息
type Interview struct {
	/************** approval order  interview  json 对应的结构体 *******************/
	// 进件订单id
	JinjianId string `json:"jinjian_id"`
	// 资金方
	FundSide string `json:"fund_side"`
	// 产品id
	SchemeId string `json:"scheme_id"`
	// 资金方对应的产品配置信息
	ProductPlan string `json:"-"`
	// 是否标准件 '1','0'
	IsStandard string `json:"is_standard"`
	// 面签方式
	InterviewMode string `json:"interview_mode"`
	// 面签地点
	InterviewAddress string `json:"interview_address"`
	// 面签点评
	Comment string `json:"comment"`
	// 印象分
	Score string `json:"score"`
	// 备注
	Remark string `json:"remark"`
	// 视频地址
	VideoPath string `json:"video_path"`
	// 面签人姓名
	InterviewName string `json:"interview_name"`
	// 面签人账号
	InterviewUsername string `json:"interview_username"`
	// 进件方案
	JinjianPlan string `json:"jinjian_plan"`
	// 进件方案相关文件
	JinjianPlanFiles []*InterviewFile `json:"jinjian_plan_files"`
	// 进件方案提交时间戳
	JinjianPlanTime int64 `json:"jinjian_plan_time"`
	// 使用中
	ContractFile     []*InterviewFile `json:"contracts"`
	IdCardFile       []*InterviewFile `json:"idCards"`
	OtherFile        []*InterviewFile `json:"other"`
	CreditReportFile []*InterviewFile `json:"credit_report"`
	LoanBank         []LoanBank       `json:"loanBank"`

	// 临时保存旧的inter_view数据用
	OldInterview string `json:"-"`

	/***************************************************/
	// 弃用
	HouseDeeds      interface{} `json:"houseDeeds"`
	Sound           interface{} `json:"sound"`
	Policy          interface{} `json:"policy"`
	InsurancePolicy interface{} `json:"insurance_policy"`
	InterviewVideo  interface{} `json:"interview_video"`
	CreditReport    interface{} `json:"creditReport"`
	BaoDanPlan      interface{} `json:"bao_dan_plan"`
	FangChanPlan    interface{} `json:"fang_chan_plan"`
	YueGongPlan     interface{} `json:"yue_gong_plan"`
}

var FUNDSIDE = map[string]bool{
	"洋葱先生":  true,
	"粤财":    true,
	"个人":    true,
	"长乐农商行": true,
	"海金社":   true,
}

// 保存面签数据时 验证数据是否合法
func (i *Interview) IsValidSaveInterview() error {

	switch {
	case i.JinjianId == "":
		return errors.New("进件id不能为空")
	case i.FundSide != "" && FUNDSIDE[i.FundSide] != true:
		return errors.New("资金方错误,请检查")
	case i.FundSide != "" && i.SchemeId == "":
		return errors.New("修改资金方需要提交产品id, 请检查")
	case i.IsStandard != "" && i.IsStandard != "0" && i.IsStandard != "1":
		return errors.New("请现在是否标准件")
	case i.InterviewMode != "" && i.InterviewMode != "远程面签" && i.InterviewMode != "现场面签":
		return errors.New("请选择面签方式")
	case i.InterviewMode == "现场面签" && i.InterviewAddress == "":
		return errors.New("请选择面签地点")
	case i.InterviewMode == "远程面签" && i.VideoPath == "":
		return errors.New("请填写面签视频地址")
	case i.InterviewUsername == "" || i.InterviewName == "":
		return errors.New("操作人信息不能为空")
	}

	// 这里根据前端提交的资金方和产品id获取配置信息
	if i.FundSide != "" {
		if configInfo, err := GetProdmngConfigInfo(i.SchemeId, i.FundSide); err != nil {
			return err
		} else {
			// 这个不可以让前端传,会泄露密码
			i.ProductPlan = util.StringifyJson(configInfo)
		}
	}

	if i.JinjianPlan != "" {
		i.JinjianPlanTime = time.Now().Unix()
	}

	return nil
}

// 提交面签时 验证面签数据是否完整
func IsValidInterview(interview string) error {
	i := Interview{}
	switch {
	case util.ParseJson(interview, &i) != nil:
		return errors.New("interview JSON 解析错误, 请检查")
	case i.JinjianId == "":
		return errors.New("进件id不能为空")
	case FUNDSIDE[i.FundSide] != true:
		return errors.New("资金方错误,请检查")
	case i.IsStandard != "0" && i.IsStandard != "1":
		return errors.New("请现在是否标准件")
	case i.InterviewMode != "远程面签" && i.InterviewMode != "现场面签":
		return errors.New("请选择面签方式")
	case i.InterviewMode == "现场面签" && i.InterviewAddress == "":
		return errors.New("请选择面签地点")
	case i.Comment == "":
		return errors.New("请填写面签点评")
	case i.Score == "":
		return errors.New("请填写面签印象分")
	case i.InterviewMode == "远程面签" && i.VideoPath == "":
		return errors.New("请填写面签视频地址")
	case i.JinjianPlan == "" || i.JinjianPlan == "[]" || i.JinjianPlan == "{}":
		return errors.New("进件方案不能为空")
	case len(i.JinjianPlanFiles) <= 0:
		return errors.New("进件方案相关文件不能为空")
	case i.JinjianPlanTime == 0:
		return errors.New("缺少进件方案时间戳")
	case len(i.IdCardFile) != 3:
		return errors.New("缺少身份证照片,请检查")
	case len(i.CreditReportFile) <= 0:
		return errors.New("缺少征信报告,请检测")
	case i.InterviewUsername == "" || i.InterviewName == "":
		return errors.New("操作人信息不能为空")
	}
	if i.FundSide == "洋葱先生" || i.FundSide == "海金社" {
		logger.Info("正在提交面签资料", "fund side", i.FundSide, "loan bank", i.LoanBank)
		if len(i.LoanBank) != 1 || len(i.LoanBank[0].FilesUrl) != 1 || i.LoanBank[0].BankUrl == "" ||
			i.LoanBank[0].BankNum == "" || i.LoanBank[0].BankName == "" {
			return errors.New("缺少放款银行卡信息")
		}
	}
	return nil
}

// 获取从产品配置信息
func GetProdmngConfigInfo(schemeId, fundSide string) (configInfo map[string]interface{}, err error) {
	if common.GetUseDocker() == 0 { //这里是测试
		return map[string]interface{}{"fund_side": `["洋葱先生"]`}, nil
	}

	result, err := httpReq.GetProxy(common.GetGprodmngHost() + "/api/v1/scheme/" + schemeId + "?fund_side=" + fundSide)
	if err != nil {
		logger.Error("错误：" + err.Error())
		return
	}

	if data, ok := result["success"].(bool); ok && data {
		return util.GetJsonFromJson(result, "data"), nil
	} else {
		logger.Error("gsso返回false", "info", result["info"])
		err = errors.New("产品系统返回错误:" + util.GetStrFromJson(result, "info"))
		return
	}
}
