#!/usr/bin/env bash

ginterview --env=$QY_ENV --docker_env=$QY_DOCKER_ENV