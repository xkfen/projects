package service

import (
	"gapproval/interview/model"
	"github.com/stretchr/testify/suite"
	"gapproval/approval/db/config"
	"testing"
	"gcoresys/common/logger"
	approvalModel "gapproval/approval/model"
	"github.com/stretchr/testify/assert"
)

type testingSuite struct {
	suite.Suite
}

func (suite *testingSuite) SetupTest() {
	config.ClearAllData()
}

func (suite *testingSuite) TearDownTest() {
	config.ClearAllData()
}

func TestRunInterviewService(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(true)
	suite.Run(t, new(testingSuite))
}

// 测试创建面签文件
func (suite *testingSuite) TestCreateFile() {
	// 创建审批订单
	ao := approvalModel.GetDefaultApprovalOrder()
	ao.InterViewTrailId = "test"
	ao.InterViewStatus = approvalModel.ApprovalStatusInterViewing
	// 使用这个方式创建审批订单会自动将订单面签状态修改为ApprovalStatusWaitInterView，不满足创建面签文件的面签状态要求
	//err := serviceV1.NewApprovalOrder(ao)
	//suite.Equal(nil, err)
	err := config.GetDb().Model(&approvalModel.ApprovalOrder{}).Create(ao).Error
	suite.Equal(nil, err)

	file := model.GetTestInterviewFile()
	file.OrderId = ao.JinjianId
	file.InterviewUsername = "test"
	err = CreateInterviewFile(&file)
	suite.Equal(nil, err)

}

// 测试删除面签文件
func (suite *testingSuite) TestDeleteFile() {
	// 创建审批订单
	ao := approvalModel.GetDefaultApprovalOrder()
	ao.InterViewTrailId = "test"
	ao.InterViewStatus = approvalModel.ApprovalStatusInterViewing
	err := config.GetDb().Model(&approvalModel.ApprovalOrder{}).Create(ao).Error
	suite.Equal(nil, err)
	// 创建面签文件
	file := model.GetTestInterviewFile()
	file.OrderId = ao.JinjianId
	file.InterviewUsername = "test"
	err = CreateInterviewFile(&file)
	suite.Equal(nil, err)
	// 删除面签文件
	err = DeleteInterviewFile(file.ID, file.OrderId)
	suite.Equal(nil, err)
}

// 测试同步放款银行卡照片到审批和LoanBank model
func (suite *testingSuite) TestRunSyncLoanBankFile() {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	// 创建审批订单
	ao := approvalModel.GetDefaultApprovalOrder()
	ao.InterViewTrailId = "test"
	ao.InterViewStatus = approvalModel.ApprovalStatusInterViewing
	err := config.GetDb().Model(&approvalModel.ApprovalOrder{}).Create(ao).Error
	suite.Equal(nil, err)

	bank := model.GetTestLoanBank()
	bank.OrderId = "J20170616007"
	// 创建/更新放款新行卡信息
	err = CreateOrUpdateLoanBank(bank)
	suite.Equal(nil, err)
}

// 测试删除面签文件
func TestRunDeleteInterviewFile(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	config.ClearAllData()
	// 创建审批订单
	order := approvalModel.GetDefaultApprovalOrder()
	order.JinjianId = "1234"
	order.InterViewStatus = approvalModel.ApprovalStatusInterViewing
	order.InterViewTrailId = "test"
	cerr := config.GetDb().Model(&approvalModel.ApprovalOrder{}).Create(order).Error
	assert.Equal(t, nil, cerr)

	// 创建面签文件
	file := model.GetTestInterviewFile()
	file.OrderId = "1234"
	err := config.GetDb().Model(&model.InterviewFile{}).Create(&file).Error
	assert.Equal(t, nil, err)

	deleteErr := DeleteInterviewFile(file.ID, file.OrderId)
	assert.Equal(t, nil, deleteErr)
}

// 测试校验审批订单状态
func TestRunValidApprovalOrderStatus(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	config.ClearAllData()

	// 创建审批订单
	order := approvalModel.GetDefaultApprovalOrder()
	order.JinjianId = "1234"
	order.InterViewStatus = approvalModel.ApprovalStatusInterViewing
	order.InterViewTrailId = "test"
	err := config.GetDb().Model(&approvalModel.ApprovalOrder{}).Create(order).Error
	assert.NoError(t, nil, err)

	_, err = validApprovalOrderStatus("1234", "test")
	assert.NoError(t, nil, err)

}
