package service

import (
	"gapproval/interview/model"
	approvalModel "gapproval/approval/model"
	"gapproval/approval/serviceV1"
	"fmt"
	"gcoresys/common/util"
	"strings"
	"gcoresys/common/logger"
)

// 全流程测试添加放款银行卡
func (suite *testingSuite) TestRunCreateOrUpdateLoanBank() {

	// 在创建订单
	order := approvalModel.GetTestApprovalOrderByInterview()
	err := serviceV1.NewApprovalOrder(order)
	suite.Equal(nil, err)
	suite.Equal(approvalModel.ApprovalStatusWaitInterView, order.InterViewStatus)

	// 查询订单池
	reqList := model.GetInterviewListReq()
	reqList.TypeKey = "all"
	list, t, c, err := serviceV1.GetNeedInterviewApprovalList(reqList)
	suite.Equal(nil, err)
	suite.Equal(1, t)
	suite.Equal(1, c)
	suite.Equal(1, len(list))

	// 面签账号信息
	username := "test"
	name := "测试"

	// 面签抢单
	err = serviceV1.GrabInterview(order.JinjianId, username, name)
	suite.Equal(nil, err)

	// 我的面签列表
	reqList.TypeKey = "me"
	list, t, c, err = serviceV1.GetNeedInterviewApprovalList(reqList)
	suite.Equal(nil, err)
	suite.Equal(1, t)
	suite.Equal(1, c)
	suite.Equal(1, len(list))

	// 查询面签详情 面签状态为面签中
	ao, err := serviceV1.GetApprovalOrderInfoByJinjianId(order.JinjianId, username)
	suite.Equal(nil, err)
	suite.Equal(approvalModel.ApprovalStatusInterViewing, ao.InterViewStatus)

	// ======== 开始面签 ========
	// 修改用户进件信息
	orderInfoReq := model.GetOrderInfoReqParams()
	orderInfoReq.Info = "all_info"
	orderInfoReq.OrderId = ao.JinjianId
	err = serviceV1.UpdateJinjianOrderInfo(orderInfoReq, ao)
	suite.Equal(nil, err)
	// 验证进件信息是否修改成功
	ao2, err := serviceV1.GetApprovalOrderInfoByJinjianId(ao.JinjianId, username)
	suite.Equal(nil, err)
	suite.NotEqual(ao.AllInfo, ao2.AllInfo)
	suite.Equal(true, strings.Contains(ao2.AllInfo, orderInfoReq.Value.(string)))

	// 添加联系人信息
	cp := model.GetContactsReqParams()
	err = serviceV1.AddContactsInfo(cp, -1, ao.JinjianId, username)
	suite.Equal(nil, err)
	// 验证添加联系人是否成功
	ao3, err := serviceV1.GetApprovalOrderInfoByJinjianId(ao.JinjianId, username)
	suite.Equal(nil, err)
	suite.NotEqual(ao.ApprovalAddContacts, ao3.ApprovalAddContacts)

	var conAry []model.ContactsReqParams
	err = util.ParseJson(ao3.ApprovalAddContacts, &conAry)
	suite.Equal(nil, err)
	suite.Equal(cp, conAry)

	// 添加或修改面签相关信息
	interview := model.GetTestInterview()
	interview.JinjianId = ao.JinjianId
	interview.FundSide = "洋葱先生"
	interview.SchemeId = "qy_001"
	err = serviceV1.UpdateApprovalInterviewInfo(interview)
	suite.Equal(nil, err)
	// 验证是否成功
	ao4, err := serviceV1.GetApprovalOrderInfoByJinjianId(ao.JinjianId, username)
	suite.Equal(nil, err)
	suite.Equal(true, strings.Contains(ao4.InterView, interview.FundSide))
	suite.Equal(interview.FundSide, ao4.FundSide)
	logger.Debug("interview", "inter_view", ao4.InterView)

	// 添加放款银行卡
	lb := model.GetTestLoanBank()
	lb.InterviewUsername = username
	lb.InterviewName = name
	lb.OrderId = ao.JinjianId
	err = CreateOrUpdateLoanBank(lb)
	suite.Equal(nil, err)

	// 验证添加放款银行卡是否成功
	ao5, err := serviceV1.GetApprovalOrderInfoByJinjianId(ao.JinjianId, username)
	suite.Equal(nil, err)
	err = util.ParseJson(ao5.InterView, &interview)
	suite.Equal(1, len(interview.LoanBank))
	if len(interview.LoanBank)>0{
		suite.Equal(lb.BankNum, interview.LoanBank[0].BankNum)
		suite.Equal(len(lb.FilesUrl), len(interview.LoanBank[0].FilesUrl))
	}

}

func doSomething(a string, b string) (func(c string) func() string) {

	return func(c string) (func() string) {
		fmt.Println(a)
		fmt.Println(b)
		return func() string {
			return ""
		}
	}

}
