package service

import (
	"gapproval/interview/model"
	"gcoresys/common/logger"
	"gapproval/approval/db/config"
	"testing"
	"github.com/stretchr/testify/assert"
	"gcoresys/common/util"
	approvalModel "gapproval/approval/model"
	"gapproval/approval/serviceV1"
	"time"
)

// 测试创建/更新面签状态记录
func TestRunCreateStatusRecord(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	// 创建审批订单
	order := approvalModel.GetDefaultApprovalOrder()
	order.InterViewTrailId = "test"
	order.InterViewStatus = approvalModel.ApprovalStatusInterViewing
	err := config.GetDb().Model(&approvalModel.ApprovalOrder{}).Create(order).Error
	assert.Equal(t, nil, err)
	// 创建面签记录
	s := model.GetTestStatusRecord()
	s.OrderId = "J20170616007"
	s.InterviewUsername = "test"
	s.IsSubmit = "0"
	assert.NoError(t, nil, SaveStatusRecord(&s))
	config.ClearAllData()
}

// 测试查询未提交的面签状态记录
func TestRunGetNoSubmitStatusRecord(t *testing.T) {
	//  初始化数据库连接
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(false)
	// 创建审批订单
	order := approvalModel.GetDefaultApprovalOrder()
	order.InterViewTrailId = "test"
	order.InterViewStatus = approvalModel.ApprovalStatusInterViewing
	err := config.GetDb().Model(&approvalModel.ApprovalOrder{}).Create(order).Error
	assert.Equal(t, nil, err)
	// 创建面签记录
	record := model.GetTestStatusRecord()
	record.OrderId = "J20170616007"
	record.IsSubmit = "0"
	record.InterviewUsername = "test"
	assert.NoError(t, nil, SaveStatusRecord(&record))

	if recordPo, err := GetNoSubmitStatusRecord(record.OrderId, record.InterviewUsername); err != nil {
		panic(err.Error())
	} else {
		assert.NotEqual(t, nil, recordPo)
		logger.Info("面签状态信息" + util.StringifyJson(recordPo))
	}
	//  测试环境，清空记录
	config.ClearAllData()

}

// 测试查询订单所有面签状态记录
func TestRunFindStatusRecordList(t *testing.T) {

	//  初始化数据库连接
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(true)
	config.ClearAllData()

	// 面签账号信息
	username := "test"
	name := "测试"

	// 在创建订单
	order := approvalModel.GetTestApprovalOrderByInterview()
	order.JinjianId = "测试123"
	err := serviceV1.NewApprovalOrder(order)
	assert.NoError(t, err)
	//suite.Equal(approvalModel.ApprovalStatusWaitInterView, order.InterViewStatus)

	// 面签抢单
	err = serviceV1.GrabInterview(order.JinjianId, username, name)
	//suite.Equal(nil, err)

	// 面签流转
	err = serviceV1.InterViewExchange(order.JinjianId, name, username, name, "流转给自己", false)
	//suite.Equal(nil, err)

	time.Sleep(300 * time.Millisecond)

	list, err := serviceV1.GetInterviewStatusRecord(order.JinjianId)
	assert.Equal(t, 2, len(list))

}
