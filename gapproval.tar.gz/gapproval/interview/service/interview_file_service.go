package service

import (
	"errors"
	"gcoresys/common/logger"
	"gapproval/interview/model"
	"strings"
	"gapproval/approval/db/config"
	"github.com/jinzhu/gorm"
	"gapproval/approval/serviceV1"
	approvalModel "gapproval/approval/model"
)

// 创建文件 file
// 检查身份证图片和放款银行卡照片唯一
// 返回类型为 fileType 的所有文件
func CreateInterviewFile(file *model.InterviewFile) (err error) {
	logger.Info("###收到创建面签文件请求####---CreateInterviewFile", "file jinjian id", file.OrderId)
	if err = file.IsValidInterviewFile(); err != nil {
		return
	}

	oldInterview, err := validApprovalOrderStatus(file.OrderId, file.InterviewUsername)
	if err != nil {
		logger.Error("创建文件时,验证出错", "进件ID", file.OrderId, "username", file.InterviewUsername)
		return
	}

	var files []*model.InterviewFile
	if strings.Contains(file.FileType, model.IDCARD) || file.FileType == model.LoanBankCard {
		err = config.GetDb().Model(model.InterviewFile{}).Where(&model.InterviewFile{OrderId: file.OrderId, FileType: file.FileType}).Find(&files).Error
		if err != nil || len(files) > 0 {
			return errors.New("已存在类型为" + file.FileType + ", 请勿重复上传")
		}
	}
	if err = config.GetDb().Model(model.InterviewFile{}).Create(&file).Error; err != nil {
		logger.Error("创建面签文件失败", "info", err.Error())
		return errors.New("创建面签文件失败,请稍后再试")
	}

	logger.Debug("=========file=======", "文件", file)
	if strings.Contains(file.FileType, model.IDCARD) {
		file.FileType = model.IDCARD
	}

	if strings.Contains(file.FileType, model.PLAN) {
		file.FileType = model.PLAN
	}

	err = config.GetDb().Model(&model.InterviewFile{}).Where("order_id = ? and file_type like ?", file.OrderId, "%"+file.FileType+"%").Find(&files).Error
	if err != nil || len(files) <= 0 {
		logger.Error("查询文件类型", "err", err, "len", len(files))
		return errors.New("查询文件类型" + file.FileType + "错误,请稍后再试")
	}

	logger.Debug("正在同步文件数据到 approval order interview JSON")
	//logger.Warn("*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=* \n 记得删除！","files", files)
	if err = SyncInterviewFile(files, oldInterview, file.OrderId, file.FileType, false); err != nil {
		logger.Error("同步文件或图片错误", "info", err.Error())
		return err
	}
	return
}

// 删除 id orderId 的文件
// 返回类型为 fileType 的所有文件
func DeleteInterviewFile(id uint, orderId string) (err error) {

	var tmpFile model.InterviewFile
	if err = config.GetDb().Where("id = ? and order_id = ?", id, orderId).First(&tmpFile).Error; err != nil {
		logger.Error("查询面签文件失败", "info", err.Error())
		return errors.New("查询面签文件失败,请稍后再试")
	}

	oldInterview, err := validApprovalOrderStatus(tmpFile.OrderId, tmpFile.InterviewUsername)
	if err != nil {
		return err
	}

	if strings.Contains(tmpFile.FileType, model.IDCARD) {
		tmpFile.FileType = model.IDCARD
	}

	if strings.Contains(tmpFile.FileType, model.PLAN) {
		tmpFile.FileType = model.PLAN
	}

	if err = config.GetDb().Where("id = ? and order_id = ?", id, orderId).Delete(&model.InterviewFile{}).Error; err != nil {
		logger.Error("删除面签文件失败", "info", err.Error())
		return errors.New("删除面签文件失败,请稍后再试")
	}

	var files []*model.InterviewFile

	if err := config.GetDb().Model(&model.InterviewFile{}).Where("order_id = ? and file_type like ?", orderId, "%"+tmpFile.FileType+"%").Find(&files).Error;
		err != nil && err != gorm.ErrRecordNotFound {
		return errors.New("查询文件类型" + tmpFile.FileType + "错误,请稍后再试")
	}

	if err = SyncInterviewFile(files, oldInterview, orderId, tmpFile.FileType, true); err != nil {
		logger.Error("同步放款银行卡照片错误", "info", err.Error())
		return err
	}
	return
}

// 同步文件到approval order
func SyncInterviewFile(files []*model.InterviewFile, oldInterview, jinjianId, fileType string, isDelete bool) (err error) {

	if isDelete && (files == nil || len(files) == 0) {
		//方案一-------------添加一个空对象,使其长度不为0,于是同步的方法可以更新------------
		//files = []*model.InterviewFile{{}}
		//方案二-------------加一个IsEmpty字段,同步时判断,为true时,置空------------------
		files = []*model.InterviewFile{{IsEmpty: true}}
	}

	interview := model.Interview{JinjianId: jinjianId, OldInterview: oldInterview}
	switch fileType {
	case model.LoanBankCard: //放款银行卡图片
		loanBank := model.LoanBank{}
		err := config.GetDb().Model(&model.LoanBank{}).Where("order_id = ?", jinjianId).First(&loanBank).Error
		if err != nil && err != gorm.ErrRecordNotFound {
			return errors.New("查询放款银行卡错误" + err.Error())
		}
		if err == gorm.ErrRecordNotFound {
			logger.Warn("未查询到放款银行卡信息", "order_id", jinjianId)
		}
		loanBank.FilesUrl = files
		if isDelete {
			loanBank.FilesUrl = nil
		}
		interview.LoanBank = []model.LoanBank{loanBank}

	case model.CreditReport: //征信报告相关文件
		interview.CreditReportFile = files

	case model.Contract:
		interview.ContractFile = files

	case model.IDCARD:
		interview.IdCardFile = files

	case model.OtherType:
		interview.OtherFile = files

	case model.PLAN:
		interview.JinjianPlanFiles = files

	default:
		return nil
	}

	//同步到审批端数据库
	if err = serviceV1.UpdateApprovalInterview(interview); err != nil {
		logger.Error("同步文件到数据库失败", "err", err.Error())
		return
	}
	return nil
}

// 验证当前操作订单状态（修改资料时的验证）
func validApprovalOrderStatus(orderId, username string) (string, error) {
	ao, err := serviceV1.GetApprovalOrderInfoByJinjianId(orderId, username)
	if err != nil {
		logger.Error("根据 jinjian_id 和 inter_view_trail_id 获取面签单信息  出错!!!!!", "进件ID", orderId, "Username", username)
		return "", err
	}

	if ao.InterViewStatus != approvalModel.ApprovalStatusInterViewing && ao.InterViewStatus != approvalModel.ApprovalStatusInterViewExchange &&
		ao.InterViewStatus != approvalModel.ApprovalStatusFirstTrailBackIv && ao.InterViewStatus != approvalModel.ApprovalStatusReTrailBackIv {
		logger.Error("订单非编辑状态", "Status", ao.InterViewStatus)
		return "", errors.New("订单状态为" + ao.InterViewStatus + ",不可编辑")
	}

	return ao.InterView, nil
}
