package service

import (
	"errors"
	"gcoresys/common/logger"
	"gapproval/interview/model"
	"gapproval/approval/db/config"
	"github.com/jinzhu/gorm"
	"gapproval/approval/serviceV1"
	approvalModel "gapproval/approval/model"
)

// 临时保存状态记录
func SaveStatusRecord(record *model.StatusRecord) (err error) {
	if err = record.IsValidStatusRecord(); err != nil {
		return err
	}

	if _, err = validApprovalOrderStatus(record.OrderId, record.InterviewUsername); err != nil {
		return err
	}

	tmp := model.StatusRecord{}
	if err := config.GetDb().Model(&model.StatusRecord{}).Where(model.StatusRecord{OrderId: record.OrderId}).Last(&tmp).Error;
		err != nil && err != gorm.ErrRecordNotFound {
		logger.Error("查询面签记录失败", "info", err.Error())
		return errors.New("查询面签记录失败,请稍后再试")
	}

	if tmp.ID > 0 {
		if err = config.GetDb().Model(&model.StatusRecord{}).Where("id=?", tmp.ID).Update(record).Error; err != nil {
			logger.Error("更新面签记录失败", "info", err.Error())
			return errors.New("更新面签记录失败,请稍后再试")
		}
	} else {
		if err = config.GetDb().Model(&model.StatusRecord{}).Create(record).Error; err != nil {
			logger.Error("创建面签记录失败", "info", err.Error())
			return errors.New("创建面签记录失败,请稍后再试")
		}
	}

	return
}

func GetNoSubmitStatusRecord(orderId, username string) (status model.StatusRecord, err error) {
	if orderId == "" || username == "" {
		return status, errors.New("orderId 和 username 不能为空")
	}

	if err := config.GetDb().Model(&model.StatusRecord{}).Where(model.StatusRecord{OrderId: orderId, InterviewUsername: username, IsSubmit: "0"}).Last(&status).Error;
		err != nil && err != gorm.ErrRecordNotFound {
		logger.Warn("查询面签记录失败", "info", err.Error())
		return status, errors.New("查询面签记录失败,请稍后再试")
	}

	return
}

// 面签提交 最后保存面签状态
func SubmitInterviewInfoToApproval(record model.StatusRecord) (err error) {

	if err = record.IsValidStatusRecord(); err != nil {
		return err
	}

	switch record.Status {
	case approvalModel.ApprovalStatusInterViewPass: //面签通过
		if err = serviceV1.CommitInterView(record.OrderId, record.Remark); err != nil {
			return err
		}

	case approvalModel.ApprovalStatusInterViewRepulse: //面签打回
		if err = serviceV1.InterViewRepulse(record.OrderId, record.RepulseData, record.Remark); err != nil {
			return err
		}

	case approvalModel.ApprovalStatusInterViewCancel: //面签撤销
		if err = serviceV1.InterViewCancel(record.OrderId, record.Remark); err != nil {
			return err
		}

	case approvalModel.ApprovalStatusInterViewExchange: //面签流转
		if err = serviceV1.InterViewExchange(record.OrderId, record.InterviewName, record.ExchangeUser, record.ExchangeName, record.Remark, false); err != nil {
			return err
		}

	case model.InterviewHangUp: //面签挂起
		if err = serviceV1.InterViewSuspending(record.OrderId, record.Remark); err != nil {
			return err
		}

	default:
		return errors.New("提交错误,请选择提交状态")
	}

	return nil
}
