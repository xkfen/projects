package service

import (
	"errors"
	"gcoresys/common/logger"
	"gapproval/interview/model"
	"gapproval/approval/db/config"
	"github.com/jinzhu/gorm"
	"gapproval/approval/serviceV1"
)

//创建或更新LoanBank模型 , 并同步到审批端数据库
func CreateOrUpdateLoanBank(lb model.LoanBank) (err error) {
	if err = lb.IsValidLoanBank(); err != nil {
		return
	}

	oldInterview, err := validApprovalOrderStatus(lb.OrderId, lb.InterviewUsername)
	if err != nil {
		return
	}

	tmp := model.LoanBank{}
	if err := config.GetDb().Model(&model.LoanBank{}).Where(model.LoanBank{OrderId: lb.OrderId}).First(&tmp).Error; err != nil && err != gorm.ErrRecordNotFound {
		logger.Warn("查询还款银行卡失败", "err", err.Error())
		return errors.New("查询还款银行卡失败,请稍后再试")
	}

	if tmp.ID > 0 {
		if err = config.GetDb().Model(&model.LoanBank{}).Where("id=?", tmp.ID).Update(&lb).Error; err != nil {
			logger.Error("修改还款银行卡信息失败", "err", err.Error())
			return errors.New("修改还款银行卡信息失败,请稍后再试")
		}
	} else {
		if err = config.GetDb().Model(&model.LoanBank{}).Create(&lb).Error; err != nil {
			logger.Error("创建还款银行卡失败", "info", err.Error())
			return errors.New("创建还款银行卡失败,请稍后再试")
		}
	}

	// 查询放款银行卡图片
	err = config.GetDb().Model(&model.InterviewFile{}).Where(&model.InterviewFile{OrderId: lb.OrderId, FileType: model.LoanBankCard}).Find(&lb.FilesUrl).Error
	if err != nil {
		return errors.New("查询放款银行卡图片错误,请稍后再试")
	}

	// 审批系统前段获取图片地址是在bank_url中
	if len(lb.FilesUrl) > 0 {
		lb.BankUrl = lb.FilesUrl[0].FilePath
	}

	//同步到审批端数据库
	if err = serviceV1.UpdateApprovalInterview(model.Interview{JinjianId: lb.OrderId, LoanBank: []model.LoanBank{lb}, OldInterview: oldInterview}); err != nil {
		logger.Error("同步放款银行卡失败", "err", err.Error())
		return
	}
	return
}
