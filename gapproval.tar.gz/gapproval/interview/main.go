package main

import (
	"gcoresys/common/logger"
	"gapproval/interview/router"
	"gcoresys/common"
	"gopkg.in/gin-gonic/gin.v1"
	"gapproval/approval/db/config"
)

func main() {
	env := common.DefineRunTimeCommonFlag()
	// 初始化日志
	if common.GetUseDocker() != 0 {
		logger.InitLogger(logger.LvlDebug, "ginterview.log")
		gin.SetMode(gin.ReleaseMode)
	} else {
		logger.InitLogger(logger.LvlDebug, nil)
		gin.SetMode(gin.DebugMode)
	}
	// 初始化数据库
	config.GetApprovalDbConfig(env)
	// 启动服务
	router.StartHttpRouter()
}
