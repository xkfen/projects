package router

import (
	"gopkg.in/gin-gonic/gin.v1"
	"gcoresys/common/logger"
	"gsso/common/jwt"
	"gcoresys/common"
	"strings"
	"errors"
	"gapproval/common/httpReq"
	"goplogger/model"
)

func routerMiddlewareHandler(c *gin.Context) {
	logger.Info("========================================================================================")
	// 解析路由
	rd := getDescription(c.Request.Method, c.Request.URL.Path)

	token := c.Request.Header.Get("authorization")
	var name, username = "无", "无"
	var err error
	if token == "" || token == "null" || rd.Router == "" {
		if rd.IsNeedToken && common.GetUseDocker() != 0 {
			err = errors.New(rd.Description)
		}
	} else {
		username, name, err = jwt.DecodeJwtToken(token)
		if err == nil {
			err = ValidateAuth(token, "interview/mq")
		}
	}
	// 统一判断错误
	if err != nil {
		c.Abort() // 中止
		logger.Info("============ 403 ============", "err", err.Error())
		c.JSON(403, gin.H{"success": false, "info": err.Error()})
		return
	}

	// test 环境手动赋值
	if common.GetUseDocker() == 0 {
		c.Set("username", "test")
		c.Set("name", "测试")
	} else {
		c.Set("username", username)
		c.Set("name", name)
		SaveRequestLog(rd.Description, c) // 业务留痕
	}

	logger.Info("操作日志=====", "username", username, "name", name, "ip", c.ClientIP(), "动作", rd.Description)
	return
}

// 保存操作日志到日志系统
func SaveRequestLog(description string, c *gin.Context) {
	log := model.OperationLog{
		OperatorID:  c.MustGet("username").(string),
		Name:        c.MustGet("name").(string),
		IP:          c.ClientIP(),
		Router:      c.Request.URL.Path,
		Description: description,
	}
	host := "http://" + common.GoploggerMicroDns + ":" + common.GetAppConfig().HttpServerPort
	result, err := httpReq.PostJsonProxy(log, host+"/api/v1/operation_logs/create")
	if err != nil {
		logger.Error("请求保存日志失败", "err", err.Error())
	}
	if data, ok := result["success"].(bool); !ok || !data {
		logger.Error("请求保存日志失败", "info", result["info"])
	}
}

// 调用GSSO系统 检查权限
func ValidateAuth(token, route string) error {
	params := map[string]interface{}{
		"jwt_token": token,
		"req_route": route,
		"only_one":  "1",
	}
	result, err := httpReq.PostJsonProxy(params, common.GetGssoHost()+"/api/v1/valid_req")
	if err != nil {
		return err
	}
	if data, ok := result["success"].(bool); ok && data {
		return nil
	} else {
		logger.Error("gsso返回false", "info", result["info"])
		return errors.New(result["info"].(string))
	}
}

// Router 为空且 IsNeedToken 为 true 说明出现错误
func getDescription(Method, path string) routerDescription {
	pathArray := strings.Split(path, "/")
	if len(pathArray) < 4 {
		return routerDescription{Router: "", Description: "路由错误", IsNeedToken: true}
	}
	v := Method + "|" + pathArray[3]
	for _, a := range routerDescriptionAry {
		if a.Router == v {
			return a
		}
	}
	return routerDescription{Router: "", Description: "未配置路由,请检查", IsNeedToken: true}
}

type routerDescription struct {
	Router      string `json:"router"`
	Description string `json:"description"`
	IsNeedToken bool   `json:"is_need_token"`
}

var routerDescriptionAry = []routerDescription{
	{
		Router:      "POST|login",
		Description: "请求登录面签系统",
		IsNeedToken: false,
	},
	{
		Router:      "PUT|change_password",
		Description: "请求修改密码",
		IsNeedToken: true,
	},
	{
		Router:      "POST|banks",
		Description: "面签获取流水状态信息",
		IsNeedToken: true,
	},
	{
		Router:      "POST|uniform_interface",
		Description: "查询微粒贷数据",
		IsNeedToken: true,
	},
	{
		Router:      "POST|phones",
		Description: "面签获取运营商流水状态信息",
		IsNeedToken: true,
	},
	{
		Router:      "POST|approval",
		Description: "查询进件系统还款卡信息",
		IsNeedToken: true,
	},
	{
		Router:      "GET|interview",
		Description: "查询进件系统所有渠道公司",
		IsNeedToken: true,
	},
	{
		Router:      "GET|scheme",
		Description: "获取产品配置信息",
		IsNeedToken: true,
	},
	{
		Router:      "GET|interview_manager",
		Description: "获取面签经理列表",
		IsNeedToken: true,
	},
	{
		Router:      "POST|interview_list",
		Description: "查询面签列表",
		IsNeedToken: true,
	},
	{
		Router:      "GET|grab_interview",
		Description: "面签抢单",
		IsNeedToken: true,
	},
	{
		Router:      "GET|interview_info",
		Description: "查询单个面签详情",
		IsNeedToken: true,
	},
	{
		Router:      "PUT|order_info",
		Description: "修改进件信息",
		IsNeedToken: true,
	},
	{
		Router:      "POST|contacts",
		Description: "添加或更新联系人信息",
		IsNeedToken: true,
	},
	{
		Router:      "POST|loan_bank",
		Description: "添加或更新放款银行卡信息",
		IsNeedToken: true,
	},
	{
		Router:      "GET|status_list",
		Description: "查询面签状态列表",
		IsNeedToken: true,
	},
	{
		Router:      "GET|status",
		Description: "获取未提交的面签状态",
		IsNeedToken: true,
	},
	{
		Router:      "POST|interview_submit",
		Description: "提交面签状态",
		IsNeedToken: true,
	},
	{
		Router:      "PUT|interview",
		Description: "保存或修改面签相关信息",
		IsNeedToken: true,
	},
	{
		Router:      "POST|interview_exchange",
		Description: "面签流转",
		IsNeedToken: true,
	},
	{
		Router:      "POST|upload_file",
		Description: "上传面签材料",
		IsNeedToken: true,
	},
	{
		Router:      "POST|upload_files",
		Description: "上传多文件面签材料",
		IsNeedToken: true,
	},
	{
		Router:      "DELETE|file",
		Description: "删除面签材料",
		IsNeedToken: true,
	},
	{
		Router:      "PUT|bulu_addition",
		Description: "补录开关",
		IsNeedToken: true,
	},
	{
		Router:      "GET|pre_fund_side",
		Description: "查询预审批资金方",
		IsNeedToken: true,
	},
}
