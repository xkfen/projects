package router

import (
	"testing"
	"github.com/stretchr/testify/assert"
	"fmt"
)

func TestRunGetDescription(t *testing.T) {
	rd := getDescription("POST", "/api/v1/login")
	assert.Equal(t, false, rd.IsNeedToken)
	assert.Equal(t, "请求登录面签系统", rd.Description)
}

func TestRunGetDescription002(t *testing.T) {
	rd := getDescription("PUT", "/api/v1/change_password")
	assert.Equal(t, true, rd.IsNeedToken)
	assert.Equal(t, "请求修改密码", rd.Description)
}

func TestMiddlewareHandler(t *testing.T) {
	fmt.Println(len(routerDescriptionAry))
}