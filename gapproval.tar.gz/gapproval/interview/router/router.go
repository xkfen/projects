package router

import (
	"gopkg.in/gin-gonic/gin.v1"
	"gcoresys/common/logger"
	"gapproval/interview/handler"
	"gcoresys/common/gin_middleware"
	"gcoresys/common"
	"net"
)

func StartHttpRouter() {

	//获得路由实例
	r := gin.Default()
	//正式用
	v1 := r.Group("/api/v1")
	// 中间件
	v1.Use(routerMiddlewareHandler)
	v1.Use(gin_middleware.PrintReq())
	v1.Use(gin_middleware.PrintResp())
	// 路由配置
	{
		// 代理接口
		/**************************************************************************/
		// 获取所有渠道列表
		v1.GET("/interview/brokerCompany", handler.QiYuanProxy)
		// 获取还款银行卡信息（易宝）
		v1.POST("/approval/repayBank", handler.QiYuanProxy)
		// 主要银行卡
		v1.POST("/banks/query_main", handler.GriskcontrolProxy)
		// 补录银行卡
		v1.POST("/banks/query_second", handler.GriskcontrolProxy)
		// 运营商通话
		v1.POST("/phones/query", handler.GriskcontrolProxy)
		// 获取所有面签人员
		v1.GET("/interview_manager", handler.GssoInterviewManger)
		// 获取资金方列表
		v1.GET("/scheme/:scheme_id", handler.GetFundSideListProxy)
		// 获取采集微粒贷h5 url
		v1.POST("/uniform_interface/GetWechatLoanURL", handler.GriskcontrolProxy)
		// 查询微粒贷数据
		v1.POST("/uniform_interface/QueryWechatLoan", handler.GriskcontrolProxy)
		/**************************************************************************/

		// 登录
		v1.POST("/login", handler.AuthorizationHandler)

		// 修改密码
		v1.PUT("/change_password/:id", handler.ChangePasswordHandler)

		// 获取列表
		v1.POST("/interview_list", handler.GetInterviewListHandler)

		// 面签单个抢单
		v1.GET("/grab_interview/:jinjian_id", handler.GrabInterviewHandler)

		// 查询单个面签详情
		v1.GET("/interview_info/:jinjian_id", handler.GetInterviewInfoHandler)

		// 单个修改进件信息
		v1.PUT("/order_info", handler.UpdateJinjianOrderInfoHandler)

		// 添加或更新联系人
		v1.POST("/contacts/:order_id", handler.AddContactsInfoHandler)

		// 添加或更新放款银行卡信息
		v1.POST("/loan_bank", handler.CreateOrUpdateLoanBankHandler)

		// 获取未提交的面签状态
		v1.GET("/status/:order_id", handler.GetNoSubmitStatusRecordHandler)

		// 查询面签状态列表
		v1.GET("/status_list/:order_id", handler.GetStatusListHandler)

		// 保存或修改面签相关信息
		v1.PUT("/interview", handler.UpdateInterviewHandler)

		// 提交面签或保存临时保存状态
		v1.POST("/interview_submit", handler.SubmitInterviewHandler)

		// 面签流转(需要验证密码)
		v1.POST("/interview_exchange", handler.InterviewExchangeHandler)

		// 上传面签文件资料
		v1.POST("/upload_file", handler.UploadInterviewFileHandler)

		// 多文件上传
		v1.POST("/upload_files", handler.UploadInterviewFilesHandler)

		// 删除面签资料
		v1.DELETE("/file/:order_id/:id", handler.DeleteInterviewFileHandler)

		// 补录开关
		v1.PUT("/bulu_addition", handler.BuluAdditionHandler)

		// 查询预审批资金方
		v1.GET("/pre_fund_side/:order_id", handler.GetPreFundSideHandler)
	}
	// 文件资源
	r.Static("/uploads/", "./assets/uploads")
	port := common.GetHttpServerPort("18000")
	addrs, _ := net.InterfaceAddrs()
	logger.Info("服务启动完成", "port", port, "ip", addrs[1])
	r.Run(":" + port)
}
