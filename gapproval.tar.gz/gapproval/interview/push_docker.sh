#!/usr/bin/env bash

cd ./docker

./mk_image.sh 1 2
echo "开发 DOCKER 上传完成"
./mk_image.sh test 2
echo "测试 DOCKER 上传完成"
./mk_image.sh preprod 2
echo "预生产 DOCKER 上传完成"