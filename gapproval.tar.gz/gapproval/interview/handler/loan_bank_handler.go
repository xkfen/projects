package handler

import (
	"gopkg.in/gin-gonic/gin.v1"
	"gapproval/interview/model"
	"gapproval/interview/service"
	"gcoresys/common/util"
)

// 添加放款银行卡信息
func CreateOrUpdateLoanBankHandler(c *gin.Context) {
	var loanBank model.LoanBank
	if c.BindJSON(&loanBank) != nil {
		util.RenderGinErrorJson("参数解析错误,请检查参数类型", nil, c)
		return
	}

	loanBank.InterviewUsername = c.MustGet("username").(string)
	loanBank.InterviewName = c.MustGet("name").(string)

	if err := service.CreateOrUpdateLoanBank(loanBank); err != nil {
		util.RenderGinErrorJson(err.Error(), nil, c)
	}else{
		util.RenderGinSuccessJson("添加放款银行卡成功", nil, c)
	}
}


