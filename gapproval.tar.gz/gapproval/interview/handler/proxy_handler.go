package handler

import (
	"gopkg.in/gin-gonic/gin.v1"
	"gcoresys/common/util"
	"gapproval/common/global"
	"gapproval/interview/model"
)

// 获取还款卡信息
func QiYuanProxy(c *gin.Context) {
	normalProxy(c, global.GetNqyServerUrl()+c.Request.URL.Path)
}

// 风控系统
func GriskcontrolProxy(c *gin.Context) {
	normalProxy(c, global.GetRiskControlServerUrl()+c.Request.URL.Path)
}

// gsso 获取有面签权限的所有面签人员
func GssoInterviewManger(c *gin.Context) {
	normalProxy(c, global.GetGssoServerUrl()+"/api/v1/group_user?permissions=interview/mq")
}

// 总代理
func normalProxy(c *gin.Context, backUrl string) {
	if respB, err := util.ProxyReq(c.Request, backUrl); err != nil {
		util.RenderGinErrorJson("转发请求返回错误:"+err.Error(), nil, c)
	} else {
		var result map[string]interface{}
		util.ParseJsonFromBytes(respB, &result)
		c.JSON(200, result)
	}
}

// 获取产品配置信息中的资金方(这里屏蔽了不必要的信息！！！)
func GetFundSideListProxy(c *gin.Context) {
	schemeId := c.Params.ByName("scheme_id")
	fundSide := c.Query("fund_side")
	if schemeId == "" || fundSide == "" {
		util.RenderGinErrorJson("产品id和资金方不能为空", nil, c)
		return
	}
	if result, err := model.GetProdmngConfigInfo(schemeId, fundSide); err != nil {
		util.RenderGinErrorJson(err.Error(), nil, c)
	} else {
		util.RenderGinSuccessJson("查询成功", &gin.H{"data": result["fund_side"]}, c)
	}
}
