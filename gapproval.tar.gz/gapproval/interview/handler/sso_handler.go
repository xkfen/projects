package handler

import (
	"gopkg.in/gin-gonic/gin.v1"
	"gcoresys/common/util"
	"gapproval/common/httpReq"
	"gapproval/common/global"
	"gcoresys/common/logger"
)

// 权限认证登录
func AuthorizationHandler(c *gin.Context) {
	var user map[string]string
	if c.BindJSON(&user) != nil {
		util.RenderGinErrorJson("参数类型解析错误", nil, c)
		return
	}
	if user["username"] == "" || user["password"] == "" {
		util.RenderGinErrorJson("用户名或密码不能为空", nil, c)
		return
	}
	params := map[string]string{
		"username":      user["username"],
		"password":      user["password"],
		"client_id":     "interview",
		"response_type": "token",
		"scope":         "everything",
	}
	statusCode, respResult, err := httpReq.PostFormDataProxyNoCheck(params, global.GetGssoServerUrl()+"/api/v1/authorize")
	if err != nil {
		logger.Error("登录错误", "err", err.Error())
		util.RenderGinErrorJson("登录失败", nil, c)
	} else {
		c.Data(statusCode, "application/json", []byte(respResult))
	}
}

// 用户修改密码
func ChangePasswordHandler(c *gin.Context) {
	id := c.Params.ByName("id")
	var user map[string]string
	if c.BindJSON(&user) != nil || len(user) != 2 || id == "" {
		util.RenderGinErrorJson("参数类型解析错误, 或缺少参数", nil, c)
		return
	}
	if user["password"] == "" || user["new_password"] == "" {
		util.RenderGinErrorJson("请输入旧密码和新密码", nil, c)
		return
	}
	respResult, err := httpReq.PutFormDataProxy(user, global.GetGssoServerUrl()+"/api/v1/user/"+id)
	if err != nil {
		util.RenderGinErrorJson("修改失败 "+err.Error(), nil, c)
	}
	if respResult["success"].(bool) {
		util.RenderGinSuccessJson("修改成功", nil, c)
	} else {
		util.RenderGinErrorJson(respResult["info"].(string), nil, c)
	}
}
