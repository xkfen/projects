package handler

import (
	"gopkg.in/gin-gonic/gin.v1"
	"gapproval/interview/model"
	"gapproval/interview/service"
	"gcoresys/common/util"
	"gcoresys/common/logger"
	"gcoresys/common"
	"mime/multipart"
	"strconv"
	"os"
	"path"
	"io"
	"errors"
	"strings"
	"fmt"
	"time"
	"gapproval/common/tool"
)

func paramsToInterviewFile(c *gin.Context) (file model.InterviewFile) {
	file.FileType = c.PostForm("fileType")
	file.OrderId = c.PostForm("orderId")
	file.FileTypeName = c.PostForm("fileTypeName")
	file.InterviewUsername = c.MustGet("username").(string)
	file.InterviewName = c.MustGet("name").(string)
	return
}

// 上传文件, 并持久化, 最终会保存在approval_order表中的inter_view JSON中
func UploadInterviewFileHandler(c *gin.Context) {
	f := paramsToInterviewFile(c)
	file, err := c.FormFile("file")
	if err != nil {
		util.RenderGinErrorJson("获取文件错误:"+err.Error(), nil, c)
		return
	}

	if f.FilePath, err = checkFileSuffixAndGetNewFilePath(file.Filename, f.FileType, f.OrderId); err != nil {
		util.RenderGinErrorJson(err.Error(), nil, c)
		return
	}

	if err = saveUploadedFile(file, f.FilePath); err != nil {
		util.RenderGinErrorJson(err.Error(), nil, c)
		return
	}

	if err := service.CreateInterviewFile(&f); err != nil {
		util.RenderGinErrorJson(err.Error(), nil, c)
	} else {
		util.RenderGinSuccessJson("上传成功", &gin.H{"data": f}, c)
	}
}

// 删除文件, 但保留历史文件及信息
func DeleteInterviewFileHandler(c *gin.Context) {
	id, err := strconv.Atoi(c.Params.ByName("id"))
	orderId := c.Params.ByName("order_id")

	if err != nil || id <= 0 || orderId == "" {
		util.RenderGinErrorJson("未获取到 orderId 和 id, 请检查", nil, c)
		return
	}

	if err = service.DeleteInterviewFile(uint(id), orderId); err == nil {
		util.RenderGinSuccessJson("删除图片或文件成功", nil, c)
	} else {
		util.RenderGinErrorJson("文件删除失败", nil, c)
	}
}

// 上传多个文件
func UploadInterviewFilesHandler(c *gin.Context) {
	f := paramsToInterviewFile(c)

	form, err := c.MultipartForm()
	if err != nil {
		util.RenderGinErrorJson(err.Error(), nil, c)
		return
	}
	files := form.File["files"]
	logger.Info("多文件上传", "文件数量len", len(files))

	// 先判断提交的所有文件类型是否合法,在保存文件
	var interviewFileAry []model.InterviewFile
	for i, file := range files {
		filePath, err := checkFileSuffixAndGetNewFilePath(file.Filename, f.FileType, f.OrderId)
		if err != nil {
			util.RenderGinErrorJson(err.Error(), &gin.H{"data": interviewFileAry}, c)
			return
		}
		if err := saveUploadedFile(file, filePath); err != nil {
			util.RenderGinErrorJson("文件上传错误:"+err.Error(), &gin.H{"data": interviewFileAry}, c)
			return
		}
		f.FilePath = filePath
		interviewFileAry = append(interviewFileAry, f)
		if err := service.CreateInterviewFile(&interviewFileAry[i]); err != nil {
			util.RenderGinErrorJson(err.Error(), &gin.H{"data": interviewFileAry[:len(interviewFileAry)-1]}, c)
			return
		}
	}

	util.RenderGinSuccessJson("所有文件上传成功", &gin.H{"data": interviewFileAry}, c)
}

// 验证文件后缀是否合法并返回文件存放的路径
func checkFileSuffixAndGetNewFilePath(fileName, fileType, orderId string) (filePath string, err error) {
	// 解析文件名后缀,并生成新的唯一文件名
	_, name := path.Split(fileName)
	logger.Info("上传文件名称", "file name", fileName)
	hz := strings.Split(name, ".")
	newFilename := fmt.Sprintf("%v_%v", "file", time.Now().UnixNano())
	if len(hz) > 1 {
		newFilename += "." + hz[len(hz)-1]
	} else {
		return "", errors.New("无法识别文件类型,请检查")
	}

	// 根据orderId和fileType生成文件存放的路径,如果为测试环境则存放在当前目录下
	filePath = "/assets/uploads/" + orderId + "/"
	if fileType == model.CreditReport {
		filePath += model.CreditReport
	}
	if common.GetUseDocker() == 0 {
		filePath = "./"
	}
	// 判断该路径是否存在,如果不,则新建
	if !tool.PathExists(filePath) {
		os.MkdirAll(filePath, os.ModePerm)
	}

	// 如果文件类型为其他,则不判断文件后缀
	if fileType == model.OtherType {
		return path.Join(filePath, newFilename), nil
	}

	// 将文件后缀转化为小写字母再匹配
	suf := strings.ToLower(hz[len(hz)-1])
	if fileType == model.LoanBankCard || strings.Contains(fileType, model.IDCARD) {
		if suf != "jpg" && suf != "png" && suf != "jpeg" {
			return "", errors.New("图片文件格式不支持,请检查")
		}
	} else if fileType == model.SoundPlan {
		if suf != "mp3" && suf != "wav" {
			return "", errors.New("录音文件格式不支持,请检查")
		}
	} else {
		if suf != "jpg" && suf != "png" && suf != "jpeg" && suf != "pdf" {
			return "", errors.New("文件格式不支持,请检查")
		}
	}
	return path.Join(filePath, newFilename), nil
}

// SaveUploadedFile uploads the form file to specific dst.
func saveUploadedFile(file *multipart.FileHeader, dst string) error {
	src, err := file.Open()
	if err != nil {
		return err
	}
	defer src.Close()

	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer out.Close()

	io.Copy(out, src)
	return nil
}
