package handler

import (
	"gopkg.in/gin-gonic/gin.v1"
	"gapproval/interview/model"
	"gcoresys/common/util"
	"gapproval/approval/serviceV1"
	"gcoresys/common/logger"
	"gapproval/interview/service"
	"gapproval/common/httpReq"
	"fmt"
	"gcoresys/common"
	"gapproval/common/global"
)

// 保存面签信息到审批订单表中
func UpdateInterviewHandler(c *gin.Context) {
	var interview model.Interview
	if c.BindJSON(&interview) != nil {
		util.RenderGinErrorJson("参数解析错误, 请检查参数类型", nil, c)
		return
	}

	interview.InterviewUsername = c.MustGet("username").(string)
	interview.InterviewName = c.MustGet("name").(string)

	if err := serviceV1.UpdateApprovalInterviewInfo(interview); err != nil {
		logger.Info("更新失败", "err", err)
		util.RenderGinErrorJson(err.Error(), nil, c)
	} else {
		util.RenderGinSuccessJson("保存成功", nil, c)
	}
}

// 提交面签资料
func SubmitInterviewHandler(c *gin.Context) {
	var params model.StatusRecord
	if c.BindJSON(&params) != nil {
		util.RenderGinErrorJson("参数类型解析错误, 请检查", nil, c)
		return
	}

	if params.IsSubmit != "0" && params.IsSubmit != "1" {
		util.RenderGinErrorJson("请选择是提交还是保存", nil, c)
		return
	}

	params.InterviewUsername = c.MustGet("username").(string)
	params.InterviewName = c.MustGet("name").(string)

	if params.IsSubmit == "0" {
		if err := service.SaveStatusRecord(&params); err != nil {
			util.RenderGinErrorJson(err.Error(), nil, c)
		} else {
			util.RenderGinSuccessJson("保存成功", nil, c)
		}
	} else {
		if err := service.SubmitInterviewInfoToApproval(params); err != nil {
			util.RenderGinErrorJson(err.Error(), nil, c)
		} else {
			util.RenderGinSuccessJson("提交成功", nil, c)
		}
	}
}

// 面签流转(需要验证密码)
func InterviewExchangeHandler(c *gin.Context) {
	var params model.StatusRecord
	if c.BindJSON(&params) != nil {
		util.RenderGinErrorJson("参数类型解析错误, 请检查", nil, c)
		return
	}

	if !validGroupPassword(params.GroupId, params.Password) {
		util.RenderGinErrorJson("密码错误", nil, c)
		return
	}

	params.InterviewUsername = c.MustGet("username").(string)
	params.InterviewName = c.MustGet("name").(string)

	if err := serviceV1.InterViewExchange(params.OrderId, params.InterviewName, params.ExchangeUser, params.ExchangeName, params.Remark, true); err != nil {
		util.RenderGinErrorJson(err.Error(), nil, c)
	} else {
		util.RenderGinSuccessJson("流转成功", nil, c)
	}
}

// 验证组密码
func validGroupPassword(groupId, password string) bool {
	if common.GetUseDocker() == 0 {
		return true
	}

	if groupId == "" || password == "" {
		logger.Info("组id和密码不能为空")
		return false
	}

	url := "/api/v1/valid_password?id=" + groupId + "&password=" + password
	result, err := httpReq.GetProxy(global.GetGssoServerUrl() + url)
	if err != nil {
		logger.Error("请求验证组密码错误：" + err.Error())
		return false
	}

	data, ok := result["success"].(bool)
	return ok && data
}

// 进件补录开关
func BuluAdditionHandler(c *gin.Context){
	var bulu model.BuluAdditionReq
	if c.BindJSON(&bulu) != nil {
		util.RenderGinErrorJson("参数类型解析错误, 请检查", nil, c)
		return
	}

	if err := serviceV1.IvManageAdditionalRecord(bulu.JinjianId, bulu.ArType, bulu.ArChannel, bulu.Onoff, "", map[string]interface{}{}); err != nil{
		util.RenderGinErrorJson(err.Error(), nil, c)
	} else {
		util.RenderGinSuccessJson(fmt.Sprintf("'%s进件补录' %s成功", bulu.ArType, bulu.Onoff), nil, c)
	}
}