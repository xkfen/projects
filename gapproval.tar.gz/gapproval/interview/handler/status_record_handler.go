package handler

import (
	"gopkg.in/gin-gonic/gin.v1"
	"gcoresys/common/util"
	"gapproval/interview/service"
	"gapproval/approval/serviceV1"
)

// 获取未提交的面签状态信息
func GetNoSubmitStatusRecordHandler(c *gin.Context) {
	orderId := c.Param("order_id")
	username := c.MustGet("username").(string)

	if status, err := service.GetNoSubmitStatusRecord(orderId, username); err != nil {
		util.RenderGinErrorJson(err.Error(), nil, c)
	} else {
		util.RenderGinSuccessJson("获取成功", &gin.H{"data": status}, c)
	}
}

//查询面签状态列表
func GetStatusListHandler(c *gin.Context) {
	orderId := c.Param("order_id")

	statusList, err := serviceV1.GetInterviewStatusRecord(orderId)
	if err != nil {
		util.RenderGinErrorJson(err.Error(), nil, c)
	} else {
		util.RenderGinSuccessJson("查询面签状态列表成功", &gin.H{"data": statusList}, c)
	}
}
