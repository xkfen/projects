package handler

import (
	"gopkg.in/gin-gonic/gin.v1"
	"gapproval/approval/serviceV1"
	"gcoresys/common/util"
	"gapproval/interview/model"
	"strconv"
)

// 获取面签列表
// type_key -> all -> 订单池
// type_key -> me -> 我的订单
// type_key -> history -> 历史订单
// type_key -> query -> 面签查询
func GetInterviewListHandler(c *gin.Context) {
	var params model.InterviewListReqParams
	if c.BindJSON(&params) != nil {
		util.RenderGinErrorJson("参数类型解析错误, 请检查", nil, c)
		return
	}

	params.Username = c.MustGet("username").(string)
	params.Name = c.MustGet("name").(string)

	list, totalPages, totalCount, err := serviceV1.GetNeedInterviewApprovalList(params)
	if err != nil {
		util.RenderGinErrorJson(err.Error(), nil, c)
	} else {
		// 整理数据给到前端
		for i := range list {
			if x := params.Status; x != "" {
				list[i].InterViewStatus = x
			}
		}
		util.RenderGinSuccessJson("查询成功", &gin.H{"data": list, "totalCount": totalCount, "totalPages": totalPages}, c)
	}
}

// 面签抢单
func GrabInterviewHandler(c *gin.Context) {
	jinjianId := c.Param("jinjian_id")
	username := c.MustGet("username").(string)
	name := c.MustGet("name").(string)

	if err := serviceV1.GrabInterview(jinjianId, username, name); err != nil {
		util.RenderGinErrorJson(err.Error(), nil, c)
	} else {
		util.RenderGinSuccessJson("抢单成功", nil, c)
	}
}

// 查询单个面签详情
func GetInterviewInfoHandler(c *gin.Context) {
	jinjianId := c.Param("jinjian_id")
	username := c.MustGet("username").(string)

	if ao, err := serviceV1.GetApprovalOrderInfoByJinjianId(jinjianId, username); err != nil {
		util.RenderGinErrorJson(err.Error(), nil, c)
	} else { // 只给前端需要的数据出去
		aoToFront := serviceV1.GetApprovalOrderInfoToFront(ao)
		util.RenderGinSuccessJson("查询成功", &gin.H{"data": aoToFront}, c)
	}
}

// 更新 order_info 和 all_info json 中的单个字段
func UpdateJinjianOrderInfoHandler(c *gin.Context) {
	var req model.OrderInfoReqParams
	if err := c.BindJSON(&req); err != nil {
		util.RenderGinErrorJson("参数解析错误,请检查参数类型", nil, c)
		return
	}
	username := c.MustGet("username").(string)

	if ao, err := serviceV1.GetApprovalOrderInfoByJinjianId(req.OrderId, username); err != nil {
		util.RenderGinErrorJson(err.Error(), nil, c)
	} else {
		if err = serviceV1.UpdateJinjianOrderInfo(req, ao); err != nil {
			util.RenderGinErrorJson(err.Error(), nil, c)
		} else {
			util.RenderGinSuccessJson("修改成功", &gin.H{"data": req}, c)
		}
	}
}

// 添加或更新联系人信息
func AddContactsInfoHandler(c *gin.Context) {
	orderId := c.Params.ByName("order_id")
	// 需要修改数组的下标
	num, err := strconv.Atoi(c.Query("num"))
	username := c.MustGet("username").(string)

	var contacts []model.ContactsReqParams
	if c.BindJSON(&contacts) != nil || err != nil {
		util.RenderGinErrorJson("参数解析错误,请检查参数类型", nil, c)
		return
	}

	if err := serviceV1.AddContactsInfo(contacts, num, orderId, username); err != nil {
		if num != -1 {
			util.RenderGinErrorJson("联系人更新失败 "+err.Error(), nil, c)
		} else {
			util.RenderGinErrorJson("联系人添加失败 "+err.Error(), nil, c)
		}
	} else {
		if num != -1 {
			util.RenderGinSuccessJson("联系人更新成功", &gin.H{"data": contacts}, c)
		} else {
			util.RenderGinSuccessJson("联系人添加成功", &gin.H{"data": contacts}, c)
		}
	}
}

// 查询预审批资金方
func GetPreFundSideHandler(c *gin.Context) {
	orderId := c.Param("order_id")
	prefundSide, err := serviceV1.GetPreTrailFundSide(orderId)
	if err != nil {
		util.RenderGinErrorJson("查询预审资金方失败", nil, c)
		return
	}
	util.RenderGinSuccessJson("查询预审资金方成功", &gin.H{"data": prefundSide}, c)
}
