package test

import (
	"gapproval/interview/model"
	approvalModel "gapproval/approval/model"
	"gapproval/approval/serviceV1"
	"gapproval/interview/service"
)

// 测试保存面签进件方案
func (s *testingSuite) TestInterviewExchange() {

	// 在创建订单
	order := approvalModel.GetTestApprovalOrderByInterview()
	err := serviceV1.NewApprovalOrder(order)
	s.Equal(nil, err)
	s.Equal(approvalModel.ApprovalStatusWaitInterView, order.InterViewStatus)

	// 查询订单池
	reqList := model.GetInterviewListReq()
	reqList.TypeKey = "all"
	list, t, c, err := serviceV1.GetNeedInterviewApprovalList(reqList)
	s.Equal(nil, err)
	s.Equal(1, t)
	s.Equal(1, c)
	s.Equal(1, len(list))

	// 面签账号信息
	username := "test"
	name := "测试"

	// 面签抢单
	err = serviceV1.GrabInterview(order.JinjianId, username, name)
	s.Equal(nil, err)

	// 我的面签列表(test)
	reqList.TypeKey = "me"
	list, t, c, err = serviceV1.GetNeedInterviewApprovalList(reqList)
	s.Equal(nil, err)
	s.Equal(1, t)
	s.Equal(1, c)
	s.Equal(1, len(list))

	// 查询面签详情 面签状态为面签中
	ao, err := serviceV1.GetApprovalOrderInfoByJinjianId(order.JinjianId, username)
	s.Equal(nil, err)
	s.Equal(approvalModel.ApprovalStatusInterViewing, ao.InterViewStatus)

	// 执行面签流转
	sr := model.StatusRecord{
		OrderId:           ao.JinjianId,
		InterviewName:     name,
		InterviewUsername: username,
		ExchangeName:      "test00",
		ExchangeUser:      "test00",
		Status:            approvalModel.ApprovalStatusInterViewExchange,
		Remark:            "XXXXXX",
	}
	err = service.SubmitInterviewInfoToApproval(sr)
	s.Equal(nil, err)

	// 查询面签详情 面签状态应为面签流转
	ao2, err := serviceV1.GetApprovalOrderInfoByJinjianId(order.JinjianId, "test00")
	s.Equal(nil, err)
	s.Equal(approvalModel.ApprovalStatusInterViewExchange, ao2.InterViewStatus)

	// 我的面签列表(test00)
	reqList.TypeKey = "me"
	reqList.Username = "test00"
	reqList.Name = "test00"
	list, t, c, err = serviceV1.GetNeedInterviewApprovalList(reqList)
	s.Equal(nil, err)
	s.Equal(1, t)
	s.Equal(1, c)
	s.Equal(1, len(list))
}
