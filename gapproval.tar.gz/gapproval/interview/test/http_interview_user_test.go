package test

//import "gopkg.in/gavv/httpexpect.v1"
//
//func (s *testingSuite) TestLogin() {
//	resp := httpexpect.New(s.T(), baseURL).
//		POST("/authorize").
//		WithJSON(map[string]interface{}{
//		"username": "123",
//		"password": "123",
//	}).Expect()
//	resp.Status(200).JSON()
//
//	respStr := resp.Body().Raw()
//	s.NotEqual("", respStr)
//	s.respStr = respStr
//}
//
//func (s *testingSuite) TestChangePassword() {
//	resp := httpexpect.New(s.T(), baseURL).
//		PUT("/user/1").
//		WithJSON(map[string]interface{}{
//		"password_new": "123",
//		"password":     "123",
//	}).Expect()
//	resp.Status(200).JSON()
//
//	respStr := resp.Body().Raw()
//	s.NotEqual("", respStr)
//	s.respStr = respStr
//}
