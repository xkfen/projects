package test

import (
	"github.com/stretchr/testify/suite"
	"testing"
	"time"
	"gcoresys/common/logger"
	"gapproval/interview/router"
	"gcoresys/common/util"
	"gapproval/approval/db/config"
	"gapproval/interview/model"
	"github.com/gavv/httpexpect"
)

type testingSuite struct {
	suite.Suite
	respStr string
}

func (s *testingSuite) SetupTest() {
	s.respStr = "" //初始数据为空
	config.ClearAllData()
}

func (s *testingSuite) TearDownTest() {
	// 统一验证返回的数据
	if s.respStr != "" {
		var respJson RespJson
		err := util.ParseJson(s.respStr, &respJson)
		s.Equal(nil, err)
		s.Equal(true, respJson.Success)
	}
	config.ClearAllData()
}

func TestRunInterview(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)
	config.GetApprovalDbConfig("test")
	config.GetDb().LogMode(true)
	go router.StartHttpRouter()
	time.Sleep(200 * time.Millisecond)
	suite.Run(t, new(testingSuite))
}

const baseURL = "http://localhost:18000/api/v1"

type RespJson struct {
	Data    map[string]interface{} `json:"data"`
	Info    string                 `json:"info"`
	Success bool                   `json:"success"`
}

func (s *testingSuite) TestAddContactsInfoHandler() {
	ao, _ := startTest(s)
	ao.ApprovalAddContacts = ""
	s.NoError(config.GetDb().Model(&ao).Where("jinjian_id=?", ao.JinjianId).Update(&ao).Error)

	//添加联系人
	contacts := model.GetContactsReqParams()
	resp := httpexpect.New(s.T(), baseURL).
		POST("/contacts/" + ao.JinjianId).WithQueryString("num=-1").WithJSON(contacts).Expect()
	resp.Status(200).JSON()

	s.NoError(config.GetDb().Model(&ao).Where("jinjian_id=?", ao.JinjianId).First(&ao).Error)
	var respContacts []model.ContactsReqParams
	s.NoError(util.ParseJson(ao.ApprovalAddContacts, &respContacts))
	s.Equal(contacts[0], respContacts[len(respContacts)-1])
}

func (s *testingSuite) TestBuluAdditionHandler() {
	ao, _ := startTest(s)
	ao.ApprovalAddContacts = ""
	s.NoError(config.GetDb().Model(&ao).Where("jinjian_id=?", ao.JinjianId).Update(&ao).Error)

	bulu := model.GetTestBuluAdditionReq()
	resp := httpexpect.New(s.T(), baseURL).
		PUT("/bulu_addition").WithJSON(bulu).Expect()
	resp.Status(200).JSON()

	s.NoError(config.GetDb().Model(&ao).Where("jinjian_id=?", bulu.JinjianId).First(&ao).Error)
	s.Equal(true, ao.CallAdditionalRecord)
}