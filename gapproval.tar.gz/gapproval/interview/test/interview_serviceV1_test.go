package test

import (
	"gapproval/interview/model"
	"gapproval/approval/serviceV1"
	"gcoresys/common/util"
	"testing"
	s "github.com/stretchr/testify/assert"
	"gcoresys/common/logger"
	approvalModel "gapproval/approval/model"
)

func TestRUNGetNewInterviewString(t *testing.T) {
	logger.InitLogger(logger.LvlDebug, nil)

	interview := model.GetTestInterviewComplete()

	iv := model.Interview{
		JinjianId:   interview.JinjianId,
		JinjianPlan: "123123123123123",
	}

	newStr, err := serviceV1.GetNewInterviewString(iv, util.StringifyJson(interview))
	s.Equal(t, nil, err)

	var newInterview model.Interview
	err = util.ParseJson(newStr, &newInterview)
	s.Equal(t, nil, err)

	s.Equal(t, newInterview.JinjianPlan, iv.JinjianPlan)

	interview.JinjianPlan = iv.JinjianPlan
	s.Equal(t, interview, newInterview)
	s.Equal(t, interview.ProductPlan, newInterview.ProductPlan)

}

// 测试保存面签进件方案
func (s *testingSuite) TestUpdateApprovalInterviewInfo() {

	// 在创建订单
	order := approvalModel.GetTestApprovalOrderByInterview()
	err := serviceV1.NewApprovalOrder(order)
	s.Equal(nil, err)
	s.Equal(approvalModel.ApprovalStatusWaitInterView, order.InterViewStatus)

	// 查询订单池
	reqList := model.GetInterviewListReq()
	reqList.TypeKey = "all"
	list, t, c, err := serviceV1.GetNeedInterviewApprovalList(reqList)
	s.Equal(nil, err)
	s.Equal(1, t)
	s.Equal(1, c)
	s.Equal(1, len(list))

	// 面签账号信息
	username := "test"
	name := "测试"

	// 面签抢单
	err = serviceV1.GrabInterview(order.JinjianId, username, name)
	s.Equal(nil, err)

	// 我的面签列表(test)
	reqList.TypeKey = "me"
	list, t, c, err = serviceV1.GetNeedInterviewApprovalList(reqList)
	s.Equal(nil, err)
	s.Equal(1, t)
	s.Equal(1, c)
	s.Equal(1, len(list))

	// 查询面签详情 面签状态为面签中
	ao, err := serviceV1.GetApprovalOrderInfoByJinjianId(order.JinjianId, username)
	s.Equal(nil, err)
	s.Equal(approvalModel.ApprovalStatusInterViewing, ao.InterViewStatus)

	// 修改面签信息
	inter := model.GetTestInterview()
	inter.IsStandard = "1"
	inter.JinjianId = ao.JinjianId
	err = serviceV1.UpdateApprovalInterviewInfo(inter)
	s.Equal(nil, err)
	ao1, err := serviceV1.GetApprovalOrderInfoByJinjianId(order.JinjianId, username)
	s.Equal(nil, err)
	s.Equal(inter.IsStandard, ao1.IsStandard)
	s.NotEqual("", ao1.FundSide)
	s.NotEqual("", ao1.ProductPlan)
}
