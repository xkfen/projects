package test

import (
	"gapproval/interview/model"
	"gapproval/approval/serviceV1"
	"gapproval/interview/service"
	gapprovalModel "gapproval/approval/model"
	"strconv"
	"github.com/gavv/httpexpect"
	"gcoresys/common/util"
	"gapproval/approval/db/config"
	"os"
	"gcoresys/common/logger"
)

func startTest(s *testingSuite) (ao gapprovalModel.ApprovalOrder, iv model.Interview) {
	ao = *gapprovalModel.GetDefaultApprovalOrder()
	ao.JinjianId = "123"
	s.NoError(serviceV1.NewApprovalOrder(&ao))
	s.NoError(serviceV1.GrabInterview("123", "test", "test"))
	iv = model.GetTestInterviewIncomplete()
	iv.OldInterview = util.StringifyJson(iv)
	s.NoError(serviceV1.UpdateApprovalInterview(iv))
	s.NoError(config.GetDb().Model(&ao).Where("jinjian_id=?", "123").First(&ao).Error)
	return
}

func (s *testingSuite) TestUploadInterviewFile() {
	ao, _ := startTest(s)

	//上传放款银行卡照片
	resp := httpexpect.New(s.T(), baseURL).
		POST("/upload_file").WithMultipart().
		WithFile("file", "./test_file/logo.png").
		WithFormField("fileType", model.CreditReport).
		WithFormField("orderId", ao.JinjianId).Expect()
	resp.Status(200).JSON()
	respStr := resp.Body().Raw()

	var respJson RespJson
	err := util.ParseJson(respStr, &respJson)
	s.Equal(nil, err)
	s.Equal(true, respJson.Success)
	s.NotEqual(nil, respJson.Data["file"])
	s.NoError(os.Remove(respJson.Data["file"].(string)))

	//上传身份证照片
	resp = httpexpect.New(s.T(), baseURL).
		POST("/upload_file").WithMultipart().
		WithFile("file", "./test_file/golang.jpg").
		WithFormField("fileType", model.IdCardA).
		WithFormField("orderId", ao.JinjianId).Expect()
	resp.Status(200).JSON()
	respStr = resp.Body().Raw()

	err = util.ParseJson(respStr, &respJson)
	s.Equal(nil, err)
	s.Equal(true, respJson.Success)
	s.NotEqual(nil, respJson.Data["file"])
	s.NoError(os.Remove(respJson.Data["file"].(string)))
}

func (s *testingSuite) TestDeleteInterviewFile() {
	ao, _ := startTest(s)

	//测试删除银行卡图片
	file := model.GetTestInterviewFile()
	file.FileType = model.LoanBankCard
	s.NoError(service.CreateInterviewFile(&file))

	//s.NoError(service.DeleteInterviewFile(file.ID, file.OrderId))

	resp := httpexpect.New(s.T(), baseURL).
		DELETE("/file/" + file.OrderId + "/" + strconv.Itoa(int(file.ID))).Expect()
	resp.Status(200).JSON()

	respStr := resp.Body().Raw()
	var respJSON RespJson
	s.NoError(util.ParseJson(respStr, &respJSON))
	s.Equal("删除图片或文件成功", respJSON.Info)

	var dbao gapprovalModel.ApprovalOrder
	s.NoError(config.GetDb().Model(&dbao).Where("jinjian_id=?", ao.JinjianId).First(&dbao).Error)
	var dbiv model.Interview
	s.NoError(util.ParseJson(dbao.InterView, &dbiv))
	logger.Error("-----------", "123123", dbiv.LoanBank)
	s.NotEqual(0, len(dbiv.LoanBank))
	s.Equal(0, len(dbiv.LoanBank[0].FilesUrl))

	//测试删除其他文件
	otherFile := model.GetTestOtherFile()
	s.NoError(service.CreateInterviewFile(&otherFile))

	resp = httpexpect.New(s.T(), baseURL).
		DELETE("/file/" + otherFile.OrderId + "/" + strconv.Itoa(int(otherFile.ID))).Expect()
	resp.Status(200).JSON()

	respStr = resp.Body().Raw()
	s.NoError(util.ParseJson(respStr, &respJSON))
	s.Equal("删除图片或文件成功", respJSON.Info)

	s.NoError(config.GetDb().Model(&dbao).Where("jinjian_id=?", ao.JinjianId).First(&dbao).Error)
	s.NoError(util.ParseJson(dbao.InterView, &dbiv))
	s.Equal(0, len(dbiv.OtherFile))

	//测试删除身份证图片
	IdFile := model.GetTestOtherFile()
	s.NoError(service.CreateInterviewFile(&IdFile))

	resp = httpexpect.New(s.T(), baseURL).
		DELETE("/file/" + IdFile.OrderId + "/" + strconv.Itoa(int(IdFile.ID))).Expect()
	resp.Status(200).JSON()

	respStr = resp.Body().Raw()
	s.NoError(util.ParseJson(respStr, &respJSON))
	s.Equal("删除图片或文件成功", respJSON.Info)

	s.NoError(config.GetDb().Model(&dbao).Where("jinjian_id=?", ao.JinjianId).First(&dbao).Error)
	s.NoError(util.ParseJson(dbao.InterView, &dbiv))
	s.Equal(0, len(dbiv.IdCardFile))
}

// test 多文件上传
func (s *testingSuite) UploadInterviewFilesHandler() {
	_, iv := startTest(s)

	resp := httpexpect.New(s.T(), baseURL).
		POST("/upload_files").WithMultipart().
		WithFile("files", "./test_file/logo.png").
		WithFile("files", "./test_file/golang.jpg").
		WithFormField("fileType", model.CreditReport).
		WithFormField("orderId", iv.JinjianId).Expect()
	resp.Status(200).JSON()
	respStr := resp.Body().Raw()

	var respJson RespJson
	s.NoError(util.ParseJson(respStr, &respJson))
	s.Equal("所有文件上传成功", respJson.Info)

	data := respJson.Data
	for _, x := range data["files"].([]model.InterviewFile) {
		s.NoError(os.Remove(x.FilePath))
	}
}
