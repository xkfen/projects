package test

import (
	"gapproval/interview/model"
	approvalModel "gapproval/approval/model"
	"gapproval/approval/serviceV1"
	"gcoresys/common/util"
	"gcoresys/common/logger"
)

// 测试保存面签进件方案
func (s *testingSuite) TestRunInterviewJinjianPlan() {

	// 在创建订单
	order := approvalModel.GetTestApprovalOrderByInterview()
	err := serviceV1.NewApprovalOrder(order)
	s.Equal(nil, err)
	s.Equal(approvalModel.ApprovalStatusWaitInterView, order.InterViewStatus)

	// 查询订单池
	reqList := model.GetInterviewListReq()
	reqList.TypeKey = "all"
	list, t, c, err := serviceV1.GetNeedInterviewApprovalList(reqList)
	s.Equal(nil, err)
	s.Equal(1, t)
	s.Equal(1, c)
	s.Equal(1, len(list))

	// 面签账号信息
	username := "test"
	name := "测试"

	// 面签抢单
	err = serviceV1.GrabInterview(order.JinjianId, username, name)
	s.Equal(nil, err)

	// 我的面签列表
	reqList.TypeKey = "me"
	list, t, c, err = serviceV1.GetNeedInterviewApprovalList(reqList)
	s.Equal(nil, err)
	s.Equal(1, t)
	s.Equal(1, c)
	s.Equal(1, len(list))

	// 查询面签详情 面签状态为面签中
	ao, err := serviceV1.GetApprovalOrderInfoByJinjianId(order.JinjianId, username)
	s.Equal(nil, err)
	s.Equal(approvalModel.ApprovalStatusInterViewing, ao.InterViewStatus)

	// 添加进件方案
	plan := model.GetTestInterview()
	plan.JinjianId = ao.JinjianId
	plan.JinjianPlan = "[{a b c d}]"
	err = serviceV1.UpdateApprovalInterviewInfo(plan)

	// 验证是否成功
	ao4, err := serviceV1.GetApprovalOrderInfoByJinjianId(ao.JinjianId, username)
	s.Equal(nil, err)

	tmp := model.Interview{}
	err = util.ParseJson(ao4.InterView, &tmp)
	s.Equal(nil, err)
	s.NotZero(tmp.JinjianPlanTime)
	logger.Info("###################", "jinjian plan time", tmp.JinjianPlanTime)

	// 添加或修改面签相关信息
	interview := model.GetTestInterview()
	interview.JinjianId = ao.JinjianId
	interview.FundSide = "洋葱先生"
	interview.SchemeId = "qy_001"
	interview.InterviewMode = "现场面签"
	interview.InterviewAddress = "深圳"
	interview.IsStandard = "1"
	interview.Comment = "123"
	interview.Score = "123"
	interview.JinjianPlanTime = 0
	err = serviceV1.UpdateApprovalInterviewInfo(interview)
	s.Equal(nil, err)

	// 验证是否成功
	ao5, err := serviceV1.GetApprovalOrderInfoByJinjianId(ao.JinjianId, username)
	s.Equal(nil, err)

	err = util.ParseJson(ao5.InterView, &tmp)
	s.Equal(nil, err)
	s.NotZero(tmp.JinjianPlanTime)
	logger.Info("###################", "jinjian plan time", tmp.JinjianPlanTime)

	logger.Info("###################", "interview", ao5.InterView)

	//statusRecord := model.StatusRecord{
	//	OrderId:ao.JinjianId,
	//	Status:model.InterviewPass,
	//	Remark:"123123",
	//	InterviewUsername: "test",
	//	InterviewName:     "测试",
	//}
	//err = service.SubmitInterviewInfoToApproval(statusRecord)
	//s.Equal(nil, err)

}
