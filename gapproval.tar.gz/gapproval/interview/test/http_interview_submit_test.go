package test

import (
	"gapproval/approval/serviceV1"
	gapprovalModel "gapproval/approval/model"
	"gapproval/interview/model"
	"github.com/gavv/httpexpect"
	"gcoresys/common/util"
	"gapproval/approval/db/config"
	"gcoresys/common/logger"
)

func ValidateInterviewStatus(s *testingSuite, status string, ao *gapprovalModel.ApprovalOrder) {
	aotmp, err := serviceV1.GetApprovalOrderInfoByJinjianId(ao.JinjianId, "test")
	ao = &aotmp
	s.Equal(nil, err)
	s.Equal(status, ao.InterViewStatus)
}

func (s *testingSuite) TestSubmitInterviewHandler()  {
	ao := gapprovalModel.GetDefaultApprovalOrder()
	ao.JinjianId = "123"
	s.NoError(serviceV1.NewApprovalOrder(ao))
	//抢单
	s.NoError(serviceV1.GrabInterview("123","test", "test"))
	//判断状态
	ValidateInterviewStatus(s, gapprovalModel.ApprovalStatusInterViewing, ao)
	//添加完整interview信息
	iv := model.GetTestInterviewComplete()
	iv.OldInterview = util.StringifyJson(iv)
	s.NoError(serviceV1.UpdateApprovalInterview(iv))
	ValidateInterviewStatus(s, gapprovalModel.ApprovalStatusInterViewing, ao)

	sr := model.GetTestStatusRecord()
	sr.IsSubmit = "1"
	//sr.RepulseData = "why"
	//sr.Status = model.InterviewRepulse
	resp := httpexpect.New(s.T(), baseURL).POST("/interview_submit").WithJSON(sr).Expect()
	resp.Status(200).JSON()
	s.respStr = resp.Body().Raw()
	//判断状态
	ValidateInterviewStatus(s, gapprovalModel.ApprovalStatusInterViewPass, ao)
	//s.NoError(config.GetDb().Model(&gapprovalModel.ApprovalOrder{}).Where("jinjian_id=?", "123").Update("first_trail_status","待初审").Error)
	//s.NoError(config.GetDb().Model(&gapprovalModel.ApprovalOrder{}).Where("jinjian_id=?", "123").First(&ao).Error)
}

func (s *testingSuite) TestInterviewExchangeHandler() {
	ao, _ := startTest(s)
	ValidateInterviewStatus(s, gapprovalModel.ApprovalStatusInterViewing, &ao)
	sr := model.GetTestStatusRecord()
	resp := httpexpect.New(s.T(), baseURL).POST("/interview_exchange").WithJSON(sr).Expect()
	resp.Status(200).JSON()
	s.respStr = resp.Body().Raw()

	var log []gapprovalModel.ApprovalLog
	s.NoError(config.GetDb().Model(&log).Where("approval_jinjian_id=?", ao.JinjianId).Find(&log).Error)
	logger.Info("查看log", "log数量", len(log), "log", log)
}